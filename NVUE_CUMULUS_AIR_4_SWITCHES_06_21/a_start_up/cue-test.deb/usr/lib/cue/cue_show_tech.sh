#!/usr/bin/env sh

HOSTNAME="$(hostname)"
CURRENT_DIR="$(pwd)"
SCRATCH="$(mktemp -d)"
BUNDLE_NAME="cue_applied_$HOSTNAME.bundle"

chmod 700 $SCRATCH

# Create the git-bundle of the applied branch in the cued repo
cd /var/lib/cue/config
git bundle create "$SCRATCH/$BUNDLE_NAME" applied

# Get the cue package version installed via dpkg
cd $SCRATCH
dpkg -l python3-cue | grep cue | sed -E "s/.+python3-cue\\s+([0-9]+\.[0-9]+\.[0-9]+.+)\\sall.+/\\1/" > cue_version.txt

# Copy /etc/cue.d and /var/log/cued.log into the scratch dir
cp -R /etc/cue.d .
cp -R /var/log/cued.log .

# Create an archive of the git-bundle, cue_version.txt, /etc/cue.d, and /var/log/cued.log
tar -cf cue_show_tech.tar $BUNDLE_NAME cue_version.txt cue.d cued.log
chmod 666 cue_show_tech.tar

# Copy the show tech into the directory where script was run
cp cue_show_tech.tar $CURRENT_DIR

# Delete the temp dir
cd ~
rm -rf $SCRATCH
