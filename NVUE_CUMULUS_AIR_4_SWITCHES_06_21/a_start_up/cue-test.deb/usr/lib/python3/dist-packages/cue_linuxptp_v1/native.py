# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.

import os
import cue_linuxptp_v1.ptp4lconstants as ptp4lconst
import cue_linuxptp_v1.ptp4lio as ptp4lio


def ptp_current_ds_get(ctx, instance_id):
    """
    Send GET TLV_CURRENT_DATA_SET management command to ptp4l
    """
    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_CURRENT_DATA_SET)
    return ds


def ptp_parent_ds_get(ctx, instance_id):
    """
    Send GET TLV_PARENT_DATA_SET management command to ptp4l
    """
    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_PARENT_DATA_SET)
    return ds


def ptp_time_properties_ds_get(ctx, instance_id):
    """
    Send GET TLV_TIME_PROPERTIES_DATA_SET management command to ptp4l
    """

    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain,
                            ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_TIME_PROPERTIES_DATA_SET)
    return ds


def ptp_acceptable_masters_get(ctx, instance_id):
    """
    Send GET TLV_ACCEPTABLE_MASTER_TABLE management command to ptp4l
    """

    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_ACCEPTABLE_MASTER_TABLE)
    return ds


def ptp_default_ds_get(ctx, instance_id):
    """
    Send GET TLV_DEFAULT_DATA_SET management command to ptp4l
    """

    return ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                              ptp4lconst.TLV_DEFAULT_DATA_SET)


def ptp_port_ds_get(ctx, interface_id):
    """
    Send GET TLV_PORT_DATA_SET management command to ptp4l
    """
    port_ds = {}

    tgt_port = ptp4lio.get_ptp4l_portid(interface_id)
    if tgt_port == 0:
        return port_ds
    port_ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, tgt_port,
                                 ptp4lconst.TLV_PORT_DATA_SET)
    return port_ds


def ptp_port_stats_get(ctx, interface_id):
    """
    Send GET TLV_PORT_STATS_NP management command to ptp4l
    """
    port_stats = {}

    tgt_port = ptp4lio.get_ptp4l_portid(interface_id)
    if tgt_port == 0:
        return port_stats
    port_stats = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, tgt_port,
                                    ptp4lconst.TLV_PORT_STATS_NP)
    return port_stats


def ptp_config_get(ctx, instance_id):
    """
    From ptp4l.conf create config data
    """
    ptp_conf = {}

    status = os.system('systemctl is-active --quiet ptp4l')
    if status == 0:
        ptp_conf['enable'] = 'on'
    else:
        ptp_conf['enable'] = 'off'

    output = ctx.fileops.load_file("/etc/ptp4l.conf")
    for line in output.splitlines():
        out_lst = line.split()
        if len(out_lst) == 2:
            if out_lst[0] == 'domainNumber':
                ptp_conf['domain'] = int(out_lst[1])
            else:
                ptp_conf['domain'] = 0

            if out_lst[0] == 'dscp_event':
                ptp_conf['ipv4-dscp'] = int(out_lst[1])
            if out_lst[0] == 'dscp_general':
                ptp_conf['ipv4-dscp'] = int(out_lst[1])
            if out_lst[0] == 'priority1':
                ptp_conf['priority1'] = int(out_lst[1])
            if out_lst[0] == 'priority2':
                ptp_conf['priority2'] = int(out_lst[1])
            if out_lst[0] == 'twoStepFlag':
                if (int(out_lst[1]) == 1):
                    ptp_conf['two-step'] = 'on'
                else:
                    ptp_conf['two-step'] = 'off'
            ptp_conf['clock-mode'] = 'boundary'
            ptp_conf['profile-type'] = 'default-1588'
            ptp_conf['message-mode'] = 'multicast'

    # Set default values for keys not in
    if 'domain' not in ptp_conf:
        ptp_conf['domain'] = 0
    if 'clock-mode' not in ptp_conf:
        ptp_conf['clock-mode'] = 'ordinary'
    if 'ipv4-dscp' not in ptp_conf:
        ptp_conf['ipv4-dscp'] = 0
    if 'priority1' not in ptp_conf:
        ptp_conf['priority1'] = 128
    if 'priority2' not in ptp_conf:
        ptp_conf['priority2'] = 128
    if 'two-step-flag' not in ptp_conf:
        ptp_conf['two-step'] = 'on'

    return ptp_conf


def ptp_monitor_get(ctx, instance_id):
    """
    From ptp4l.conf create monitor data
    """
    mon_conf = {}

    output = ctx.fileops.load_file("/etc/ptp4l.conf")
    for line in output.splitlines():
        out_lst = line.split()
        if len(out_lst) == 2:
            # Monitor
            if out_lst[0] == 'offset_from_master_min_threshold':
                mon_conf['min-offset-threshold'] = int(out_lst[1])
            if out_lst[0] == 'offset_from_master_max_threshold':
                mon_conf['max-offset-threshold'] = int(out_lst[1])
            if out_lst[0] == 'mean_path_delay_threshold':
                mon_conf['path-delay-threshold'] = int(out_lst[1])

    if 'min-offset-threshold' not in mon_conf:
        mon_conf['min-offset-threshold'] = -100000
    if 'offset_from_master_max_threshold' not in mon_conf:
        mon_conf['max-offset-threshold'] = 100000
    if 'path-delay-threshold' not in mon_conf:
        mon_conf['path-delay-threshold'] = 1000000000

    return mon_conf


def ptp_if_config_get(ctx, interface_id):
    """
    From ptp4l.conf create interface config data
    """
    if_ptp_conf = {}
    port_found = 0
    port_section = 0

    match_str = '[' + interface_id + ']'

    output = ctx.fileops.load_file("/etc/ptp4l.conf")
    for line in output.splitlines():
        out_lst = line.split()
        if (len(out_lst) == 0):
            continue
        if out_lst[0] == match_str:
            port_section = 1
            port_found = 1
            continue
        else:
            if out_lst[0] == "[global]":
                port_section = 0
            elif out_lst[0] == "[unicast_master_table]":
                port_section = 0
            elif out_lst[0] == "[acceptable_master_table]":
                port_section = 0
            elif (port_section == 1) and out_lst[0][0] == '[':
                port_section = 0
        if len(out_lst) >= 2 and port_section == 1:
            if out_lst[0] == "masterOnly":
                if int(out_lst[1]) == 1:
                    if_ptp_conf['forced-master'] = 'on'
                else:
                    if_ptp_conf['forced-master'] = 'off'
            if out_lst[0] == "delay_mechanism":
                if out_lst[1] == '0':
                    if_ptp_conf['delay-mechanism'] = 'auto'
                elif out_lst[1] == '1':
                    if_ptp_conf['delay-mechanism'] = 'end-to-end'
                elif out_lst[1] == '2':
                    if_ptp_conf['delay-mechanism'] = 'peer-to-peer'
                else:
                    if_ptp_conf['delay-mechanism'] = 'end-to-end'

            if out_lst[0] == "udp_ttl":
                if_ptp_conf['ttl'] = int(out_lst[1])

            if out_lst[0] == "acceptableMasterTableEnabled":
                if out_lst[1] == '1':
                    if_ptp_conf['acceptable-master'] = 'on'
                else:
                    if_ptp_conf['acceptable-master'] = 'off'
            if out_lst[0] == "network_transport":
                if out_lst[1] == 'L2':
                    if_ptp_conf['transport'] = '802.3'
                elif out_lst[1] == 'UDPv4':
                    if_ptp_conf['transport'] = 'ipv4'
                elif out_lst[1] == 'UDPv6':
                    if_ptp_conf['transport'] = 'ipv6'
                elif out_lst[1] == 'RAWUDPv4':
                    if_ptp_conf['transport'] = 'ipv4'
                elif out_lst[1] == 'RAWUDPv6':
                    if_ptp_conf['transport'] = 'ipv6'
                elif out_lst[1] == '':
                    if_ptp_conf['transport'] = 'null'

    if port_found == 1:
        if 'forced-master' not in if_ptp_conf:
            if_ptp_conf['forced-master'] = 'off'
        if 'delay-mechanism' not in if_ptp_conf:
            if_ptp_conf['delay-mechanism'] = 'end-to-end'
        if 'ttl' not in if_ptp_conf:
            if_ptp_conf['ttl'] = 1
        if 'message-mode' not in if_ptp_conf:
            if_ptp_conf['message-mode'] = 'multicast'
        if 'acceptable-master' not in if_ptp_conf:
            if_ptp_conf['acceptable-master'] = 'off'

    return if_ptp_conf


def ptp_if_timer_config_get(ctx, interface_id):
    """
    From ptp4l.conf create interface timer config data
    """
    if_ptp_timer_conf = {}
    port_found = 0
    port_section = 0

    match_str = '[' + interface_id + ']'

    output = ctx.fileops.load_file("/etc/ptp4l.conf")
    for line in output.splitlines():
        out_lst = line.split()
        if (len(out_lst) == 0):
            continue
        if out_lst[0] == match_str:
            port_section = 1
            port_found = 1
            continue
        else:
            if out_lst[0] == "[global]":
                port_section = 0
            elif out_lst[0] == "[unicast_master_table]":
                port_section = 0
            elif out_lst[0] == "[acceptable_master_table]":
                port_section = 0
            elif (port_section == 1) and out_lst[0][0] == '[':
                port_section = 0
        if len(out_lst) >= 2 and port_section == 1:
            if out_lst[0] == "logAnnounceInterval":
                if_ptp_timer_conf['announce-interval'] = int(out_lst[1])
            if out_lst[0] == "logMinDelayReqInterval":
                if_ptp_timer_conf['delay-req-interval'] = int(out_lst[1])
            if out_lst[0] == "logMinPdelayReqInterval":
                if_ptp_timer_conf['delay-req-interval'] = int(out_lst[1])
            if out_lst[0] == "logSyncInterval":
                if_ptp_timer_conf['sync-interval'] = int(out_lst[1])
            if out_lst[0] == "announceReceiptTimeout":
                if_ptp_timer_conf['announce-timeout'] = int(out_lst[1])

    if port_found == 1:
        if 'announce-interval' not in if_ptp_timer_conf:
            if_ptp_timer_conf['announce-interval'] = 1
        if 'delay-req-interval' not in if_ptp_timer_conf:
            if_ptp_timer_conf['delay-req-interval'] = 0
        if 'sync-interval' not in if_ptp_timer_conf:
            if_ptp_timer_conf['sync-interval'] = 0
        if 'announce-timeout' not in if_ptp_timer_conf:
            if_ptp_timer_conf['announce-timeout'] = 3


'''
      nw_trans_enu),
            if out_lst[1] == "transportSpecific", 0, 0, 0x0F),
            if out_lst[1] == "namespace", NULL),
            if out_lst[1] == "vlan", 0, 0, 4095),
            if out_lst[1] == "src_ip", "127.0.0.1"),
            if out_lst[1] == "src_mac", "e4:1d:2d:46:f8:48"),
            if out_lst[1] == "vlan_intf", ""),
            if out_lst[1] == "lag_intf", ""),
            if out_lst[1] == "tmPortName", ""),
'''
