# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates
from pydash import py_


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("linuxptp_v1", handle_verify_config)
    ctx.events.ready_apply.register("linuxptp_v1", handle_ready_apply)
    ctx.events.check_health.register("linuxptp_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """


def format_acceptable_masters_clocks(ptps):
    """
    The config file expects clock-ids in a different format.
    """
    for ptp in ptps.values():
        new_masters = {}
        for clock_id, acc in ptp["acceptable-master"].items():
            parts = clock_id.split(":")
            new_clock_id = "{}{}{}.{}{}.{}{}{}".format(*parts)
            new_masters[new_clock_id] = acc
        ptp["acceptable-master"] = new_masters


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    ptps = evt.config_v1.getPtps()

    # For now, assume a single instance, named "1".
    if "1" in ptps and ptps["1"]["enable"] == "on":
        format_acceptable_masters_clocks(ptps)

        vrfs = evt.config_v1.getVrfs()

        # Build the set of interfaces with PTP enabled
        if_ptps = {}
        for iface_name, iface in evt.config_v1.getInterfaces().items():
            if_ptp = py_.get(iface, "service.ptp", {"enable": "off"})

            # If auto, then inherit from VRF.
            if if_ptp["enable"] == "auto":
                vrf = iface["ip"]["vrf"]
                if vrf in vrfs:
                    if_ptp = vrfs[vrf]["service"]["ptp"]

            # If explicitly on (or inherited on), add it to the list of
            # interface instances
            if if_ptp["enable"] == "on":
                if_ptps[iface_name] = if_ptp

        # Check if running in HW or SW
        hw = evt.platform_v1.getHardware()
        if (hw.get("vendor") == "cumulus" and hw.get("model") == "vx"):
            sim = True
        else:
            sim = False
        evt.render(
            templates, "ptp4l.conf",
            py_=py_,
            running=True,
            simulation=sim,
            ptp_conf=ptps["1"],
            if_ptps=if_ptps
        )
        evt.stage_file("ptp4l.conf", "/etc/ptp4l.conf")
        evt.schedule_reload_or_restart("ptp4l")
    else:
        # Render a config for a stopped service
        evt.render(templates, "ptp4l.conf", running=False)
        evt.stage_file("ptp4l.conf", "/etc/ptp4l.conf")
        # Make sure the service is stopped.
        evt.schedule_stop("ptp4l")


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
