# Copyright (C) 2018-2020 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates
import ipaddress
import logging


logger = logging.getLogger(__name__)


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("isc_dhcp_v1", handle_verify_config)
    ctx.events.ready_apply.register("isc_dhcp_v1", handle_ready_apply)
    ctx.events.check_health.register("isc_dhcp_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """
    dhcp_server = evt.config_v1.getDhcpServers()
    for vrf in dhcp_server:
        server = dhcp_server[vrf]
        pool = server['pool']
        for addr in pool:
            try:
                ipaddress.IPv4Network(addr)
            except ValueError:
                msg = "pool-id " + addr + " is not valid"
                evt.report_issue(msg)

    dhcp_server_v6 = evt.config_v1.getDhcpServers6()
    for vrf in dhcp_server_v6:
        server6 = dhcp_server_v6[vrf]
        pool = server6['pool']
        for addr in pool:
            try:
                ipaddress.IPv6Network(addr)
            except ValueError:
                msg = "pool-id " + addr + " is not valid"
                evt.report_issue(msg)


def process_dhcp_v6interface(evt, dhcp_conf, vrf):
    path = "/etc/default/"
    config_file = "isc-dhcp-server6-"
    config_file += vrf
    path += config_file

    conf = '"' + "-cf /etc/dhcp/dhcpd6-" + vrf + ".conf" + '"'
    pid = '"' + "-pf /var/run/dhcpd6-" + vrf + ".pid" + '"'
    option = '"' + "-lf /var/lib/dhcp/dhcpd6-" + vrf + ".leases" + '"'
    dhcp_conf.update({"conf": conf})
    dhcp_conf.update({"pid": pid})
    dhcp_conf.update({"option": option})

    opt_file = "dhcpd6-" + vrf + ".leases"
    # creating .lease file
    script = "dhccpd6-" + vrf + "-lease.sh"
    evt.render(templates, script, "lease.sh", lease_file=opt_file)
    evt.schedule_run_script(script)

    evt.render(templates, config_file, "isc-dhcp-server6",
               config=dhcp_conf)
    evt.stage_file(config_file, path)


def process_dhcp_interface(evt, dhcp_conf, vrf):
    path = "/etc/default/"
    config_file = "isc-dhcp-server-"
    config_file += vrf
    path += config_file

    conf = '"' + "-cf /etc/dhcp/dhcpd-" + vrf + ".conf" + '"'
    pid = '"' + "-pf /var/run/dhcpd-" + vrf + ".pid" + '"'
    option = '"' + "-lf /var/lib/dhcp/dhcpd-" + vrf + ".leases" + '"'
    dhcp_conf.update({"conf": conf})
    dhcp_conf.update({"pid": pid})
    dhcp_conf.update({"option": option})

    opt_file = "dhcpd-" + vrf + ".leases"
    # creating .lease file
    script = "dhccpd-" + vrf + "-lease.sh"
    evt.render(templates, script, "lease.sh", lease_file=opt_file)
    evt.schedule_run_script(script)

    evt.render(templates, config_file, "isc-dhcp-server",
               config=dhcp_conf)
    evt.stage_file(config_file, path)


def process_dhcp_intrf_config(evt, dhcp_server, dhcp_conf):
    if dhcp_server['interface']:
        port = "".join(map(lambda n: n + ' ', dhcp_server['interface']))
        # add extra quotes at the begin and end to satisfy the
        # Linux format for the ports and remove the extra
        # space getting added at the end, while formating the port
        port = '"' + port[0:-1] + '"'
        dhcp_conf['port'] = port


def process_dhcp_domain_name_config(evt, dhcp_server, dhcp_conf):
    if dhcp_server['domain-name']:
        # TODO: Seems like overkill.  Only a single domain-name
        # is possible.  not sure if the OM restricts this correctly.
        # In any case, look through them and take the last one ?
        for name in dhcp_server['domain-name']:
            dn = '"' + name + '"'
            dhcp_conf['domain'] = dn + ';'


def process_dhcp_dns_config(evt, dhcp_server, dhcp_conf):
    if dhcp_server['domain-name-server']:
        dns = ", ".join(dhcp_server['domain-name-server']) + ";"
        dhcp_conf['dns'] = dns


def process_dhcp_config(evt, server):
    for vrf in server:
        dhcp_conf = {}
        pool = {}

        dhcp_server = server[vrf]
        process_dhcp_intrf_config(evt, dhcp_server, dhcp_conf)
        process_dhcp_domain_name_config(evt, dhcp_server, dhcp_conf)
        process_dhcp_dns_config(evt, dhcp_server, dhcp_conf)

        pool = dhcp_server['pool']
        for addr in pool:
            ip_addr = ipaddress.IPv4Network(addr)
            pool[addr]['ip'] = ip_addr.network_address
            pool[addr]['netmask'] = ip_addr.netmask

        process_dhcp_interface(evt, dhcp_conf, vrf)
        dhcp_conf.update(dhcp_server)

        # creating dhcp  config file by adding <vrf-key>
        # under /etc/dhcp
        path = "/etc/dhcp/"
        config_file = "dhcpd-"
        config_file += vrf
        config_file += ".conf"
        path += config_file
        service = "dhcpd@" + vrf

        evt.render(templates, config_file, "dhcpd.conf",
                   config=dhcp_conf)
        evt.stage_file(config_file, path)
        evt.schedule_reload_or_restart(service)


def process_dhcp_v6_config(evt, server):
    for vrf in server:
        dhcp_conf = {}
        pool = {}

        dhcp_server = server[vrf]
        process_dhcp_intrf_config(evt, dhcp_server, dhcp_conf)
        process_dhcp_domain_name_config(evt, dhcp_server, dhcp_conf)
        process_dhcp_dns_config(evt, dhcp_server, dhcp_conf)

        pool = dhcp_server['pool']
        for addr in pool:
            ip_addr = ipaddress.IPv6Network(addr)
            pool[addr]['ip'] = ip_addr
            pool[addr]['netmask'] = ip_addr.netmask

        process_dhcp_v6interface(evt, dhcp_conf, vrf)
        dhcp_conf.update(dhcp_server)

        # creating dhcp  config file by adding <vrf-key>
        # under /etc/dhcp
        path = "/etc/dhcp/"
        config_file = "dhcpd6-"
        config_file += vrf
        config_file += ".conf"
        path += config_file
        service = "dhcpd6@" + vrf

        evt.render(templates, config_file, "dhcpd6.conf",
                   config=dhcp_conf)
        evt.stage_file(config_file, path)
        evt.schedule_reload_or_restart(service)


def get_current_config(evt, path, file_name):
    conf_files = []
    for f in evt.fileops.list_files(path):
        # we are interested in dhcp server config file only
        if not f.name.startswith(file_name):
            continue
        # extracting the VRF name from the config file
        conf_files.append(f.name)
    return conf_files


def handle_isc_stale_config(evt, dhcp, dhcp6):
    """
    Check the existing DHCP config files in /etc/default associated
    with particular vrf, delete them if they are not required any more.

    Args:
    dhcp: current DHCP server config received.
    dhcp6: current DHCP server6 config received.
    """
    old = get_current_config(evt, "/etc/default/", "isc-dhcp-server-")
    new = []
    for vrf in dhcp:
        new.append('isc-dhcp-server-' + vrf)
    diff_v4 = set(old) - set(new)

    old = get_current_config(evt, "/etc/default/", "isc-dhcp-server6-")
    new = []
    for vrf in dhcp6:
        new.append('isc-dhcp-server6-' + vrf)
    diff_v6 = set(old) - set(new)

    diff = diff_v4 | diff_v6
    if len(diff) > 0:
        evt.render(templates, "isc_cleanup.sh", stale_configs=diff)
        evt.schedule_run_script("isc_cleanup.sh")

    # below code handles deletes the vrf specific lease files
#    old = get_current_config(evt, "/var/lib/dhcp/", "dhcpd-")
#    new = []
#    for vrf in dhcp:
#        new.append('dhcpd-' + vrf + ".leases")
#    diff_v4 = set(old) - set(new)

#    old = get_current_config(evt, "/var/lib/dhcp/", "dhcpd6-")
#    new = []
#    for vrf in dhcp6:
#        new.append('dhcpd6-' + vrf + ".leases")
#    diff_v6 = set(old) - set(new)

#    diff = diff_v4 | diff_v6
#    if len(diff) > 0:
#        evt.render(templates, "lease_cleanup.sh", lease_configs=diff)
#        evt.schedule_run_script("lease_cleanup.sh")


def handle_dhcpd_stale_config(evt, dhcp, dhcp6):
    """
    Check the existing DHCP server config files in /etc/default associated
    with particular vrf, delete them if they are not required any more.

    Args:
    dhcp: current DHCP sercver config received.
    dhcp6: current DHCP server6 config received.
    """
    old = get_current_config(evt, "/etc/dhcp/", "dhcpd-")
    new = []
    for vrf in dhcp:
        new.append('dhcpd-' + vrf + '.conf')
    diff_v4 = set(old) - set(new)

    old = get_current_config(evt, "/etc/dhcp/", "dhcpd6-")
    new = []
    for vrf in dhcp6:
        new.append('dhcpd6-' + vrf + '.conf')
    diff_v6 = set(old) - set(new)

    diff = diff_v4 | diff_v6
    if len(diff) > 0:
        evt.render(templates, "dhcpd_cleanup.sh", stale_configs=diff)
        evt.schedule_run_script("dhcpd_cleanup.sh")


def handle_stale_config(evt, dhcp, dhcp6):
    handle_isc_stale_config(evt, dhcp, dhcp6)
    handle_dhcpd_stale_config(evt, dhcp, dhcp6)


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    dhcp_server = evt.config_v1.getDhcpServers()
    dhcp_server_v6 = evt.config_v1.getDhcpServers6()
    handle_stale_config(evt, dhcp_server, dhcp_server_v6)
    process_dhcp_config(evt, dhcp_server)
    process_dhcp_v6_config(evt, dhcp_server_v6)


def handle_check_health(evt):
    """
    Handle an check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
