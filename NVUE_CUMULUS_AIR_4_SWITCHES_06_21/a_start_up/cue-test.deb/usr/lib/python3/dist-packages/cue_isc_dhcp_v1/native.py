# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


from ipaddress import IPv4Network


def decode_dhcpinterface(ctx, f):
    """
    Returns list of DHCP enabled interfaces by reading the
    file passed
    """

    output = ctx.fileops.load_file(f)
    intf = {}
    for line in output.splitlines():
        for word in line.split():
            if (word.find('INTERFACES') != -1):
                # Removing Initial word 'INTERFACES="' from string
                new_line = line[12:-1]
                for port in new_line.split():
                    intf[port] = {}
    return intf


def dhcpinterface_get(ctx, in_file):
    """
    Returns list of DHCP enabled interfaces by reading the
    /etc/default/isc-dhcp-server file
    """
    dhcp_intf = {}
    intf = decode_dhcpinterface(ctx, in_file)
    dhcp_intf.update({'interface': intf})
    return dhcp_intf


def dhcpinterface6_get(ctx, in_file):
    """
    Returns list of DHCP enabled interfaces by reading the
    /etc/default/isc-dhcp-server6 file
    """

    dhcp_intf = {}
    intf = decode_dhcpinterface(ctx, in_file)
    dhcp_intf.update({'interface': intf})
    return dhcp_intf


def decode_static_dhcp_host(block, v4_flag):
    """
    Returns list of static hosts
    """
    d = {}
    temp = {}
    host = ethr = addr = url = ""
    word_list = block.split()

    try:
        host = word_list[word_list.index('host') + 1]
    except ValueError:
        return d

    try:
        ethr = word_list[word_list.index('ethernet') + 1]
        ethr = ethr[0:-1]
    except ValueError:
        return d

    try:
        if v4_flag:
            addr = word_list[word_list.index('fixed-address') + 1]
        else:
            addr = word_list[word_list.index('fixed-address6') + 1]
        addr = addr[0:-1]
    except ValueError:
        return d

    try:
        url = word_list[word_list.index('cumulus-provision-url') + 1]
        url = url[1:-2]
    except ValueError:
        pass

    if host and ethr and addr:
        temp['mac-address'] = ethr
        temp['ip-address'] = addr
    if url:
        temp['cumulus-provision-url'] = url

    d[host] = temp
    return d


def decode_static_dhcp(ctx, v4_flag, in_file):
    """
    Returns list of static DHCP conf by reading the
    file passed in f
    """
    pool = {}
    s_flag = g_flag = host_flag = False
    block = ""
    output = ctx.fileops.load_file(in_file)
    for line in output.splitlines():
        if g_flag and line.startswith('}'):
            g_flag = False
            break
        if g_flag:
            if line.find('host') != -1:
                host_flag = True
                block += line
            elif line.find('}') != -1:
                host_flag = False
                d = decode_static_dhcp_host(block, v4_flag)
                if bool(d):
                    pool.update(d)
                block = ""
            elif host_flag:
                block += line

        # Check for "# Static" in the file
        if not s_flag:
            if not line.startswith('# Static'):
                continue
            else:
                s_flag = True
        if line.startswith('group'):
            g_flag = True

    return pool


def decode_subnet(block, v4_flag, conf):
    pool = {}
    word_list = block.split()

    if v4_flag:
        subnet = word_list[word_list.index('subnet') + 1]
        netmask = word_list[word_list.index('netmask') + 1]
        ip_addr = '0.0.0.0/' + netmask
        pfx = IPv4Network(ip_addr).prefixlen
        subnet += '/' + str(pfx)
    else:
        subnet = word_list[word_list.index('subnet6') + 1]

    try:
        n = {}
        name_server = word_list[word_list.index('domain-name-servers') + 1]
        name_server = name_server[0:-1]
        n.update({name_server: {}})
        pool['domain-name-server'] = n
    except ValueError:
        pool['domain-name-server'] = {}
        pass

    try:
        routers = word_list[word_list.index('routers') + 1]
        routers = routers[0:-1]
        pool['gateway'] = {routers: {}}
    except ValueError:
        pool['gateway'] = {}
        pass

    try:
        n = {}
        domain_name = word_list[word_list.index('domain-name') + 1]
        domain_name = domain_name[1:-2]
        n.update({domain_name: {}})
        pool['domain-name'] = n
    except ValueError:
        pool['domain-name'] = {}
        pass

    try:
        lease = word_list[word_list.index('default-lease-time') + 1]
        lease = lease[0:-1]
        pool['lease-time'] = int(lease)
    except ValueError:
        pool['lease-time'] = 0
        pass

    try:
        url = word_list[word_list.index('default-url') + 1]
        url = url[1:-2]
        pool['default-url'] = url
    except ValueError:
        pool['default-url'] = ""
        pass

    try:
        cum_url = word_list[word_list.index('cumulus-provision-url') + 1]
        cum_url = cum_url[1:-2]
        pool['cumulus-provision-url'] = cum_url
    except ValueError:
        pool['cumulus-provision-url'] = ""
        pass

    r = {}
    t = {}
    try:
        if v4_flag:
            range1 = word_list[word_list.index('range') + 1]
            range2 = word_list[word_list.index('range') + 2]
        else:
            range1 = word_list[word_list.index('range6') + 1]
            range2 = word_list[word_list.index('range6') + 2]
        range2 = range2[0:-1]
        t['to'] = range2
        r[range1] = t
    except ValueError:
        pass

    pool['range'] = r
    conf[subnet] = pool


def decode_domain_name_server(line, conf):
    dns = {}
    word_list = line.split()
    index = 1
    try:
        while index > 0:
            name_server = word_list[word_list.index(
                'domain-name-servers') + index]
            name_server = name_server[0:-1]
            dns.update({name_server: {}})
            index += 1
    except IndexError:
        pass
    conf['domain-name-server'] = dns


def decode_domain_name(line, conf):
    dns = {}
    word_list = line.split()
    index = 1
    try:
        while index > 0:
            name_server = word_list[word_list.index('domain-name') + index]
            name_server = name_server[1:-2]
            dns.update({name_server: {}})
            index += 1
    except IndexError:
        pass
    conf['domain-name'] = dns


def decode_dhcppool(ctx, v4_flag, in_file):
    """
    Returns list of DHCP pool and range by reading the
    file passed
    """
    pool = {}
    subnet = {}
    s_flag = False
    block = ""
    output = ctx.fileops.load_file(in_file)
    for line in output.splitlines():
        if not s_flag and line.find('domain-name-servers') != -1:
            decode_domain_name_server(line, pool)
            continue
        if not s_flag and line.find('domain-name') != -1:
            decode_domain_name(line, pool)
            continue
        if not s_flag:
            if not line.startswith('subnet'):
                continue
            else:
                s_flag = True
                block += line
        else:
            block += line
        if line.startswith('}'):
            s_flag = False
            decode_subnet(block, v4_flag, subnet)
            block = ""
    pool['pool'] = subnet
    if "domain-name-server" not in pool.keys():
        pool["domain-name-server"] = {}
    if "domain-name" not in pool.keys():
        pool["domain-name"] = {}
    return pool


def dhcp_pool_get(ctx, in_file):
    """
    Returns list of DHCP pools and its range
    """
    pool = decode_dhcppool(ctx, True, in_file)
    return pool


def static_dhcp_get(ctx, infile):
    """
    Returns list of static DHCP pools
    """
    static_dhcp = {}
    conf = decode_static_dhcp(ctx, True, infile)
    static_dhcp.update({'static': conf})
    return static_dhcp


def dhcpv6_pool_get(ctx, in_file):
    pool = decode_dhcppool(ctx, False, in_file)
    return pool


def v6_static_dhcp_get(ctx, in_file):
    """
    Returns list of static DHCP pools
    """
    static_dhcp = {}
    conf = decode_static_dhcp(ctx, False, in_file)
    static_dhcp.update({'static': conf})
    return static_dhcp


def dhcpd_conf_data_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/dhcp/"):
        vrf_dhcp_data = {}
        # we are interested in dhcp server config file only
        if not config_file.name.startswith('dhcpd-'):
            continue
        # extracting the VRF name from the dhcpd config file
        # Ex: in dhcpd-blue, vrf is blue
        # handling DHCP server V4
        vrf = config_file.name[6:-5]
        vrf_dhcp_data.update(dhcp_pool_get(ctx, config_file))
        vrf_dhcp_data.update(static_dhcp_get(ctx, config_file))
        config_data.update({vrf: vrf_dhcp_data})
    return config_data


def dhcpd6_conf_data_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/dhcp/"):
        vrf_dhcp_data = {}
        # we are interested in dhcp server config file only
        if not config_file.name.startswith('dhcpd6-'):
            continue
        # extracting the VRF name from the dhcpd config file
        # Ex: in dhcpd6-blue, vrf is blue
        # handling DHCP server V6
        vrf = config_file.name[7:-5]
        vrf_dhcp_data.update(dhcpv6_pool_get(ctx, config_file))
        vrf_dhcp_data.update(v6_static_dhcp_get(ctx, config_file))
        config_data.update({vrf: vrf_dhcp_data})
    return config_data


def isc_dhcp_server_data_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/default/"):
        vrf_dhcp_data = {}
        # we are interested in dhcp server config file only
        if not config_file.name.startswith('isc-dhcp-server-'):
            continue
        # extracting the VRF name from the dhcpd server config file
        # Ex: in isc-dhcp-server-blue, vrf is blue
        # handling DHCP server V4
        vrf = config_file.name[16:]
        vrf_dhcp_data.update(dhcpinterface_get(ctx, config_file))
        config_data.update({vrf: vrf_dhcp_data})
    return config_data


def isc_dhcp_server6_data_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/default/"):
        vrf_dhcp_data = {}
        # we are interested in dhcp server config file only
        if not config_file.name.startswith('isc-dhcp-server6-'):
            continue
        # extracting the VRF name from the dhcpd server config file
        # Ex: in isc-dhcp-server6-blue, vrf is blue
        # handling DHCP server V6
        vrf = config_file.name[17:]
        vrf_dhcp_data.update(dhcpinterface6_get(ctx, config_file))
        config_data.update({vrf: vrf_dhcp_data})
    return config_data
