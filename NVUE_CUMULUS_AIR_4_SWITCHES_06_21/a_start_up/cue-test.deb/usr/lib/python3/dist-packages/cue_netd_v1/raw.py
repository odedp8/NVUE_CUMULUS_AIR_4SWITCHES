# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from connexion.decorators.validation import problem
from unittest.mock import ANY


AVAILABLE_SHOW_COMMANDS = (
    ["lldp"],
    ["lldp", "json"],
    ["lldp", ANY],
    ["lldp", ANY, "json"],
)


def show_get(ctx, cmd):
    cmd_tokens = cmd.split()
    if cmd_tokens not in AVAILABLE_SHOW_COMMANDS:
        return problem(
            400,
            'Bad Request',
            f"{cmd!r} not available."
        )
    # TODO: CUE-4467
    # TODO: get rid of sudo here: neuter nclu and add cue to netshow users
    result = ctx.sh.sudo.net.show(*cmd_tokens)
    return result.stdout
