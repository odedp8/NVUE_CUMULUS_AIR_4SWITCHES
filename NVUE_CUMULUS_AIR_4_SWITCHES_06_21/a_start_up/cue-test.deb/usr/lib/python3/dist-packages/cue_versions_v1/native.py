# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

import shlex
from cue import utils


INFO_FIELDS = {
    '%s': "subject",
    "%b": "body",
    "%cI": "date",
    "%P": "parent-hashes",
    "%H": "hash",
    "%D": "ref-names",
}


FULL_FIELDS = [
    "%H",    # commit hash
    "%h",    # abbreviated commit hash
    "%T",    # tree hash
    "%t",    # abbreviated tree hash
    "%P",    # parent hashes
    "%p",    # abbreviated parent hashes
    "%an",   # author name
    "%ae",   # author email
    "%aI",   # author date, strict ISO 8601 format
    "%cn",   # committer name
    "%ce",   # committer email
    "%cI",   # committer date, strict ISO 8601 format
    "%D",    # ref names without the " (", ")" wrapping.
    "%s",    # subject
    "%b",    # body
    "%N",    # commit notes
]


FIELD_DELIMITER = "\n:DELIMITER:\n"
COMMIT_DELIMITER = "\n::COMMIT::\n"


SHOW_DUMP_FORMAT = FIELD_DELIMITER.join(FULL_FIELDS)
LOG_DUMP_FORMAT = COMMIT_DELIMITER + SHOW_DUMP_FORMAT


def split_refnames(raw):
    items = raw.split(", ")
    result = []
    for item in items:
        # Values often come with something like 'HEAD -> refname' or
        # `tag: refname`. We only want the last token in that mumbojumbo.
        *_, name = item.split(' ')
        if name != "":
            result.append(name)
    return result


def parse_dump_commit(dump_commit: dict):
    result = {}
    for dump_key, res_key in INFO_FIELDS.items():
        result[res_key] = dump_commit[dump_key]
    result['parent-hashes'] = result['parent-hashes'].split()
    result['ref-names'] = split_refnames(result['ref-names'])
    body = result['body']
    if body.startswith('---\n'):
        result['parsed-body'] = utils.yaml_load(body, typ='safe')
    return result


def parse_raw_commit(raw_commit: str) -> dict:
    values = raw_commit.split(FIELD_DELIMITER)
    return dict(zip(FULL_FIELDS, values))


def git_show_get(ctx, revision_id):
    dump = ctx.versions_v1.getDumpGitShow(revision_id)
    return parse_dump_commit(dump)


def git_show_dump_get(ctx, revision_id):
    command_tokens = ["show"]

    command_tokens.extend([
        "--no-patch",
        f"--format={shlex.quote(SHOW_DUMP_FORMAT)}",
    ])
    raw = ctx.versions_v1.getGit(
        revision_id, " ".join(command_tokens)
    )
    return parse_raw_commit(raw)


def get_log_get(ctx, revision_id):
    history_dump = ctx.versions_v1.getDumpGitLog(revision_id)
    return [
        parse_dump_commit(commit)
        for commit in history_dump
    ]


def git_log_dump_get(ctx, revision_id):
    command_tokens = ["log"]

    command_tokens.extend([
        f"--format={shlex.quote(LOG_DUMP_FORMAT)}",
    ])
    raw = ctx.versions_v1.getGit(
        revision_id, " ".join(command_tokens)
    )
    # Drop the first one, since it's empty
    _, *raw_commits = raw.split(COMMIT_DELIMITER)

    return [
        parse_raw_commit(commit)
        for commit in raw_commits
    ]
