How to register for an event
----------------------------
Each [event] is exposed as an `EventBroadcaster` instance.

To register a [handler function] to be called whenever an event is fired, pass
a function (along with a name for the handler) into
`EventBroadcaster.register`.

Take the following example:

    ctx.events.ready_apply.register("some-name", some_handler_function)

This sets it up so whenever the `ready_apply` event is fired,
`some_handler_function` will be called.
*(In the logs, the handler will be referred to as `"some-name"`.)*


### Deregistering events
*(This isn't relevant for most foundation unit development workflows, but it's
worth noting to explain why you have to give all your event handlers a name.)*

To deregister a handler from an event, call `EventBroadcaster.deregister` with
the name the handler was originally registered with.

For example, to deregister the handler we registered in the example above:

    ctx.events.ready_apply.deregister("some-name")


Handler functions
-----------------
A handler function is a regular python function. It's called whenever the event
it's [registered] for is fired. Handler functions accept a single argument
`evt`.

A handler function is called as follows:

    handler(evt)


### What is `evt`?
In short, it depends on which [event] the handler function is registered for.

Similar to `ctx`, `evt` will be an object with the functions/properties needed
to handle a given event. These are documented in the docstring for each event.

Going deeper, `evt` is always going to be an instance of a subclass of
`AbstractEvent`. The documentation for the `AbstractEvent` class has links to
all its subclasses, if you want to see more.


.. note:: `evt.config_v1`
  Some events expose `evt.config_v1`. This is an interface to the `config_v1`
  unit's API as defined in `cue_config_v1/openapi.yaml`.

  To call a particular openapi endpoint, call that endpoint's `operationId` as a
  method on `evt.config_v1`.

  For example, to "get" the data for `/{revision-id}/interface/swp`, you would
  call it by its `operationId` `getSwps`:

      evt.config_v1.getSwps()

  This returns the same data that you'd get from a curl request to that
  endpoint.


[handler function]: #handler-functions
[event]: #available-events
[registered]: #how-to-register-for-an-event
