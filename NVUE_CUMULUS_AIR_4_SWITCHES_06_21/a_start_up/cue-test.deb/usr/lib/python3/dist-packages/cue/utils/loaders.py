# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Utilities to load YAML and JSON files, report errors, etc.


from urllib import parse as urlparse
from pathlib import Path
import collections
import json
import io
from ruamel import yaml
from ruamel.yaml import YAMLError  # noqa
from ruamel.yaml.constructor import RoundTripConstructor
from pydash import py_
import logging
from . import misc, jsonref_resolver


__all__ = [
    "ParseError", "raise_parse_error", "json_load", "yaml_load",
    "yaml_load_safe", "yaml_dump", "json_dump", "find_location",
    "schema_filter_patch", "schema_filter_show", "schema_filter_defaults",
    "schema_filter_config"
]


cue_filter_schemes = [
    "cue-import", "cue-patch", "cue-show", "cue-config", "cue-defaults",
    "cue-config-paths", "cue-config-responses"
]
"""
List of filter schemes.  These are document loads, followed by a filter, then
fragments are taken.
"""


# Convince urlparse to treat our schemes the same as it does "file:"
urlparse.uses_netloc.extend(cue_filter_schemes)
urlparse.uses_relative.extend(cue_filter_schemes)
urlparse.uses_fragment.extend(cue_filter_schemes)


logger = logging.getLogger(__name__)


class ParseError(Exception):
    """
    Exception that indicates we ran into a parse error.  location is a string
    that should help the user understand where the error was found.
    reason is a description of the error that should help them fix it.

    The description property puts it all together into a single string.
    """

    def __init__(self, location, reason):
        super().__init__()
        self.location = location

        # Trim excessively long messages.  In some cases, we still see
        # jsonschema or ruamel trying to append the complete schema.  That's
        # too much noise to be useful.
        self.reason = reason[:300]
        if self.reason != reason:
            self.reason += "..."

    @property
    def description(self):
        if self.location is not None and len(self.location) > 0:
            return "Error at {}: {}".format(
                self.location, self.reason)
        else:
            return "Error: {}".format(self.reason)

    def __str__(self):
        return self.description


def translate_config_path(config_object):
    """
    Given a `config_object`, generate an openapi path object for it that's
    appropriate in the config_v1 unit.  The config_v1 unit is intentionally
    very formulaic, so most of the path object is boiler plate.
    """
    type_ = config_object["type"]
    title = config_object["title"]
    object_id = config_object["objectId"]
    camel_id = misc.upper_camel_case(object_id)

    ocy = "openapi/configs.yaml"
    ory = "openapi/responses.yaml"
    shr = "cue-import://cue/openapi/shared.yaml"
    get = {
        "summary": f"Return the configuration of {title}.",
        "tags": config_object["tags"],
        "operationId": f"get{camel_id}",
        "x-cue-controller": f"cue_config_v1.{object_id}_get",
        "parameters": [
            {"$ref": ocy + "#/components/parameters/revisionId"},
            {"$ref": ocy + "#/components/parameters/filled"},
        ],
        "responses": {
            "default": {
                "$ref": shr + "#/components/responses/default"
            },
            "200": {
                "$ref": ory + f"#/components/responses/{object_id}"
            }
        },
    }

    put = {
        "summary": f"Set the configuration of {title}.",
        "tags": config_object["tags"],
        "operationId": f"set{camel_id}",
        "x-cue-controller": f"cue_config_v1.{object_id}_put",
        "parameters": [
            {"$ref": ocy + "#/components/parameters/revisionId"},
        ],
        "requestBody": get["responses"]["200"],
        "responses": get["responses"],
    }

    if type_ == "mapping":
        get["parameters"].append(
            {"$ref": ocy + "#/components/parameters/attrs"})

    if type_ == "instance":
        id_param = {"$ref": ocy + "#/components/parameters/instanceId"}
        get["parameters"].append(id_param)
        put["parameters"].append(id_param)

    return {"get": get, "put": put}


def translate_config_response(config_object):
    """
    Given a `config_object`, generate an openapi response object for it that's
    appropriate in the config_v1 unit.  The config_v1 unit is intentionally
    very formulaic, so most of the response object is boiler plate.
    """
    title = config_object["title"]
    object_id = config_object["objectId"]

    ocy = "openapi/configs.yaml"
    return {
        "description": f"Configuration of {title}.",
        "content": {
            "application/json": {
                "schema": {
                    "$ref": ocy + f"#/components/schemas/{object_id}"
                },
            }
        }
    }


def translate_config_paths(object_defs):
    """
    Given an `object_defs` object, return an openapi paths object.

    The `object_defs` format is a simplified version of openapi with all the
    config_v1 boiler plate removed.  This function puts the boiler plate back
    in to build the paths object.
    """
    # Start with the pre-defined paths.
    paths = dict(object_defs["static-paths"])

    # Generate paths for each object
    for config_rel, config_object in object_defs["objects"].items():
        path_rel = "/rev/{revision-id}" + config_rel
        paths[path_rel] = translate_config_path(config_object)

    # Return the complete set
    return paths


def translate_config_responses(object_defs):
    """
    Given an `object_defs` object, return an openapi responses object.

    The `object_defs` format is a simplified version of openapi with all the
    config_v1 boiler plate removed.  This function puts the boiler plate back
    in to build the responses object.
    """
    # Start with the pre-defined responses.
    responses = dict(object_defs["static-responses"])

    # Generate responses for each object
    for config_object in object_defs["objects"].values():
        object_id = config_object["objectId"]
        responses[object_id] = translate_config_response(config_object)

    # Return the complete set
    return responses


def drop_marked(obj, filter_name, markers):
    """
    Recursively iterate though a dict and drop any sub-dicts where the value of
    "x-cue-marker" is equal to one of the specified markers, returning a new
    dict.  Where possible, we'll avoid cloning so the returned dict will share
    memory with the original.

    Args:
        obj: The dict to iterate through
        markers: A list of markers that we want dropped

    Returns:
        A shallow copy of the original object sans any sub-objects that
        were marked with one of the provided markers.
    """
    # Get an iterable of children.
    children = misc.child_iterator(obj)

    # If we have children, filter and update obj.
    if children:
        obj_updated = False

        # Create a shallow copy of obj we can modify.
        new_obj = misc.copy_yamllink(obj)

        for key, child in children:
            # If the child is a dictionary containing our marker, remove it.
            if (isinstance(child, collections.Mapping)
                    and "x-cue-marker" in child
                    and child["x-cue-marker"] in markers):
                del new_obj[key]
                obj_updated = True

            else:
                # Otherwise, recursively check the child for markers.
                new_child = drop_marked(child, filter_name, markers)

                # If we got back a different child, replace it.
                if child is not new_child:
                    new_obj[key] = new_child
                    obj_updated = True

        # If we updated the object, return the new one.  Otherwise, return
        # the original and avoid the clone.
        if obj_updated:
            # If the original obj has an anchor, derive a new anchor for the
            # new obj.
            if hasattr(obj, "yaml_anchor") and obj.yaml_anchor() is not None:
                old_anchor = obj.yaml_anchor().value
                new_anchor = filter_name + "-" + old_anchor
                new_obj.yaml_set_anchor(new_anchor)

            obj = new_obj

    return obj


def schema_filter_patch(schema):
    """
    Implement "cue-patch" by filtering the given schema and returning a new
    schema.  The schema will be filtered using markers.
    """
    return drop_marked(schema, "cue-patch", [
        "constraints", "show", "show-children", "presentation", "defaults"])


def schema_filter_show(schema):
    """
    Implement "cue-show" by filtering the given schema and returning a new
    schema.  The schema will be filtered using markers.
    """
    return drop_marked(schema, "cue-show", ["constraints", "defaults"])


def schema_filter_defaults(schema):
    """
    Implement "cue-defaults" by filtering the given schema and returning a new
    schema.  The schema will be filtered using markers.
    """
    return drop_marked(schema, "cue-defaults", [
        "constraints", "show", "show-children", "presentation"])


def schema_filter_config(schema):
    """
    Implement "cue-config" by filtering the given schema and returning a new
    schema.  The schema will be filtered using markers.
    """
    return drop_marked(schema, "cue-config", [
        "show", "show-children", "presentation", "defaults"])


class CueJsonRefResolver(jsonref_resolver.JsonRefResolver):
    """
    Handle CUE's schemes.
    """
    def get_absolute_uri(self, base_uri, relative_uri):
        """
        Special handling when there's a cue- scheme involved.

        We went to preserve the cue scheme when it's in `relative_uri`, but
        still use the path in `base_uri` to make it relative.

        When a cue scheme is in `base_uri`, we want to treat it as "file://"
        and not inherit it.
        """
        bscheme, bhost, bpath, bquery, bfrag = urlparse.urlsplit(base_uri)
        scheme, host, path, query, frag = urlparse.urlsplit(relative_uri)

        # Make the base scheme match the relative scheme, if we have one.  This
        # tricks urljoin() into joining things the way we like.
        if scheme:
            bscheme = scheme
        # Otherwise, make sure we don't inherit a cue scheme.
        elif bscheme in cue_filter_schemes:
            bscheme = "file"

        # We can rebuild the base_uri now.
        base_uri = urlparse.urlunsplit((bscheme, bhost, bpath, bquery, bfrag))

        # Resolve packages into paths.  In cue- schemes, we'll find the package
        # name in the host field.
        if scheme in cue_filter_schemes and host:
            # host is a package name.
            base_path = misc.package_base_path(host)
            path = str(Path(base_path, path.lstrip("/")).resolve())
            # Rebuild the relative_uri
            relative_uri = urlparse.urlunsplit((scheme, "", path, query, frag))

        # Continue as normal.
        return super().get_absolute_uri(base_uri, relative_uri)

    def get_source_uri(self, uri):
        """
        Given a `uri`, return a `source_uri`.

        A `source_uri` is the raw file that's input into a filter scheme.
        """
        _, _, path, query, fragment = urlparse.urlsplit(uri)
        return urlparse.urlunsplit(("file", "", path, query, fragment))

    def load_document(self, document_uri):
        """
        Handle the cue- schemes.
        """
        scheme, host, path, *_ = urlparse.urlsplit(document_uri)

        if scheme in cue_filter_schemes:
            # Start with a regular lookup of the source document.
            source_uri = self.get_source_uri(document_uri)
            result = self._lookup_document(source_uri)
            needs_resolve = True

            # Apply our filter.
            if scheme == "cue-config-paths":
                result = translate_config_paths(result)
            elif scheme == "cue-config-responses":
                result = translate_config_responses(result)
            elif scheme == "cue-patch":
                result = schema_filter_patch(result)
                needs_resolve = False
            elif scheme == "cue-show":
                result = schema_filter_show(result)
                needs_resolve = False
            elif scheme == "cue-defaults":
                result = schema_filter_defaults(result)
                needs_resolve = False
            elif scheme == "cue-config":
                result = schema_filter_config(result)
                needs_resolve = False

            return result, needs_resolve
        else:
            # Anything else, do what we normally do.
            return super().load_document(document_uri)


def yaml_dump(obj, **kwargs):
    """
    Dump an object to YAML.  The given kwargs are passed directly
    to the YAML dumper, after setting our own defaults.
    """
    py_.defaults(kwargs, {
        "default_flow_style": False,
        "Dumper": yaml.RoundTripDumper,
    })

    return yaml.dump(obj, **kwargs)


def json_dump(obj, **kwargs):
    """
    Dump an object to JSON.  The given kwargs are passed directly
    to the JSON dumper, after setting our own defaults.
    """
    return json.dumps(obj, **kwargs)


_loaded_openapi_json = {}


def load_openapi_json(unit_name):
    """
    Retrieve the built openapi.json spec for a given unit.

    Raise the normal python error (usually FileNotFoundError) if something goes
    wrong with retrieving the file.
    """
    if unit_name in _loaded_openapi_json:
        # NOTE: tests expect this function to always log a message
        logger.dump("Loaded spec", unit_name)
        return _loaded_openapi_json[unit_name]

    unit_base_path = misc.package_base_path(unit_name)
    spec_path = unit_base_path / "dist/openapi.json"

    logger.dump("Loading spec", unit_name, spec_path)
    spec = json_load(spec_path, resolver_cls=jsonref_resolver.JsonRefResolver)

    _loaded_openapi_json[unit_name] = spec
    return spec


def _normalize_keys(data):
    """
    Recursively force keys in mappings to be strings.
    """
    if isinstance(data, dict):
        # The mapping object might have metadata we want to keep or be of a
        # type we can't re-create, so don't create a new one.  But if we start
        # changing key names, we'll lose the order.  So, dump the items, clear,
        # and put everything back in the same order, renaming keys along the
        # way.
        items = list(data.items())
        data.clear()
        for key, val in items:
            # Coerce key into a string.  If it's already a string, str() just
            # returns it, so this is faster then checking the type first.
            key = str(key)

            # Recurse through the value
            _normalize_keys(val)

            # Put it back into the dictionary.
            data[key] = val

    if isinstance(data, list):
        # Nothing to rename here, but we need to recurse and keep looking.
        for val in data:
            _normalize_keys(val)


def raise_parse_error(location, msg):
    """
    Raise a ParseError with the given `location` and `msg`.  We do this in a
    subroutine so pytest dumps less noise.  Also, raise "from None" to detach
    the root cause and further reduce noise.
    """
    # Note: Remove the "from None" if you want to see the root cause, but
    # usually it's just noise and generates excessive pytest output.
    raise ParseError(location, msg) from None


def _construct_yaml_map_with_filename(self, node):
    """
    Map constructor that also squirrels away the name of the file being loaded.
    Ruamel's map constructor keeps the line and column, but not the filename.
    Fortunately, the filename is saved by the parser (inside node.start_mark),
    so we just need to get it into the map's "lc", so we can find it later.
    """
    # Let the normal round trip map constructor do it's thing.  ruamel uses
    # generators to build the instance out, so that's what the constructor will
    # return.
    generator = RoundTripConstructor.construct_yaml_map(self, node)

    # The first thing off the generator will be the map itself.  We need that.
    data = next(generator)

    # If the map has an lc, add the filename to it.  It should already contain
    # the line and column.
    if hasattr(data, "lc"):
        data.lc.filename = node.start_mark.name

    # Yield the map as normal
    yield data

    # Yield everything else from ruamel's generator, like we were never here.
    yield from generator


class OaiLoader(yaml.YAML):
    """
    Loader that can handle `rt_oai`.

    This behaves much like ruamel's `rt` loader, except that it also generates
    anchors for the interesting stuff in an OpenAPI spec.
    """
    def load(self, *args, **kwargs):
        # Start with the ruamel loader
        obj = super().load(*args, **kwargs)

        # Generate anchors for OAI things.
        self._anchor_oai(obj)

        return obj

    def _anchor_oai(self, root):
        """
        Generate anchors schemas, responses, and parameters in the spec.

        `root` is an OpenAPI spec.  The ruamel metadata will be modified in
        place.  Existing anchors will not be replaced.
        """
        # Get the components child.  If we don't have, then we're already done.
        try:
            components = root["components"]
        except KeyError:
            return

        # Generate a prefix for the generated anchors.  We'll use the source
        # filename as a namespace.
        if root.lc.filename.endswith("openapi.yaml"):
            # This is the top-level spec.  No need for namespacing.
            prefix = ""
        else:
            # This is subspec.  Strip the suffix and use the filename as a
            # prefix.
            filename = Path(root.lc.filename).name
            prefix = misc.removesuffix(filename, ".yaml") + "-"

        # Anchor the bits of the schema that are likely to be referenced.
        self._anchor_oai_components(
            components.get("schemas", {}), "schema-" + prefix)
        self._anchor_oai_components(
            components.get("responses", {}), "response-" + prefix)
        self._anchor_oai_components(
            components.get("parameters", {}), "parameter-" + prefix)

    def _anchor_oai_components(self, components, prefix):
        """
        Loop through components and anchor each, if it isn't already.
        """
        for schema_name, schema in components.items():
            if hasattr(schema, "yaml_anchor") and schema.yaml_anchor() is None:
                schema.yaml_set_anchor(prefix + schema_name)


def _data_load(data_in, loader, resolver=None, deps=None, filename=None,
               base_uri=""):
    """
    Load `data_in` using `loader` and dereference it.

    `data_in` can be a string, file handle, or a Path.

    References ($ref) will be followed and resolved.  If `resolver` is
    provided, it will be used.  To resolve relative references, `data_in` must
    be a Path.

    Exceptions raised by loader are passed through.  Also, raises ParseError
    when things go wrong.
    """
    # If we don't have a base_uri already, try to get one from data_in
    try:
        base_uri = base_uri or data_in.as_uri()
    except AttributeError:
        pass

    # If it's not a stream, but a stream can be opened, open it now.  This will
    # make it easier on the loader.  Not all loaders can handle Path.
    if not hasattr(data_in, 'read') and hasattr(data_in, 'open'):
        with data_in.open('rb') as data_fp:
            return _data_load(data_fp, loader, resolver, deps, filename,
                              base_uri)

    # If data_in is a string, turn it into a stream so we can name it.
    if isinstance(data_in, str):
        data_in = io.StringIO(data_in)
        filename = filename or "(str)"
        data_in.name = filename

    # Otherwise, it's a Path or stream and we cannot name it.
    else:
        if filename:
            raise ValueError(
                "filename parameter can only be used when loading a string")

        # Get the filename out data_in, if we can.  Both Path and stream use
        # the name attribute.
        try:
            filename = data_in.name
        except AttributeError:
            pass
        filename = filename or "(file)"

    logger.dump("Loading", data_in=filename, base_uri=base_uri)

    try:
        # Load the root document.
        root = loader.load(data_in)

        # Resolve its references
        if resolver is None:
            resolver = CueJsonRefResolver(loader=loader)
        obj = resolver.resolve(root, base_uri=base_uri)

        # If the caller asked for the list of files this file depends on, we
        # can fill it in now.
        if deps is not None:
            deps += resolver.loaded_files

        return obj
    except jsonref_resolver.JsonRefResolverError as ref_error:
        if isinstance(ref_error, jsonref_resolver.JsonRefResolverLoadError):
            # Let the caller handle this one since it came from the loader
            # they provided.
            raise ref_error

        # This is a generic jsonref resolver error.  We can handle it here.

        # Pull out the filename.
        filename = Path(ref_error.referring_uri).name

        # Generate a location, as best we can.
        try:
            lc = ref_error.reference.lc
            location = _render_location(filename, lc.line + 1, lc.col + 1)
        except AttributeError:
            # We don't have line numbers
            location = filename

        raise_parse_error(location, str(ref_error))


def yaml_load(yaml_in, typ=None, deps=None, filename=None):
    """
    Load a YAML file and dereference it.  `yaml_in` can be a string, file
    handle, or a Path.  References ($ref) will be followed and replaced.  To
    resolve relative references, `yaml_in` must be a Path.

    `typ` can be `rt_oai` or any other value supported by ruamel.yaml.  If
    omitted, ruamel will default it to 'rt', which will preserve comments and
    line numbers, but is slower and very expensive to deepcopy.  Use 'safe' for
    performance and if you don't care about line numbers.  `rt_oai` is like
    `rt`, except it also auto-generates anchors for OpenAPI schemas.

    If `deps` is provided, it will be filled the list of files referenced as
    absolute uris.

    If `filename` is provided and ruamel is preserving line numbers, we'll
    augment those line numbers with this filename.  This is useful if the
    caller passed `yaml_in` as a string or a stream, but can identify the
    original source for us.

    Raises ParseError when things go wrong.
    """
    loader_cls = yaml.YAML

    # If it's an rt_oai load, use our special sub-class to load it.
    if typ == "rt_oai":
        typ = "rt"
        loader_cls = OaiLoader

    # Create the loader
    loader = loader_cls(typ=typ)

    # If this loader will collect line and column, make sure it also
    # collects the filename, too.  This is a bit of ruamel hackery.
    if typ is None or typ == "rt":
        loader.constructor.add_constructor(
            u'tag:yaml.org,2002:map', _construct_yaml_map_with_filename)

    try:
        root = _data_load(yaml_in, loader, deps=deps, filename=filename)

        # Force the keys into strings.  This keeps our YAML files more
        # compatible with JSON.  JSON keys are always strings, while YAML
        # allows just about anything (in particular, integers) to be strings.
        _normalize_keys(root)

        return root

    except yaml.YAMLError as yaml_error:
        # Convert the YAMLError into a ParseError
        mark = yaml_error.problem_mark
        location = _render_location(mark.name, mark.line + 1, mark.column + 1)
        raise_parse_error(location, yaml_error.problem)

    except jsonref_resolver.JsonRefResolverLoadError as ref_error:
        # We failed to load the target file.  Report the ParseError relative to
        # that file.

        # Convert the YAMLError into a ParseError
        mark = ref_error.cause.problem_mark
        location = _render_location(
            mark.name, mark.line + 1, mark.column + 1)
        raise_parse_error(location, ref_error.cause.problem)


def json_load(json_in, resolver_cls=None, deps=None, filename=None):
    """
    Load a JSON file and dereference it.

    `json_in` can be a string, file handle, or a Path.  References ($ref) will
    be followed and replaced.  To resolve relative references, `json_in` must
    be a Path.

    If `resolver_cls` is provided, we'll use it to create a custom resolver
    with json as the loader.

    If `deps` is provided, it will be filled the list of files referenced as
    absolute uris.

    If `filename` is provided, we'll use it in error messages.  This is useful
    if the caller passed `json_in` as a string or a stream, but can identify
    the original source for us.

    Raises ParseError when things go wrong.
    """
    try:
        # Create a resolver if we need to
        if resolver_cls:
            resolver = resolver_cls(json)
        else:
            resolver = None

        # Run the data_load()
        return _data_load(json_in, json, resolver=resolver,
                          deps=deps, filename=filename)
    except json.JSONDecodeError as json_error:
        # Convert into a ParseError
        location = _render_location(None, json_error.lineno, json_error.colno)
        raise_parse_error(location, json_error.msg)

    except jsonref_resolver.JsonRefResolverLoadError as ref_error:
        # We failed to load the target file.  Report the ParseError relative to
        # that file.

        # Pull out the filename.
        filename = Path(ref_error.document_uri).name

        location = _render_location(filename, ref_error.cause.lineno,
                                    ref_error.cause.colno)
        raise_parse_error(location, ref_error.cause.msg)


def yaml_load_safe(yaml_in, deps=None, filename=None, verifier=None):
    """
    Load `yaml_in` and return it as pure Python data structures (no line
    numbers or other ruamel metadata).  If the load fails, a `ParseError` is
    raised.

    If `verifier` is provided, it will be run after the file is loaded.  It
    will be passed the loaded file and can raise a `ParseError`.

    To create a meaningful `ParseError`, `yaml_in` is actually reloaded with
    the `rt` loader so that line numbers and context can be added to the
    exception.

    If `deps` is provided, it will be filled as described by `yaml_load()`.

    If `filename` is provided, it will be used as described by `yaml_load()`.
    """
    try:
        # Try loading without line numbers.  If this works, then we don't need
        # the line numbers anyway.
        spec = yaml_load(yaml_in, typ="safe", deps=deps, filename=filename)
        if verifier:
            verifier(spec)
        return spec
    except ParseError as ex:
        # Try again, but with line numbers.  The same error should be raised
        # but now with a location.  We'll let this one go to the caller.
        spec = yaml_load(yaml_in, typ="rt", filename=filename)
        if verifier:
            verifier(spec)

        # Just in case we don't get an error on the reload, raise the original
        # error to make sure we fail.
        raise ex  # pragma: no cover


def _render_location(filename, line, col):
    """
    Given a location, return a string representing it. `filename` can be None
    but `line` and `col` must be numbers.
    """
    if filename is None or filename == "(str)":
        # No filename.  Just return line and column.
        return f"line {line}, col {col}"
    else:
        # If it's a file URL, treat it as a normal filename.  When we come
        # through jsonref, we get URLs, but that's more of an implementation
        # detail and not something we need to see in our errors.
        try:
            parts = urlparse.urlparse(filename)
            if parts.scheme == "file":
                # It's a file URL.  Proceed with just the path.
                filename = parts.path
        except ValueError:
            pass

        # Try to make it a relative path.  It's prettier.
        try:
            filename = str(Path(filename).relative_to(Path.cwd()))
        except ValueError:
            pass

        return f"{filename}, line {line}, col {col}"


def find_location(root, path=None, path_prefix=None):
    """
    Given a `root` and an optional `path` relative to the `root`, return a
    string representing the path's real location.  For example, if `root` was
    loaded from a file, the returned string will reference a line and column.
    """
    instance = root
    path = path or []
    path_prefix = path_prefix or []
    path_iter = collections.deque(path)
    filename, line, col = (None, None, None)

    while True:
        # Try to improve our lc.
        if hasattr(instance, "lc"):
            # The instance node has an line/column, use it and keep digging.
            line = instance.lc.line
            col = instance.lc.col
            try:
                filename = instance.lc.filename
            except AttributeError:
                pass

        # Get the next item in the path, working from the start.
        try:
            path_item = path_iter.popleft()
            candidate = instance[path_item]
        except (TypeError, KeyError, IndexError):
            # We either ran out of path or couldn't follow it.  Either
            # way, we're done.
            break

        if hasattr(candidate, "lc"):
            instance = candidate
        else:
            # The candidate doesn't have an lc, which probably means we've dug
            # into a scalar.  Try to use its parent to refine our location a
            # bit.
            if hasattr(instance, "lc"):
                try:
                    # Point to the key if we must, and the value if we can.
                    # This covers us for both the list and dictionary cases.
                    line, col = instance.lc.key(path_item)
                    line, col = instance.lc.value(path_item)
                except IndexError:
                    pass

            # This is the best we can do.
            break

    # Build a location as best we can.
    if line is None or col is None:
        return ".".join([str(item) for item in [*path_prefix, *path]])
    else:
        return _render_location(filename, line + 1, col + 1)
