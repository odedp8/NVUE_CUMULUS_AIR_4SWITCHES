# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from werkzeug.serving import WSGIRequestHandler, BaseWSGIServer
import socket
import struct
import os


# Any user on the switch should be able to interact with CUE. CUE will handle
# authorization itself.
UDS_PERMISSIONS = 0o666


UDS_PATH = "/run/cue/cue.sock"


def get_peercred(conn):
    """
    Get the `SO_PEERCRED` options for a UNIX domain socket connection.

    Returns:
        A 3-tuple (pid, uid, gid).
    """
    creds = conn.getsockopt(
        socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i")
    )
    pid, uid, gid = struct.unpack("3i", creds)
    return pid, uid, gid


class UnixRequestHandler(WSGIRequestHandler):
    """
    WSGIRequestHandler for UNIX domain sockets.

    Embeds each connection's `SO_PEERCRED` info in WSGI `environ`.
    """

    def make_environ(self):
        environ = super().make_environ()
        pid, uid, gid = get_peercred(self.connection)
        environ["cue.peer_pid"] = pid
        environ["cue.peer_uid"] = uid
        environ["cue.peer_gid"] = gid
        return environ


class UnixWSGIServer(BaseWSGIServer):
    """
    A WSGI server that uses UNIX domain sockets.

    Attributes:
        uds_permissions: chmod permission flags to set for created socket file.
    """
    def __init__(self, *args, uds_permissions, **kwargs):
        super().__init__(*args, **kwargs)
        # Socket file has been created by now. Make sure it has the right
        # permissions.
        os.chmod(self.server_address, uds_permissions)


def make_server(app, **options):
    host = f"unix://{UDS_PATH}"
    server = UnixWSGIServer(
        host,
        # NOTE: The WSGI server requires a port, but it doesn't seem to use it
        #       for anything when host is a UDS.
        8080,
        app,
        uds_permissions=UDS_PERMISSIONS,
        handler=UnixRequestHandler,
        **options,
    )
    return server
