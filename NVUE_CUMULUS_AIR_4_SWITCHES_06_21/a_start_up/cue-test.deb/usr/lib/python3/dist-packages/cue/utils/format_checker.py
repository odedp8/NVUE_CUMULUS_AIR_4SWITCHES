# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


import re
from jsonschema import draft7_format_checker, FormatChecker, FormatError
import ctypes
from datetime import datetime


############################################################
# Patterns for matching link names
############################################################
patterns = {
    'swp': (r'^(?P<base_name>sw)(?P<suffix>(?P<module>\d*)p'
            r'(?P<port>L?\d+)(s(?P<breakout>\d+))?)$'),
    'eth': r'^eth(?P<id>\d+)$',
    'bond': r'^[a-zA-Z][a-zA-Z_0-9]*$',
    'svi': r'^vlan([a-zA-Z]+[0-9]*|\d+)$',
    'sub': r'^[a-zA-Z][a-zA-Z_0-9]*(\.\d+)+$',
    'loopback': r'^lo$',
}


reserved_names = ["auto", "none", "null"]
"""
List of names we want to disallow.
"""


class CueFormatChecker(FormatChecker):
    """
    A `format` property checker for CUE.  It covers the formats we suport and
    balks at ones we don't.
    """
    def __init__(self):
        # A subclass of FormatChecker starts with no formats.  Each needs to be
        # registered.  But what we really want to do is "subclass" the draft7
        # checker.  (We choose draft7 because we are heading to 2019-09 and
        # draft7 is the closest available now.)  The best we can do is just
        # copy the set of draft7 checkers.
        self.checkers = dict(draft7_format_checker.checkers)

    def check(self, instance, format_):
        """
        Check as normal, but first make sure it's a known format.
        """
        if format_ not in self.checkers:
            raise FormatError(f"Unknown format '{format_}'")
        return super().check(instance, format_)


cue_format_checker = CueFormatChecker()
"""
Instance of our format checker.  It will be re-used with every validator.
"""


# Register standard formats that aren't available upstream

@cue_format_checker.checks('date-time')
def is_datetime(instance):
    """
    Return True if instance is a date-time format matching RFC3339.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True
    # Alphanumerics are case-insensitive in date-times.
    instance = instance.upper()
    # HACK: Python's datetime doesn't recognize Z.
    instance = instance.replace("Z", "+00:00")
    # HACK: datetime doesn't support arbitrary decimal precision.
    if "." in instance:
        # Find the digits that come after '.', and truncate/pad the digits to a
        # precision that datetime can handle.
        idx = instance.index(".") + 1
        found_digits = []
        for char in instance[idx:]:
            if not char.isdigit():
                break
            found_digits.append(char)
        # EARLY RETURN
        if found_digits == []:
            # At least one digit must follow the '.'
            return False
        # Chomp digit chars to 3 (datetime supports 3, 6, or 0 digits.)
        chomped_digits = found_digits[:3]
        # Pad digits out to 3 if they're not already.
        needed_digits = 3 - len(chomped_digits)
        chomped_digits.extend(['0'] * needed_digits)
        # Replace the digits with our 3 digits.
        instance = instance.replace(
            "." + "".join(found_digits),
            "." + "".join(chomped_digits),
        )
    # Now that we've cleaned up the instance, see if datetime understands it.
    try:
        dt = datetime.fromisoformat(instance)
    except ValueError:
        return False
    else:
        if dt.utcoffset() is None:
            # UTC offset is required here.
            return False
    return True


# Register our non-standard formats

@cue_format_checker.checks('ipv4-unicast')
def is_ipv4_unicast(instance):
    """
    Return True if instance looks like an IPv4 unicast address.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    # Verify the address as normal
    is_ipv4, _ = cue_format_checker.checkers["ipv4"]
    if not is_ipv4(instance):
        return False

    # Verify it's not a multicast address
    octets = instance.split(".")
    octet = int(octets[0])
    if octet >= 224 and octet <= 239:
        return False

    return True


@cue_format_checker.checks('ipv4-multicast')
def is_ipv4_multicast(instance):
    """
    Return True if instance looks like an IPv4 multicast address.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    # Verify the address as normal
    is_ipv4, _ = cue_format_checker.checkers["ipv4"]
    if not is_ipv4(instance):
        return False

    # Verify it's a multicast address
    octets = instance.split(".")
    octet = int(octets[0])
    if octet >= 224 and octet <= 239:
        return True

    return False


@cue_format_checker.checks('ipv4-prefix')
def is_ipv4_prefix(instance):
    """
    Return True if instance looks like an IPv4 address with prefix.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    # Split the address from the prefix
    parts = instance.split("/", 1)
    if len(parts) != 2:
        return False
    addr, prefix = parts

    # Verify the address as normal
    is_ipv4, _ = cue_format_checker.checkers["ipv4"]
    if not is_ipv4(addr):
        return False

    # Verify prefix
    try:
        prefix = int(prefix)
    except ValueError:
        return False
    if prefix < 0 or prefix > 32:
        return False

    return True


@cue_format_checker.checks('ipv6-prefix')
def is_ipv6_prefix(instance):
    """
    Return True if instance looks like an IPv6 address with prefix.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    # Split the address from the prefix
    parts = instance.split("/", 1)
    if len(parts) != 2:
        return False
    addr, prefix = parts

    # Verify the address as normal
    try:
        is_ipv6, _ = cue_format_checker.checkers["ipv6"]
        is_ipv6(addr)
    except OSError:
        return False

    # Verify prefix
    try:
        prefix = int(prefix)
    except ValueError:
        return False
    if prefix < 0 or prefix > 128:
        return False

    return True


_mac_re = re.compile(r'^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$')


@cue_format_checker.checks('mac')
def is_mac_address(instance):
    """
    Return True if instance looks like a mac address.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    if not _mac_re.match(instance):
        return False

    return True


@cue_format_checker.checks('integer')
def is_integer(instance):
    """
    Return True if instance looks like an integer.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    # If Python can convert it, then we like it.
    try:
        int(instance)
    except ValueError:
        return False

    return True


@cue_format_checker.checks('swp-name')
def is_swp_name(instance):
    """
    Return True if instance looks like an swp name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    res = True if re.match(patterns['swp'], instance) else False

    return res


@cue_format_checker.checks('eth-name')
def is_eth_name(instance):
    """
    Return True if instance looks like an eth name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    res = True if re.match(patterns['eth'], instance) else False

    return res


@cue_format_checker.checks('sub-name')
def is_sub_name(instance):
    """
    Return True if instance looks like an sub name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    res = True if re.match(patterns['sub'], instance) else False

    return res


@cue_format_checker.checks('svi-name')
def is_svi_name(instance):
    """
    Return True if instance looks like an svi name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    res = True if re.match(patterns['svi'], instance) else False

    return res


@cue_format_checker.checks('loopback-name')
def is_loopback_name(instance):
    """
    Return True if instance looks like an loopback name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    res = True if re.match(patterns['loopback'], instance) else False

    return res


@cue_format_checker.checks('bond-name')
def is_bond_name(instance):
    """
    Return True if instance looks like an bond name.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    if (re.match(patterns['sub'], instance)
        or re.match(patterns['eth'], instance)
        or re.match(patterns['svi'], instance)
            or re.match(patterns['loopback'], instance)):
        return False

    for if_type in ['swp', 'eth', 'vlan', 'lo']:
        if instance.startswith(if_type):
            return False

    if instance in reserved_names:
        return False

    res = True if re.match(patterns['bond'], instance) else False

    return res


@cue_format_checker.checks('interface-name')
def is_interface_name(instance):
    """
    Return True if instance looks like an interface name.
    """
    return (
        is_swp_name(instance)
        or is_eth_name(instance)
        or is_sub_name(instance)
        or is_svi_name(instance)
        or is_loopback_name(instance)
        or is_bond_name(instance)
    )


_instance_re = re.compile(r'^[a-zA-Z][0-9A-Za-z_]*$')


@cue_format_checker.checks('instance-name')
def is_instance_name(instance):
    """
    Return True if instance is acceptable as a generic instance name.  This is
    the common set of constraints on named things in CUE, such as vrfs,
    bridges, policies, etc.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    if not _instance_re.match(instance):
        return False

    if instance in reserved_names:
        return False

    return True


_item_re = re.compile(r'^[0-9a-zA-Z][0-9A-Za-z_]*$')


@cue_format_checker.checks('item-name')
def is_item_name(item):
    """
    Return True if item is acceptable as a generic item name.  Item names are
    like instance names, except they can start with a number.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    if not _item_re.match(item):
        return False

    if item in reserved_names:
        return False

    return True


@cue_format_checker.checks('bridge-name')
def is_bridge_name(instance):
    """
    Return True if instance is acceptable as a bridge name.
    """
    return is_instance_name(instance)


@cue_format_checker.checks('vrf-name')
def is_vrf_name(instance):
    """
    Return True if instance is acceptable as a vrf name.
    """
    return is_instance_name(instance)


@cue_format_checker.checks('route-distinguisher')
def is_route_distinguisher(item):
    """
    Return True if item is acceptable as a route distinguisher.  We'll accept
    type 0, 1, and 2 RDs.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    # Split at the colon
    left, _, right = item.partition(":")

    # Check the right side.  This has to be an integer
    try:
        right = int(right)
    except ValueError:
        return False

    # If the left side is also an integer, we're dealing with a type 0 or type
    # 2.  See if the integers are in the correct ranges.
    try:
        left = int(left)

        # Use ctypes to check the ranges.  This packs the integer into the
        # format required.  It the result's value is different, that means it
        # was too big (or too small) for the format.

        # Try for a type 0
        if (ctypes.c_uint16(left).value == left
                and ctypes.c_uint32(right).value == right):
            return True

        # Try for a type 2
        elif (ctypes.c_uint32(left).value == left
                and ctypes.c_uint16(right).value == right):
            return True

        # We have two integers, but at least one is out of range.
        else:
            return False

    except ValueError:
        # The left is not an integer
        pass

    # If the left is an ipv4 address, try for a type type 1
    is_ipv4, _ = cue_format_checker.checkers["ipv4"]
    if is_ipv4(left) and ctypes.c_uint16(right).value == right:
        return True

    return False


@cue_format_checker.checks('route-target')
def is_route_target(item):
    """
    Return True if item is acceptable as a route target.  We'll accept
    type 0, 1, and 2 RDs.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    # Split at the colon
    left, _, right = item.partition(":")

    # Both sides have to be an integer.
    try:
        right = int(right)
        left = int(left)
    except ValueError:
        return False

    # Use ctypes to check the ranges.  This packs the integer into the format
    # required.  It the result's value is different, that means it was too big
    # (or too small) for the format.

    if (ctypes.c_uint32(left).value == left
            and ctypes.c_uint32(right).value == right):
        return True

    return False


@cue_format_checker.checks('well-known-community')
def is_well_known_community(item):
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    return item in [
        "local-as",
        "no-advertise",
        "no-export",
        "internet",
        "additive",
    ]


@cue_format_checker.checks('route-target-any')
def is_route_target_any(item):
    """
    Return True if item is acceptable as an "any" route target.  This is
    a route-target where the left-hand side is "ANY".
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    # Split at the colon
    left, _, right = item.partition(":")

    if left != "ANY":
        return False

    # The right side has to be an integer.
    try:
        right = int(right)
    except ValueError:
        return False

    # Use ctypes to check the ranges.  This packs the integer into the format
    # required.  It the result's value is different, that means it was too big
    # (or too small) for the format.

    if ctypes.c_uint32(right).value == right:
        return True

    return False


@cue_format_checker.checks('community')
def is_community(item):
    """
    Return True if item is acceptable as a community number.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    # Split at the colon
    parts = item.split(":", 1)
    if len(parts) != 2:
        return False
    right, left = parts

    # Both sides have to be an integer.
    try:
        right = int(right)
        left = int(left)
    except ValueError:
        return False

    # Use ctypes to check the ranges.  This packs the integer into the format
    # required.  It the result's value is different, that means it was too big
    # (or too small) for the format.

    if (ctypes.c_uint16(left).value == left
            and ctypes.c_uint16(right).value == right):
        return True

    return False


@cue_format_checker.checks('large-community')
def is_large_community(item):
    """
    Return True if item is acceptable as a large community.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    parts = item.split(":", 2)
    if len(parts) != 3:
        return False
    right, center, left = parts

    # all 3 part have to be an integer.
    try:
        right = int(right)
        center = int(center)
        left = int(left)
    except ValueError:
        return False

    # Use ctypes to check the ranges.  This packs the integer into the format
    # required.  It the result's value is different, that means it was too big
    # (or too small) for the format.

    if (ctypes.c_uint32(left).value == left
            and ctypes.c_uint32(center).value == center
            and ctypes.c_uint32(right).value == right):
        return True

    return False


@cue_format_checker.checks('ext-community')
def is_ext_community(item):
    """
    Return True if item is acceptable as a extended community.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return False

    # Split at the colon
    left, _, right = item.partition(":")

    # Check the right side.  This has to be an integer
    try:
        right = int(right)
    except ValueError:
        return False

    # If the left side is also an integer,
    # check if the integers are in the correct ranges.
    try:
        left = int(left)

        # Use ctypes to check the ranges.  This packs the integer into the
        # format required.  It the result's value is different, that means it
        # was too big (or too small) for the format.

        if (ctypes.c_uint16(left).value == left
                and ctypes.c_uint32(right).value == right):
            return True

        elif (ctypes.c_uint32(left).value == left
                and ctypes.c_uint16(right).value == right):
            return True

        # We have two integers, but at least one is out of range.
        else:
            return False

    except ValueError:
        # The left is not an integer
        pass

    # Check If the left is an ipv4 address
    is_ipv4, _ = cue_format_checker.checkers["ipv4"]
    if is_ipv4(left) and ctypes.c_uint16(right).value == right:
        return True

    return False


_bgp_regex = re.compile(r'[0-9_:\.^$[\]\*\?,(){}\\|+-]*$')
_not_bgp_regex = re.compile(r'[0-9\.:]*$')


@cue_format_checker.checks('bgp-regex')
def is_bgp_regex(exp_str):
    """
    Return True if instance is acceptable as a generic instance name.  This is
    the common set of constraints on named things in CUE, such as vrfs,
    bridges, policies, etc.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(exp_str, str):
        return True

    if not _bgp_regex.match(exp_str):
        return False

    if _not_bgp_regex.match(exp_str):
        return False

    return True


_clock_id_re = re.compile(r'^([0-9A-Fa-f]{2}[:]){7}([0-9A-Fa-f]{2})$')


@cue_format_checker.checks('clock-id')
def is_clock_id(instance):
    """
    Return True if instance looks like a mac address.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    if not _clock_id_re.match(instance):
        return False

    return True


_esi_re = re.compile(r'^([0-9A-Fa-f]{2}[:]){8}([0-9A-Fa-f]{2})$')


@cue_format_checker.checks('es-identifier')
def is_esi_address(instance):
    """
    Return True if instance looks like an ethernet segment identifier.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(instance, str):
        return True

    if not _esi_re.match(instance):
        return False

    return True


_port_num_re = re.compile(r'^([0-9A-Fa-f]{2}[:]){1}([0-9A-Fa-f]{2})$')


@cue_format_checker.checks('ptp-port-id')
def is_ptp_port_id(item):
    """
    Return True if item is acceptable as a PTP Port Id.
    """
    # If it's not a string, then the format doesn't apply.
    if not isinstance(item, str):
        return True

    # Split at the '-'
    left, _, right = item.partition("-")

    # Check if the left is an Clock ID
    # Use ctypes to check the right value ranges.  This packs the integer
    # into the format required.  It the result's value is different, that
    # means it was too big (or too small) for the format.
    if is_clock_id(left) and _port_num_re.match(right):
        return True

    return False
