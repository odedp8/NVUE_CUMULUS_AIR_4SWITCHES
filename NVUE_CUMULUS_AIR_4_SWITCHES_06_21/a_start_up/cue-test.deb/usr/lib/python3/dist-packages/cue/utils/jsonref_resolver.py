# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


import io
from urllib import parse as urlparse
from urllib.request import urlopen
from urllib.error import URLError
from . import json_pointers, misc


__all__ = [
    "resolve_jsonrefs", "JsonRefResolverError",
    "JsonRefResolverLookupError", "JsonRefResolverNoLoaderError",
    "JsonRefResolverOpenError", "JsonRefResolverLoadError"
]


class JsonRefResolverError(Exception):
    """
    Exception indicating we couldn't resolve JsonRefs.

    The `referring_uri` property is the URI of the document containing the
    reference, `reference` is the actual reference object itself.

    `reference_uri` is also set as a convenience for `reference["$ref"]`.

    The `description` property is a human readable error message.
    """
    def __init__(self):
        self.referring_uri = None
        self.reference = None

    @property
    def reference_uri(self):
        return self.reference["$ref"]

    def __str__(self):
        return self.description


class JsonRefResolverLookupError(JsonRefResolverError):
    """
    Exception that indicates we couldn't lookup a JsonRef.

    The `reference_uri` property is the URI as we received it and
    `absolute_uri` is what we actually tried to lookup.
    """
    def __init__(self, absolute_uri):
        super().__init__()
        self.absolute_uri = absolute_uri

    @property
    def description(self):
        return f"Unable to lookup $ref: {self.reference_uri}"


class JsonRefResolverForwardLookupError(JsonRefResolverLookupError):
    """
    Exception that indicates we couldn't lookup a JsonRef because
    it's a forward reference to something we haven't resolved yet.

    The `reference_uri` property is the URI as we received it and
    `absolute_uri` is what we actually tried to lookup.
    """
    @property
    def description(self):
        return f"Unable to follow forward $ref: {self.reference_uri}"


class JsonRefResolverNoLoaderError(JsonRefResolverError):
    """
    Exception that indicates we tried to load a document when we don't have a
    loader.
    """
    def __init__(self, document_uri):
        super().__init__()
        self.document_uri = document_uri

    @property
    def description(self):
        return f"Attempt to load without a loader: {self.reference_uri}"


class JsonRefResolverOpenError(JsonRefResolverError):
    """
    Exception that indicates we tried to open a document, but couldn't.

    We attempted to open `document_uri` with `urlopen()` and `cause` is the
    exception it raised.
    """
    def __init__(self, document_uri, cause):
        super().__init__()
        self.document_uri = document_uri
        self.cause = cause

    @property
    def description(self):
        return f"Unable to open: {self.reference_uri}"


class JsonRefResolverLoadError(JsonRefResolverError):
    """
    Exception that indicates we were able to open, but not load a document.

    We attempted to load `document_uri` with `loader.load()` and `cause` is the
    exception it raised.
    """
    def __init__(self, document_uri, cause):
        super().__init__()
        self.document_uri = document_uri
        self.cause = cause

    @property
    def description(self):
        return f"Unable to load: {self.reference_uri}"


class JsonRefResolver(object):
    """
    Class to handle resolution of JsonRefs ($ref).
    """
    def __init__(self, loader=None):
        """
        Create a new resolver.

        The optional `loader` will be used to load additional files.  If a $ref
        points to another file, we'll load it by calling loader.load().  A
        `JsonRefResolverNoLoaderError` will be raised if a loader is needed and
        one has not been provided.

        The `loaded_files` property is a list of files, as absolute file URIs,
        we loaded while resolving references.
        """
        self.loader = loader
        self._cache = {}
        self.loaded_files = []

    def resolve(self, root, base_uri=""):
        """
        Resolve jsonrefs ($ref) in `root` and return a shallow copy.

        Relative URIs will be converted into absolute URIs using `base_uri`.
        Supported URI schemes will be handled as well.

        `root` is not modified, but the return is only a minimal copy.
        """
        return self._resolve_document(root, base_uri)

    def get_absolute_uri(self, base_uri, relative_uri):
        """
        Given a `relative_uri`, return an absolute_uri.

        The `relative_uri` will be made absolute using `base_uri`.  The
        absolute_uri will unambiguously identify the resource.
        """
        return urlparse.urljoin(base_uri, relative_uri)

    def is_reference(self, obj):
        """
        Return True if obj is a reference.
        """
        if isinstance(obj, dict) and "$ref" in obj:
            return True
        else:
            return False

    def load_document(self, document_uri):
        """
        Load `document_uri` using `loader.load()`.

        This works for json.load(), yaml.load(), or anything else that
        implements a load() callable.  If `document_uri` cannot be loaded, a
        `JsonRefResolverError` is raised.

        Subclasses can override this method to control how documents are
        loaded.  The override must return a tuple containing the document and a
        boolean indicating whether the document contains refs that need to be
        resolved.
        """
        # If we get here, we need a loader.
        if self.loader is None:
            raise JsonRefResolverNoLoaderError(document_uri)

        # Open the URI as a stream
        try:
            raw_stream = urlopen(document_uri)
        except URLError as ex:
            raise JsonRefResolverOpenError(document_uri, ex)

        # Name it.  This will help render_location and find_location report
        # something useful instead of "<urllib response>".
        raw_stream.name = str(document_uri)

        # The URI stream is a binary stream and we need a text stream. Wrap it
        # in a TextIOWrapper so we can decode as we load.
        with io.TextIOWrapper(raw_stream, encoding="utf-8") as text_stream:
            try:
                # Load the document and return it
                document = self.loader.load(text_stream)
                self.loaded_files.append(document_uri)
                return document, True
            except Exception as ex:
                # If the loader raised an exception, wrap it in our own.
                raise JsonRefResolverLoadError(document_uri, cause=ex)

    def _lookup_document(self, document_uri):
        """
        Given a `document_uri`, return the document it refers to.

        The returned document will have all references resolved.

        We'll first look for it in the cache.  If that fails, we'll call
        `load_document()` and resolve its references.
        """
        # Check the cache first
        try:
            return self._cache[document_uri]
        except KeyError:
            pass

        # We'll have to load it.
        document, needs_resolve = self.load_document(document_uri)

        if needs_resolve:
            # Resolve all refs in the document and return it.
            return self._resolve_document(document, document_uri)
        else:
            # Cache the result and return it.
            self._cache[document_uri] = document
            return document

    def load_ref(self, absolute_uri):
        """
        Given an `absolute_uri`, load the object it refers to.

        The object will be found and resolved by loading its document and then
        dereferencing the fragment.

        Subclasses can override this method to control how refs are loaded, but
        usually they'll want to override `load_document()` instead.
        """
        document_uri, fragment = urlparse.urldefrag(absolute_uri)

        # Get the document
        document = self._lookup_document(document_uri)

        # Get the object, if we can.
        try:
            obj = json_pointers.dereference_json_pointer(fragment, document)
        except json_pointers.JsonPointerError as ex:
            if isinstance(ex, json_pointers.JsonPointerLookupError):
                if self.is_reference(ex.found):
                    # We died on a forward reference to an unresolved
                    # reference.  Let our caller know this is a little
                    # more interesting than a typical lookup error.
                    raise JsonRefResolverForwardLookupError(absolute_uri)

            # Otherwise, this is a normal lookup error.
            raise JsonRefResolverLookupError(absolute_uri)

        # Make sure obj isn't a reference.  If it is, then we're
        # trying to return an object that will be replaced.  Call
        # it a forward lookup and let our caller figure out what to do.
        if self.is_reference(obj):
            raise JsonRefResolverForwardLookupError(absolute_uri)

        return obj

    def _lookup_ref(self, absolute_uri):
        """
        Return the object referred to by `absolute_uri`.

        We'll first look for it in the cache.  If that fails, we'll load it.
        """
        # Check the cache first
        try:
            return self._cache[absolute_uri]
        except KeyError:
            pass

        # We'll need to load it.
        obj = self.load_ref(absolute_uri)

        # Cache and return
        self._cache[absolute_uri] = obj
        return obj

    def _find_refs(self, obj, refs, base_uri):
        """
        Recursively look for $refs and return a shallow copy of obj.

        Found $refs will be accumulated in `refs` as
        `(new_obj, key, absolute_uri)` tuples.  `_replace_refs()` knows
        what to do with this tuple.  `new_obj` is a shallow clone of `obj`
        that can be modified later as refs are replaced.  `absolute_uri`
        is the $ref's URI made absolute using `base_uri`.
        """
        # Get an iterable of children.
        children = misc.child_iterator(obj)

        # If we have children, filter and update obj.
        if children:
            obj_updated = False

            # Create a shallow copy of obj we can modify.
            new_obj = misc.copy_yamllink(obj)

            # Recursively look for references.
            for key, child in children:
                if self.is_reference(child):
                    # This child is a reference.  Add it to the list.

                    # Fully qualify the reference.
                    absolute_uri = self.get_absolute_uri(
                        base_uri, child["$ref"])

                    # Add it to the refs list.
                    refs.append((new_obj, key, absolute_uri))

                    # Make sure we keep the new_obj around.  We'll update
                    # it later.
                    obj_updated = True
                else:
                    # Recurse into the child.
                    new_child = self._find_refs(child, refs, base_uri)

                    # If we got back a different child, replace it.
                    if child is not new_child:
                        new_obj[key] = new_child
                        obj_updated = True

            # If we updated the object, return the new one.  Otherwise, return
            # the original and let the copy be garbage collected.
            if obj_updated:
                obj = new_obj

        return obj

    def _replace_refs(self, refs, document_uri):
        """
        Replace the $refs found by `_find_refs()`.

        `refs` is expected to be in the format accumulated by `_find_refs()`.
        `document_uri` is informational.
        """
        # Resolve refs until we run out of them or can't get anywhere.
        while True:
            # Remember the refs we couldn't resolve yet because they
            # look like forward references
            forward_refs = []
            forward_ref_ex = None

            # Loop  over each ref and try to resolve it
            for ref in refs:
                obj, key, absolute_uri = ref

                try:
                    # Look it up and set it.
                    obj[key] = self._lookup_ref(absolute_uri)
                except JsonRefResolverError as ex:
                    # Add some context, if we haven't already
                    if ex.referring_uri is None:
                        ex.referring_uri = document_uri
                        ex.reference = obj[key]

                    # Is this a forward reference?
                    if isinstance(ex, JsonRefResolverForwardLookupError):
                        # If it is a forward reference, try it again later.
                        forward_refs.append(ref)
                        # Keep a forward ref exception around.  We might
                        # re-raise it.
                        forward_ref_ex = forward_ref_ex or ex
                    else:
                        # This is a permanent resolver error.  re-raise it.
                        raise

            # If we ran into forward refs, but it still looks like we're making
            # progress, loop back up and try again.
            if len(forward_refs) > 0:
                if len(forward_refs) < len(refs):
                    # We're still making progress.  Loop again.
                    refs = forward_refs
                else:
                    # Not making progress. Stop trying.
                    raise forward_ref_ex
            else:
                # We ran out of refs.  This is a good thing.  We're done.
                break

    def _resolve_document(self, document, document_uri):
        """
        Find all refs in the `document` and resolve them.
        """
        # Find all refs in the document.
        found_refs = []
        new_document = self._find_refs(document, found_refs, document_uri)

        # Add the new version to the cache before starting.  This simple trick
        # helps us handle files that refer to each other (but not objects that
        # refer to each other).
        self._cache[document_uri] = new_document

        # Replace all those refs we found.
        self._replace_refs(found_refs, document_uri)

        return new_document


def resolve_jsonrefs(root, base_uri="", loader=None):
    """
    Resolve refs in `root`.

    Convenience function.  Creates a `JsonRefResolver` with the optional
    `base_uri` and `loader`, then uses it to resolve refs.  The result is
    returned.
    """
    return JsonRefResolver(loader).resolve(root, base_uri=base_uri)
