# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("dhcp_relay_v1", handle_verify_config)
    ctx.events.ready_apply.register("dhcp_relay_v1", handle_ready_apply)
    ctx.events.check_health.register("dhcp_relay_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """


def get_current_relay6_config(evt):
    relay_files = []
    for relay_config_file in evt.fileops.list_files("/etc/default/"):
        # we are interested in dhcp relay6 config file only
        if not relay_config_file.name.startswith('isc-dhcp-relay6-'):
            continue
        # extracting the VRF name from the dhcp config file
        # Ex: in isc-dhcp-relay6-blue, vrf is blue
        if relay_config_file.name.startswith('isc-dhcp-relay6-'):
            relay_files.append(relay_config_file.name)
    return relay_files


def get_current_relay_config(evt):
    relay_files = []
    for relay_config_file in evt.fileops.list_files("/etc/default/"):
        # we are interested in dhcp relay config file only
        if not relay_config_file.name.startswith('isc-dhcp-relay-'):
            continue
        # extracting the VRF name from the dhcp config file
        # Ex: in isc-dhcp-relay-blue, vrf is blue
        if relay_config_file.name.startswith('isc-dhcp-relay-'):
            relay_files.append(relay_config_file.name)
    return relay_files


def handle_stale_config(evt, dhcp_relay, dhcp_relay6):
    """
    Check the existing DHCP relay config files in /etc/default associated
    with particular vrf, delete them if they are not required any more.

    Args:
    dhcp_relay: current DHCP relay config received.
    dhcp_relay6: current DHCP relay6 config received.
    """
    old = get_current_relay_config(evt)
    new = []
    for vrf in dhcp_relay:
        new.append('isc-dhcp-relay-' + vrf)
    diff_v4 = set(old) - set(new)

    old = get_current_relay6_config(evt)
    new = []
    for vrf in dhcp_relay6:
        new.append('isc-dhcp-relay6-' + vrf)
    diff_v6 = set(old) - set(new)

    diff = diff_v4 | diff_v6
    if len(diff) > 0:
        evt.render(templates, "cleanup.sh", stale_configs=diff)
        evt.schedule_run_script("cleanup.sh")


def process_dhcp_relay6_config(evt, dhcp_relay):
    # get the dhcp relay config under all vrf keys
    for vrf in dhcp_relay:
        relay_conf = {}
        conf = dhcp_relay[vrf]

        options = '"'
        if conf["interface"]["upstream"]:
            intf = conf["interface"]["upstream"]
            for port in intf:
                try:
                    if intf[port]["address"]:
                        options += "-u " + intf[port]["address"] + "%" + port \
                            + " "
                except KeyError:
                    options += "-u " + port + " "
            options = options[0:-1]
        options += '"'
        relay_conf['server'] = options

        options = '"'
        if conf["interface"]["downstream"]:
            intf = conf["interface"]["downstream"]
            for port in intf:
                try:
                    if intf[port]["address"]:
                        options += "-l " + intf[port]["address"] + "%" + port \
                            + " "
                except KeyError:
                    options += "-l " + port + " "
            options = options[0:-1]
        options += '"'
        relay_conf['interface'] = options

        # creating dhcp relay config file by adding -<vrf-key>
        # under /etc/default
        path = "/etc/default/"
        relay_config_file = "isc-dhcp-relay6-"
        relay_config_file += vrf
        path += relay_config_file
        relay_service = "dhcrelay6@" + vrf

        evt.render(templates, relay_config_file, "isc-dhcp-relay6",
                   config=relay_conf)
        evt.stage_file(relay_config_file, path)
        evt.schedule_reload_or_restart(relay_service)


def process_dhcp_relay_config(evt, dhcp_relay):
    # get the dhcp relay config under all vrf keys
    for vrf in dhcp_relay:
        relay_conf = {}
        conf = dhcp_relay[vrf]

        server = '""'
        if "server" in conf:
            server = "".join(map(lambda n: n + ' ', conf['server']))
            server = '"' + server[0:-1] + '"'
        relay_conf['server'] = server

        intf = '""'
        if "interface" in conf:
            intf = "-i ".join(map(lambda n: n + ' ', conf['interface']))
            intf = '"-i ' + intf[0:-1] + '"'
        relay_conf['interface'] = intf

        options = '"'
        giintf_flag = False
        if conf["giaddress-interface"]:
            for giintf in conf['giaddress-interface']:
                giintf_flag = True
                if conf['giaddress-interface'][giintf]["address"] != "auto":
                    addr = conf['giaddress-interface'][giintf]['address']
                    options += "-U " + addr + "%" + giintf
                else:
                    options += "-U " + giintf

        if conf['source-ip'] == "giaddress":
            if giintf_flag:
                options += ' --giaddr-src'
            else:
                options += '--giaddr-src'
        options += '"'
        relay_conf['options'] = options

        # creating dhcp relay config file by adding vrf-<vrf-key>
        # under /etc/default
        path = "/etc/default/"
        relay_config_file = "isc-dhcp-relay-"
        relay_config_file += vrf
        path += relay_config_file
        relay_service = "dhcrelay@" + vrf

        evt.render(templates, relay_config_file, "isc-dhcp-relay",
                   config=relay_conf)
        evt.stage_file(relay_config_file, path)
        evt.schedule_reload_or_restart(relay_service)


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    dhcp_relay = evt.config_v1.getDhcpRelays()
    dhcp_relay6 = evt.config_v1.getDhcpRelays6()
    handle_stale_config(evt, dhcp_relay, dhcp_relay6)
    process_dhcp_relay_config(evt, dhcp_relay)
    process_dhcp_relay6_config(evt, dhcp_relay6)


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
