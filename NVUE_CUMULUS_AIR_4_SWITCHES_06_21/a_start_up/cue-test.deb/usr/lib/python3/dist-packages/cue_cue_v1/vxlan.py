# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue_cue_v1.root import root_patch
from cue.exceptions import NotFound


###############################
# VxLAN
###############################
def vxlan_get(ctx, rev):
    if rev == 'operational':
        # VxLAN config does not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getNveVxlan(rev)


def vxlan_patch(ctx, rev, body=None):
    root = {"nve": {"vxlan": body}}
    root = root_patch(ctx, rev, {"nve": {"vxlan": body}})
    nve = root.get("nve", {})
    return nve.get("vxlan", {})


def vxlan_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev)


###############################
# VxLAN Source
###############################

def vxlan_source_get(ctx, rev):
    return vxlan_get(ctx, rev)["source"]


def vxlan_source_patch(ctx, rev, body=None):
    vxlan = vxlan_patch(ctx, rev, {"source": body})
    return vxlan.get("source", {})


def vxlan_source_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev, "source")


###############################
# VxLAN MLAG
###############################

def vxlan_mlag_get(ctx, rev):
    return vxlan_get(ctx, rev)["mlag"]


def vxlan_mlag_patch(ctx, rev, body=None):
    vxlan = vxlan_patch(ctx, rev, {"mlag": body})
    return vxlan.get("mlag", {})


def vxlan_mlag_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev, "mlag")


###############################
# VxLAN Flooding
###############################

def vxlan_flooding_get(ctx, rev):
    output = vxlan_get(ctx, rev)
    try:
        return output["flooding"]
    except KeyError:
        raise NotFound


def vxlan_flooding_patch(ctx, rev, body=None):
    vxlan = vxlan_patch(ctx, rev, {"flooding": body})
    return vxlan.get("flooding", {})


def vxlan_flooding_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev,
        "flooding")


###############################
# VxLAN Flooding head-end-replications
###############################

def vxlan_hreps_get(ctx, rev):
    output = vxlan_flooding_get(ctx, rev)
    try:
        return output["head-end-replication"]
    except KeyError:
        raise NotFound


def vxlan_hreps_patch(ctx, rev, body=None):
    flooding = vxlan_flooding_patch(ctx, rev, {"head-end-replication": body})
    return flooding.get("head-end-replication", {})


def vxlan_hreps_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev,
        "flooding", "head-end-replication")


###############################
# VxLAN Flooding head-end-replication
###############################

def vxlan_hrep_get(ctx, rev, hrep_id):

    hreps = vxlan_hreps_get(ctx, rev)
    try:
        return hreps[hrep_id]
    except KeyError:
        raise NotFound


def vxlan_hrep_patch(ctx, rev, hrep_id, body=None):
    hreps = vxlan_hreps_patch(ctx, rev, {hrep_id: body})
    return hreps.get(hrep_id, {})


def vxlan_hrep_delete(ctx, rev, hrep_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNveVxlan, ctx.config_v1.setNveVxlan, rev,
        "flooding", "head-end-replication", hrep_id)
