# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.service import service_patch


###############################
# DHCP6 Servers
###############################

def servers_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getDhcpServers6(rev)

    return ctx.isc_dhcp_v1.getServers6()


def servers_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"dhcp-server6": body})
    return service["dhcp-server6"]


def servers_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServers6,
                             ctx.config_v1.setDhcpServers6, rev)


###############################
# DHCP6 Server/{vrf-id}
###############################

def server_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getDhcpServer6(rev, vrf_id)

    return ctx.isc_dhcp_v1.getServer6(vrf_id)


def server_patch(ctx, rev, vrf_id, body=None):
    servers = servers_patch(ctx, rev,
                            {vrf_id: body})
    try:
        return servers[vrf_id]
    except KeyError:
        raise NotFound


def server_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev, vrf_id)


###############################
# Server/{vrf-id}/interfaces/
###############################

def interfaces_get(ctx, rev, vrf_id):
    if rev != "operational":
        s = ctx.config_v1.getDhcpServer6(rev, vrf_id)
        return s["interface"]

    s = ctx.isc_dhcp_v1.getServer6(vrf_id)
    return s["interface"]


def interfaces_patch(ctx, rev, vrf_id, body=None):
    server = server_patch(ctx, rev, vrf_id,
                          {"interface": body})
    return server["interface"]


def interfaces_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "interface")


####################################################
# Server/{vrf-id}/interfaces/{dhcp-interface-id}
####################################################

def interface_get(ctx, rev, vrf_id, intrf_id):
    s = interfaces_get(ctx, rev, vrf_id)
    try:
        return s[intrf_id]
    except KeyError:
        raise NotFound


def interface_patch(ctx, rev, vrf_id, intrf_id, body=None):
    server = interfaces_patch(ctx, rev, vrf_id,
                              {intrf_id: body})
    return server[intrf_id]


def interface_delete(ctx, rev, vrf_id, intrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "interface", intrf_id)


###############################
# DHCP6 Server/{vrf-id}/pool
###############################

def pools_get(ctx, rev, vrf_id):
    if rev != "operational":
        s = ctx.config_v1.getDhcpServer6(rev, vrf_id)
        return s["pool"]

    s = ctx.isc_dhcp_v1.getServer6(vrf_id)
    return s["pool"]


def pools_patch(ctx, rev, vrf_id, body=None):
    server = server_patch(ctx, rev, vrf_id,
                          {"pool": body})
    return server["pool"]


def pools_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6,
                             rev, vrf_id, "pool")


###############################
# DHCP6 Server/{vrf-id}/pool
###############################

def pool_get(ctx, rev, vrf_id, pool_id):
    pools = pools_get(ctx, rev, vrf_id)
    try:
        return pools[pool_id]
    except KeyError:
        raise NotFound


def pool_patch(ctx, rev, vrf_id, pool_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "pool", pool_id, patch=body)


def pool_delete(ctx, rev, vrf_id, pool_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id)


###############################
# Pool - Domain name servers
###############################

def pool_domain_name_servers_get(ctx, rev, vrf_id, pool_id):
    pools = pools_get(ctx, rev, vrf_id)
    try:
        return pools[pool_id]['domain-name-server']
    except KeyError:
        raise NotFound


def pool_domain_name_servers_patch(ctx, rev, vrf_id, pool_id, body=None):
    pool = pool_patch(ctx, rev, vrf_id, pool_id,
                      {"domain-name-server": body})
    return pool["domain-name-server"]


def pool_domain_name_servers_delete(ctx, rev, vrf_id, pool_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id,
                             "domain-name-server")


###############################
# Pool - Domain name server
###############################

def pool_domain_name_server_get(ctx, rev, vrf_id, pool_id,
                                domain_name_server_id):
    dn_servers = pool_domain_name_servers_get(ctx, rev, vrf_id, pool_id)
    try:
        return dn_servers[domain_name_server_id]
    except KeyError:
        raise NotFound


def pool_domain_name_server_patch(ctx, rev, vrf_id, pool_id,
                                  dns_id, body=None):
    dn_servers = pool_domain_name_servers_patch(ctx, rev, vrf_id, pool_id,
                                                {dns_id: body})
    return dn_servers[dns_id]


def pool_domain_name_server_delete(ctx, rev, vrf_id, pool_id, dns_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id,
                             "domain-name-server", dns_id)


###############################
# Pool - Domain names
###############################

def pool_domain_names_get(ctx, rev, vrf_id, pool_id):
    pools = pools_get(ctx, rev, vrf_id)
    try:
        return pools[pool_id]['domain-name']
    except KeyError:
        raise NotFound


def pool_domain_names_patch(ctx, rev, vrf_id, pool_id, body=None):
    pool = pool_patch(ctx, rev, vrf_id, pool_id,
                      {"domain-name": body})
    return pool["domain-name"]


def pool_domain_names_delete(ctx, rev, vrf_id, pool_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id,
                             "domain-name")


###############################
# Pool - Domain name
###############################

def pool_domain_name_get(ctx, rev, vrf_id, pool_id, domain_name_id):
    domain_names = pool_domain_names_get(ctx, rev, vrf_id, pool_id)
    try:
        return domain_names[domain_name_id]
    except KeyError:
        raise NotFound


def pool_domain_name_patch(ctx, rev, vrf_id, pool_id,
                           domain_name_id, body=None):
    domain_names = pool_domain_names_patch(
        ctx, rev, vrf_id, pool_id,
        {domain_name_id: body})
    return domain_names[domain_name_id]


def pool_domain_name_delete(ctx, rev, vrf_id, pool_id, domain_name_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id,
                             "domain-name", domain_name_id)


###############################
# Pool - Gateways
###############################

def pool_gateways_get(ctx, rev, vrf_id, pool_id):
    pools = pools_get(ctx, rev, vrf_id)
    try:
        return pools[pool_id]["gateway"]
    except KeyError:
        raise NotFound


def pool_gateways_patch(ctx, rev, vrf_id, pool_id, body=None):
    pool = pool_patch(ctx, rev, vrf_id, pool_id, {"gateway": body})
    return pool["gateway"]


def pool_gateways_delete(ctx, rev, vrf_id, pool_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id, "gateway")


###############################
# DHCP6 Pool - Gateway
###############################

def pool_gateway_get(ctx, rev, vrf_id, pool_id, gateway_id):
    gateways = pool_gateways_get(ctx, rev, vrf_id, pool_id)
    try:
        return gateways[gateway_id]
    except KeyError:
        raise NotFound


def pool_gateway_patch(ctx, rev, vrf_id, pool_id, gateway_id, body=None):
    gateways = pool_gateways_patch(ctx, rev, vrf_id, pool_id,
                                   {gateway_id: body})
    return gateways[gateway_id]


def pool_gateway_delete(ctx, rev, vrf_id, pool_id, gateway_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id, "gateway", gateway_id)


###############################
# DHCP6 Pool - Ranges
###############################

def ranges_get(ctx, rev, vrf_id, pool_id):
    pool = pool_get(ctx, rev, vrf_id, pool_id)
    return pool["range"]


def ranges_patch(ctx, rev, vrf_id, pool_id, body=None):
    pool = pool_patch(ctx, rev, vrf_id, pool_id, {"range": body})
    return pool["range"]


def ranges_delete(ctx, rev, vrf_id, pool_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id, "range")


###############################
# DHCP6 Pool - Range
###############################

def range_get(ctx, rev, vrf_id, pool_id, range_id):
    ranges = ranges_get(ctx, rev, vrf_id, pool_id)
    try:
        return ranges[range_id]
    except KeyError:
        raise NotFound


def range_patch(ctx, rev, vrf_id, pool_id, range_id, body=None):
    ranges = ranges_patch(ctx, rev, vrf_id, pool_id, {range_id: body})
    return ranges[range_id]


def range_delete(ctx, rev, vrf_id, pool_id, range_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "pool", pool_id, "range", range_id)


###############################
# DHCP6 Pool/domain-name
###############################

def domain_names_get(ctx, rev, vrf_id):
    if rev != "operational":
        s = ctx.config_v1.getDhcpServer6(rev, vrf_id)
        return s["domain-name"]

    s = ctx.isc_dhcp_v1.getServer6(vrf_id)
    return s["domain-name"]


def domain_names_patch(ctx, rev, vrf_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "domain-name", patch=body)


def domain_names_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6,
                             rev, vrf_id, "domain-name")


######################################
# DHCP6 Pool/domain-name/
######################################

def domain_name_get(ctx, rev, vrf_id, name_id):
    domain_names = domain_names_get(ctx, rev, vrf_id)
    try:
        return domain_names[name_id]
    except KeyError:
        raise NotFound


def domain_name_patch(ctx, rev, vrf_id, name_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "domain-name", name_id, patch=body)


def domain_name_delete(ctx, rev, vrf_id, name_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "domain-name", name_id)


######################################
# DHCP6 {vrf-id}/Pool/domain-name-server/
######################################

def domain_name_servers_get(ctx, rev, vrf_id):
    if rev != "operational":
        s = ctx.config_v1.getDhcpServer6(rev, vrf_id)
        return s["domain-name-server"]

    s = ctx.isc_dhcp_v1.getServer6(vrf_id)
    return s["domain-name-server"]


def domain_name_servers_patch(ctx, rev, vrf_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "domain-name-server", patch=body)


def domain_name_servers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "domain-name-server")


def domain_name_server_get(ctx, rev, vrf_id, name_id):
    domain_name_servers = domain_name_servers_get(ctx, rev, vrf_id)
    try:
        return domain_name_servers[name_id]
    except KeyError:
        raise NotFound


def domain_name_server_patch(ctx, rev, vrf_id, name_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "domain-name-server", name_id, patch=body)


def domain_name_server_delete(ctx, rev, vrf_id, name_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "domain-name-server", name_id)


def statics_get(ctx, rev, vrf_id):
    if rev != "operational":
        s = ctx.config_v1.getDhcpServer6(rev, vrf_id)
        return s["static"]

    s = ctx.isc_dhcp_v1.getServer6(vrf_id)
    return s["static"]


def statics_patch(ctx, rev, vrf_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "static", patch=body)


def statics_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "static")


def static_get(ctx, rev, vrf_id, static_id):
    statics = statics_get(ctx, rev, vrf_id)
    try:
        return statics[static_id]
    except KeyError:
        raise NotFound


def static_patch(ctx, rev, vrf_id, static_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDhcpServer6, ctx.config_v1.setDhcpServer6, rev,
        vrf_id, "static", static_id, patch=body)


def static_delete(ctx, rev, vrf_id, static_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpServer6,
                             ctx.config_v1.setDhcpServer6, rev,
                             vrf_id, "static", static_id)
