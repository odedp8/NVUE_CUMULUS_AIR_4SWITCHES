# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.service import service_patch


###############################
# NTP
###############################

def ntps_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getNtps(rev)

    return ctx.ntp_v1.getNtpConfigurations()


def ntps_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"ntp": body})
    return service["ntp"]


def ntps_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getNtps,
                             ctx.config_v1.setNtps, rev)


###############################
# NTP/{vrf-id}
###############################

def ntp_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getNtp(rev, vrf_id)

    return ctx.ntp_v1.getNtpConfiguration(vrf_id)


def ntp_patch(ctx, rev, vrf_id, body=None):
    ntps = ntps_patch(ctx, rev, {vrf_id: body})
    return ntps[vrf_id]


def ntp_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getNtp,
                             ctx.config_v1.setNtp, rev, vrf_id)


###############################
# NTP Servers
###############################

def servers_get(ctx, rev, vrf_id):
    if rev != "operational":
        ntp = ctx.config_v1.getNtp(rev, vrf_id)
        return ntp["server"]

    return ctx.ntp_v1.getNtpServers()


def servers_patch(ctx, rev, vrf_id, body=None):
    ntp = ntp_patch(ctx, rev, vrf_id,
                    {"server": body})
    return ntp["server"]


def servers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNtp, ctx.config_v1.setNtp, rev, vrf_id, "server")


###############################
# NTP Server
###############################

def server_get(ctx, rev, vrf_id, server_id):
    servers = servers_get(ctx, rev, vrf_id)
    try:
        return servers[server_id]
    except KeyError:
        raise NotFound


def server_patch(ctx, rev, vrf_id, server_id, body=None):
    servers = servers_patch(ctx, rev, vrf_id,
                            {server_id: body})
    return servers[server_id]


def server_delete(ctx, rev, vrf_id, server_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getNtp,
                             ctx.config_v1.setNtp, rev, vrf_id,
                             "server", server_id)


###############################
# NTP Pools
###############################

def pools_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getNtp(rev, vrf_id)["pool"]

    return ctx.ntp_v1.getNtpConfiguration(vrf_id)["pool"]


def pools_patch(ctx, rev, vrf_id, body=None):
    ntp = ntp_patch(ctx, rev, vrf_id,
                    {"pool": body})
    return ntp["pool"]


def pools_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNtp, ctx.config_v1.setNtp, rev, vrf_id, "pool")


###############################
# NTP Pool
###############################

def pool_get(ctx, rev, vrf_id, server_id):
    pools = pools_get(ctx, rev, vrf_id)
    try:
        return pools[server_id]
    except KeyError:
        raise NotFound


def pool_patch(ctx, rev, vrf_id, server_id, body=None):
    pools = pools_patch(ctx, rev, vrf_id,
                        {server_id: body})
    return pools[server_id]


def pool_delete(ctx, rev, vrf_id, server_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getNtp,
                             ctx.config_v1.setNtp, rev, vrf_id,
                             "pool", server_id)
