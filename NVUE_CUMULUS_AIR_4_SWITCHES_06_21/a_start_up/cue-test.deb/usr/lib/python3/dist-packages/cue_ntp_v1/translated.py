# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


from pydash import py_
from cue.exceptions import NotFound


def ntp_configs_get(ctx):
    """
    Get the ntp config from the system
    """
    config = py_.clone_deep(ctx.ntp_v1.getNtpConfig())

    # TODO: How to deal if its empty config? Should we use
    # default vrf?
    # Make sure we have servers and pools, even if they are empty.
    for vrf in config:
        config[vrf].setdefault("server", {})
        config[vrf].setdefault("pool", {})

    return config


def ntp_config_get(ctx, vrf_id):
    try:
        return ctx.ntp_v1.getNtpConfigurations()[vrf_id]
    except KeyError:
        raise NotFound


def ntp_servers_get(ctx):
    """
    Get the ntp peers from the native
    """
    # Note: While testing FUnit, test mock passes the
    # obj, when translate modifies it, we get exception

    new_op = ctx.ntp_v1.getNtpQueryPeers()
    op = py_.clone_deep(new_op)
    resp = {}
    for peer in op:
        # Get the first char of the peer, which gives the
        # state : It can be + * - or blank space
        # Remove the state sign prefixed with the peer from
        # native layer and update according to translate format
        state = peer[0]
        p = op[peer]
        if state == '*' or state == '+' or state == '-':
            peer1 = peer[1:]
            resp.update({peer1: p})
            p = resp[peer1]
            p.update({'peer-state': state})
        else:
            peer1 = peer
            resp.update({peer1: p})
            p = resp[peer1]
            p.update({'peer-state': ' '})

    return resp
