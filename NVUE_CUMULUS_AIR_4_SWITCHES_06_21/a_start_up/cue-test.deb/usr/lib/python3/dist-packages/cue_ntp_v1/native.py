# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


def ntp_config_per_vrf_get(ctx, conf_file):
    config = {}
    s = {}
    p = {}
    f = ctx.fileops.load_file(conf_file)
    config = {}
    s_flag = False
    iburst = False
    for line in f.splitlines():
        lst = line.split()
        if lst:
            itr = iter(lst)
            if line.find('server') != -1:
                s_flag = True
            elif line.find('pool') != -1:
                s_flag = False
            elif line.find('interface') != -1:
                next(itr)
                next(itr)
                intf = next(itr)
                config.update({'listen': intf})
                continue
            next(itr)
            server = next(itr)
            if line.find('iburst') != -1:
                iburst = True
            else:
                iburst = False

            if s_flag:
                if iburst:
                    s[server] = {'iburst': 'on'}
                else:
                    s[server] = {'iburst': 'off'}
                config.update({'server': s})
            else:
                if iburst:
                    p[server] = {'iburst': 'on'}
                else:
                    p[server] = {'iburst': 'off'}
                config.update({'pool': p})

    return config


def ntp_config_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/"):
        # we are interested in NTP config file only
        if not config_file.name.startswith('ntp-'):
            continue
        # extracting the VRF name from the config file
        # Ex: in ntp-blue, vrf is blue
        vrf = config_file.name[4:-5]
        vrf_data = ntp_config_per_vrf_get(ctx, config_file)
        config_data.update({vrf: vrf_data})
    return config_data


def parse_ntp_peers(output):
    resp = {}
    flag = False
    for line in output.splitlines():
        if (flag):
            entry = {}
            count = 1
            for word in line.split():
                if count == 2 and word.startswith('('):
                    continue
                if count == 1:
                    remote = word
                    count += 1
                    continue
                if count == 2:
                    entry['refid'] = word
                    count += 1
                    continue
                if count == 3:
                    entry['stratum'] = int(word)
                    count += 1
                    continue
                if count == 4:
                    entry['type'] = word
                    count += 1
                    continue
                if count == 5:
                    entry['when'] = word
                    count += 1
                    continue
                if count == 6:
                    entry['poll'] = int(word)
                    count += 1
                    continue
                if count == 7:
                    entry['reach'] = int(word)
                    count += 1
                    continue
                if count == 8:
                    entry['delay'] = word
                    count += 1
                    continue
                if count == 9:
                    entry['offset'] = word
                    count += 1
                    continue
                if count == 10:
                    entry['jitter'] = word
                    count += 1
                    continue
            resp[remote] = entry
            continue
        if line.startswith('===='):
            flag = True
    return resp


def ntp_query_peers_get(ctx):
    output = ctx.sh.ntpq('-p')
    return parse_ntp_peers(output)
