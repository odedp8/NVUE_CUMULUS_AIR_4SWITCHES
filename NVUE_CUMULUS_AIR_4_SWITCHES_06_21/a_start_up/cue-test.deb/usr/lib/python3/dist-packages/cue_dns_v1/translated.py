# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


from cue.exceptions import NotFound


def servers_get(ctx):
    return ctx.dns_v1.getDnsNameserver()


def server_get(ctx, vrf_id, dns_server_id):
    try:
        dnss = ctx.dns_v1.getDnsNameserver()
        return dnss[vrf_id]["server"][dns_server_id]
    except KeyError:
        raise NotFound


def host_entries_get(ctx):
    # XXX Mocked
    return {
        "larry.local": {
            "alias": {},
            "ip-address": {
                "9.18.14.10": {}
            }
        },
        "curly.local": {
            "alias": {
                "not-shemp.local": {}
            },
            "ip-address": {
                "9.18.14.13": {},
                "129.22.1.8": {}
            }
        },
        "moe.local": {
            "alias": {},
            "ip-address": {
                "9.18.14.18": {}
            }
        },
    }


def host_entry_get(ctx, dns_host_entry_id):
    # XXX Mocked
    return {
        "alias": {},
        "ip-address": {
            "9.18.14.18": {}
        }
    }
