# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


def dns_nameserver_get(ctx):
    """
    Returns lists of DNS servers reading from /etc/resolv.conf
    """

    output = ctx.fileops.load_file("/etc/resolv.conf")
    # search IP address
    name_servers = {}
    for line in output.splitlines():
        if "nameserver" in line:
            word_list = line.split()
            if "vrf" in word_list:
                vrf = word_list[word_list.index("vrf") + 1]
            else:
                vrf = "mgmt"
            addr = word_list[word_list.index("nameserver") + 1]
            if vrf in name_servers.keys():
                new = name_servers[vrf]["server"]
                new.update({addr: {}})
                name_servers[vrf]["server"] = new
            else:
                s = {}
                s["server"] = {addr: {}}
                name_servers.update({vrf: s})

    return name_servers
