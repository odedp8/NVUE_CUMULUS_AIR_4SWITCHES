# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import json


def somecmd_get(ctx):
    # 1. Run some command
    output = str(ctx.sh.sudo.somecmd())

    # 2. Parse it's output.  Maybe it's already in JSON?
    result = json.loads(output)

    # 3. Return it.
    return result
