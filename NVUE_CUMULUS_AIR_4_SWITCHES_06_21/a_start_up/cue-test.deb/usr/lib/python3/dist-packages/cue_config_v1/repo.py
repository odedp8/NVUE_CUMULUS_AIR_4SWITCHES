# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Retrieve and store a config from the repository.  This is mostly just
# yaml.load() and yaml.dump(), but we'll cache a few in memory.


from cue import exceptions, utils
from . import schema
from pydash import py_
import collections
import logging


logger = logging.getLogger(__name__)


# Maximum number of repo configs we'll let hang around.
MAX_CACHED = 4


def _create_config_cache():
    """
    Return a new repo config cache.
    """
    # We'll use this as a associative LIFO.
    return collections.OrderedDict()


def prepare_repo(ctx):
    """
    Prepare the config cache.
    """
    ctx.config_v1._repo_cached_confs = _create_config_cache()


def repo_get(ctx, rev_id):
    """
    Load a config from the repo and parse it, given a rev_id.
    """
    # If it's cached, return it, but first, mark it as the most recently
    # accessed.
    cached_confs = ctx.config_v1._repo_cached_confs

    if rev_id in cached_confs:
        logger.dump("Repo cached", rev_id)
        cached_confs.move_to_end(rev_id)
        return cached_confs[rev_id]

    logger.dump("Repo loading", rev_id)

    # Get the config. This file will always exist.
    conf_txt = ctx.versions_v1.getFileRaw(rev_id, "cue.yaml")

    # Parse and put together the conf.
    try:
        # Load the configuration.
        conf = utils.yaml_load_safe(conf_txt)

        # Fill in anything that's missing.
        # - The defaults will always be missing since we only store the version
        # with the config, not the actual defaults.  When applying, we'll
        # always use this build's defaults.
        # - The repo was just initialized, cue.yaml might have been empty.
        conf = conf or {}
        py_.defaults(conf, schema.empty_config())
    except utils.ParseError as ex:
        # We can't load the cue file.  Raise an HTTP exception.
        raise exceptions.UnprocessableEntity(
            "In " + rev_id + ":cue.yaml: " + ex.description
        )

    # Add it to the cache.
    cached_confs[rev_id] = conf

    # Drop the oldest config, if we have too many.
    if len(cached_confs) > MAX_CACHED:
        cached_confs.popitem(last=False)

    return conf


def repo_put(ctx, rev_id, conf):
    """
    Save a config to the repo, given a rev_id.
    """
    logger.dump("Repo putting", rev_id)

    # Check the current state of the config.
    rev = ctx.versions_v1.getRevision(rev_id)

    # HACK: hardcode all the conflict states. There's a circular dependency
    #       issue with `apply_config.py`. We were always hardcoding which
    #       states were conflicts though. We should eventually encode that
    #       information in a more declarative way (probably in versions_v1).
    _conflict_states = [
        # "inactive" revisions are often used for keeping an audit trail. We
        # don't want to modify those unless someone explicitly set them to
        # "pending".
        "inactive",
        #########################################
        # terminal "success" states
        "applied",
        "saved",
        #########################################
        # apply_config FSM "active" states
        "apply",
        "verifying",
        "verified",
        "readying",
        "ays",
        "ays_yes",
        "ays_no",
        "ready",
        "reloading",
        "reloaded",
        "checking",
        "checked",
        "ignore_fail",
        "ignore_fail_no",
        "ignore_fail_yes",
        "confirm",
        "confirm_no",
        "confirm_yes",
        #########################################
        # save_config FSM "active" states
        "save",
        "saving",
    ]

    if rev["state"] in _conflict_states:
        raise exceptions.Conflict("rev " + rev_id + " cannot be updated")

    if rev["state"] != "pending":
        # Since we're updating the config, any failure states aren't applicable
        # anymore.
        ctx.versions_v1.updateRevision(rev_id, "pending")

    repo_put_internal(ctx, rev_id, conf)


def repo_put_internal(ctx, rev_id, conf):
    """
    Save a config to the repo, given a rev_id.
    """
    # Dump the cache, because we're writing a new version.
    clear_cached_config(ctx, rev_id)

    # Create a shallow copy of the config.
    putting_conf = dict(conf)

    # Instead of saving the whole defaults schema, just remember the version.
    # That's all we'll need for forensics.
    if "_defaults" in putting_conf:
        defaults = putting_conf["_defaults"]
        if "x-version" in defaults:
            putting_conf["_defaults_version"] = defaults["x-version"]
        del putting_conf["_defaults"]

    # Save the config
    conf_txt = utils.yaml_dump(putting_conf)
    ctx.versions_v1.setFileRaw(rev_id, "cue.yaml", contents=conf_txt)


def clear_cached_config(ctx, rev_id):
    """
    Dump the given revision from the config.
    """
    cached_confs = ctx.config_v1._repo_cached_confs

    if rev_id in cached_confs:
        del cached_confs[rev_id]
