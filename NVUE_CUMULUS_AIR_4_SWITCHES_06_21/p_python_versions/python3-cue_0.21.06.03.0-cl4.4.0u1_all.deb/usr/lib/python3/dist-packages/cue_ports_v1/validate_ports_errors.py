# Copyright 2021 NVIDIA Corporation

import re
from cue_config_v1.apply_config import AbstractEvent
from pydash import py_


"""
Error handling for errors returned by /usr/cumulus/bin/validate-ports.

To add a new error, in error_regexes: create an error handler
and add a regular expression that parses the error and map it
to the error handler.
"""


#####################
# Error Handlers
#####################
def _blocked_port_error(evt: AbstractEvent, msg: str,
                        blocked_port: str, blocking_port: str):
    """
    Handle the blocked port error returned by /usr/cumulus/bin/validate-ports

    Example:
        "64 is blocked by port 63 but is marked '2x25G' instead of "
        "disable[d]":

    Arguments:
        evt: An Event object implementing AbstractEvent
        blocked_port: The blocked port (parsed from error)
        blocking_port: The blocking port (parsed from error)

    Returns:
        Translated error string
    """

    # If the blocked port or blocking port didn't get matched
    # for some reason, return the original error message
    if not blocked_port or not blocking_port:  # pragma: no cover
        return None

    # Get the platform info from platform_v1
    model = py_.get(evt.platform_v1.getHardware(),
                    'model')

    # Need the model to generate actionable error string
    if not model:
        return None

    # Convert blocked port into a path into OM:
    # interface.<port>.link.breakout
    blocked_ifname = _get_ifname(blocked_port)
    breakout_path = f'interface.{blocked_ifname}.link.breakout'

    blocking_ifname = _get_ifname(blocking_port)

    # Get the mode of the blocking port
    mode = py_.get(evt.config_v1.getInterface(blocking_ifname),
                   'link.breakout')
    if not mode:  # pragma: no cover
        return msg

    # Generate the error string
    msg = (f'Platform {model} requires {breakout_path} to be'
           f' disabled when {mode} is configured on'
           f' {blocking_ifname}')
    return msg


####################
# Map valida-ports error regexes to handlers
error_regexes = {
    (r"(?P<blocked_port>\w+) is blocked"
     r" by port (?P<blocking_port>\w+)"): _blocked_port_error
}


def translate_port_error(evt: AbstractEvent, msg: str):
    """
    Takes an error msg returned by /usr/cumulus/bin/validate-ports
    and tries to match it with one of the known errors in error_regexes
    and then calls its handler.
    """
    global error_regexes
    err_msg = msg
    for regex, handler in error_regexes.items():
        m = re.search(regex, msg, re.ASCII)
        if m:
            translated = handler(evt, msg, **m.groupdict())
            err_msg = translated if translated else msg
    return err_msg


def _get_ifname(port):
    """
    Translate a port to an interface name
    """
    if 'p' in port:
        ifname = f'sw{port}'
    else:
        ifname = f'swp{port}'
    return ifname
