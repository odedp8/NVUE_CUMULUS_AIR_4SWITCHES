# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import json
import logging
from cue.exceptions import NotFound
from cue import utils

logger = logging.getLogger(__name__)


################################
# lldpctl
################################


def lldpctls_get(ctx):
    """
    Return the output of "lldpctl".
    """
    # Get the all neigbors using lldpctl.
    logger.info("Running 'lldpctl -f json'")
    nbr_txt = ctx.sh.sudo.lldpctl("-f", "json")

    # Load the JSON output
    try:
        result = json.loads(nbr_txt.strip())

        # Check if any neighbors exist.
        try:
            nbr_list = result["lldp"][0]["interface"]
        except KeyError:
            logger.info("Empty lldpctl output")
            nbr_list = []

    except json.JSONDecodeError:
        logger.warning("Unable to parse lldpctl output")
        nbr_list = []

    # Create a list of neighbors with a mapping
    # of interface name to interface neighbor
    objs = {}
    for nbr in nbr_list:
        # Pull the name up
        name = nbr.pop("name")

        # Add it to the response
        try:
            objs[name].append(nbr)
        except KeyError:
            objs[name] = []
            objs[name].append(nbr)

    return objs


def lldpctl_get(ctx, lldpctl_id):
    """
    Return the output of "lldpctl <lldpctl_id>".
    """
    # Get the neighbor from lldpctl.
    logger.info("Running 'lldpctl -f json'")
    nbr_txt = ctx.sh.sudo.lldpctl("-f", "json", lldpctl_id)

    # Load the JSON output.
    try:
        result = json.loads(nbr_txt.strip())

        # Check if any neighbors exist.
        try:
            nbr_list = result["lldp"][0]["interface"]
        except KeyError:
            logger.info("Empty lldpctl output")
            nbr_list = []

    except json.JSONDecodeError:
        logger.warning("Unable to parse lldpctl output")
        return []

    objs = []

    if len(nbr_list) == 0:
        raise NotFound
    else:
        for nbr in nbr_list:
            # Pull the name up
            nbr.pop("name")
            objs.append(nbr)

        # Return it as is.
        return objs


def lldpcli_config_get(ctx):
    """
    Return the output of "lldpcli show config".
    """
    logger.info("Running 'lldpcli -f json show config'")
    config = str(ctx.sh.sudo.lldpcli('-f', 'json', 'show', 'config'))

    try:
        result = json.loads(config)
    except json.JSONDecodeError:
        logger.warning("Unable to parse lldpcli show config outupt")
        return {}

    # For some reason the global lldp config object is returned
    # in json format as {'configuration': [{'config': [{ <config> }]}]}...
    # Return the data we're actually interested in.
    result = _remove_lldpcli_arrays(result)
    if ('configuration' in result and 'config' in result['configuration']):
        result = result['configuration']['config']
    else:
        logger.warning(("lldpcli show config object doesn't "
                        "have configuration: %s"), result)
        return {}

    return _massage_lldpcli_config_obj(result)


def _massage_lldpcli_config_obj(obj):
    obj = _remove_lldpcli_value_key(obj)
    obj = utils.convert_str_vals_to_int(obj)
    obj = _convert_none_to_null(obj)
    return obj


def _remove_lldpcli_arrays(obj):
    """
    Recursively remove arrays from lldpcli show config object
    that only contain one item
    """
    for key in list(obj.keys()):
        if type(obj[key]) == list:
            obj[key] = _remove_lldpcli_arrays(obj[key][0])
    return obj


def _remove_lldpcli_value_key(obj):
    """
    The json output of lldpcli show config includes
    a value key under each property we're interested in...
    remove value keyword and set the value directly
    """
    for key in list(obj.keys()):
        if 'value' in obj[key]:
            obj[key] = obj[key]['value']
        else:
            obj[key] = _remove_lldpcli_value_key(obj[key])
    return obj


def _convert_none_to_null(obj):
    for key in list(obj.keys()):
        if obj[key] == '(none)':
            obj[key] = 'null'
    return obj
