# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.

import re
from pydash import py_
from cue import utils, exceptions, config
import logging
logger = logging.getLogger("cue_netlink_v1")


############################################################
# Patterns for matching link names
############################################################
patterns = utils.format_checker.patterns
swp_pattern = patterns['swp']
sub_pattern = patterns['sub']
eth_pattern = patterns['eth']
bond_pattern = patterns['bond']
vlan_pattern = patterns['svi']
bridge_pattern = bond_pattern


############################################################
# Translation endpoints
############################################################
def interfaces_get(ctx):
    response = {}
    links = ctx.netlink_v1.getIpAddrs()
    for link in links:
        interface = _create_translated_interface(ctx, link)
        if interface:
            response[link['ifname']] = interface
    return response


def interface_get(ctx, if_id):
    links = ctx.netlink_v1.getIpAddr(if_id)
    if len(links) > 0:
        return _create_translated_interface(ctx, links[0])
    else:
        # The interface doesn't exist.
        raise exceptions.NotFound


def interface_ip_get(ctx, if_id):
    interface = interface_get(ctx, if_id)
    if interface and 'ip' in interface:
        # We can assume interface_get() always fills in "ip"
        return interface['ip']


def interface_ipv4_neighbors_get(ctx, if_id):
    ipv4_neighbors = ctx.netlink_v1.getIpv4Neighbors()
    return _translate_neighbors(ipv4_neighbors, if_id)


def interface_ipv6_neighbors_get(ctx, if_id):
    ipv6_neighbors = ctx.netlink_v1.getIpv6Neighbors()
    return _translate_neighbors(ipv6_neighbors, if_id)


def interface_vrr_get(ctx, if_id):
    links = ctx.netlink_v1.getIpAddr(if_id + "-v0")
    if not links:
        # The interface doesn't exist.
        raise exceptions.NotFound

    link = links[0]

    valid_vlan = 'link' in link and link['link'] == if_id
    if valid_vlan and _check_link_kind(link, 'macvlan'):
        return _create_vrr_object(link)

    # The interface exists, but we doesn't have VRR.  Return a representation
    # of "vrr down".
    return {
        "state": {
            "down": {}
        },
        "address": {}
    }


def interface_bridge_stp_get(ctx, if_id):
    stp_info = ctx.netlink_v1.getMstpctlBridgeDetails(if_id)
    if not stp_info:
        # STP information not found for interface
        return {}
    elif 'errorMsg' in stp_info:
        # interface invalid
        raise exceptions.NotFound

    return _convert_to_on_off(
        {'bpdu-filter': stp_info['bpdufilter port'],
            'bpdu-guard': stp_info['bpdu guard port'],
            'admin-edge': stp_info['admin edge port'],
            'auto-edge': stp_info['auto edge port'],
            'network': stp_info['network port'],
            'restrrole': stp_info['restricted role']
         })


def interface_bridge_vlans_get(ctx, if_id):
    """
    Fill in the parts of the if-bridge object we can get from
    getIfBridgeVlans().  This results in a sparse version of the bridge object.
    """
    if_vlans = ctx.netlink_v1.getIfBridgeVlans(if_id)
    if_bridge_vlan = {}
    vlans = {}
    pvid = None
    brname = None
    brlist = {}

    for vlan in if_vlans:
        if 'vlan' not in vlan:
            brlist[vlan['master']] = {}
            brname = vlan['master']
            continue
        if 'flags' in vlan:
            for flag in vlan['flags']:
                if 'Untagged' in flag:
                    pvid = vlan['vlan']
        else:
            vlans[str(vlan['vlan'])] = {}

    if vlans:
        if_bridge_vlan['domain'] = brlist
        if_bridge_vlan['domain'][brname]['vlan'] = vlans
        if pvid:
            if_bridge_vlan['domain'][brname]['untagged'] = pvid
    else:
        if pvid and brname:
            if_bridge_vlan['domain'] = brlist
            if_bridge_vlan['domain'][brname]['access'] = pvid

    return if_bridge_vlan


def interface_link_fec_get(ctx, interface_id):
    fec_data = ctx.netlink_v1.getEthtoolFec(interface_id)
    if 'configured-encodings' in fec_data:
        return fec_data['configured-encodings'].lower()
    return None


def _get_svd_enabled():
    return config.TVD_FALLBACK is None


def bridge_get(ctx):
    all_links = ctx.netlink_v1.getIpBridges()
    all_vlans = ctx.netlink_v1.getIfBridgeVlan()
    svd_enabled = _get_svd_enabled()
    domains = {}
    for link in all_links:
        if _check_link_kind(link, 'bridge') and link['ifname'] != "br_l3vni":
            info_data = py_.get(link, 'linkinfo.info_data')
            # Only get VLAN aware bridge
            if info_data['vlan_filtering'] == 1:
                res = _create_bridge_object(ctx, link, all_vlans,
                                            svd_enabled)
                domains[link['ifname']] = res
    if domains:
        return {
            'domain': domains
        }
    else:
        return {}


def mac_table_get(ctx, domain_id):
    res = {}
    mac_table_index = 0
    link_map = {}
    links = ctx.netlink_v1.getIpAddrs()
    for link in links:
        link_map[link['ifname']] = link

    # Using a separate table to map <ifname, mac> to mac_table entries
    # in order to making addition of remote VTEP destinations easier
    mt_indices = {}

    for fdb_entry in ctx.netlink_v1.getBridgeFdb(domain_id):
        ifname = fdb_entry['ifname']
        mac = fdb_entry['mac']
        mt_entry = {}

        # Try to get the index from mt_indices if it exists in order to
        # append to the remote destinations
        mt_i = mt_indices.get('{},{}'.format(ifname, mac))
        if mt_i is not None:
            mt_i = str(mt_i)

        if 'dst' in fdb_entry and mt_i is not None:
            if 'remote-dst' in res[mt_i]:
                res[mt_i]['remote-dst'][fdb_entry['dst']] = {}
            else:
                res[mt_i]['remote-dst'] = {fdb_entry['dst']: {}}
            continue
        elif 'dst' in fdb_entry and mt_i is None:
            mt_entry['remote-dst'] = {fdb_entry['dst']: {}}
        elif mt_i is not None:
            # An entry for <ifname, mac> already exists.  Might hit this
            # in the event that we process a VTEP entry before the vxlan
            # interface
            continue

        mt_entry['mac'] = mac
        mt_entry['interface'] = ifname

        if 'updated' in fdb_entry:
            mt_entry['age'] = fdb_entry['updated']
        if 'used' in fdb_entry:
            mt_entry['last-update'] = fdb_entry['used']
        if fdb_entry['state'] != '':
            mt_entry['entry-type'] = fdb_entry['state']
        if 'vlan' in fdb_entry:
            mt_entry['vlan'] = fdb_entry['vlan']
        if 'src_vni' in fdb_entry:
            mt_entry['src-vni'] = fdb_entry['src_vni']
        if 'master' in fdb_entry:
            mt_entry['bridge-domain'] = fdb_entry['master']

        if fdb_entry['ifname'] in link_map:
            link = link_map[fdb_entry['ifname']]
            if _check_link_kind(link, 'vxlan'):
                mt_entry['vni'] = py_.get(link, 'linkinfo.info_data.id')

        res[str(mac_table_index)] = mt_entry
        mt_indices['{},{}'.format(ifname, mac)] = mac_table_index
        mac_table_index += 1
    return res


def mlag_get(ctx):
    resp = {}
    mlag_info = ctx.netlink_v1.getMlagInfo()

    if mlag_info:
        if 'errorMsg' in mlag_info:
            raise exceptions.NotFound

        status = py_.get(mlag_info, 'status')
        if status:
            resp['backup'] = {status['backupIp']: {}}
            resp['mac-address'] = status['sysMac']
            resp['priority'] = status['ourPriority']

    return resp


def vrfs_get(ctx):
    response = {}
    svd_enabled = _get_svd_enabled()
    links = ctx.netlink_v1.getIpAddrs()
    for link in links:
        if _check_link_kind(link, 'vrf'):
            response[link['ifname']] = \
                _create_vrf_object(ctx, link, svd_enabled)
    response["default"] = _create_default_vrf_object(ctx)
    return response


def vrf_get(ctx, vrf_id):
    svd_enabled = _get_svd_enabled()
    if vrf_id == "default":
        return _create_default_vrf_object(ctx)

    links = ctx.netlink_v1.getIpAddr(vrf_id)
    if len(links) > 0:
        vrf = _create_vrf_object(ctx, links[0], svd_enabled)
        return vrf
    else:
        raise exceptions.NotFound


# def bridges_get(ctx):
#     response = {}
#     for link in ctx.netlink_v1.getIpBridges():
#         if _check_link_kind(link, 'bridge'):
#             # Expecting bridge ifname to be a string of characters
#             # followed by 1 or more integers
#             m = re.match(bridge_pattern, link['ifname'])
#             if m:
#                 response[m.group('id')] = _create_bridge_object(link)
#     return response


def if_link_settings_get(ctx, interface_id):
    device = {}
    ethtool_info = ctx.netlink_v1.getEthtoolInfo(interface_id)

    if ethtool_info:
        auto_negotiation = py_.get(ethtool_info,
                                   'auto-negotiation')
        duplex = py_.get(ethtool_info, 'duplex')
        speed = py_.get(ethtool_info, 'speed')

        # TODO: Get FEC.  This requires different tools depending
        # on the platform

        if auto_negotiation:
            device['auto-negotiate'] = auto_negotiation.lower()
        # When the link is down, speed and duplex are unknown
        if speed and 'Unknown' not in speed:
            device['speed'] = _translate_speed(speed)
        if duplex and 'Unknown' not in duplex:
            device['duplex'] = duplex.lower()

    return device


# def offon(src_bool):
#     """
#     Convert a boolean into off/on.  Return "on" if src is True.  Otherwise,
#     "off".
#     """
#     return "on" if src_bool else "off"


############################################################
# Functions used by endpoints to create schema objects
############################################################
def _create_translated_interface(ctx, link):
    if _check_link_kind(link, 'sub'):
        return _create_subintf_object(ctx, link)

    elif _check_link_kind(link, 'vlan'):
        return _create_vlan_object(ctx, link)

    elif _check_link_kind(link, 'bond'):
        return _create_bond_object(ctx, link)

    elif _check_link_kind(link, 'swp'):
        return _create_swp_object(ctx, link)

    elif _check_link_kind(link, 'eth'):
        return _create_eth_object(ctx, link)

    elif _check_link_kind(link, 'loopback'):
        return _create_loopback_object(ctx, link)

    # TODO: cue_v1 supprot global bridge
    # elif _check_link_kind(link, 'bridge'):
    #     return _create_bridge_object(link)

    return {}


def _create_interface_object(ctx, link, info_data):
    """Create an interface object.

    Args:
        link (dict): The link object
        info_data (link): link['info_data'].  The link info_data object
            can contian properties unique to specific interface types, such
            as bonds with their 'updelay' property.  Since bonds also call
            this function to fill in common cue_v1 attributes, its better to
            retrieve info_data in the calling funciton and pass it in here.

    Returns:
        dict: A generic interface object
    """
    info_slave_kind = py_.get(link, 'linkinfo.info_slave_kind')
    interface = {'link': {}}
    if "mtu" in link:
        interface["link"]["mtu"] = link["mtu"]
    if "operstate" in link and link['operstate'] == 'UP':
        interface["link"]["state"] = {'up': {}}
    else:
        interface["link"]["state"] = {'down': {}}

    stats = {}
    rx_stats = py_.get(link, 'stats64.rx')
    tx_stats = py_.get(link, 'stats64.tx')
    if rx_stats:
        stats['in-bytes'] = rx_stats['bytes']
        stats['in-pkts'] = rx_stats['packets']
        stats['in-errors'] = rx_stats['errors']
        stats['in-drops'] = rx_stats['dropped']

    if tx_stats:
        stats['out-bytes'] = tx_stats['bytes']
        stats['out-pkts'] = tx_stats['packets']
        stats['out-errors'] = tx_stats['errors']
        stats['out-drops'] = tx_stats['dropped']
        stats['carrier-transitions'] = tx_stats['carrier_changes']

    if stats:
        interface['link']['stats'] = stats

    if info_data:
        # This is not the same mode expected by OM.
        # OM expects either lacp or static, but there
        # are 7 different bonding modes supported

        # interface['mode'] = info_data['mode']
        if 'ad_lacp_rate' in info_data:
            interface['bond'] = {}
            interface['bond']['lacp-rate'] = info_data['ad_lacp_rate']
        if 'id' in info_data:
            interface['vlan'] = info_data['id']

    if info_slave_kind and info_slave_kind == 'bridge':
        info_slave_data = py_.get(link, 'linkinfo.info_slave_data')
        interface['bridge'] = {
            "domain": {
                "br_default": {}
            }
        }
        interface['bridge']["domain"]["br_default"] = {
            'learning': 'on' if info_slave_data['learning'] else 'off',
        }

    interface['ip'] = _create_ip_object(link)

    return interface


def _create_swp_object(ctx, link):
    info_data = py_.get(link, 'linkinfo.info_data')
    swp = _create_interface_object(ctx, link, info_data)
    swp['type'] = 'swp'

    return swp


def _create_subintf_object(ctx, link):
    info_data = py_.get(link, 'linkinfo.info_data')
    subintf = _create_interface_object(ctx, link, info_data)
    subintf['type'] = 'sub'
    subintf['base-interface'] = link['link']

    return subintf


def _create_eth_object(ctx, link):
    # Same as an swp, as far as we know
    eth = _create_swp_object(ctx, link)
    eth['type'] = 'eth'
    return eth


def _create_loopback_object(ctx, link):
    info_data = py_.get(link, 'linkinfo.info_data')
    loopback = _create_interface_object(ctx, link, info_data)
    if 'UP' in link['flags']:
        loopback['link']['state'] = {'up': {}}
    loopback['type'] = 'loopback'
    return loopback


def _create_bond_object(ctx, link):
    info_data = py_.get(link, 'linkinfo.info_data')

    bond = _create_interface_object(ctx, link, info_data)

    links = ctx.netlink_v1.getIpAddrs()
    members = _get_bond_members(links, link['ifname'])
    mlag_info = ctx.netlink_v1.getMlagInfo()
    clag_intfs = py_.get(mlag_info, 'clagIntfs')

    if info_data:
        bond.setdefault('bond', {})
        bond['bond']['up-delay'] = info_data['updelay']
        bond['bond']['down-delay'] = info_data['downdelay']
        bond['bond']['member'] = members
    if clag_intfs and link['ifname'] in clag_intfs:
        bond['bond']['mlag'] = {
            'id': clag_intfs[link['ifname']]['clagId']
        }
    bond['type'] = 'bond'

    return bond


def _create_vlan_object(ctx, link):
    info_data = py_.get(link, 'linkinfo.info_data')
    vlan = _create_interface_object(ctx, link, info_data)
    vlan['type'] = 'svi'
    return vlan


def _create_vrr_object(link):
    vrr = {}
    vrr['mac-address'] = link['address']

    addr_info = py_.get(link, 'addr_info')
    if addr_info:
        vrr['address'] = _get_addresses(addr_info)

    vrr['state'] = {"up": {}}

    return vrr


def _create_vni_dsts(ctx, fdb, vni_id):
    remote_ip = {}
    for fdb_entry in fdb:
        if fdb_entry['mac'] == "00:00:00:00:00:00" and\
                "extern_learn" not in fdb_entry['flags'] and\
                "src_vni" in fdb_entry and fdb_entry["src_vni"] == vni_id:

            # Verify it's a multicast address
            octets = fdb_entry['dst'].split(".")
            octet = int(octets[0])
            if octet >= 224 and octet <= 239:
                return fdb_entry['dst'], {}
            else:
                remote_ip[fdb_entry['dst']] = {}
    return "", remote_ip


def _create_bridge_object(ctx, link, all_vlans, svd_enabled):
    info_data = py_.get(link, 'linkinfo.info_data')

    bridge = {}
    stp = {}
    vlans = {}
    mac_learning = 'off'
    remote_ip = []
    multicast = {}

    # STP has 5 states.  0 is DISABLED.
    stp["state"] = {}
    if info_data['stp_state'] > 0:
        stp["state"]["up"] = {}
    else:
        stp["state"]["down"] = {}

    stp['priority'] = info_data['priority']

    if info_data['vlan_filtering'] == 1:
        bridge_type = "vlan-aware"

    if info_data['mcast_snooping'] == 1:
        multicast['snooping'] = {'enable': 'on'}
    else:
        multicast['snooping'] = {'enable': 'off'}
    if info_data['mcast_querier'] == 1:
        multicast['snooping']['querier'] = {'enable': 'on'}
    else:
        multicast['snooping']['querier'] = {'enable': 'off'}

    for if_vlan in all_vlans:
        if if_vlan['ifname'] == link['ifname']:
            continue
        if_link = ctx.netlink_v1.getIpBridge(if_vlan['ifname'])[0]
        if _check_link_kind(if_link, 'bridge'):
            continue
        if if_link['master'] != link['ifname']:
            continue

        fdb = ctx.netlink_v1.getBridgeFdb(if_vlan['ifname'], 'dev')
        if _check_link_kind(if_link, 'vxlan'):
            if svd_enabled:
                info = if_link['linkinfo']['info_slave_data']
                if 'learning' in info:
                    if info['learning'] is False:
                        mac_learning = 'off'
                    else:
                        mac_learning = 'on'
                for tunnel in ctx.netlink_v1.getIfBridgeVlanTunnels(
                        if_vlan['ifname']):
                    vlan_id = tunnel["vlan"]
                    vni_id = tunnel["tunid"]
                    if "vlanEnd" in tunnel:
                        for vlan_id in range(tunnel["vlan"],
                                             tunnel["vlanEnd"] + 1):
                            vni = {}
                            vni[str(vni_id)] = {'mac-learning': mac_learning}
                            multicast_group, remote_ip = _create_vni_dsts(
                                ctx, fdb, vni_id)
                            if multicast_group:
                                vni[str(vni_id)]['flooding'] = {
                                    'multicast-group': multicast_group
                                }
                            elif remote_ip:
                                vni[str(vni_id)]['flooding'] = \
                                    {'head-end-replication': remote_ip}
                            vlans[str(vlan_id)] = {'vni': vni}
                            vni_id += 1
                    else:
                        vni = {}
                        vni[str(vni_id)] = {'mac-learning': mac_learning}
                        multicast_group, remote_ip = _create_vni_dsts(
                            ctx, fdb, vni_id)
                        if multicast_group:
                            vni[str(vni_id)]['flooding'] = {
                                'multicast-group': multicast_group
                            }
                        elif remote_ip:
                            vni[str(vni_id)]['flooding'] = \
                                {'head-end-replication': remote_ip}
                        vlans[str(vlan_id)] = {'vni': vni}
                continue
        for vlan in if_vlan['vlans']:
            # The L3 VNI reserved VLAN range will be handled
            # at the VRF level. Those VLANS are being ignored here.
            vni = {}
            remote_ip = {}
            if _check_link_kind(if_link, 'vxlan') and not svd_enabled:
                info = if_link['linkinfo']['info_data']
                vni_id = str(info['id'])
                vni[vni_id] = {}

                if 'learning' in info:
                    if info['learning'] is False:
                        vni[vni_id]['mac-learning'] = 'off'
                    else:
                        vni[vni_id]['mac-learning'] = 'on'

                if 'group' in info:
                    vni[vni_id]['flooding'] = {'multicast-group':
                                               info['group']}
                else:
                    for fdb_entry in ctx.netlink_v1.getBridgeFdb(
                            if_vlan['ifname'], 'dev'):
                        if fdb_entry['mac'] == "00:00:00:00:00:00":
                            remote_ip[fdb_entry['dst']] = {}
                    if remote_ip:
                        vni[vni_id]['flooding'] = {'head-end-replication':
                                                   remote_ip}

                vlans[str(vlan['vlan'])] = {'vni': vni}

    # Commented until we add support for stats capture.
    # bridge['capture-multicast-statistics']:
    #     True if info_data['mcast_stats_enabled'] else False,
    # bridge['capture-vlan-statistics']:
    #     True if info_data['vlan_stats_enabled'] else False,

    bridge['stp'] = stp
    bridge['encap'] = info_data['vlan_protocol']
    bridge['type'] = bridge_type
    if vlans:
        bridge['vlan'] = vlans
    bridge['multicast'] = multicast

    return bridge


def _create_default_vrf_object(ctx):
    vrf = {'table': 254}

    # Use 'lo' ip vrf data to fill in ip structure for the default vrf.
    # Ifupdown2 prohibits 'lo' from being placed in another vrf.
    links = ctx.netlink_v1.getIpAddr('lo')
    if len(links) > 0:
        vrf['loopback'] = {'ip': _create_ip_object(links[0])}
    return vrf


def _create_vrf_object(ctx, link, svd_enabled):
    info_data = py_.get(link, 'linkinfo.info_data')
    vrf = {'table': info_data['table']}
    vrf['loopback'] = {'ip': _create_ip_object(link)}
    evpn = _create_vrf_evpn_object(ctx, link['ifname'], svd_enabled)
    if evpn:
        vrf['evpn'] = evpn
    return vrf


def _create_vrf_evpn_object(ctx, ifname, svd_enabled):
    all_vlans = ctx.netlink_v1.getIfBridgeVlan()
    vrf_evpn = {}
    vlans = {}
    for if_vlan in all_vlans:
        if_link = ctx.netlink_v1.getIpBridge(if_vlan['ifname'])[0]
        if _check_link_kind(if_link, 'vxlan'):
            if svd_enabled:
                for tunnel in ctx.netlink_v1.getIfBridgeVlanTunnels(
                        if_vlan['ifname']):
                    vlan_id = tunnel["vlan"]
                    vni_id = tunnel["tunid"]
                    if "vlanEnd" in tunnel:
                        for vlan_id in range(tunnel["vlan"],
                                             tunnel["vlanEnd"] + 1):
                            vni = {}
                            vlans[str(vlan_id)] = {'vni': vni}
                            svi_name = "vlan{}_l3".format(vlan_id)
                            link = ctx.netlink_v1.getIpBridge(svi_name)
                            if not link:
                                continue
                            vlan_link = link[0]
                            if vlan_link['master'] != ifname:
                                vni_id += 1
                            else:
                                vrf_evpn['vni'] = {str(vni_id): {}}
                                vrf_evpn['vlan'] = vlan_id
                                return vrf_evpn
                    else:
                        svi_name = "vlan{}_l3".format(vlan_id)
                        link = ctx.netlink_v1.getIpBridge(svi_name)
                        if not link:
                            continue
                        vlan_link = link[0]
                        if vlan_link['master'] == ifname:
                            vrf_evpn['vni'] = {str(vni_id): {}}
                            vrf_evpn['vlan'] = vlan_id
                            return vrf_evpn
            else:
                for vlan in if_vlan['vlans']:
                    svi_name = "vlan{}_l3".format(vlan['vlan'])
                    link = ctx.netlink_v1.getIpBridge(svi_name)
                    if not link:
                        continue
                    vlan_link = link[0]
                    if vlan_link['master'] == ifname:
                        vrf_evpn['vni'] = {
                            str(if_link['linkinfo']['info_data']['id']): {}
                        }
                        vrf_evpn['vlan'] = vlan['vlan']
                        return vrf_evpn


def _create_ip_object(link):
    addr_info = py_.get(link, 'addr_info')
    ip = {'address': {}}
    if addr_info:
        addresses = _get_addresses(addr_info)
        # if-ip schema accepts single address/prefix or list of address/prefix
        ip['address'] = addresses
    return ip


############################################################
# Utilities to aid translation
############################################################
def _check_link_kind(link, kind):
    info_kind = py_.get(link, 'linkinfo.info_kind')
    # subinterfaces are vlans so we have to check this before
    # checking if vlan or we'll create a vlan object
    if (kind == 'sub'
        and re.match(sub_pattern, link['ifname'])
        and info_kind
            and info_kind == 'vlan'):
        return True

    elif info_kind and info_kind == kind:
        return True

    elif kind == 'swp' and re.match(swp_pattern, link['ifname']):
        return True

    elif kind == 'eth' and re.match(eth_pattern, link['ifname']):
        return True

    elif kind == 'loopback' and link['link_type'] == 'loopback':
        return True

    return False


def _get_bond_members(links, master):
    members = {}
    for link in links:
        if 'master' in link and link['master'] == master:
            members[link['ifname']] = {}
    return utils.sorted_dict(members)


def _get_addresses(addr_info):
    addresses = {}
    for obj in addr_info:
        address = '{}/{}'.format(obj['local'], obj['prefixlen'])
        # Don't include link local address
        if not address.startswith('fe80'):
            addresses[address] = {}
    return utils.sorted_dict(addresses)


def _translate_speed(speed):
    """
    Translate the link speed into a CUE recognized speed

    The translated speed should be one of:
        100M, 1G, 10G, 25G, 40G, 50G, 100G
    """
    speed = speed.strip('Mb/s')
    if speed == '100':
        speed += 'M'
    else:
        # Convert Mb to Gb
        speed = str(int(speed) // 1000) + 'G'

    return speed


def _convert_to_on_off(obj):
    for key, val in obj.items():
        if val in ['yes', 'no']:
            obj[key] = 'on' if val == 'yes' else 'off'
    return obj


def _translate_neighbors(neighbors, if_id):
    if_nbrs = {}
    for n in neighbors:
        if 'dev' in n and n['dev'] == if_id:
            if 'dst' in n:
                ip_addr = n['dst']
            nbr = if_nbrs[ip_addr] = {'state': {}}

            if 'lladdr' in n:
                nbr['lladdr'] = n['lladdr']

            for s in n['state']:
                nbr['state'][s.lower()] = {}

            flag = nbr['flag'] = {}
            if 'router' in n:
                flag['is-router'] = {}
            if 'extern_learn' in n:
                flag['ext-learn'] = {}

    return if_nbrs


def _get_system_id_from_sysmac(sysmac):
    """
    Convert the last 2 bytes of sysmac to integer for system id
    """
    return int(sysmac[-5:].replace(':', ''), base=16)
