# Copyright (C) 2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue import utils
import configparser
import logging
from pydash import py_


logger = logging.getLogger(__name__)
PTP4L_CONF = "/etc/ptp4l.conf"


def ptp4l_conf_raw_get(ctx):
    return ctx.fileops.load_file(PTP4L_CONF)


def ptp4l_conf_get(ctx):
    """
    Parse the ptp4l.conf file.

    The format is pretty close to an INI format, so we can use
    Python's configparser module.
    """
    parser = configparser.ConfigParser(
        # Use space delimiters between key and value.
        delimiters=[' '],
        # Allow a key to be repeated
        strict=False,
        # Don't try to interpolate
        interpolation=None,
        # When a key is repeated, keep all the values.
        dict_type=utils.MultiDict
    )

    # Don't modify the case in attributes
    parser.optionxform = str

    # Don't try to join multiline values.  We want to do that ourselves.
    parser._join_multiline_values = lambda: None

    # Parse the file.
    try:
        parser.read_string(
            ctx.linuxptp_v1.getRawPtp4lConf(), source=PTP4L_CONF)
    except configparser.ParsingError as ex:
        logger.info("Failed to parse %s: %s", PTP4L_CONF, str(ex)) # noqa

        # Treat a bad file as an empty file.
        return {}

    # Convert it into a dictionary of dictionaries and return.  This isn't as
    # simple as it could be because ptp4l breaks the INI rules and repeats
    # keys.  We look for those repeats and handle them.
    res = {}
    for section_name in parser.sections():
        res[section_name] = res_section = {}

        # Loop through the items and clean each up.  We need to do what
        # parser._join_multiline_values() does, but while being aware of
        # repeated keys
        for item_name, value in parser.items(section_name):
            if isinstance(value, utils.MultiDict.MultiList):
                # Multiple values found for this item.  Flatten each
                # and return as a list.
                res_section[item_name] = res_value = []
                for sub_value in value:
                    joined = "".join(sub_value)
                    if joined:
                        res_value.append(joined)
            else:
                res_section[item_name] = "".join(value)

    # Parse acceptable-master, if we have any.  This is configured as a
    # compound, space delimited field.
    try:
        amt = res["acceptable_master_table"]
        orig_cis = amt["acceptable_master_clockIdentity"]
        amt["acceptable_master_clockIdentity"] = cis = []

        for ci in orig_cis:
            tokens = ci.split()
            if len(tokens) == 2:
                cis.append({"clock_id": tokens[0], "alt_priority": tokens[1]})
    except KeyError:
        pass

    return res


def int_offon(obj, key):
    return 'on' if int(py_.get(obj, key, 0)) == 1 else 'off'


def cuev1_ptp_get(ctx):
    """
    Fill in the global ptp object using ptp4l.conf.
    """
    ptp4l_conf = ctx.linuxptp_v1.getPtp4lConf()
    ptp = {}

    try:
        if ptp4l_conf:
            ptp["domain"] = int(py_.get(ptp4l_conf, "global.domainNumber", 0))
            ptp["ip-dscp"] = int(py_.get(ptp4l_conf, "global.dscp_event", 0))
            ptp["priority1"] = int(
                py_.get(ptp4l_conf, "global.priority1", 128))
            ptp["priority2"] = int(
                py_.get(ptp4l_conf, "global.priority2", 128))
            ptp["two-step"] = int_offon(ptp4l_conf, "global.twoStepFlag")

            ptp["monitor"] = mon = {}
            mon["min-offset-threshold"] = int(
                py_.get(ptp4l_conf,
                        "global.offset_from_master_min_threshold", -200)
            )
            mon["max-offset-threshold"] = int(
                py_.get(ptp4l_conf,
                        "global.offset_from_master_max_threshold", 200)
            )
            mon["path-delay-threshold"] = int(
                py_.get(ptp4l_conf,
                        "global.mean_path_delay_threshold", 1)
            )

            # TODO CUE-4775: Parse profile-type and message-mode

            ptp["acceptable-master"] = {}
            am_key = "acceptable_master_table.acceptable_master_clockIdentity"
            for am in py_.get(ptp4l_conf, am_key, []):
                # Convert clock-id from ptp4l format: 248a07.fffe.f41606
                # Into OM format: 24:8a:07:ff:fe:f4:16:06
                clock_id = am["clock_id"].replace(".", "")
                parts = [clock_id[i:i + 2] for i in range(0, len(clock_id), 2)]
                clock_id = ":".join(parts)

                alt_priority = am["alt_priority"]
                ptp["acceptable-master"][clock_id] = {
                    "alt-priority": int(alt_priority)
                }
    except Exception:
        # Pretend we didn't have a config at all
        return {}

    return ptp


def cuev1_if_ptps_get(ctx):
    """
    Fill in the interface ptp objects using ptp4l.conf.
    """
    ptp4l_conf = ctx.linuxptp_v1.getPtp4lConf()
    if_ptps = {}

    if not ptp4l_conf:
        return if_ptps

    try:
        for section_name, section in ptp4l_conf.items():
            # Skip sections that we know are not interfaces
            if section_name in ("global", "unicast_master_table",
                                "acceptable_master_table"):
                continue

            # Try to treat other sections as interfaces.
            if_ptp = {}
            if_ptps[section_name] = {"service": {"ptp": if_ptp}}

            if_ptp["forced-master"] = int_offon(section, "masterOnly")
            if_ptp["ttl"] = int(py_.get(section, "udp_ttl", 1))

            dm = py_.get(section, "delay_mechanism", "E2E")
            if dm == "E2E":
                if_ptp["delay-mechanism"] = "end-to-end"

            transport = py_.get(section, "network_transport", "UDPv4")
            if transport == "UDPv4":
                if_ptp["transport"] = "ipv4"
            elif transport == "UDPv6":
                if_ptp["transport"] = "ipv6"
            elif transport == "L2":
                if_ptp["transport"] = "802.3"

            # TODO CUE-4775: Parse profile-type and message-mode

            if_ptp["timers"] = timers = {}
            timers["announce-interval"] = \
                int(py_.get(section, "logAnnounceInterval", 0))
            timers["sync-interval"] = \
                int(py_.get(section, "logSyncInterval", -3))
            timers["delay-req-interval"] = \
                int(py_.get(section, "logMinDelayReqInterval", -3))
            timers["announce-timeout"] = \
                int(py_.get(section, "announceReceiptTimeout", 3))
    except Exception:
        # Pretend we didn't have a config at all
        return {}

    return if_ptps
