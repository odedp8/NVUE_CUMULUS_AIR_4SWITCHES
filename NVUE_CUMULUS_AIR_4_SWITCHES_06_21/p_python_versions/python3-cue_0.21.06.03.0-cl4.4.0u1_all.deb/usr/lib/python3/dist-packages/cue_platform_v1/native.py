# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.

import logging
import json
import functools
import re
import os
from pydash import py_
from datetime import timedelta
from pathlib import Path
from cue import utils

logger = logging.getLogger(__name__)


def _parse_platform_detect(output):
    splitlist = output.split(",")
    if splitlist[0] != output:
        return {'platform': output,
                'manufacturer': splitlist[0],
                'model': splitlist[1]}
    else:
        return {}


def platform_detect_get(ctx):
    response = {}
    try:
        output = str(ctx.sh.platform_detect()).strip()
        response = _parse_platform_detect(output)
    except Exception:
        logger.exception("Failed to retrieve platform-detect")

    return response


def _platform_info_dirs():
    return (
        "/usr/share/cumulus-platform/common/platform-info/",
        "/usr/share/cumulus/platform-info/"
    )


def platforms_get(ctx):
    response = {}

    # Create a database of platform information.  We have to do this because
    # manufacturer/model is not always listed in the expected json file.
    json_dirs = _platform_info_dirs()

    for directory in json_dirs:
        if not os.path.isdir(directory):
            continue

        for filename in os.listdir(directory):
            json_file_path = Path(directory) / filename
            if not os.path.isfile(json_file_path):
                continue

            data = ctx.fileops.load_file(json_file_path)
            platform_info = json.loads(data)
            py_.merge(response, platform_info)

    return response


# We can assume the port modes will not change without a cued restart.  Cache
# the return from portmodes.py and save some forks.
@functools.lru_cache()
def portmodes_get(ctx):
    cmd = "/usr/lib/python2.7/dist-packages/cumulus/portmodes.py"
    try:
        portmodes_cmd = ctx.sh.Command(cmd)
        output = str(portmodes_cmd())
        port_modes = json.loads(output)
        return port_modes
    except Exception:
        return {}


def platform_os_get(ctx):
    response = {}
    try:
        os_release = ctx.fileops.load_file("/etc/os-release")
    except IOError:
        logger.exception("Could not determine os-release.")
        os_release = None
    if os_release is not None:
        os_name = re.search(
            r'''^\s*NAME\s*=\s*"(.+)"''',
            os_release, re.IGNORECASE | re.MULTILINE)
        if os_name is not None:
            os_name = os_name.group(1)
            response['name'] = os_name

        os_version = re.search(
            r'''^\s*VERSION\s*=\s*"(.+)"''',
            os_release, re.IGNORECASE | re.MULTILINE)
        if os_version is not None:
            os_version = os_version.group(1)
            response['version'] = os_version

        os_version_id = re.search(
            r"""^\s*VERSION_ID\s*=\s*(.+)""",
            os_release, re.IGNORECASE | re.MULTILINE)
        if os_version_id is not None:
            os_version_id = os_version_id.group(1)
            response['version ID'] = os_version_id
    return response


def platform_uptime_get(ctx):
    response = {}
    try:
        uptime_read = ctx.fileops.load_file("/proc/uptime")
        uptime = str(timedelta(seconds=float(uptime_read.split()[0])))
        response['uptime'] = uptime
        return response
    except Exception:
        logger.exception("Could not determine uptime.")
        return {}


def platform_hostname_get(ctx):
    response = {}
    cmd = "/bin/hostname"
    try:
        hostname_cmd = ctx.sh.Command(cmd)
        output = str(hostname_cmd())
        hostname = output.rstrip()
        response['hostname'] = hostname
        return response
    except Exception:
        logger.exception("Could not retrieve hostname.")
        return {}


def platform_cpu_get(ctx):
    response = {}
    try:
        cpu_arr = str(ctx.sh.lscpu("--json"))
        output = json.loads(cpu_arr)
    except Exception:
        logger.exception("Could not retrieve cpu info.")
        return {}
    lscpu = output['lscpu']
    for elem in lscpu:
        if elem['field'] == 'Architecture:':
            response['Architecture'] = elem['data']
        if elem['field'] == 'CPU(s):':
            response['CPU Count'] = int(elem['data'])
        if elem['field'] == 'Model name:':
            response['Model Name'] = elem['data']
    return response


def platform_memory_get(ctx):
    try:
        meminfo = ctx.fileops.load_file("/proc/meminfo")
    except IOError:
        logger.exception("Could not get info about memory.")
        return {}

    response = {}
    for line in meminfo.splitlines():
        if line.startswith('MemTotal'):
            response['total'] = line.split(':')[1].strip()
        if line.startswith('MemFree'):
            response['free'] = line.split(':')[1].strip()
        if line.startswith('MemAvailable'):
            response['available'] = line.split(':')[1].strip()

    return response


def platform_disk_get(ctx):
    response = {}
    cmd = '/usr/bin/lsblk --json'
    try:
        disk_cmd = ctx.sh.Command(cmd)
        disk_arr = str(disk_cmd())
        output = json.loads(disk_arr)
    except Exception:
        logger.exception("Cannot get the block devices.")
        return {}
    lsblk = output['blockdevices']
    for elem in lsblk:
        if elem['name'] == 'sda':
            response['size'] = elem['size']
            response['d_type'] = elem['type']
            response['name'] = elem['name']
    return response


def platform_disk_s_get(ctx):
    response = {}
    command = '/usr/bin/lsblk -S --json'
    try:
        disk_command = ctx.sh.Command(command)
        disk_array = str(disk_command())
        output_info = json.loads(disk_array)
    except Exception:
        logger.exception("Cannot get the block info.")
        return {}
    lsblk_s = output_info['blockdevices']
    for elem in lsblk_s:
        if elem['name'] == 'sda':
            response['transport'] = elem['tran'].strip()
            response['model'] = elem['model'].strip()
            response['vendor'] = elem['vendor'].strip()
            response['rev'] = elem['rev'].strip()
    return response


def platform_eeprom_get(ctx):
    response = {}
    try:
        output = str(ctx.sh.decode_syseeprom("--json"))
        response['eeprom'] = json.loads(output)
        return response
    except Exception:
        logger.exception("Can't get eeprom info.")
        return {}


def platform_led_get(ctx):
    try:
        output = str(ctx.sh.ledmgrd("-j"))
        led_dict = json.loads(output)
        return led_dict
    except Exception:
        logger.exception("Could not get led info.")
        return {}


def platform_asic_get(ctx):
    cmd = "/usr/cumulus/bin/cl-resource-query -j"
    try:
        asic_cmd = ctx.sh.Command(cmd)
        output = str(asic_cmd())
        asic_dict = json.loads(output)
        return asic_dict
    except Exception:
        logger.exception("Could not get asic info.")
        return {}


def platform_sensors_get(ctx):
    try:
        output = str(ctx.sh.smonctl("-j"))
        sensors_dict = json.loads(output)
        return sensors_dict
    except Exception:
        logger.exception("Could not get sensors info.")
        return {}


def platform_pluggables_get(ctx):
    cmd = "sudo /sbin/ethtool -m swp1"
    try:
        pluggables_cmd = ctx.sh.Command(cmd)
        output = str(pluggables_cmd())
        return output
    except Exception:
        logger.exception("Could not get info.")
        return None


def platform_fans_get(ctx):
    try:
        output = str(ctx.sh.smonctl("-v", "-j"))
        fans_dict = json.loads(output)
        return fans_dict
    except Exception:
        logger.exception("Could not get info about fans.")
        return {}


def platform_linecards_get(ctx):
    try:
        response = platform_detect_get(ctx)
        if response['model'] == 'vx':
            logger.debug("We are on VX")
            return {}
        if response['model'].find('msn4800') != -1:
            output = str(ctx.sh.chassismgrctl(
                "-l", "all", "-s", "detail", "-j"))
            res = json.loads(output)
            return res

        return {}

    except Exception:
        logger.exception("Could not get info about linecards.")
        return {}


IFUPDOWN2_POLICY_DIRS = [
    Path('/var/lib/ifupdown2/policy.d'),
    Path('/etc/network/ifupdown2/policy.d'),
]


def ifupdown2_policy_get(ctx):
    """
    Return the ifupdown2 policy.

    It may seem strange to return the ifupdown2 policies from the platform
    module.  However, we're using these policies to set the platform's behavior
    and capabilities, which very much makes it a platform thing.
    """
    policies = {}
    policy_files = []

    for policy_dir in IFUPDOWN2_POLICY_DIRS:
        try:
            policy_files.extend(
                [Path(f) for f in ctx.fileops.list_files(policy_dir)]
            )
        except FileNotFoundError:
            pass

    for file_path in policy_files:
        if not file_path.name.endswith(".json"):
            continue

        try:
            data = utils.json_load(file_path)
        except utils.ParseError:
            # Ignore any policy files we can't read.
            logger.info("Unable to load ifupdown2 policy %s", file_path)
            continue

        py_.merge(policies, data)

    return policies


def systemctl_is_active_get(ctx, service_id):
    """
    Get the status of the given service.
    """
    try:
        return str(ctx.sh.systemctl("is-active", service_id)).strip()
    except Exception:
        return "unknown"


def system_mac_get(ctx):
    """
    Try to load the system mac from /run/system_mac.

    If the file doesn't exist or it can't be loaded this
    will return None.
    """
    return ctx.fileops.load_file('/run/system_mac',
                                 default='').strip('\n')


def platform_reboot_reason_get(ctx):
    path = "/var/reset-reason/previous-reset-reason.json"
    try:
        output = ctx.fileops.load_file(path)
    except FileNotFoundError:
        # We're probably running on a platform that doesn't support reboot
        # reason. That's cool. Pretend like we got an empty JSON object.
        output = "{}"
    return json.loads(output)


REBOOT_HISTORY_DIRS = [
    Path('/var/reset-reason/history/'),
]


def platform_reboot_history_get(ctx):
    reason_files = []
    for reset_dir in REBOOT_HISTORY_DIRS:
        try:
            reason_files.extend([
                Path(f)
                for f in ctx.fileops.list_files(reset_dir)
                if f.name.endswith('.json')
            ])
        except NotADirectoryError:
            # This case is probably a bug somewhere else on the system. Log it
            # as an error to increase likelihood of getting a bug report.
            logger.error('%s is not a directory.', reset_dir)
        except FileNotFoundError:
            # This means we're probably running on VX or a platform that
            # doesn't support reboot history, which is totally fine.
            pass

    reasons = sorted(
        [
            utils.json_load(file_path)
            for file_path in reason_files
        ],
        # Sort by date.
        key=lambda reason: reason.get('gen_time'),
        # Put more recent items first.
        reverse=True,
    )

    return {
        (idx + 1): reason
        for idx, reason in enumerate(reasons)
    }
