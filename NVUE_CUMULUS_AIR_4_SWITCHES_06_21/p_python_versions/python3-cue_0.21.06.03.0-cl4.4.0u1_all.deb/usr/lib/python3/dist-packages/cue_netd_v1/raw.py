# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from connexion.decorators.validation import problem
from unittest.mock import ANY


AVAILABLE_SHOW_COMMANDS = (

    # Ticket numbers are the tickets in get the changes in place to
    # 'retire' the legacy commands

    # ------------------------------------------------------------------------
    # CUE-4802 retire: 'net show lldp [<interface>] ...'
    # ------------------------------------------------------------------------
    # net show lldp [<interface>] [json]
    ["lldp"],
    ["lldp", "json"],
    ["lldp", ANY],
    ["lldp", ANY, "json"],

    # ------------------------------------------------------------------------
    # CUE-4579  retire: net show counters
    # ------------------------------------------------------------------------
    # net show counters [json]
    ["counters"],
    ["counters", "json"],

    # ------------------------------------------------------------------------
    # CUE-4760 retire: 'net show pluggables'
    # ------------------------------------------------------------------------
    # net show interface pluggables [json]
    ["interface", "pluggables"],
    ["interface", "pluggables", "json"],

    # ------------------------------------------------------------------------
    # CUE-4761 retire: 'net show interface'
    # CUE-4762 retire: 'net show interface all [mac]'
    # CUE-4763 retire: 'net show interface (bonds|bondmems) [mac]
    # ------------------------------------------------------------------------
    # net show interface
    # net show interface (all|bonds|bondmems) [mac|json]
    ["interface"],
    ["interface", "json"],
    ["interface", "all"],
    ["interface", "all", "json"],
    ["interface", "all", "mac"],
    ["interface", "bonds"],
    ["interface", "bonds", "json"],
    ["interface", "bonds", "mac"],
    ["interface", "bondmems"],
    ["interface", "bondmems", "json"],
    ["interface", "bondmems", "mac"],

    # ------------------------------------------------------------------------
    # CUE-4764 retire: 'net show interface <interface> [detail]'
    # ------------------------------------------------------------------------
    # net show interface [<interface>] [json]
    # net show interface <interface> detail [json]
    ["interface", ANY],
    ["interface", ANY, "json"],
    ["interface", ANY, "detail"],
    ["interface", ANY, "detail", "json"],

    # ------------------------------------------------------------------------
    # CUE-4765 retire: 'net show system'
    # ------------------------------------------------------------------------
    # net show system [json]
    ["system"],
    ["system", "json"],

    # ------------------------------------------------------------------------
    # CUE-4766 retire: 'net show system leds'
    # ------------------------------------------------------------------------
    # net show sysem leds [json]
    ["system", "leds"],
    ["system", "leds", "json"],

    # ------------------------------------------------------------------------
    # CUE-4767 retire: 'net show system ztp [script]'
    # ------------------------------------------------------------------------
    # net show system ztp [json]
    # net show system ztp script
    ["system", "ztp"],
    ["system", "ztp", "json"],
    ["system", "ztp", "script"],

    # ------------------------------------------------------------------------
    # CUE-4903 retire: 'net show system sensors ...'
    # ------------------------------------------------------------------------
    # net show system sensors [json]
    # net show sysem sensors detail [json]
    ["system", "sensors"],
    ["system", "sensors", "json"],
    ["system", "sensors", "detail"],
    ["system", "sensors", "detail", "json"],

    # ------------------------------------------------------------------------
    # CUE-4796 retire: ‘net show system asic’
    # ------------------------------------------------------------------------
    # net show system asic [json]
    ["system", "asic"],
    ["system", "asic", "json"],

    # ------------------------------------------------------------------------
    # CUE-4797  'net show neighbor [<interface>] [ipv4|ipv6|<ipv4>|<ipv6>]'
    # ------------------------------------------------------------------------
    # net show neighbor [<interface>] [ipv4|ipv6|<ipv4>|<ipv6>] [json]
    ["neighbor"],
    ["neighbor", "json"],
    ["neighbor", ANY],
    ["neighbor", ANY, "json"],

    # ------------------------------------------------------------------------
    # CUE-4798 retire: 'net show time [zone]'
    # ------------------------------------------------------------------------
    # net show time [zone] [json]
    ["time"],
    ["time", "json"],
    ["time", "zone"],
    ["time", "zone", "json"],

    # ------------------------------------------------------------------------
    # CUE-4799 retire: 'net show bridge ...'
    # ------------------------------------------------------------------------
    # net show bridge vlan [<number>] [json]
    ["bridge", "vlan"],
    ["bridge", "vlan", "json"],
    ["bridge", "vlan", ANY],
    ["bridge", "vlan", ANY, "json"],

    # net show bridge macs [<mac>|vlan <number>|<ip>|permanent|dynamic] [json]
    ["bridge", "macs"],
    ["bridge", "macs", "json"],
    ["bridge", "macs", ANY],
    ["bridge", "macs", ANY, "json"],
    ["bridge", "macs", "vlan", ANY],
    ["bridge", "macs", "vlan", ANY, "json"],
    ["bridge", "macs", ANY],
    ["bridge", "macs", ANY, "json"],
    ["bridge", "macs", "permanent"],
    ["bridge", "macs", "permanent", "json"],
    ["bridge", "macs", "dynamic"],
    ["bridge", "macs", "dynamic", "json"],

    # net show bridge spanning-tree [<interface>] [json]
    ["bridge", "spanning-tree"],
    ["bridge", "spanning-tree", "json"],
    ["bridge", "spanning-tree", ANY],
    ["bridge", "spanning-tree", ANY, "json"],

    # net show bridge spanning-tree detail [json]
    ["bridge", "spanning-tree", "detail"],
    ["bridge", "spanning-tree", "detail", "json"],

    # ------------------------------------------------------------------------
    # retire: net show bridge with CUE-4146 MDB Dump (show)
    # ------------------------------------------------------------------------
    # net show bridge (link|mdb)
    ["bridge", "link"],
    ["bridge", "mdb"],

    # ------------------------------------------------------------------------
    # CUE-4800  retire: 'net show clag ...'
    # ------------------------------------------------------------------------
    # net show clag [our-macs|our-multicast-entries|our-multicast-route|
    #                our-multicast-router-ports|peer-macs|
    #                peer-multicast-entries|peer-multicast-route|
    #                peer-multicast-router-ports|params|backup-ip|id]
    #                [verbose] [json]
    ["clag", "our-macs"],
    ["clag", "our-macs", "json"],
    ["clag", "our-macs", "verbose"],
    ["clag", "our-macs", "verbose", "json"],
    ["clag", "our-multicast-entries"],
    ["clag", "our-multicast-entries", "json"],
    ["clag", "our-multicast-entries", "verbose"],
    ["clag", "our-multicast-entries", "verbose", "json"],
    ["clag", "our-multicast-route"],
    ["clag", "our-multicast-route", "json"],
    ["clag", "our-multicast-route", "verbose"],
    ["clag", "our-multicast-route", "verbose", "json"],
    ["clag", "our-multicast-router-ports"],
    ["clag", "our-multicast-router-ports", "json"],
    ["clag", "our-multicast-router-ports", "verbose"],
    ["clag", "our-multicast-router-ports", "verbose", "json"],
    ["clag", "peer-macs"],
    ["clag", "peer-macs", "json"],
    ["clag", "peer-macs", "verbose"],
    ["clag", "peer-macs", "verbose", "json"],
    ["clag", "peer-multicast-entries"],
    ["clag", "peer-multicast-entries", "json"],
    ["clag", "peer-multicast-entries", "verbose"],
    ["clag", "peer-multicast-entries", "verbose", "json"],
    ["clag", "peer-multicast-route"],
    ["clag", "peer-multicast-route", "json"],
    ["clag", "peer-multicast-route", "verbose"],
    ["clag", "peer-multicast-route", "verbose", "json"],
    ["clag", "peer-multicast-router-ports"],
    ["clag", "peer-multicast-router-ports", "json"],
    ["clag", "peer-multicast-router-ports", "verbose"],
    ["clag", "peer-multicast-router-ports", "verbose", "json"],
    ["clag", "params"],
    ["clag", "params", "json"],
    ["clag", "params", "verbose"],
    ["clag", "params", "verbose", "json"],
    ["clag", "backup-ip"],
    ["clag", "backup-ip", "json"],
    ["clag", "backup-ip", "verbose"],
    ["clag", "backup-ip", "verbose", "json"],
    ["clag", "id"],
    ["clag", "id", "json"],
    ["clag", "id", "verbose"],
    ["clag", "id", "verbose", "json"],

    # net show clag macs [<mac>] [json]
    ["clag", "macs"],
    ["clag", "macs", "json"],
    ["clag", "macs", ANY],
    ["clag", "macs", ANY, "json"],

    # net show clag neighbors [verbose]
    ["clag", "neighbors"],
    ["clag", "neighbors", "verbose"],

    # net show clag peer-lacp-rate
    ["clag", "peer-lacp-rate"],

    # net show clag verify-vlans [verbose]
    ["clag", "verify-vlans"],
    ["clag", "verify-vlans", "verbose"],

    # net show clag status [verbose] [json]
    ["clag", "status"],
    ["clag", "status", "json"],
    ["clag", "status", "verbose"],
    ["clag", "status", "verbose", "json"],

    # ------------------------------------------------------------------------
    # CUE-4801 retire: 'net show hostname ...'
    # ------------------------------------------------------------------------
    # net show hostname [json]
    ["hostname"],
    ["hostname", "json"],

    # ------------------------------------------------------------------------
    # CUE-4803 retire: 'net show vrf ...'
    # ------------------------------------------------------------------------
    # net show vrf [list [<text>]]
    # net show vrf vni [json]
    ["vrf"],
    ["vrf", "list"],
    ["vrf", "list", ANY],
    ["vrf", "vni"],
    ["vrf", "vni", "json"],

    # ------------------------------------------------------------------------
    # CUE-4804 retire: 'net show bgp ...'
    # ------------------------------------------------------------------------
    # net show bgp vrf
    # net show bgp [vrf <text>] [summary] [json]
    # net show bgp vrf <text> vni [json]
    ["bgp", "vrf"],
    ["bgp", "vrf", ANY],
    ["bgp", "vrf", ANY, "summary"],
    ["bgp", "vrf", ANY, "summary", "json"],
    ["bgp", "vrf", ANY, "vni"],
    ["bgp", "vrf", ANY, "vni", "json"],

    # net show bgp [vrf <text>]
    #     (<ipv4>|<ipv4/prefixlen>|<ipv6>|<ipv6/prefixlen>)
    #     [bestpath|multipath] [json]
    ["bgp"],
    ["bgp", "vrf", ANY, ANY],
    ["bgp", "vrf", ANY, ANY, "bestpath"],
    ["bgp", "vrf", ANY, ANY, "multipath"],
    ["bgp", "vrf", ANY, ANY, "bestpath", "json"],
    ["bgp", "vrf", ANY, ANY, "multipath", "json"],

    # net show bgp vrf <text> ipv4 unicast
    #     [<ipv4>|<ipv4/prefixlen>|summary] [json]
    ["bgp", "vrf", ANY, "ipv4", "unicast"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", ANY],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "summary"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", ANY, "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "summary", "json"],

    # net show bgp vrf <text> ipv6 unicast
    #     [<ipv6>|<ipv6/prefixlen>|summary] [json]
    ["bgp", "vrf", ANY, "ipv6", "unicast"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", ANY],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "summary"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", ANY, "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "summary", "json"],

    # net show bgp ipv4 (unicast|labeled-unicast|vpn)
    #     [<ipv4>|<ipv4/prefixlen>|summary] [json]
    ["bgp", "ipv4", "unicast"],
    ["bgp", "ipv4", "unicast", ANY],
    ["bgp", "ipv4", "unicast", ANY, "json"],
    ["bgp", "ipv4", "labeled-unicast"],
    ["bgp", "ipv4", "labeled-unicast", ANY],
    ["bgp", "ipv4", "labeled-unicast", ANY, "json"],
    ["bgp", "ipv4", "vpn"],
    ["bgp", "ipv4", "vpn", ANY],
    ["bgp", "ipv4", "vpn", ANY, "json"],

    # net show bgp ipv6 (unicast|labeled-unicast|vpn)
    #     [<ipv6>|<ipv6/prefixlen>|summary] [json]
    ["bgp", "ipv6", "unicast"],
    ["bgp", "ipv6", "unicast", ANY],
    ["bgp", "ipv6", "unicast", ANY, "json"],
    ["bgp", "ipv6", "labeled-unicast"],
    ["bgp", "ipv6", "labeled-unicast", ANY],
    ["bgp", "ipv6", "labeled-unicast", ANY, "json"],
    ["bgp", "ipv6", "vpn"],
    ["bgp", "ipv6", "vpn", ANY],
    ["bgp", "ipv6", "vpn", ANY, "json"],

    # net show bgp ipv4 vpn rd <rd> [<ipv4/prefixlen>] [json]
    ["bgp", "ipv4", "vpn", "rd", ANY],
    ["bgp", "ipv4", "vpn", "rd", ANY, "json"],
    ["bgp", "ipv4", "vpn", "rd", ANY, ANY],
    ["bgp", "ipv4", "vpn", "rd", ANY, ANY, "json"],

    # net show bgp ipv6 vpn rd <rd> [<ipv6/prefixlen>] [json]
    ["bgp", "ipv6", "vpn", "rd", ANY],
    ["bgp", "ipv6", "vpn", "rd", ANY, "json"],
    ["bgp", "ipv6", "vpn", "rd", ANY, ANY],
    ["bgp", "ipv6", "vpn", "rd", ANY, ANY, "json"],

    # net show bgp [vrf <text>] (ipv4 unicast|ipv6 unicast) route-leak [json]
    ["bgp", "ipv4", "unicast", "route-leak"],
    ["bgp", "ipv4", "unicast", "route-leak", "json"],
    ["bgp", "ipv6", "unicast", "route-leak"],
    ["bgp", "ipv6", "unicast", "route-leak", "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "route-leak"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "route-leak", "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "route-leak"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "route-leak", "json"],

    # net show bgp [vrf <text>] neighbor [<text-bgppeer>] [json]
    ["bgp", "vrf", ANY, "neighbor"],
    ["bgp", "vrf", ANY, "neighbor", "json"],
    ["bgp", "vrf", ANY, "neighbor", ANY],
    ["bgp", "vrf", ANY, "neighbor", ANY, "json"],
    ["bgp", "neighbor"],
    ["bgp", "neighbor", "json"],
    ["bgp", "neighbor", ANY],
    ["bgp", "neighbor", ANY, "json"],

    # net show bgp [vrf <text>] neighbor <text-bgppeer>
    #     (advertised-routes|received-routes|routes) [json]
    ["bgp", "neighbor", ANY, "advertised-routes"],
    ["bgp", "neighbor", ANY, "advertised-routes", "json"],
    ["bgp", "neighbor", ANY, "received-routes"],
    ["bgp", "neighbor", ANY, "received-routes", "json"],
    ["bgp", "neighbor", ANY, "routes"],
    ["bgp", "neighbor", ANY, "routes", "json"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "advertised-routes"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "advertised-routes", "json"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "received-routes"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "received-routes", "json"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "routes"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "routes", "json"],

    # net show bgp [vrf <text>] neighbor <text-bgppeer> graceful-restart
    ["bgp", "neighbor", ANY, "graceful-restart"],
    ["bgp", "vrf", ANY, "neighbor", ANY, "graceful-restart"],

    # net show bgp [vrf <text>] (ipv4|ipv6) (unicast|labeled-unicast)
    #     neighbor <bgppeer> (advertised-routes|received-routes|routes) [json]
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "advertised-routes"],
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "advertised-routes", "json"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "advertised-routes"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "advertised-routes", "json"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "advertised-routes"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "advertised-routes", \
     "json"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "advertised-routes"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "advertised-routes", \
     "json"],
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "received-routes", "json"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "received-routes", "json"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "received-routes", \
     "json"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "received-routes", \
     "json"],
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "routes"],
    ["bgp", "ipv4", "unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "routes"],
    ["bgp", "ipv6", "unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "routes"],
    ["bgp", "ipv4", "labeled-unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "routes"],
    ["bgp", "ipv6", "labeled-unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, \
     "advertised-routes"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, \
     "advertised-routes", "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, \
     "advertised-routes"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, \
     "advertised-routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, \
     "advertised-routes"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, \
     "advertised-routes", "json"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, \
     "advertised-routes"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, \
     "advertised-routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, \
     "received-routes", "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, "received-routes"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, \
     "received-routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, \
     "received-routes"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, \
     "received-routes", "json"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, \
     "received-routes"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, \
     "received-routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, "routes"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, "routes"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "neighbor", ANY, "routes", "json"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, "routes"],
    ["bgp", "vrf", ANY, "ipv4", "labeled-unicast", "neighbor", ANY, "routes", \
     "json"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, "routes"],
    ["bgp", "vrf", ANY, "ipv6", "labeled-unicast", "neighbor", ANY, "routes", \
     "json"],

    # net show bgp [vrf <text>] (ipv4|ipv6) unicast
    #     (large-community <large-community>|
    #      large-community-list <large-community-list>) [json]
    ["bgp", "ipv4", "unicast", "large-community", ANY],
    ["bgp", "ipv4", "unicast", "large-community", ANY, "json"],
    ["bgp", "ipv6", "unicast", "large-community", ANY],
    ["bgp", "ipv6", "unicast", "large-community", ANY, "json"],
    ["bgp", "ipv4", "unicast", "large-community-list", ANY],
    ["bgp", "ipv4", "unicast", "large-community-list", ANY, "json"],
    ["bgp", "ipv6", "unicast", "large-community-list", ANY],
    ["bgp", "ipv6", "unicast", "large-community-list", ANY, "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "large-community", ANY],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "large-community", ANY, "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "large-community", ANY],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "large-community", ANY, "json"],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "large-community-list", ANY],
    ["bgp", "vrf", ANY, "ipv4", "unicast", "large-community-list", ANY, \
     "json"],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "large-community-list", ANY],
    ["bgp", "vrf", ANY, "ipv6", "unicast", "large-community-list", ANY, \
     "json"],

    # net show bgp (ipv4|ipv6) labeled-unicast
    #     (large-community <large-community>|
    #      large-community-list <large-community-list>) [json]
    ["bgp", "ipv4", "labeled-unicast", "large-community", ANY],
    ["bgp", "ipv4", "labeled-unicast", "large-community", ANY, "json"],
    ["bgp", "ipv6", "labeled-unicast", "large-community", ANY],
    ["bgp", "ipv6", "labeled-unicast", "large-community", ANY, "json"],
    ["bgp", "ipv4", "labeled-unicast", "large-community-list", ANY],
    ["bgp", "ipv4", "labeled-unicast", "large-community-list", ANY, "json"],
    ["bgp", "ipv6", "labeled-unicast", "large-community-list", ANY],
    ["bgp", "ipv6", "labeled-unicast", "large-community-list", ANY, "json"],

    # net show bgp [vrf <text>] update-groups
    ["bgp", "update-groups"],
    ["bgp", "vrf", ANY, "update-groups"],

    # net show bgp nexthop [<ipv4>|<ipv6>]
    ["bgp", "nexthop"],
    ["bgp", "nexthop", ANY],

    # net show bgp [l2vpn] evpn vrf-import-rt [json]
    ["bgp", "evpn", "vrf-import-rt"],
    ["bgp", "evpn", "vrf-import-rt", "json"],
    ["bgp", "l2vpn", "evpn", "vrf-import-rt"],
    ["bgp", "l2vpn", "evpn", "vrf-import-rt", "json"],

    # net show bgp [l2vpn] evpn import-rt [json]
    ["bgp", "evpn", "import-rt"],
    ["bgp", "evpn", "import-rt", "json"],
    ["bgp", "l2vpn", "evpn", "import-rt"],
    ["bgp", "l2vpn", "evpn", "import-rt", "json"],

    # net show bgp [l2vpn] evpn route [detail] [json]
    ["bgp", "evpn", "route"],
    ["bgp", "evpn", "route", "detail"],
    ["bgp", "evpn", "route", "json"],
    ["bgp", "evpn", "route", "detail", "json"],
    ["bgp", "l2vpn", "evpn", "route"],
    ["bgp", "l2vpn", "evpn", "route", "detail"],
    ["bgp", "l2vpn", "evpn", "route", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", "json"],

    # net show bgp [l2vpn] evpn route rd <rd> [json]
    ["bgp", "evpn", "route", "rd", ANY],
    ["bgp", "evpn", "route", "rd", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "json"],

    # net show bgp [l2vpn] evpn route rd <rd> mac <mac> [ip <ip>] [json]
    ["bgp", "evpn", "route", "rd", ANY, "mac", ANY],
    ["bgp", "evpn", "route", "rd", ANY, "mac", ANY, "ip", ANY],
    ["bgp", "evpn", "route", "rd", ANY, "mac", ANY, "json"],
    ["bgp", "evpn", "route", "rd", ANY, "mac", ANY, "ip", ANY, "json"],

    # net show bgp [l2vpn] evpn route rd <rd>
    #     prefix (<ipv4/prefixlen>|<ipv6/prefixlen>) [json]
    ["bgp", "evpn", "route", "rd", ANY, "prefix", ANY],
    ["bgp", "evpn", "route", "rd", ANY, "prefix", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "prefix", ANY],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "prefix", ANY, "json"],

    # net show bgp [l2vpn] evpn route rd <rd>
    #     type (ead|1|macip|2|multicast|3|es|4|prefix|5) [json]
    ["bgp", "evpn", "route", "rd", ANY, "type", "ead"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "1"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "macip"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "2"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "multicast"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "3"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "es"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "4"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "prefix"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "5"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "ead", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "1", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "macip", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "2", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "multicast", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "3", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "es", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "4", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "prefix", "json"],
    ["bgp", "evpn", "route", "rd", ANY, "type", "5", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "ead"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "1"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "macip"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "2"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "multicast"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "3"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "es"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "4"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "prefix"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "5"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "ead", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "1", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "macip", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "2", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "multicast", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "3", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "es", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "4", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "prefix", "json"],
    ["bgp", "l2vpn", "evpn", "route", "rd", ANY, "type", "5", "json"],

    # net show bgp [l2vpn] evpn route [detail]
    #     type (ead|1|macip|2|multicast|3|es|4|prefix|5) [json]
    ["bgp", "evpn", "route", "detail", ANY, "type", "ead"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "1"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "macip"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "2"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "multicast"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "3"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "es"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "4"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "prefix"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "5"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "ead", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "1", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "macip", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "2", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "multicast", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "3", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "es", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "4", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "prefix", "json"],
    ["bgp", "evpn", "route", "detail", ANY, "type", "5", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "ead"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "1"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "macip"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "2"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "multicast"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "3"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "es"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "4"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "prefix"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "5"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "ead", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "1", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "macip", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "2", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "multicast", \
     "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "3", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "es", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "4", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "prefix", "json"],
    ["bgp", "l2vpn", "evpn", "route", "detail", ANY, "type", "5", "json"],

    # net show bgp [l2vpn] evpn route vni all [detail] [json]
    ["bgp", "evpn", "route", "vni", "all"],
    ["bgp", "evpn", "route", "vni", "all", "detail"],
    ["bgp", "evpn", "route", "vni", "all", "json"],
    ["bgp", "evpn", "route", "vni", "all", "detail", "json"],
    ["bgp", ANY, "evpn", "route", "vni", "all"],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "detail"],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "detail", "json"],

    # net show bgp [l2vpn] evpn route vni <1-16777215> [json]
    ["bgp", "evpn", "route", "vni", ANY],
    ["bgp", "evpn", "route", "vni", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "json"],

    # net show bgp [l2vpn] evpn route vni <1-16777215> vtep <ipv4> [json]
    ["bgp", "evpn", "route", "vni", ANY, "vtep", ANY],
    ["bgp", "evpn", "route", "vni", ANY, "vtep", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "vtep", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "vtep", ANY, "json"],

    # net show bgp [l2vpn] evpn route vni all [detail] vtep <ipv4> [json]
    ["bgp", "evpn", "route", "vni", "all", "vtep", ANY],
    ["bgp", "evpn", "route", "vni", "all", "vtep", ANY, "json"],
    ["bgp", "evpn", "route", "vni", "all", "detail", "vtep", ANY],
    ["bgp", "evpn", "route", "vni", "all", "detail", "vtep", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "vtep", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "vtep", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "detail", "vtep", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", "all", "detail", "vtep", ANY, \
     "json"],

    # net show bgp [l2vpn] evpn route vni <1-16777215> mac <mac> [ip <ip>]
    #     [json]
    ["bgp", "evpn", "route", "vni", ANY, "mac", ANY],
    ["bgp", "evpn", "route", "vni", ANY, "mac", ANY, "json"],
    ["bgp", "evpn", "route", "vni", ANY, "mac", ANY, "ip", ANY],
    ["bgp", "evpn", "route", "vni", ANY, "mac", ANY, "ip", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "mac", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "mac", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "mac", ANY, "ip", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "mac", ANY, "ip", ANY, \
     "json"],

    # net show bgp [l2vpn] evpn route vni <1-16777215> multicast <ipv4> [json]
    ["bgp", "evpn", "route", "vni", ANY, "muticast", ANY],
    ["bgp", "evpn", "route", "vni", ANY, "muticast", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "muticast", ANY],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "muticast", ANY, "json"],

    # net show bgp [l2vpn] evpn route vni <1-16777215>
    #     type (ead|1|macip|2|multicast|3) [json]
    ["bgp", "evpn", "route", "vni", ANY, "type", "ead"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "1"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "macip"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "2"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "multicast"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "3"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "ead", "json"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "1", "json"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "macip", "json"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "2", "json"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "multicast", "json"],
    ["bgp", "evpn", "route", "vni", ANY, "type", "3", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "ead"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "1"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "macip"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "2"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "multicast"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "3"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "ead", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "1", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "macip", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "2", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "multicast", "json"],
    ["bgp", "l2vpn", "evpn", "route", "vni", ANY, "type", "3", "json"],

    # net show bgp [l2vpn] evpn summary [json]
    ["bgp", "evpn", "summary"],
    ["bgp", "evpn", "summary", "json"],
    ["bgp", "l2vpn", "evpn", "summary"],
    ["bgp", "l2vpn", "evpn", "summary", "json"],

    # net show bgp [l2vpn] evpn vni [<1-16777215>] [json]
    ["bgp", "evpn", "vni", ANY],
    ["bgp", "evpn", "vni", ANY, "json"],
    ["bgp", "l2vpn", "evpn", "vni", ANY],
    ["bgp", "l2vpn", "evpn", "vni", ANY, "json"],

    # net show bgp l2vpn evpn es [detail] [json]
    ["bgp", "l2vpn", "evpn", "es"],
    ["bgp", "l2vpn", "evpn", "es", "detail"],
    ["bgp", "l2vpn", "evpn", "es", "json"],
    ["bgp", "l2vpn", "evpn", "es", "detail", "json"],

    # net show bgp l2vpn evpn es <text-esi> [json]
    ["bgp", "l2vpn", "evpn", "es", ANY],
    ["bgp", "l2vpn", "evpn", "es", ANY, "json"],

    # net show bgp l2vpn evpn es-evi [detail|json]
    ["bgp", "l2vpn", "evpn", "es-evi"],
    ["bgp", "l2vpn", "evpn", "es-evi", "detail"],
    ["bgp", "l2vpn", "evpn", "es-evi", "json"],
    ["bgp", "l2vpn", "evpn", "es-evi", "detail", "json"],

    # net show bgp l2vpn evpn es-evi vni <1-16777215> [detail|json]
    ["bgp", "l2vpn", "evpn", "es-evi", "vni", ANY],
    ["bgp", "l2vpn", "evpn", "es-evi", "vni", ANY, "detail"],
    ["bgp", "l2vpn", "evpn", "es-evi", "vni", ANY, "json"],

    # net show bgp l2vpn evpn es-vrf [json]
    ["bgp", "l2vpn", "evpn", "es-vrf"],
    ["bgp", "l2vpn", "evpn", "es-vrf", "json"],

    # net show bgp l2vpn evpn es-vrf <text-esi> [json]
    ["bgp", "l2vpn", "evpn", "es-vrf", ANY],
    ["bgp", "l2vpn", "evpn", "es-vrf", ANY, "json"],

    # net show bgp large-community-info
    ["bgp", "large-communit-info"],

    # ------------------------------------------------------------------------
    # CUE-4805 retire: 'net show evpn ...'
    # ------------------------------------------------------------------------
    # net show evpn [json]
    ["evpn"],
    ["evpn", "json"],

    # net show evpn access-vlan [detail] [json]
    ["evpn", "access-vlan"],
    ["evpn", "access-vlan", "detail"],
    ["evpn", "access-vlan", "json"],
    ["evpn", "access-vlan", "detail", "json"],

    # net show evpn arp-cache vni all [json]
    ["evpn", "arp-cache", "vni", "all"],
    ["evpn", "arp-cache", "vni", "all", "json"],

    # net show evpn arp-cache vni all detail [json]
    ["evpn", "arp-cache", "vni", "all", "detail"],
    ["evpn", "arp-cache", "vni", "all", "detail", "json"],

    # net show evpn arp-cache vni all duplicate [json]
    ["evpn", "arp-cache", "vni", "all", "duplicate"],
    ["evpn", "arp-cache", "vni", "all", "duplicate", "json"],

    # net show evpn arp-cache vni <1-16777215> [json]
    ["evpn", "arp-cache", "vni", ANY],
    ["evpn", "arp-cache", "vni", ANY, "json"],

    # net show evpn arp-cache vni <1-16777215> duplicate [json]
    ["evpn", "arp-cache", "vni", ANY, "duplicate"],
    ["evpn", "arp-cache", "vni", ANY, "duplicate", "json"],

    # net show evpn arp-cache vni <1-16777215> ip <ip> [json]
    ["evpn", "arp-cache", "vni", ANY, "ip", ANY],
    ["evpn", "arp-cache", "vni", ANY, "ip", ANY, "json"],

    # net show evpn arp-cache vni <1-16777215> vtep <ipv4> [json]
    ["evpn", "arp-cache", "vni", ANY, "vtep", ANY],
    ["evpn", "arp-cache", "vni", ANY, "vtep", ANY, "json"],

    # net show evpn (es|es-evi) [json]
    ["evpn", "es"],
    ["evpn", "es", "json"],
    ["evpn", "es-evi"],
    ["evpn", "es-evi", "json"],

    # net show evpn (es|es-evi) detail [json]
    ["evpn", "es", "detail"],
    ["evpn", "es", "detail", "json"],
    ["evpn", "es-evi", "detail"],
    ["evpn", "es-evi", "detail", "json"],

    # net show evpn es <text-esi> [json]
    ["evpn", "es", ANY],
    ["evpn", "es", ANY, "json"],

    # net show evpn es-evi vni <1-16777215> [detail] [json]
    ["evpn", "es-evi", "vni", ANY],
    ["evpn", "es-evi", "vni", ANY, "detail"],
    ["evpn", "es-evi", "vni", ANY, "json"],
    ["evpn", "es-evi", "vni", ANY, "detail", "json"],

    # net show evpn l2-nh [json]
    ["evpn", "l2-nh"],
    ["evpn", "l2-nh", "json"],

    # net show evpn mac vni all [json]
    ["evpn", "mac", "vni", "all"],
    ["evpn", "mac", "vni", "all", "json"],

    # net show evpn mac vni all detail [json]
    ["evpn", "mac", "vni", "all", "detail"],
    ["evpn", "mac", "vni", "all", "detail", "json"],

    # net show evpn mac vni all duplicate [json]
    ["evpn", "mac", "vni", "all", "duplciate"],
    ["evpn", "mac", "vni", "all", "duplicate", "json"],

    # net show evpn mac vni <1-16777215> [json]
    ["evpn", "mac", "vni", ANY],
    ["evpn", "mac", "vni", ANY, "json"],

    # net show evpn mac vni <1-16777215> duplicate [json]
    ["evpn", "mac", "vni", ANY, "duplciate"],
    ["evpn", "mac", "vni", ANY, "duplicate", "json"],

    # net show evpn mac vni <1-16777215> mac <mac> [json]
    ["evpn", "mac", "vni", ANY, "mac", ANY],
    ["evpn", "mac", "vni", ANY, "mac", ANY, "json"],

    # net show evpn mac vni <1-16777215> vtep <ipv4> [json]
    ["evpn", "mac", "vni", ANY],
    ["evpn", "mac", "vni", ANY, "json"],

    # net show evpn mac vni all vtep <ipv4> [json]
    ["evpn", "mac", "vni", "all", "vtep", ANY],
    ["evpn", "mac", "vni", "all", "vtep", ANY, "json"],

    # net show evpn vni [<1-16777215>|detail]  [json]
    ["evpn", "vni", ANY],
    ["evpn", "vni", "detail"],
    ["evpn", "vni", ANY, "json"],
    ["evpn", "vni", "detail", "json"],

    # net show evpn rmac vni <1-16777215> [mac <mac>] [json]
    ["evpn", "rmac", "vni", ANY],
    ["evpn", "rmac", "vni", ANY, "mac", ANY],
    ["evpn", "rmac", "vni", ANY, "json"],
    ["evpn", "rmac", "vni", ANY, "mac", ANY, "json"],

    # net show evpn rmac vni all [json]
    ["evpn", "rmac", "vni", "all"],
    ["evpn", "rmac", "vni", "all", "json"],

    # net show evpn next-hops vni (all | <1-16777215>) [json]
    ["evpn", "next-hops", "vni", "all"],
    ["evpn", "next-hops", "vni", ANY],
    ["evpn", "next-hops", "vni", "all", "json"],
    ["evpn", "next-hops", "vni", ANY, "json"],

    # net show evpn next-hops vni <1-16777215> ip <ip> [json]
    ["evpn", "next-hops", "vni", ANY, "ip", ANY],
    ["evpn", "next-hops", "vni", ANY, "ip", ANY, "json"],

    # ------------------------------------------------------------------------
    # CUE-4806 retire: 'net show ospf ...'
    # ------------------------------------------------------------------------
    # net show ospf vrf
    # net show ospf [vrf <text>] [json]
    ["ospf", "vrf"],
    ["ospf", "vrf", ANY],
    ["ospf", "vrf", "json"],
    ["ospf", "vrf", ANY, "json"],

    # net show ospf [vrf <text>] database
    #     (asbr-summary|external|network|nssa-external|opaque-area|opaque-as|
    #      opaque-link|router|summary)
    #     [<ipv4>|adv-router <ipv4-adv-router>|self-originate]
    ["ospf", "database", "asbr-summary"],
    ["ospf", "database", "asbr-summary", ANY],
    ["ospf", "database", "asbr-summary", "adv-router", ANY],
    ["ospf", "database", "asbr-summary", "self-originate"],
    ["ospf", "database", "external"],
    ["ospf", "database", "external", ANY],
    ["ospf", "database", "external", "adv-router", ANY],
    ["ospf", "database", "external", "self-originate"],
    ["ospf", "database", "network"],
    ["ospf", "database", "network", ANY],
    ["ospf", "database", "network", "adv-router", ANY],
    ["ospf", "database", "network", "self-originate"],
    ["ospf", "database", "nssa-external"],
    ["ospf", "database", "nssa-external", ANY],
    ["ospf", "database", "nssa-external", "adv-router", ANY],
    ["ospf", "database", "nssa-external", "self-originate"],
    ["ospf", "database", "opaque-area"],
    ["ospf", "database", "opaque-area", ANY],
    ["ospf", "database", "opaque-area", "adv-router", ANY],
    ["ospf", "database", "opaque-area", "self-originate"],
    ["ospf", "database", "opaque-as"],
    ["ospf", "database", "opaque-as", ANY],
    ["ospf", "database", "opaque-as", "adv-router", ANY],
    ["ospf", "database", "opaque-as", "self-originate"],
    ["ospf", "database", "opaque-link"],
    ["ospf", "database", "opaque-link", ANY],
    ["ospf", "database", "opaque-link", "adv-router", ANY],
    ["ospf", "database", "opaque-link", "self-originate"],
    ["ospf", "database", "router"],
    ["ospf", "database", "router", ANY],
    ["ospf", "database", "router", "adv-router", ANY],
    ["ospf", "database", "router", "self-originate"],
    ["ospf", "database", "summary"],
    ["ospf", "database", "summary", ANY],
    ["ospf", "database", "summary", "adv-router", ANY],
    ["ospf", "database", "summary", "self-originate"],
    ["ospf", "vrf", ANY, "database", "asbr-summary"],
    ["ospf", "vrf", ANY, "database", "asbr-summary", ANY],
    ["ospf", "vrf", ANY, "database", "asbr-summary", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "asbr-summary", "self-originate"],
    ["ospf", "vrf", ANY, "database", "external"],
    ["ospf", "vrf", ANY, "database", "external", ANY],
    ["ospf", "vrf", ANY, "database", "external", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "external", "self-originate"],
    ["ospf", "vrf", ANY, "database", "network"],
    ["ospf", "vrf", ANY, "database", "network", ANY],
    ["ospf", "vrf", ANY, "database", "network", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "network", "self-originate"],
    ["ospf", "vrf", ANY, "database", "nssa-external"],
    ["ospf", "vrf", ANY, "database", "nssa-external", ANY],
    ["ospf", "vrf", ANY, "database", "nssa-external", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "nssa-external", "self-originate"],
    ["ospf", "vrf", ANY, "database", "opaque-area"],
    ["ospf", "vrf", ANY, "database", "opaque-area", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-area", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-area", "self-originate"],
    ["ospf", "vrf", ANY, "database", "opaque-as"],
    ["ospf", "vrf", ANY, "database", "opaque-as", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-as", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-as", "self-originate"],
    ["ospf", "vrf", ANY, "database", "opaque-link"],
    ["ospf", "vrf", ANY, "database", "opaque-link", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-link", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "opaque-link", "self-originate"],
    ["ospf", "vrf", ANY, "database", "router"],
    ["ospf", "vrf", ANY, "database", "router", ANY],
    ["ospf", "vrf", ANY, "database", "router", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "router", "self-originate"],
    ["ospf", "vrf", ANY, "database", "summary"],
    ["ospf", "vrf", ANY, "database", "summary", ANY],
    ["ospf", "vrf", ANY, "database", "summary", "adv-router", ANY],
    ["ospf", "vrf", ANY, "database", "summary", "self-originate"],

    # net show ospf [vrf <text>] database [max-age|self-originate]
    ["ospf", "database", "max-age"],
    ["ospf", "database", "self-originate"],
    ["ospf", "vrf", ANY, "database", "max-age"],
    ["ospf", "vrf", ANY, "database", "self-originate"],

    # net show ospf [vrf <text>] interface [<interface>] [json]
    ["ospf", "interface"],
    ["ospf", "interface", "json"],
    ["ospf", "interface", ANY],
    ["ospf", "interface", ANY, "json"],
    ["ospf", "vrf", ANY, "interface"],
    ["ospf", "vrf", ANY, "interface", "json"],
    ["ospf", "vrf", ANY, "interface", ANY],
    ["ospf", "vrf", ANY, "interface", ANY, "json"],

    # net show ospf neighbor [all|<interface>|<ipv4>|detail] [json]
    ["ospf", "neighbor"],
    ["ospf", "neighbor", "json"],
    ["ospf", "neighbor", "all"],
    ["ospf", "neighbor", "all", "json"],
    ["ospf", "neighbor", ANY],
    ["ospf", "neighbor", ANY, "json"],
    ["ospf", "neighbor", "detail"],
    ["ospf", "neighbor", "detail", "json"],

    # net show ospf vrf <text> neighbor [all|detail] [json]
    ["ospf", "vrf", ANY, "neighbor"],
    ["ospf", "vrf", ANY, "neighbor", "json"],
    ["ospf", "vrf", ANY, "neighbor", "all"],
    ["ospf", "vrf", ANY, "neighbor", "all", "json"],
    ["ospf", "vrf", ANY, "neighbor", "detail"],
    ["ospf", "vrf", ANY, "neighbor", "detail", "json"],

    # net show ospf [vrf <text>] route [json]
    ["ospf", "route"],
    ["ospf", "route", "json"],
    ["ospf", "vrf", ANY, "route"],
    ["ospf", "vrf", ANY, "route", "json"],

    # net show ospf [vrf <text>] border-routers
    ["ospf", "border-routers"],
    ["ospf", "vrf", ANY, "border-routers"],

    # net show ospf [vrf <text>] interface traffic [<interface>] [json]
    ["ospf", "interface", "traffic"],
    ["ospf", "interface", "traffic", "json"],
    ["ospf", "interface", "traffic", ANY],
    ["ospf", "interface", "traffic", ANY, "json"],
    ["ospf", "vrf", ANY, "interface", "traffic"],
    ["ospf", "vrf", ANY, "interface", "traffic", "json"],
    ["ospf", "vrf", ANY, "interface", "traffic", ANY],
    ["ospf", "vrf", ANY, "interface", "traffic", ANY, "json"],


    # ------------------------------------------------------------------------
    # CUE-4807 retire: 'net show ospf6 ...'
    # ------------------------------------------------------------------------
    # net show ospf6
    ["ospf6"],

    # net show ospf6 database [linkstate-id <ipv4-id>|self-originated]
    #     [detail|dump|internal]
    ["ospf6", "database"],
    ["ospf6", "database", "detail"],
    ["ospf6", "database", "dump"],
    ["ospf6", "database", "internal"],
    ["ospf6", "database", "linkstate-id", ANY],
    ["ospf6", "database", "linkstate-id", ANY, "detail"],
    ["ospf6", "database", "linkstate-id", ANY, "dump"],
    ["ospf6", "database", "linkstate-id", ANY, "internal"],
    ["ospf6", "database", "self-originated"],
    ["ospf6", "database", "self-originated", "detail"],
    ["ospf6", "database", "self-originated", "dump"],
    ["ospf6", "database", "self-originated", "internal"],

    # net show ospf6 database adv-router <ipv4-id> linkstate-id <ipv4-id>
    #     [detail|dump|internal]
    ["ospf6", "database", "adv-router", ANY, "linkstate-id", ANY],
    ["ospf6", "database", "adv-router", ANY, "linkstate-id", ANY, "detail"],
    ["ospf6", "database", "adv-router", ANY, "linkstate-id", ANY, "dump"],
    ["ospf6", "database", "adv-router", ANY, "linkstate-id", ANY, "internal"],

    # net show ospf6 interface [<interface>]
    ["ospf6", "interface"],
    ["ospf6", "interface", ANY],

    # net show ospf6 linkstate (detail|router <ipv4>)
    ["ospf6", "linkstate", "detail"],
    ["ospf6", "linkstate", "router", ANY],

    # net show ospf6 neighbor [detail|drchoice]
    ["ospf6", "neighbor", "detail"],
    ["ospf6", "neighbor", "drchoice"],

    # net show ospf6 redistribute
    ["ospf6", "redistribute"],

    # net show ospf6 route [<ipv6>|<ipv6/prefixlen>|detail|summary]
    ["ospf6", "route"],
    ["ospf6", "route", ANY],
    ["ospf6", "route", "detail"],
    ["ospf6", "route", "summary"],

    # net show ospf6 route (intra-area|inter-area|external-1|external-2)
    #     [detail]
    ["ospf6", "route", "intra-area"],
    ["ospf6", "route", "inter-area"],
    ["ospf6", "route", "external-1"],
    ["ospf6", "route", "external-2"],
    ["ospf6", "route", "intra-area", "detail"],
    ["ospf6", "route", "inter-area", "detail"],
    ["ospf6", "route", "external-1", "detail"],
    ["ospf6", "route", "external-2", "detail"],

    # net show ospf6 route <ipv6/prefixlen> longer
    ["ospf6", "route", ANY, "longer"],

    # net show ospf6 route <ipv6/prefixlen> match [detail]
    ["ospf6", "route", ANY, "match"],
    ["ospf6", "route", ANY, "match", "detail"],

    # net show ospf6 spf tree
    ["ospf6", "spf", "tree"],

    # ------------------------------------------------------------------------
    # CUE-4808 retire: 'net show route ...'
    # ------------------------------------------------------------------------
    # net show route [vrf <text>] [json]
    ["route"],
    ["route", "json"],
    ["route", "vrf", ANY, "json"],

    # net show route [vrf <text>] (ipv4|ipv6|<ipv4>|<ipv6>)
    ["route", "ipv4"],
    ["route", "ipv6"],
    ["route", ANY],
    ["route", "vrf", ANY, "ipv4"],
    ["route", "vrf", ANY, "ipv6"],
    ["route", "vrf", ANY, ANY],

    # net show route [vrf <text>] (<ipv4/prefixlen>|<ipv6/prefixlen>)
    #     [longer-prefixes [json]]
    ["route", ANY, "longer-prefixes"],
    ["route", ANY, "longer-prefixes", "json"],
    ["route", "vrf", ANY, ANY, "longer-prefixes"],
    ["route", "vrf", ANY, ANY, "longer-prefixes", "json"],

    # net show route [vrf <text>] summary
    ["route", "summary"],
    ["route", "vrf", ANY, "summary"],

    # net show route [vrf <text>]
    #     (bgp|connected|kernel|ospf|ospf6|rip|static|supernets-only|table)
    #     [json]
    ["route", "bgp"],
    ["route", "connected"],
    ["route", "kernel"],
    ["route", "ospf"],
    ["route", "ospf6"],
    ["route", "rip"],
    ["route", "static"],
    ["route", "supernets-only"],
    ["route", "table"],
    ["route", "bgp", "json"],
    ["route", "connected", "json"],
    ["route", "kernel", "json"],
    ["route", "ospf", "json"],
    ["route", "ospf6", "json"],
    ["route", "rip", "json"],
    ["route", "static", "json"],
    ["route", "supernets-only", "json"],
    ["route", "table", "json"],
    ["route", "vrf", ANY, "bgp"],
    ["route", "vrf", ANY, "connected"],
    ["route", "vrf", ANY, "kernel"],
    ["route", "vrf", ANY, "ospf"],
    ["route", "vrf", ANY, "ospf6"],
    ["route", "vrf", ANY, "rip"],
    ["route", "vrf", ANY, "static"],
    ["route", "vrf", ANY, "supernets-only"],
    ["route", "vrf", ANY, "table"],
    ["route", "vrf", ANY, "bgp", "json"],
    ["route", "vrf", ANY, "connected", "json"],
    ["route", "vrf", ANY, "kernel", "json"],
    ["route", "vrf", ANY, "ospf", "json"],
    ["route", "vrf", ANY, "ospf6", "json"],
    ["route", "vrf", ANY, "rip", "json"],
    ["route", "vrf", ANY, "static", "json"],
    ["route", "vrf", ANY, "supernets-only", "json"],
    ["route", "vrf", ANY, "table", "json"],

    # ------------------------------------------------------------------------
    # CUE-4809  retire: 'net show ip ...'
    # ------------------------------------------------------------------------
    # net show ip nht [vrf <text>|route-map]
    ["ip", "nht"],
    ["ip", "nht", "vrf", ANY],
    ["ip", "nht", "route-map"],

    # net show ip as-path-access-list [<as-path-access-list>]
    ["ip", "as-path-access-list"],
    ["ip", "as-path-access-list", ANY],

    # net show ip community-list <community-list>
    ["ip", "community-list", ANY],

    # net show ip extcommunity-list <extcommunity-list>
    ["ip", "extcommunity-list", ANY],

    # net show ip large-community-list [<large-community-list>]
    ["ip", "large-community-list"],
    ["ip", "large-community-list", ANY],

    # net show ip prefix-list [<prefix-list-v4>]
    ["ip", "prefix-list"],
    ["ip", "prefix-list", ANY],

    # net show ip prefix-list <prefix-list-v4> seq <1-4294967295>
    ["ip", "prefix-list", ANY, "seq", ANY],

    # net show ip prefix-list <prefix-list-v4> <ipv4/prefixlen>
    #     [longer|first-match]
    ["ip", "prefix-list", ANY, ANY],
    ["ip", "prefix-list", ANY, ANY, "longer"],
    ["ip", "prefix-list", ANY, ANY, "first-match"],

    # net show ip prefix-list summary [<prefix-list-v4>]
    ["ip", "prefix-list", "list-summary"],
    ["ip", "prefix-list", "list-summary", ANY],

    # net show ip prefix-list detail [<prefix-list-v4>]
    ["ip", "prefix-list", "detail"],
    ["ip", "prefix-list", "detail", ANY],

    # ------------------------------------------------------------------------
    # CUE-4810 - retire: 'net show ipv6 ...'
    # ------------------------------------------------------------------------
    # net show ipv6 prefix-list [<prefix-list-v6>]
    ["ipv6", "prefix-list"],
    ["ipv6", "prefix-list", ANY],

    # net show ipv6 prefix-list <prefix-list-v6> seq <1-4294967295>
    ["ipv6", "prefix-list", ANY, "seq", ANY],

    # net show ipv6 prefix-list <prefix-list-v6> <ipv6/prefixlen>
    #     [longer|first-match]
    ["ipv6", "prefix-list", ANY, ANY],
    ["ipv6", "prefix-list", ANY, ANY, "longer"],
    ["ipv6", "prefix-list", ANY, ANY, "first-match"],

    # net show ipv6 prefix-list summary [<prefix-list-v6>]
    ["ipv6", "prefix-list", "summary"],
    ["ipv6", "prefix-list", "summary", ANY],

    # net show ipv6 prefix-list detail [<prefix-list-v6>]
    ["ipv6", "prefix-list", "detail"],
    ["ipv6", "prefix-list", "detail", ANY],

    # ------------------------------------------------------------------------
    # CUE-4811 - retire: 'net show route-map [<route-map>] ...'
    # ------------------------------------------------------------------------
    # net show route-map [<route-map>]
    ["route-map"],
    ["route-map", ANY],

    # ------------------------------------------------------------------------
    # CUE-4812 retire: 'net show pbr ...'
    # ------------------------------------------------------------------------
    # net show pbr
    # net show pbr [<text>]
    ["pbr"],
    ["pbr", ANY],

    # net show pbr map [<text>]
    ["pbr", "map"],
    ["pbr", "map", ANY],

    # net show pbr nexthop-group [<text>]
    ["pbr", "nexthop-group"],
    ["pbr", "nexthop-group", ANY],

    # net show pbr interface [<interface>]
    ["pbr", "interface"],
    ["pbr", "interface", ANY],

)


def show_raw_get(ctx, cmd):
    cmd_tokens = cmd.split()
    if cmd_tokens not in AVAILABLE_SHOW_COMMANDS:
        return problem(
            400,
            'Bad Request',
            f"'cl legacy show {cmd}' not available."
        )
    # TODO: CUE-4467
    # TODO: get rid of sudo here: neuter nclu and add cue to netshow users
    result = ctx.sh.sudo.net.show(*cmd_tokens)
    return result.stdout
