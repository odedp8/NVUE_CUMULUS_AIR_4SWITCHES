# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

"""
Networking utilities for the CUE CLI client.
"""

import json
from cli_cue.exceptions import UserError
from functools import wraps, lru_cache
from dataclasses import dataclass


UDS_PATH = "/run/cue/cue.sock"


#################
# Exceptions
#################

class CueRequestError(Exception):
    """
    Indicates an error that happened while sending an HTTP request.
    """
    def __init__(self, method, url, status, reason, body):
        self.method = method
        self.url = url
        self.status = status
        self.reason = reason
        self.body = body


class ConnectionNotInitializedError(ConnectionError):
    """
    Throw this error when attempting to make a request without having
    initialized the connection. Initialize a connection by running
    `init_connection(hostname)`.
    """
    def __str__(self):
        return (
            "Connection not initialized. This is likely a bug in the client"
            + " script."
        )


#################
# Classes
#################

@dataclass(frozen=True)
class CueRequest:
    method: str
    path: str
    query_params: dict = None
    payload: dict = None
    header_overrides: dict = None

    @property
    def url(self):
        from urllib.parse import urlencode
        querystring = ""
        if self.query_params is not None:
            querystring = f"?{urlencode(self.query_params)}"
        return f"{self.path}{querystring}"

    @property
    def headers(self):
        # EARLY RETURN
        if self.header_overrides is not None:
            # header_overrides clobbers all the headers defaults
            return self.header_overrides

        headers = {}
        if self.payload is not None:
            # body will always be JSON for now (unless overridden)
            headers["Content-Type"] = "application/json"
        return headers

    @property
    def body(self):
        return (
            json.dumps(self.payload)
            if self.payload is not None
            else None
        )

    def make_request_kwargs(self):
        """
        Make a dict of keyword arguments to be used in HTTPConnection.request
        calls, based off the contents of the CueRequest instance.
        """

        return {
            "method": self.method,
            "url": self.url,
            "body": self.body,
            "headers": self.headers,
        }


########################
# Connection handling
########################

_conn = None


def connect_unix(path):  # pragma: no cover
    """
    Create an HTTP connection via AF_UNIX socket.

    Args:
        path: The string path to the socket.
    """
    from http.client import HTTPConnection
    import socket
    class SocketHTTPConnection(HTTPConnection):

        def connect(self):
            # Other than how it's initialized, the UDS connection is the same
            # as a regular HTTPConnection (at least for our purposes.)
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self.host)
            self.sock = sock

    return SocketHTTPConnection(path)


def connect_inet(hostname):  # pragma: no cover
    """
    Create a normal HTTP connection over TCP/IP.

    Args:
        hostname: The string hostname to connect to.
    """
    from http.client import HTTPConnection
    return HTTPConnection(hostname)


def init_connection(hostname=None):
    """
    Initialize the live connection. Store it in a global variable so we can
    retrieve it with get_connection.

    If hostname is None, use a UNIX domain socket. Otherwise, create a normal
    HTTPConnection.
    """
    global _conn
    if _conn is not None:
        # Nothing to do!
        pass
    elif hostname is None:
        # No hostname means use UNIX domain socket.
        _conn = connect_unix(UDS_PATH)
    else:
        _conn = connect_inet(hostname)


def get_connection():  # pragma: no cover
    """
    Return the live connection.
    """
    global _conn
    return _conn


def needs_connection(
    user_function=None, *, get_hostname=None
):
    """
    Decorate a function that makes a network connection. Initializes the global
    connection variable.

    Also handles CueRequestError and turns it into a human-readable UserError.

    Can be used as

    ```
    @needs_connection
    def some_user_func(*args): ...
    ```

    or

    ```
    @needs_connection(**kwargs)
    def some_user_func(*args): ...
    ```

    Args:
        user_function: The callable to wrap. If not supplied on,
            `needs_connection` will return a decorator with signature
            `decorator(user_function)`.
        get_hostname: (optional; keyword-only) A callable to retrieve the
            hostname from the call args. Should return a string hostname. Is
            called with the same args/kwargs as the decorated function. If no
            callable is provided, assume that the hostname is an attribute of
            the first positional args (ie, `args[0].hostname`).
    """

    def needs_connection_decorator(user_function):

        @wraps(user_function)
        def needs_connection_wrapper(*args, **kwargs):
            if get_hostname is not None:
                # Use the provided getter function.
                hostname = get_hostname(*args, **kwargs)
            else:
                # Or assume it's inside the first argument.
                hostname = args[0].hostname

            # Initialize the connection to global _conn variable
            init_connection(hostname)
            try:
                result = user_function(*args, **kwargs)
            except CueRequestError as req_err:
                # Make it human-readable.
                url = req_err.url
                method = req_err.method
                status = req_err.status
                reason = req_err.reason
                detail = req_err.body['detail']

                err_msg = (
                    f"Error: {method} {url} responded with {status} {reason}"
                )
                if status == 400:
                    message = detail
                elif status == 403:
                    message = (
                        "You do not have permission to execute that command."
                    )
                else:
                    message = err_msg
                raise UserError(message)
            except ConnectionError as err:
                conn_location = hostname or UDS_PATH
                message = (
                    f"Unable to connect to cued at {conn_location}."
                    f"\n - {err}"
                )
                raise UserError(message)
            return result
        return needs_connection_wrapper

    if user_function is None:
        return needs_connection_decorator
    else:
        return needs_connection_decorator(user_function)


#######################
# Request handling
#######################

def parse_content_type(content_type):
    """
    Parse a Content-Type header into its parts.

        >>> parse_content_type('text/plain; charset=utf-8')
        ('text/plain', {'charset': 'utf-8'})
        >>> parse_content_type('application/json')
        ('application/json', {})

    Returns:
        A 2-tuple of the mimetype and a dict of parameters.
    """
    mimetype, *others = map(str.strip, content_type.split(';'))

    parameters = {}
    for other in others:
        key, value = map(str.strip, other.split("="))
        parameters[key] = value
    return (mimetype, parameters)


def send_request(cue_request):
    """
    Call the server and return the response.  If the request failed, an
    exception is raised.
    """
    conn = get_connection()
    if conn is None:
        raise ConnectionNotInitializedError()

    req_kwargs = cue_request.make_request_kwargs()

    # Send the request.
    conn.request(**req_kwargs)

    # Get the response and parse it.
    resp = conn.getresponse()

    # Parse the response body based on the content type
    content_type = resp.getheader('Content-Type', default="application/json")
    mimetype, parameters = parse_content_type(content_type)
    raw_body = resp.read()
    if mimetype == "text/plain":
        body = raw_body.decode(parameters.get('charset', 'utf-8'))
    else:
        body = json.loads(raw_body)

    if resp.status == 200:
        return body
    else:
        raise CueRequestError(
            method=req_kwargs["method"],
            url=req_kwargs["url"],
            status=resp.status,
            reason=resp.reason,
            body=body,
        )


def encode_path(api, *segments):
    from urllib.parse import quote
    api = quote(api, safe="")
    # The api part wants the trailing slash, so we've got to handle it
    # specially.
    return f"/{api}/" + "/".join(map(
        lambda segment: quote(segment, safe=""),
        segments,
    ))


###########################
# fetch_openapi_schemas
###########################

def convert_path_to_json_pointer(path: tuple) -> str:
    return "/".join(["", *[
        token.replace("~", "~0").replace("/", "~1")
        for token in path
    ]])


def convert_json_pointer_to_path(pointer: str) -> tuple:
    return tuple(
        token.replace("~1", "/").replace("~0", "~")
        for token in pointer.split("/")
    )[1:]


@lru_cache()
def _fetch_openapi_schemas(api, positional, subpaths):
    pointers_to_paths = {
        convert_path_to_json_pointer(path): path
        for path in subpaths
    }
    query = {"pointers": json.dumps(list(pointers_to_paths.keys()))}

    resp = send_request(
        CueRequest(
            path=encode_path(api, *positional),
            method="GET",
            query_params=query,
            header_overrides={
                "Accept": "application/vnd.oai.openapi+json"
            }
        )
    )
    return {
        pointers_to_paths[ptr]: val
        for ptr, val in resp.items()
    }


def fetch_openapi_schemas(api, positional, *, subpaths):
    """
    Fetch the openapi spec info for the path specified by `api` and
    `positional`.

    Args:
        api: String value of the API we're querying
        positional: List of positional args from the command
        subpaths: A sequence of tuple key paths to the desired parts of the
            openapi response.

    Returns:
        The openapi spec info for the endpoint's path.
    """

    # "Freeze" anything immutable before calling the cache-enabled function.
    return _fetch_openapi_schemas(
        api, tuple(positional), tuple(subpaths)
    )


###########################
# fetch_templatelinks
###########################

@lru_cache()
def _fetch_templatelinks(api=None, positional=tuple()):
    if api is None:
        path = "/"
    else:
        path = encode_path(api, *positional)
    return send_request(CueRequest(
        path=path,
        method="GET",
        header_overrides={
            "Accept": "application/vnd.cue.templatelinks+json"
        }
    ))


def fetch_templatelinks(api=None, positional=tuple()):
    # "Freeze" anything immutable before calling the cache-enabled function.
    return _fetch_templatelinks(api, tuple(positional))
