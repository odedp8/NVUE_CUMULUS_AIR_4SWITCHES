# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from dataclasses import dataclass


class TableInputError(Exception):
    pass


def justify_cell(cell: str, width: int) -> str:
    """
    Justify the contents of a single cell in the table.

    Args:
        cell: the string cell contents.
        width: the integer width of the column.

    Returns:
        The formatted cell as a string.
    """
    return cell.ljust(width, " ")


def justify_table(table, min_width=2):
    """
    Justify the contents of all cells in a table.

    Args:
        table: A 2d array of string cells
    """
    headers, *_ = table
    column_count = len(headers)
    column_widths = []
    for col_index in range(column_count):
        col_width = min_width
        # Find the widest cell in the column.
        for row in table:
            cell_text = row[col_index]
            col_width = max(col_width, len(cell_text))
        column_widths.append(col_width)

    padded_table = []
    for row in table:
        padded_row = []
        for cell, width in zip(row, column_widths):
            padded_row.append(justify_cell(cell, width))
        padded_table.append(padded_row)
    return padded_table


def row_dicts_to_lists(headers, dict_rows):
    """
    Convert a list of row dicts to a list of row lists.

    Args:
        headers: A list of string headers.
        dict_rows: A list of dict rows. Each dict row's keys should correspond
            with headers.

    Returns:
        A list of lists rows. Each row's values are extracted from the dict in
        the order specified by headers.
    """
    rows = []
    for dict_row in dict_rows:
        list_row = []
        for header in headers:
            list_row.append(dict_row[header])
        rows.append(list_row)

    return rows


@dataclass
class BaseTable:
    headers: list
    # A list of dicts
    rows: list

    def __post_init__(self):
        # Headers must all be stirngs
        if not all(map(lambda hdr: isinstance(hdr, str), self.headers)):
            raise TableInputError("Headers must all be strings")
        # Headers must NOT contain newlines
        if any(map(lambda hdr: "\n" in hdr, self.headers)):
            raise TableInputError("Values must not contain newlines")

        set_headers = frozenset(self.headers)
        if len(set_headers) != len(self.headers):
            raise TableInputError("Duplicate headers not allowed")

        # Validate the rows
        for idx, row in enumerate(self.rows):
            # Keys must match headers
            if frozenset(row.keys()) != set_headers:
                raise TableInputError(
                    f"Keys in row {idx} do not match the table headers",
                )
            # Values must all be strings
            if not all(map(lambda val: isinstance(val, str), row.values())):
                raise TableInputError("Values must all be strings")

            # Values must NOT contain newlines
            if any(map(lambda val: "\n" in val, row.values())):
                raise TableInputError("Values must not contain newlines")

    def _render_cells(self):
        """
        Return a 2-tuple of the headers and dict rows to render.
        """
        return (self.headers, self.rows)

    def render(self) -> str:
        headers, dict_rows = self._render_cells()

        list_rows = row_dicts_to_lists(headers, dict_rows)
        header_cells, *row_cells = justify_table([
            headers,
            *list_rows,
        ])

        header_divider = [
            "-" * len(cell)
            for cell in header_cells
        ]

        return "\n".join(
            map(
                # Strip trailing whitespace from rows
                lambda str_row: str_row.rstrip(" "),
                map(
                    "  ".join,
                    [header_cells, header_divider, *row_cells]
                )
            )
        )


@dataclass
class SummaryTable(BaseTable):
    SUMMARY_HEADER = "Summary"

    id_headers: list = None
    summary_keys: list = None
    summary_rows: list = None

    def __post_init__(self):
        super().__post_init__()
        skip_summary = (
            self.id_headers is None
            and self.summary_keys is None
            and self.summary_rows is None
        )
        # EARLY RETURN
        if skip_summary:
            # It's cool. We won't mess with this
            return
        # Row counts must match
        if len(self.summary_rows) != len(self.rows):
            raise TableInputError(
                "Count of summary rows must match count of table rows."
            )

        if not hasattr(self.id_headers, "__contains__"):
            raise TableInputError(
                "id_headers must implement __contains__"
            )

        if not set(self.id_headers).issubset(set(self.headers)):
            raise TableInputError(
                "id_headers must be a subset of headers"
            )

        set_summary_keys = frozenset(self.summary_keys)

        for summary_row in self.summary_rows:
            if frozenset(summary_row.keys()) != set_summary_keys:
                raise TableInputError(
                    "Keys in each of summary_rows must match summary_keys"
                )

            for summary_values in summary_row.values():
                if not isinstance(summary_values, list):
                    raise TableInputError(
                        "Values in each of summary_rows must be lists"
                    )
                for summary_val in summary_values:
                    if not isinstance(summary_val, str):
                        raise TableInputError(
                            "Each summary value must be a string"
                            + f": {repr(summary_val)}"
                        )
                    if "\n" in summary_val:
                        raise TableInputError(
                            "Summary values must not contain newlines"
                        )

    def _render_summary_cells(self):
        """Returns a 2-tuple (formatted_header, formatted_rows)"""
        # EARLY RETURN
        if self.summary_keys is None:
            return None
        # The separator string between summary key and summary value.
        separator = ": "

        # Loop through to find the maximum length of the summary column so we
        # can justify the rendered strings.
        max_summary_length = len(self.SUMMARY_HEADER)
        for summary_row in self.summary_rows:
            for summary_key in self.summary_keys:
                summary_values = summary_row[summary_key]
                for summary_val in summary_values:
                    cur_len = (
                        len(summary_key) + len(separator) + len(summary_val)
                    )
                    max_summary_length = max(cur_len, max_summary_length)

        # Loop through again, and collect the lists of rendered summary cell
        # strings, with values justified to the right. Each item in this list
        # is the list of summary cells associated with the corresponding row.
        summary_row_strings = []
        for summary_row in self.summary_rows:
            cur_row_strings = []
            summary_row_strings.append(cur_row_strings)

            for summary_key in self.summary_keys:
                summary_values = summary_row[summary_key]
                for summary_val in summary_values:
                    prefix = f"{summary_key}{separator}"
                    length_to_justify = max_summary_length - len(prefix)
                    justified_value = summary_val.rjust(length_to_justify)
                    summary_string = f"{prefix}{justified_value}"
                    cur_row_strings.append(summary_string)

            if len(cur_row_strings) == 0:
                # HACK: put an empty string in there, so we can be guaranteed
                #       at least one entry
                cur_row_strings.append("")

        return summary_row_strings

    def _render_cells(self):
        summary_rows = self._render_summary_cells()
        if summary_rows is None:
            return super()._render_cells()

        base_row_prefix = "+ "
        continuation_prefix = " " * len(base_row_prefix)

        #######################################################################
        # For the summary table, each "row" can span multiple lines. (One line
        # for base content, and an extra line for each additional summary
        # item.)
        # Expand the rows to include the summary contents.
        dict_lines = []
        for base_row, summary_cell in zip(self.rows, summary_rows):
            # Updates to the values contained in base_row.
            base_row_updates = {}
            # Show values for continuation lines. (Aside from the summary
            # column, everything else defaults to empty.)
            continuation_updates = {}

            for header in self.id_headers:
                identifier_value = base_row[header]

                # Add prefix to the identifier values.
                base_row_updates[header] = (
                    f"{base_row_prefix}{identifier_value}"
                )
                # Continuation lines should always show identifier.
                continuation_updates[header] = (
                    f"{continuation_prefix}{identifier_value}"
                )

            # NOTE: we are guaranteed to have at least one summary item per row
            first_summary_item, *extra_summary_items = summary_cell
            # Append our updated row with contents.
            dict_lines.append({
                **base_row,
                **base_row_updates,
                self.SUMMARY_HEADER: first_summary_item,
            })

            # Use the continuation_cells for any additional summary lines.
            for summary_cell in extra_summary_items:
                dict_lines.append({
                    # Continuation cells are blank by default.
                    **dict.fromkeys(self.headers, ""),
                    **continuation_updates,
                    self.SUMMARY_HEADER: summary_cell,
                })

        headers = [*self.headers, self.SUMMARY_HEADER]
        return (headers, dict_lines)


###############
# TreeTable
###############

def treeify(list_paths):
    """
    Take a list of path tuples and create a dict tree of the paths, filling in
    any "implied" path leaves.
    """
    root = {}
    for path in list_paths:
        cur_node = root
        subpath = tuple()
        for token in path:
            subpath = (*subpath, token)
            cur_node = cur_node.setdefault(subpath, {})
    return root


@dataclass
class TreeTable(BaseTable):

    INDENT = "  "

    def __post_init__(self):
        super().__post_init__()

        id_key, *other_keys = self.headers

        map_path_to_rows = {}
        for row in self.rows:
            id_path = tuple(row[id_key].split("."))
            path_rows = map_path_to_rows.setdefault(id_path, [])
            path_rows.append(row)
        root = treeify(map_path_to_rows.keys())

        def _get_new_rows(node, indent=""):
            # Recursively traverse the tree, yielding each indented row.
            for id_path, inner_node in node.items():
                *_, id_value = id_path
                indented_id = indent + id_value
                matched_rows = map_path_to_rows.get(
                    id_path,
                    # It's not a row we had data for. Fill in contents with
                    # empty strings.
                    [{
                        key: ""
                        for key in other_keys
                    }]
                )
                for row_contents in matched_rows:
                    yield {
                        **row_contents,
                        # Overwrite the id column with our indented id.
                        id_key: indented_id,
                    }
                # Bump the indent and get the next level
                next_indent = indent + self.INDENT
                yield from _get_new_rows(inner_node, next_indent)

        self.rows = list(_get_new_rows(root))
        # Validate again for good measure
        super().__post_init__()
