# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
The `locoparse` module is the magic behind CUE's CLI argument parser.
`locoparse` is short for "locomotive parser". Picture a cartoon animal riding
on the front of a speeding train, frantically laying railroad tracks ahead to
keep the train on the rails. That's how `locoparse` works.

Instead of generating the whole parse tree, `locoparse` lets you define a
subset of the parse tree, and fill out just the important bits at runtime.

Before doing the full parse of argv, `locoparse` does a partial parse. If a
hook was triggered, that hook's callback can update the parser while looking at
the result of the partial parse. The hook is how you lay down more railroad
track after hitting the end of a defined path.

`parse_from_json` is the primary interface for `locoparse`. It provides a layer
of sanity between us and the insane Frankenstein monster known as `LocoParser`.
`LocoParser` is a hacked up subclass of `argparse.ArgumentParser`, and it is
not pretty. `parse_from_json` exposes all the important behavior in a way
that's decoupled from insanity.
"""
import os
import sys
from functools import partial
from io import StringIO
from argparse import (
    ArgumentParser,
    Namespace,
    _SubParsersAction,
    _MutuallyExclusiveGroup,
    SUPPRESS,
    RawDescriptionHelpFormatter,
)

from cli_cue.minimock import SimplePatch


def _hack_disable_gettext():
    """
    PERFORMANCE HACK: argparse spends a significant amount of time trying (and
    failing) to translate messages using gettext. i18n isn't being used or
    tested currently, so it's worth disabling for now.

    Once we start supporting i18n, it'll be worth taking another look at this.
    """
    import argparse
    argparse._ = lambda msg: msg


_hack_disable_gettext()


##################
# argv smarts
##################

def wants_completion():
    """
    Are we just looking for completions right now?
    """
    return "_ARGCOMPLETE" in os.environ


def get_argv():
    """
    Get argv, even if we're in tab completion mode.
    """
    # EARLY RETURN
    if not wants_completion():
        # It's a normal command, so we can just return argv
        return sys.argv

    comp_line = os.environ["COMP_LINE"]
    comp_point = int(os.environ["COMP_POINT"])

    cword_prefix = comp_line[:comp_point]

    argv = cword_prefix.split()
    if not cword_prefix.endswith(" "):
        # Drop the last argument from argv
        *argv, _ = argv
    return argv


#######################
# argparse subclasses
#######################

_WILDCARD_SUBPARSER = "__WILDCARD_SUBPARSER__"

_HOOK_GENERATE_SUBCOMMANDS_ATTR = "_hook_generate_subcommands"

_DEEPEST_PARSER_ATTR = "_deepest_parser"


class LocoParser(ArgumentParser):

    def __init__(
        self, *args, hook_generate_subcommands=None, _is_root=True, **kwargs
    ):
        """
        Args:
            hook_generate_subcommands: optional - A callback to be invoked
                during `generate()` if this parser is matched by the partial
                parse.
        """
        self.wants_help = kwargs.get("add_help", True)

        super().__init__(
            *args,
            formatter_class=RawDescriptionHelpFormatter,
            **kwargs,
        )

        # Use our own class for subparsers
        self.register('action', 'parsers', _LocoSubParsersAction)
        self.register(
            'action', 'accumulate_subcommands', _AccumulateSubParsersAction
        )
        self.register(
            'action', 'accumulate_subcommands_wildcard',
            _AccumulateWildcardSubParsersAction,
        )

        # Store the hook if we've got it
        self.hook_generate_subcommands = hook_generate_subcommands
        # Add a place for us to do identifiers
        self.identifiers = []
        # Used to help determine when we should remove "private" attributes
        # from the parsed namespace.
        self._is_root_parser = _is_root

    def _format_help(self):
        formatter = self._get_formatter()

        # usage
        formatter.add_usage(self.usage, self._actions,
                            self._mutually_exclusive_groups)

        subcommand_groups = []
        positional_groups = []
        option_groups = []
        # Separate subparsers from the action_groups
        for action_group in self._action_groups:
            if action_group.title in [
                "optional arguments", "positional arguments", SUPPRESS,
            ]:
                # HACK: don't show default groups, since those are sometimes
                #       weird (e.g., with mutex groups)
                continue
            is_subparser_group = (
                len(action_group._group_actions) == 1
                and isinstance(
                    action_group._group_actions[0],
                    _SubParsersAction,
                )
            )
            is_positional_group = not (is_subparser_group or any(map(
                # NOTE: Positional arguments don't have `option_strings`, so
                #       that's how we're figuring out if it's a positional or
                #       an option.
                lambda action: action.option_strings,
                action_group._group_actions
            )))
            if is_subparser_group:
                subcommand_groups.append(action_group)
            elif is_positional_group:
                positional_groups.append(action_group)
            else:
                option_groups.append(action_group)

        # Description
        if self.description is not None:
            formatter.start_section("Description")
            formatter.add_text(self.description)
            formatter.end_section()

        # Identifiers
        if self.identifiers:
            formatter.start_section("Identifiers")
            identifier_arguments = [
                Namespace(
                    metavar=f"<{id_}>",
                    help=text,
                    option_strings=None,
                    dest=None,
                )
                for id_, text in self.identifiers
            ]
            formatter.add_arguments(identifier_arguments)
            formatter.end_section()

        # Subcommands
        for action_group in subcommand_groups:
            formatter.start_section(action_group.title)
            formatter.add_text(action_group.description)

            # Collapse subparser groups
            subparsers_action = action_group._group_actions[0]
            pseudo_actions = subparsers_action._choices_actions
            formatter.add_arguments(pseudo_actions)

            formatter.end_section()

        # Positionals
        for action_group in positional_groups:
            formatter.start_section(action_group.title)
            formatter.add_text(action_group.description)
            formatter.add_arguments(action_group._group_actions)
            formatter.end_section()

        # Mutually exclusive options
        for mutex_group in self._mutually_exclusive_groups:
            if mutex_group.title in [None, SUPPRESS]:
                # Skip rendering these
                continue
            formatter.start_section(mutex_group.title)
            formatter.add_text(mutex_group.description)
            formatter.add_arguments(mutex_group._group_actions)
            formatter.end_section()

        # Options
        for action_group in option_groups:
            formatter.start_section(action_group.title)
            formatter.add_text(action_group.description)
            formatter.add_arguments(action_group._group_actions)
            formatter.end_section()

        # epilog
        formatter.add_text(self.epilog)

        # determine help from format above
        return formatter.format_help()

    def format_help(self):
        self._action_groups = reversed(self._action_groups)
        super_help = self._format_help()
        usage_prefix = "usage: "
        indent_prefix = "  "

        return "Usage:\n" + indent_prefix + super_help[len(usage_prefix):]

    def just_usage(self):
        """Return the formatted usage string on its own."""
        formatter = self._get_formatter()
        formatter.add_usage(
            self.usage, self._actions, self._mutually_exclusive_groups, ""
        )
        return formatter.format_help().strip()

    def parse_args(self, args=None, namespace=None):
        args, argv = self.parse_known_args(
            args,
            namespace,
            _collect_deepest_subparser=True,
        )
        # Report any errors from the closest subparser to ensure a good usage
        # message.
        closest_subparser = vars(args).pop(_DEEPEST_PARSER_ATTR)
        ############################################################
        # Everthing else is copy/paste from superclass, but using
        # closest_subparser instead of `self` and skipping the call to gettext.
        if argv:
            msg = 'unrecognized arguments: %s'
            closest_subparser.error(msg % ' '.join(argv))  # noqa: S001,G002
        return args

    def parse_known_args(
        self,
        args=None,
        namespace=None,
        *,
        _collect_deepest_subparser=False,
        _collect_hook=False,
    ):
        if namespace is None:
            namespace = Namespace()
        # We always want the deepest parser here. By attaching it to the
        # namespace BEFORE calling the superclass, it won't override any deeper
        # parsers that may be in the parsed results.
        setattr(namespace, _DEEPEST_PARSER_ATTR, self)
        if self.hook_generate_subcommands is not None:
            # We only care about the hook if it's present.
            setattr(
                namespace,
                _HOOK_GENERATE_SUBCOMMANDS_ATTR,
                # The hook is always called with the parser instance as the
                # first arg. Bind it now to keep track of which instance it
                # goes with.
                partial(self.hook_generate_subcommands, self)
            )

        parsed, unknown = super().parse_known_args(args, namespace)

        if self._is_root_parser:
            # Time to clean up! Unless the caller asked for it, we're getting
            # rid of these.
            if not _collect_deepest_subparser:
                delattr(parsed, _DEEPEST_PARSER_ATTR)
            if not _collect_hook:
                try:
                    delattr(parsed, _HOOK_GENERATE_SUBCOMMANDS_ATTR)
                except AttributeError:
                    pass

        return parsed, unknown

    def generate(self, args):
        try:
            # HACK: Clip args to everything before first occurrence of help
            #       token. This makes it so we can generate helptext metadata
            #       for the subcommand that needs it and no more. Clipping out
            #       the help token also makes it so we don't exit early when we
            #       have the helptext token present.
            # FIXME: this behavior happens even when there's no help argument
            #        defined.
            # TODO: teach this how to recognize when "-h" isn't being used as
            #       an option
            help_idx = next((
                idx
                for idx, token in enumerate(args)
                if token in ["-h", "--help"]
            ))
            args = args[:help_idx]
        except StopIteration:
            # No help in args. This is fine.
            pass
        parsed, unknown = self.parse_known_args(args, _collect_hook=True)
        hook = vars(parsed).pop(
            _HOOK_GENERATE_SUBCOMMANDS_ATTR, None
        )
        if hook is not None:
            hook(parsed, unknown, args)

    def get_subparsers(self):
        # HACK: Find the existing subparsers action.
        return next(filter(
            lambda action: isinstance(action, _SubParsersAction),
            self._subparsers._actions
        ))

    def add_mutually_exclusive_group(self, **kwargs):
        # Do the same thing as the superclass, but with a class that can
        # accommodate a "title".
        group = _LocoMutuallyExclusiveGroup(self, **kwargs)
        self._mutually_exclusive_groups.append(group)
        return group

    def add_subcommand(self, name, metavar=None, **kwargs):
        """
        This is similar to add_parser on a subparsers action, but it
        automatically finds this parser's subparsers, adds a parser to it, and
        handles any other details that need to be ironed out between parent and
        child.

        tl;dr, use this in favor of subparsers.add_parser(), unless you're
            looking to circumvent LocoParser's helpful magic.

        Args:
            name: The string name of the subcommand
            metavar: optional - string to use when implementing the subparser's
                `prog` value. Defaults to `name` if not specified.

        Returns:
            The newly created parser.
        """
        if self._subparsers is None:
            subparsers = self.add_subparsers()
        else:
            subparsers = self.get_subparsers()

        # Use a more sensible default for subcommand's "prog". (argparse will
        # use the parent parser's "usage" string instead of "prog", which gives
        # us super wonky helptext.)
        metavar = metavar or name
        kwargs.setdefault("prog", f"{self.prog} {metavar}")
        # HACK: don't let "help" be None. Setting it as an empty string will
        #       ensure that it shows up in the subcommand.
        help_str = kwargs.setdefault("help", "")

        if help_str == SUPPRESS:
            # MONDO HACK: When argcomplete asks whether this completion is
            #             valid for a given prefix, always say "nope!". Note
            #             that this will always keep suppressed subcommands out
            #             of completions, regardless of how argcomplete is
            #             configured.
            class _StringThatStartsWithNothingLiar(str):
                def startswith(self, *_):
                    # TODO: consider checking that we're in argcomplete mode
                    #       before doing this.
                    return False

            name = _StringThatStartsWithNothingLiar(name)

        return subparsers.add_parser(
            name,
            add_help=self.wants_help,
            _is_root=False,
            **kwargs,
        )


class _LocoMutuallyExclusiveGroup(_MutuallyExclusiveGroup):
    """
    Pretty much exactly the same thing as `argparse._MutuallyExclusiveGroup`,
    but this one can handle a title and a description (similar to a regular
    argument group.)
    """

    def __init__(self, *args, **kwargs):
        title = kwargs.pop("title", None)
        description = kwargs.pop("description", None)

        super().__init__(*args, **kwargs)

        self.title = title
        self.description = description


class _LocoSubParsersAction(_SubParsersAction):
    """
    A subparsers action that is better at sharing info with subparsers.
    """

    def __call__(self, parser, namespace, values, option_string=None):
        # Pass in an empty namespace, so we can control how we overwrite.
        subnamespace = Namespace()
        super().__call__(parser, subnamespace, values, option_string)
        # Overwrite values that are usually defaults.
        # NOTE: This isn't aware of actual defaults. It can be weird when a
        #       default is set to something that's not a common default.
        common_defaults = [None, tuple(), 'auto']
        for key, value in vars(subnamespace).items():
            if getattr(namespace, key, None) in common_defaults:
                setattr(namespace, key, value)
            elif key == _DEEPEST_PARSER_ATTR:
                # We always want the deeper value here.
                setattr(namespace, key, value)


class _AccumulateSubParsersAction(_LocoSubParsersAction):
    """
    Accumulates the names of "used" subparsers in a tuple at the provided
    `dest`. (The "normal" parser behavior is to set `dest` to the name of just
    one subparser.)
    """

    def __init__(self, *args, **kwargs):
        if "dest" not in kwargs:
            raise Exception(
                "'dest' required for 'accumulate_subcommands' action"
            )
        super().__init__(*args, **kwargs)
        # Subparsers sensibly default their value to `None`. Here, an empty
        # tuple is more appropriate as the default.
        self.default = tuple()

    def __call__(self, parser, namespace, values, option_string=None):
        # HACK: this is how the superclass decides the name of the subparser.
        parser_name, *_ = values

        with SimplePatch(self, "dest", SUPPRESS):
            # HACK: Suppress the dest while calling superclass to keep it from
            #       clobbering the accumulated names.
            super().__call__(parser, namespace, values, option_string)

        # Get the tokens accumulated in the namespace so far.
        accumulated = getattr(namespace, self.dest)
        # Add parser_name to the BEGINNING of the accumulated value. Since the
        # calls are nested, child parsers finish parsing before parents.
        setattr(namespace, self.dest, (parser_name, *accumulated))


class _AccumulateWildcardSubParsersAction(_AccumulateSubParsersAction):
    """
    We need to allow wildcard values in the OM. For example, `<interface-id>`
    in `nv show interface <interface-id> ip address`. The templatelinks
    mechanism can suggest possible values for a wildcard, but it can't give an
    authoritative list. This doesn't work well with the default subparsers.

    We need a way to say, "Just treat any token you get as the subcommand."
    Bonus points if we can still pass suggested values to argcomplete.

    This class can only accommodate a single subparser. It will use that
    subparser's definition for any token it consumes. It writes that token to
    `dest` as if that were the name of the subparser.
    """

    class _HackContainsEverythingLiar:
        """
        A thin wrapper around a regular dict. Can't use a superclass here,
        since we're relying on mutation, and the init/sharing of the dict
        happens in a place we can't easily override.

        The only real purpose of this is to override self.choices.__contains__
        so `arg in self.choices` always evaluates to True. Without this, the
        argparser will error out we can get to anything.
        """
        def __init__(self, data):
            self.data = data

        def __contains__(self, *_):
            # Whatever you're looking for, we've got it!
            return True

        def __getattr__(self, attr):
            # Proxy anything we haven't overridden to `self.data`.
            return getattr(self.data, attr)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # HACK: Whenever someone asks, "Is this a valid choice?" the answer is,
        #       "Oh yes, most definitely!"
        self.choices = self._HackContainsEverythingLiar(self.choices)

    def add_parser(self, name, **kwargs):
        if name != _WILDCARD_SUBPARSER:
            # NOTE: we could hardcode the name, but that makes the
            #       implementation of `LocoParser.add_subcommand` trickier.
            #       It's easier to say, "Any name you want as long as it's
            #       _WILDCARD_SUBPARSER."
            raise Exception(
                f"{repr(_WILDCARD_SUBPARSER)} is the only name allowed."
            )
        if hasattr(self, "_the_subparser"):
            raise Exception(
                "Cannot add multiple parsers to an"
                + " 'accumulate_subcommands_wildcard' action."
                + " Use the 'alias' keyword to populate completions."
            )
        result = super().add_parser(name, **kwargs)
        # HACK: Pop it off so it doesn't show up in completions/helptext,
        #       but make sure we can get back to it later.
        self._the_subparser = self._name_parser_map.pop(
            _WILDCARD_SUBPARSER
        )
        return result

    def __call__(self, parser, namespace, values, option_string=None):
        parser_name, *_ = values
        # HACK: Peek at the name the superclass will look for. Patch THE
        #       subparser in as if it were actually associated with that name.
        with SimplePatch(
            self, "_name_parser_map", {parser_name: self._the_subparser}
        ):
            super().__call__(parser, namespace, values, option_string)


#######################
# parse_from_json
#######################

_ARGUMENT_PASSTHROUGH_KEYS = [
    "action", "help", "default", "metavar", "const", "dest", "choices",
    "nargs", "type",
]
_SUBPARSERS_PASSTHROUGH_KEYS = [
    "title", "required", "dest", "metavar",
]


def _add_group(group, parser):
    if group.get("mutually_exclusive", False):
        argparse_group = parser.add_mutually_exclusive_group(
            title=group["title"],
        )
    else:
        argparse_group = parser.add_argument_group(
            title=group["title"],
        )
    for argument in group["arguments"]:
        argnames = argument["value"]
        if str(argnames) == argnames:
            argnames = [argnames]
        arg_kwargs = {
            key: argument[key]
            for key in _ARGUMENT_PASSTHROUGH_KEYS
            if key in argument
        }
        new_arg = argparse_group.add_argument(
            *argnames, **arg_kwargs,
        )
        if "completer" in argument:
            new_arg.completer = argument["completer"]


def _attach_hook(parser, parser_def, parser_decorators):
    if "hook" not in parser_def:
        return
    hook = parser_def["hook"]

    def _created_hook(parser, parsed, unknown, *_):
        found_def = hook(parsed, unknown)
        _configure_parser(parser, found_def, parser_decorators)

    parser.hook_generate_subcommands = _created_hook


def _create_nodes(parser, parser_def, parser_decorators):
    if "nodes" not in parser_def:
        return
    nodes = parser_def["nodes"]
    parser.add_subparsers(
        action="accumulate_subcommands",
        **{
            key: nodes[key]
            for key in _SUBPARSERS_PASSTHROUGH_KEYS
            if key in nodes
        }
    )
    for choice in nodes["choices"]:
        subp = parser.add_subcommand(
            choice["value"], help=choice["help"]
        )
        _configure_parser(subp, choice, parser_decorators)


def _add_identifier(identifier, helptext, parser):
    if helptext is not None:
        parser.identifiers.append((identifier, helptext))


def _create_identifier_node(parser, parser_def, parser_decorators):
    if "identifier_node" not in parser_def:
        return
    identifier_node = parser_def["identifier_node"]
    metavar = identifier_node["metavar"]
    # Clip off the `<` and `>`
    identifier = metavar[1:-1]
    parser.add_subparsers(
        action='accumulate_subcommands_wildcard',
        **{
            key: identifier_node[key]
            for key in _SUBPARSERS_PASSTHROUGH_KEYS
            if key in identifier_node
        }
    )
    decorate_identifier = partial(
        _add_identifier, identifier, identifier_node["help"]
    )
    decorate_identifier(parser)
    subp = parser.add_subcommand(
        _WILDCARD_SUBPARSER,
        aliases=identifier_node["choices"],
        metavar=metavar,
        help=SUPPRESS,
    )
    _configure_parser(
        subp, identifier_node, (*parser_decorators, decorate_identifier)
    )


_MUTUALLY_EXCLUSIVE_ATTRS = {"hook", "commands", "nodes", "identifier_node"}


def _configure_parser(parser, parser_def, parser_decorators=tuple()):
    if len(_MUTUALLY_EXCLUSIVE_ATTRS.intersection(parser_def.keys())) > 1:
        raise Exception(
            f"Only one of {repr(_MUTUALLY_EXCLUSIVE_ATTRS)} is allowed."
        )
    parser_attributes = ["usage", "description"]
    for attr in parser_attributes:
        # NOTE: don't overwrite things that have already been written. (Since
        #       the hook doesn't know about its parent, we put the burden on
        #       the parent to avoid setting unneeded properties.)
        if attr in parser_def and not getattr(parser, attr):
            setattr(parser, attr, parser_def[attr])

    # Use "help" value for "description" if no "description" found
    if parser.description is None and "description" not in parser_def:
        parser.description = parser_def.get("help")

    if "defaults" in parser_def:
        parser.set_defaults(**parser_def["defaults"])

    local_decorators = tuple()
    if "groups" in parser_def:
        groups = parser_def["groups"]
        parser_decorators = parser_decorators + tuple((
            partial(_add_group, group)
            for group in groups
            if group.get("propagate", False)
        ))
        local_decorators = tuple((
            partial(_add_group, group)
            for group in groups
            if not group.get("propagate", False)
        ))

    # HACK: cache which decorators have been applied, so we don't duplicate
    parser._applied_decorators = getattr(parser, "_applied_decorators", [])

    for func in (*parser_decorators, *local_decorators):
        if func not in parser._applied_decorators:
            func(parser)
            parser._applied_decorators.append(func)

    _attach_hook(parser, parser_def, parser_decorators)

    _create_nodes(parser, parser_def, parser_decorators)
    _create_identifier_node(parser, parser_def, parser_decorators)

    if "commands" in parser_def:
        commands = parser_def["commands"]
        parser.add_subparsers(
            **{
                key: commands[key]
                for key in _SUBPARSERS_PASSTHROUGH_KEYS
                if key in commands
            }
        )
        for choice in commands["choices"]:
            subcommand_parser = parser.add_subcommand(
                choice["value"],
                help=choice["help"],
            )
            _configure_parser(subcommand_parser, choice, parser_decorators)
    return parser


def parse_from_json(parser_def, *, callback=None):
    """
    Use a JSON-esque data structure to define what argv gets parsed into. This
    is the pretty facade over the horrible ugliness of argparse and my crazy
    LocoParser hacks.

    A parser can be defined as a pure JSON blob. There's also a "hook" keyword,
    which can be used to dynamically augment the parser at runtime using the
    results of a partial parse. This is useful when defining commands based off
    the output of an API.

    A hook function is called as `hook(parsed, unknown)`, where
     - `parsed` is the `argparse.Namespace` containing the known parse results
     - and `unknown` is a list of tokens that weren't recognized by the parser.

    The return value of a hook function is expected to be a JSON-esque parser
    definition, which will be applied to the subparser the hook was attached
    to.

    After applying the hook (if any was found), `parse_from_json` will do a
    full parse of argv using the created parser.

    Args:
        parser_def: The JSON-esque data structure defining the parser.
        callback: (keyword only) An optional function to be called AFTER
            creating the parser, but BEFORE the full parse of argv. Called as
            `callback(parser)`. This is mostly intended as a way to attach
            argcomplete to the parser.

    Returns:
        An `argparse.Namespace` containing the final parse results.
    """
    parser = LocoParser(add_help=False)
    _configure_parser(parser, parser_def)

    _, *args = get_argv()
    # HACK: don't exit or print to stderr while attempting to fill out the
    #       parser
    with SimplePatch(sys, "stderr", StringIO()):
        try:
            parser.generate(args)
        except SystemExit:
            pass
    if callback is not None:
        callback(parser)
    return parser.parse_args()
