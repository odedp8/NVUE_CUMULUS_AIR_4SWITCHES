# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

"""
Utilities for handling the per-user config file.
"""


def find_config_file():
    from os import environ
    from os.path import join

    try:
        # $XDG_CONFIG_HOME defines the base directory relative to which
        # user-specific configuration files should be stored.
        base_dir = environ["XDG_CONFIG_HOME"]
    except KeyError:
        base_dir = None

    # If $XDG_CONFIG_HOME is either not set or empty, a default equal to
    # $HOME/.config should be used.
    if not base_dir:
        base_dir = join(environ["HOME"], ".config")

    nvue_dir = join(base_dir, "nvue")
    return join(nvue_dir, "nvue.ini")


def load_config() -> dict:
    from configparser import ConfigParser
    config = ConfigParser(default_section="base")
    # Don't lowercase-ify option names.
    config.optionxform = str
    config.read(find_config_file())
    # Dumb down the data structure. A dict of dicts is perfectly fine for our
    # needs. More importantly, it's less likely to surprise us than a
    # ConfigParser object is.
    return {
        section: dict(contents)
        for section, contents in config.items()
    }


def update_environ():
    try:
        environ_config = load_config()["environ"]
    except KeyError:
        # EARLY RETURN
        # No environ config -> nothing to do!
        return
    from os import environ

    environ.update(environ_config)
