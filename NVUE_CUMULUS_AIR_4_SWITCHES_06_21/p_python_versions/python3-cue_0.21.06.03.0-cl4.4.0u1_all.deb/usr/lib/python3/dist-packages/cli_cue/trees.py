# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from dataclasses import dataclass, field
from .schema_utils import (
    group_schema_paths_by_instance_path,
    PATH_WILDCARD,
    PATH_KEY,
    get_schema_types,
    find_schema_keyword,
)


@dataclass
class SimpleNode:
    name: str = None
    read_only: bool = False
    type_: str = ""
    key_param: str = None
    children: list = field(default_factory=list)
    proposed: bool = False

    @property
    def contained_depth(self):
        # HACK: used for sorting with depth
        if self.proposed:
            return 0
        depth = 0
        if self.name:
            depth += 1
        if self.key_param is not None:
            depth += 1
        if self.children:
            depth += max(child.contained_depth for child in self.children)
        return depth

    def get_base_string(self):
        status = "?" if self.proposed else "+"
        flags = (
            "-p" if self.proposed
            else "ro" if self.read_only
            else "rw"
        )
        result = f"{status}--{flags} {self.name}"
        if self.key_param is not None:
            result = f"{result}* [{self.key_param}]"
        return result

    def find_or_create(self, name):
        try:
            return next(filter(
                lambda child: child.name == name,
                self.children
            ))
        except StopIteration:
            new_node = SimpleNode(name=name)
            self.children.append(new_node)
            return new_node


SPACE_FACTOR = 3
INDENT_STRING = " " * 3


def _link_siblings(sibling_lines):
    last_sibling_index = 0
    for index, (base, _) in enumerate(sibling_lines):
        if not base.startswith(" "):
            last_sibling_index = index

    return [
        (
            ("|" + base[1:], type_)
            if index < last_sibling_index and base.startswith(" ")
            else (base, type_)
        )
        for index, (base, type_) in enumerate(sibling_lines)
    ]


def _render_simple_tree(node):
    return [
        (node.get_base_string(), node.type_),
        # FIXME: clean this up!!
        *map(
            lambda line: (INDENT_STRING + line[0], line[1]),
            _link_siblings([
                (base_str, type_)
                for rendered_child in map(_render_simple_tree, node.children)
                for base_str, type_ in rendered_child
            ])
        )
    ]


def render_simple_tree(node):
    if node.name is None:
        # FIXME: clean this up!!
        lines = [
            # HACK: just come up with a module name for now
            ("module: root", ""),
            *map(
                lambda line: ("  " + line[0], line[1]),
                _link_siblings([
                    (base_str, type_)
                    for rendered_child in map(
                        _render_simple_tree, node.children
                    )
                    for base_str, type_ in rendered_child
                ])
            )
        ]
    else:
        lines = _render_simple_tree(node)
    # Find the length of the longest base
    found_max = 0
    for base, _ in lines:
        found_max = max(len(base), found_max)

    str_lines = [
        (base.ljust(found_max) + INDENT_STRING + type_).rstrip()
        for base, type_ in lines
    ]
    return "\n".join(str_lines) + "\n"


#######################
# stream_command_tree
#######################

VERB_SET = "set"
VERB_SHOW = "show"
VERB_UNSET = "unset"
VERB_SET_OR_UNSET = f"[un]set"

VERBS = [
    VERB_SET,
    VERB_SHOW,
    VERB_UNSET,
    VERB_SET_OR_UNSET,
]

MAX_LEN = max(map(len, VERBS))


def _as_command_wildcard(token):
    return f"<{token}>"


@dataclass(frozen=True)
class TreeCommand:
    verb: str
    tokens: tuple

    def __str__(self):
        verb = self.verb.ljust(MAX_LEN)
        return " ".join(["nv", verb, *self.tokens])


def yield_commands_from_tree(node, tokens=()):
    # EARLY RETURN
    if node.proposed:
        return

    current_tokens = tokens
    if current_tokens:
        yield TreeCommand(VERB_SHOW, current_tokens)

    if node.name:
        current_tokens = (*current_tokens, node.name)
        if node.key_param is not None:
            # OM considers a key as a child. So this one will have an endpoint.
            yield TreeCommand(VERB_SHOW, current_tokens)

    if node.key_param is not None:
        current_tokens = (
            *current_tokens, _as_command_wildcard(node.key_param)
        )

    has_children = any(not child.proposed for child in node.children)
    if has_children:
        sorted_children = sorted(
            node.children,
            key=lambda child: child.contained_depth,
        )
        for child in sorted_children:
            yield from yield_commands_from_tree(child, current_tokens)
    else:
        set_tokens = current_tokens
        if node.type_ != "object" and not node.children:
            set_tokens = (*set_tokens, _as_command_wildcard(node.type_))
        unset_tokens = current_tokens

        if not node.read_only:
            if set_tokens != unset_tokens:
                yield TreeCommand(VERB_SET, set_tokens)
                yield TreeCommand(VERB_UNSET, unset_tokens)
            else:
                yield TreeCommand(VERB_SET_OR_UNSET, set_tokens)


def stream_command_tree(tree, thusfar_tokens=()):
    # Prevent duplicate commands.
    seen = set()
    for line in yield_commands_from_tree(tree, thusfar_tokens):
        if line not in seen:
            seen.add(line)
            yield str(line)


###########################
# schemas_as_simple_tree
###########################

ROOT_NODE_NAME = ""
DEFAULT_KEY_PARAM = "???"


def schemas_as_simple_tree(read_schema, write_schema, full_schema=None):
    if full_schema is None:
        full_schema = read_schema
    # dicts of instance loc to list of schema locs
    full_locations = group_schema_paths_by_instance_path(full_schema)
    read_locations = group_schema_paths_by_instance_path(read_schema)
    write_locations = group_schema_paths_by_instance_path(write_schema)

    proposed_paths = set(full_locations) - set(read_locations)
    read_only_paths = set(read_locations) - set(write_locations)
    # Going to focus on the superset of all schemas
    schema_paths_by_instance = full_locations

    root = SimpleNode(ROOT_NODE_NAME)
    seen_paths = set([tuple()])
    # Group locations by depth
    deepest_first = reversed(sorted(
        schema_paths_by_instance.keys(),
        key=len,
    ))

    def _add_path(path):
        cur_path = tuple()
        cur_node = root
        # Process each ancestor path of the path argument
        for token in path:
            cur_path = (*cur_path, token)
            if token is PATH_WILDCARD:
                # Get the instance path of the key for this wildcard.
                key_path = (*cur_path[:-1], PATH_KEY)
                # Set the key_param based off the key schema if we haven't
                # already
                cur_node.key_param = cur_node.key_param or next(
                    find_schema_keyword(
                        "format", full_schema, key_path
                    ),
                    DEFAULT_KEY_PARAM
                )
            else:
                cur_node = cur_node.find_or_create(token)

            if cur_path in read_only_paths:
                cur_node.read_only = True
            if cur_path in proposed_paths:
                cur_node.proposed = True
            # Add to seen_paths, so we don't process ancestors again.
            seen_paths.add(cur_path)

        # cur_node is now the node associated with the full path, making it a
        # leaf. Add type information to it.
        types = tuple(get_schema_types(full_schema, path))
        if "string" in types:
            # Show the string format if we've got it
            cur_node.type_ = next(
                find_schema_keyword("format", full_schema, path),
                "string"
            )
        else:
            found_type = next(iter(types), DEFAULT_KEY_PARAM)
            cur_node.type_ = found_type

    # Start at the deepest paths, and work back toward the "root". Each
    # invokation of _add_path adds that paths ancestors to seen_paths. By
    # skipping handled ancestors, we can guarantee that the final node in each
    # path is a leaf and handle it as such.
    for path in deepest_first:
        if (
            path not in seen_paths
            # Don't process paths to keys (those get handled elsewhere)
            and path[-1] is not PATH_KEY
        ):
            _add_path(path)

    return root
