# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from functools import partial
from cli_cue.minimock import sentinel
import json


# For representing additionalProperties in path sequences
PATH_WILDCARD = sentinel.PATH_WILDCARD
# Represents that the path is referring to the key value(s) of the instance
PATH_KEY = sentinel.PATH_KEY


# Keywords that contain a list of subschemas
SCHEMA_LIST_APPLICATORS = [
    "allOf",
    "oneOf",
    "anyOf",
]


# Keywords that contain a dict where each value is a subschema
SCHEMA_OBJECT_APPLICATORS = [
    "properties",
]


# Keywords that contain a single subschema
SCHEMA_SINGLE_APPLICATORS = [
    "x-propertyNames",
    "additionalProperties",
]


class PathLookupError(LookupError):
    """
    Could not find the specified path in a nested object.

    Attributes:
        path: The full path tuple sought.
        found: The portion of the path tuple that was found.
    """

    def __init__(self, path, found):
        self.path = tuple(path)
        self.found = tuple(found)

    def __str__(self):
        return f"{self.path!r} only found {self.found!r}"


#####################
# Misc object utils
#####################

def make_tree(paths, values):
    """
    Make a dictionary tree from a list of paths and a list of values. The paths
    are the list of keys to get from the tree root to the corresponding value
    in the dictionary.

    Args:
        paths: A list of paths, where each path is a list of dict keys
        values: A list of values corresponding to the paths
    """
    root = {}
    for path_idx, path in enumerate(paths):
        cur = root
        # Make dicts for every node up until last
        for token in path[:-1]:
            cur = cur.setdefault(token, {})
        # Last node gets the value
        cur[path[-1]] = values[path_idx]
    return root


def convert_to_flat_paths(data, condition=None, path=None):
    """
    Convert a deeply nested dict into a generator returning paths and leaf
    values.

    Args:
        data: A tree of dicts/lists.
        condition: An optional callable, called at each node while walking the
            data tree. If `condition` returns a falsey value, no descendants of
            that node will be yielded. Invoked as `condition(data)`.

    Yields:
        2-tuple `(path, data)` where `path` is the tuple of indexes/keys
        representing the location of leaf `data` from the root of the tree.
    """
    if path is None:
        path = []

    # EARLY RETURN
    if data in [[], {}]:
        # Handle empty objects
        if len(path) != 0:
            # Only treat empty objects as "primitives" if they're leaves in the
            # tree. An empty root object should yield nothing.
            yield (tuple(path), data)
        return

    # Convert sequences to dicts
    if hasattr(data, "index") and not hasattr(data, "capitalize"):
        # Make it so the keys are indexes
        data = dict(enumerate(data))

    # EARLY RETURN
    if not hasattr(data, "items"):
        yield (tuple(path), data)
        return
    elif condition is not None and not condition(data):
        # Bail out if the condition isn't met
        return

    for key, value in data.items():
        yield from convert_to_flat_paths(value, condition, [*path, key])


def map_deep(obj, function):
    """
    Create a new dict by mapping over all non-object values in `obj` with
    `function`. `function` is invoked with two arguments: `(value, path)`.
    """
    from copy import deepcopy
    obj = deepcopy(obj)
    flat_paths = convert_to_flat_paths(obj)
    for path, value in flat_paths:
        new_value = function(value, path)
        # Mutate the value in the copy
        *path_to_mutable, final_key = path
        mutable = deep_get(obj, path_to_mutable)
        mutable[final_key] = new_value
    return obj


# Sentinel to mark when the user has not provided a default value to deep_get
_raise_error_on_missing = object()


def deep_get(
    obj, path, default=_raise_error_on_missing, *, coerce_indexes=False
):
    """
    Follow a path of keys to a specific node of a dict/list tree.

    Args:
        obj: The dict to get a value from
        path: The sequence of keys/indexes defining the desired value's
            location

        default: (optional) The value to return if the path is not found
            (otherwise raise a PathLookupError)
        coerce_indexes: (optional) If True, coerce identifiers to int before
            using them in sequences. (default: False)

    Returns:
        The found value or the value specified by `default`.

    Raises:
        PathLookupError if path wasn't found and no default was provided.
    """
    found_path = []
    cur = obj
    for identifier in path:
        if coerce_indexes and hasattr(cur, "index"):
            identifier = int(identifier)
        try:
            cur = cur[identifier]
        except LookupError:
            if default is _raise_error_on_missing:
                raise PathLookupError(path, found_path) from None
            else:
                return default
        found_path.append(identifier)
    return cur


def are_paths_matching(path1, path2):
    """
    Check if two paths are matching, handling PATH_WILDCARD tokens.

    Args:
        path1: A sequence of path tokens and PATH_WILDCARDs.
        path2: A sequence of path tokens and PATH_WILDCARDs.

    Returns:
        True if the paths match eachother, otherwise False.
    """
    # EARLY RETURN
    if path1 == path2:
        # Obviously, the paths are equal. Report them as such.
        return True
    elif len(path1) != len(path2):
        # If the lengths aren't equal, don't spend any more time on it.
        return False
    elif PATH_WILDCARD not in (*path1, *path2):
        # PATH_WILDCARD is the only way the paths could match without being
        # equal.
        return False
    # Make sure all the tokens match.
    return all((
        token1 == token2
        or (
            PATH_WILDCARD in [token1, token2]
            # PATH_KEY doesn't match the wildcard
            and PATH_KEY not in [token1, token2]
        )
        for token1, token2 in zip(path1, path2)
    ))


###################
# Schema utilities
###################

def find_subschema_locations(schema, skip_bool=True, _path=tuple()):
    """
    Traverse a schema and find every location containing a subschema.
    """
    # EARLY RETURN
    if schema in (True, False):
        # Don't try to traverse boolean schemas.
        if not skip_bool:
            # We may want to see this (but usually we don't.)
            yield _path
        return

    yield _path
    for applicator in SCHEMA_LIST_APPLICATORS:
        if applicator in schema:
            for idx, subschema in enumerate(schema[applicator]):
                yield from find_subschema_locations(
                    subschema,
                    skip_bool,
                    _path=(*_path, applicator, idx)
                )
    for applicator in SCHEMA_OBJECT_APPLICATORS:
        if applicator in schema:
            for prop, subschema in schema[applicator].items():
                yield from find_subschema_locations(
                    subschema,
                    skip_bool,
                    _path=(*_path, applicator, prop),
                )
    for applicator in SCHEMA_SINGLE_APPLICATORS:
        if applicator in schema:
            subschema = schema[applicator]
            yield from find_subschema_locations(
                subschema,
                skip_bool,
                _path=(*_path, applicator)
            )


_cache_schema_paths_by_instance = {}


# HACK: cache by json string. It's cheaper than crawling over huge
#       schemas multiple times.
_CACHE_KEY_FUNCS = [id, json.dumps]


def group_schema_paths_by_instance_path(schema):
    cache_keys = []
    for func in _CACHE_KEY_FUNCS:
        try:
            cache_key = func(schema)
            if cache_key in _cache_schema_paths_by_instance:
                found = _cache_schema_paths_by_instance[cache_key]
                # Set other cache_keys to point to the found object.
                for cache_key in cache_keys:
                    if cache_key is not None:
                        _cache_schema_paths_by_instance[cache_key] = found
                return found
        except TypeError:
            # We couldn't serialize it, so there's a slight performance hit. Oh
            # well!
            cache_key = None
        cache_keys.append(cache_key)

    paths_by_instance = {}
    for schema_path in find_subschema_locations(schema):
        instance_path = schema_path_to_instance_path(schema_path)
        paths_by_instance.setdefault(
            instance_path,
            []
        ).append(schema_path)

    for cache_key in cache_keys:
        if cache_key is not None:
            _cache_schema_paths_by_instance[cache_key] = paths_by_instance
    return paths_by_instance


def coerce_jsonschema_type(value, schema_type):
    """
    Coerce a value based off the JSON schema type.
    """
    if schema_type == "string":
        return str(value)
    elif schema_type == "integer":
        return int(value)
    elif schema_type == "number":
        return float(value)
    elif schema_type == "object":
        return {value: {}}
    else:
        # Do nothing, since it might be valid
        return value


def find_schema_keyword(keyword, schema, target_path, *, strict_match=False):
    paths_by_instance = group_schema_paths_by_instance_path(schema)

    # Put seen values in a set, so we don't repeat anything
    seen_values = set()

    is_match = (
        tuple.__eq__
        if strict_match
        else are_paths_matching
    )

    for instance_path, schema_paths in paths_by_instance.items():
        if not is_match(instance_path, target_path):
            continue
        for schema_path in schema_paths:
            subschema = deep_get(schema, schema_path)
            if keyword in subschema:
                value = subschema[keyword]
                should_yield = False
                try:
                    if value not in seen_values:
                        seen_values.add(value)
                        should_yield = True
                except TypeError:
                    # Eh, yield it anyway if we can't hash it.
                    should_yield = True
                if should_yield:
                    yield value


get_schema_types = partial(find_schema_keyword, "type")


def coerce_value_from_schema(schema, value, path):
    """
    Coerce the type of `value` into the type specified by `schema`.

    Args:
        `schema`: A JSON Schema object.
        `value`: A value found on the instance
        `path`: The path to the instance location where `value` was found.
    """
    schema_types = tuple(get_schema_types(schema, tuple(path)))

    _type_precedence = [
        "integer",
        "number",
        "object",
        "string",
    ]

    for schema_type in filter(schema_types.__contains__, _type_precedence):
        try:
            return coerce_jsonschema_type(value, schema_type)
        except Exception:
            # Catch any exception here, since we absolutely want to return
            # something.
            pass
    # It's nothing we know about, but that's not going to stop us from sending
    # it in "as-is"!
    return value


def schema_path_to_instance_path(schema_path, _instance_path=()):
    """
    Get the path to the instance location that would be validated by a
    subschema at the given path.

    Args:
        schema_path: The sequence of keys pointing to a specific schema
            location.

    Returns:
        A tuple of keys describing the path to the instance location.
    """
    # Base case: We're at the end of the schema path.
    if len(schema_path) == 0:
        return _instance_path

    keyword = schema_path[0]
    if keyword == "properties" and len(schema_path) > 1:
        # The next path token is the property name; add it to path.
        _instance_path = (*_instance_path, schema_path[1])
        # Then skip to the next schema location.
        schema_path = schema_path[2:]
    elif keyword in ["allOf", "oneOf", "anyOf"]:
        # The instance location doesn't change for in-place applicators.
        # The next path token is an array index (skip it)
        schema_path = schema_path[2:]
    elif keyword == "additionalProperties":
        # The instance token can be anything.
        _instance_path = (*_instance_path, PATH_WILDCARD)
        # The value of additionalProperties is a schema
        schema_path = schema_path[1:]
    elif keyword == "x-propertyNames":
        _instance_path = (*_instance_path, PATH_KEY)
        # The value of propertyNames is a schema
        schema_path = schema_path[1:]
    else:
        # Assume it's a keyword validating the current instance location, and
        # throw away the remaining schema path.
        schema_path = ()

    return schema_path_to_instance_path(
        schema_path,
        _instance_path,
    )
