# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
A minimal version of unittest.mock
"""


class SimplePatch:
    """Because unittest.mock is big, and my needs are small."""

    def __init__(self, target, attribute=None, new=None, **patches):
        self.target = target

        if attribute is not None:
            patches[attribute] = new
        self.patches = patches

    def __enter__(self):
        self.originals = {}
        for attribute, new in self.patches.items():
            self.originals[attribute] = getattr(self.target, attribute)
            setattr(self.target, attribute, new)

    def __exit__(self, *_):
        for attribute, original in self.originals.items():
            setattr(self.target, attribute, original)


############################################################################
# START COPY PASTE from unittest.mock (Only addition is "noqa" comments)
class _SentinelObject(object):
    "A unique, named, sentinel object."
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return 'sentinel.%s' % self.name  # noqa: S001

    def __reduce__(self):
        return 'sentinel.%s' % self.name  # noqa: S001


class _Sentinel(object):
    """Access attributes to return a named object, usable as a sentinel."""
    def __init__(self):
        self._sentinels = {}

    def __getattr__(self, name):
        if name == '__bases__':
            # Without this help(unittest.mock) raises an exception
            raise AttributeError
        return self._sentinels.setdefault(name, _SentinelObject(name))

    def __reduce__(self):
        return 'sentinel'


sentinel = _Sentinel()
# END COPY PASTE from unittest.mock
############################################################################
