# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
Constants used in the CLI.

This module exists to avoid circular dependencies when multiple modules need to
use the same constant.
"""


from cli_cue.minimock import sentinel


###############################################################################
# Names of API bases

MAIN_API = "nvue_v1"
CONFIG_API = "config_v1"
LEGACY_API = "netd_v1"
VERSIONS_API = "versions_v1"


###############################################################################
# CLI options/defaults

DEFAULT_HOSTNAME = None  # None means use the UNIX domain socket
DEFAULT_OUTPUT = "auto"
DEFAULT_API = MAIN_API
DEFAULT_TOGGLE = "auto"


SUPPORTED_OUTPUTS = [
    "json", "yaml", "auto", "constable", "end-table"
]
SUPPORTED_TOGGLE_OPTIONS = ["on", "off", "auto"]


# Assume user wants to be prompted
PROMPT_ASSUME_DEFAULT = sentinel.PROMPT_ASSUME_DEFAULT
# Assume 'yes' for everything
PROMPT_ASSUME_YES = sentinel.PROMPT_ASSUME_YES
# Assume 'no' for everything
PROMPT_ASSUME_NO = sentinel.PROMPT_ASSUME_NO


###############################################################################
# Detailed command descriptions

HELPTEXT_CL_EDIT = """\
Edit the CUE configuration tree as a YAML file.

Open the contents of a CUE revision in a text editor. The saved
contents will REPLACE the revision's existing contents after you
close the text editor.

An empty file will abort the edit without making any changes.

If the edited configuration is invalid, the revision's original
contents will be restored.

The text editor will be chosen from the following (in order).

- the VISUAL environment variable
- the EDITOR environment variable
- "nano"

By default, "nv edit" will edit the current pending revision.
To edit a specific revision, use the <revision> argument.
"""


HELPTEXT_CL_TREE = """\
View the CUE object model as a tree.

WARNING: This is a development feature! It may be
         changed/removed without any notice!

"nv tree" queries cued for a command's "nv show" schema and its
"nv set" schema. From the schemas, it determines the tree of valid
instance locations, and which locations are "read only".

"Read only" nodes (ie, valid for "nv show", but not valid for "nv set")
are prefixed with "+--ro".
"Read/write" nodes are prefixed with "+--rw".

Collections are marked by "* [found-type]" after the node name, where
"found-type" is the type/format expected as the key for the collection.

If the "--show-proposed" flag is set, "nv tree" will fetch the
"proposed" schema (which doesn't show up in the CLI) in addition
to the "set" and "show" schemas.
Any node in the "proposed" schema is prefixed with "?---p".

The format is roughly modeled off of RFC 8340 "YANG Tree Diagrams".
Since CUE is using OpenAPI (not YANG) as its modeling language, a
compliant diagram would be impossible/nonsensical.
"""


APPLY_CONFIRM_EXPLANATION = """\
To keep this configuration, use

    nv config apply [<revision>] --confirm-yes

To roll this configuration back immediately, use

    nv config apply [<revision>] --confirm-no

To see how much time is left until automatic roll back, use

    nv config apply [<revision>] --confirm-status

"""


###############################################################################
# HTTP facts

HTTP_METHODS = [
    "GET",
    "HEAD",
    "POST",
    "PUT",
    "DELETE",
    "CONNECT",
    "OPTIONS",
    "TRACE",
    "PATCH",
]
HTTP_METHODS_WITH_BODIES = [
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
]


###############################################################################
# revision states

STATE_PENDING = "pending"

# apply config
STATE_APPLY = "apply"
STATE_VERIFYING = "verifying"
STATE_INVALID = "invalid"
STATE_VERIFIED = "verified"
STATE_VERIFY_ERROR = "verify_error"
STATE_READYING = "readying"
STATE_READY = "ready"
STATE_READY_ERROR = "ready_error"
STATE_AYS = "ays"
STATE_AYS_FAIL = "ays_fail"
STATE_AYS_NO = "ays_no"
STATE_AYS_YES = "ays_yes"
STATE_RELOADING = "reloading"
STATE_RELOADED = "reloaded"
STATE_CHECKING = "checking"
STATE_CHECKED = "checked"
STATE_APPLY_ERROR = "apply_error"
STATE_IGNORE_FAIL = "ignore_fail"
STATE_IGNORE_FAIL_NO = "ignore_fail_no"
STATE_IGNORE_FAIL_YES = "ignore_fail_yes"
STATE_APPLY_FAIL = "apply_fail"
STATE_CONFIRM = "confirm"
STATE_CONFIRM_NO = "confirm_no"
STATE_CONFIRM_YES = "confirm_yes"
STATE_CONFIRM_FAIL = "confirm_fail"
STATE_APPLIED = "applied"
STATE_APPLY_INTERRUPTED = "apply_interrupted"

# save_config
STATE_SAVE = "save"
STATE_SAVING = "saving"
STATE_SAVED = "saved"
STATE_SAVE_ERROR = "save_error"
STATE_SAVE_INTERRUPTED = "save_interrupted"


ALL_STATES = [
    STATE_PENDING,
    # apply config
    STATE_APPLY,
    STATE_VERIFYING,
    STATE_INVALID,
    STATE_VERIFIED,
    STATE_VERIFY_ERROR,
    STATE_READYING,
    STATE_READY,
    STATE_READY_ERROR,
    STATE_AYS,
    STATE_AYS_FAIL,
    STATE_AYS_NO,
    STATE_AYS_YES,
    STATE_RELOADING,
    STATE_RELOADED,
    STATE_CHECKING,
    STATE_CHECKED,
    STATE_APPLY_ERROR,
    STATE_IGNORE_FAIL,
    STATE_IGNORE_FAIL_NO,
    STATE_IGNORE_FAIL_YES,
    STATE_APPLY_FAIL,
    STATE_CONFIRM,
    STATE_CONFIRM_NO,
    STATE_CONFIRM_YES,
    STATE_CONFIRM_FAIL,
    STATE_APPLIED,
    STATE_APPLY_INTERRUPTED,
    # save config
    STATE_SAVE,
    STATE_SAVING,
    STATE_SAVED,
    STATE_SAVE_ERROR,
    STATE_SAVE_INTERRUPTED,
]
FAILURE_STATES = [
    # apply failures
    STATE_INVALID,
    STATE_VERIFY_ERROR,
    STATE_READY_ERROR,
    STATE_AYS_FAIL,
    STATE_APPLY_ERROR,
    STATE_APPLY_FAIL,
    STATE_CONFIRM_FAIL,
    STATE_APPLY_INTERRUPTED,
    # save failures
    STATE_SAVE_ERROR,
    STATE_SAVE_INTERRUPTED,
]
PROMPT_USER_STATES = {
    STATE_AYS: {
        True: STATE_AYS_YES,
        False: STATE_AYS_NO,
    },
    STATE_IGNORE_FAIL: {
        True: STATE_IGNORE_FAIL_YES,
        False: STATE_IGNORE_FAIL_NO,
    },
}
EARLY_EXIT_STATES = [
    STATE_CONFIRM,
]
IN_PROGRESS_STATES = [
    # apply config
    STATE_APPLY,
    STATE_VERIFYING,
    STATE_VERIFIED,
    STATE_READYING,
    STATE_READY,
    STATE_RELOADING,
    STATE_RELOADED,
    STATE_CHECKING,
    STATE_CHECKED,
    STATE_AYS_NO,
    STATE_AYS_YES,
    STATE_IGNORE_FAIL_NO,
    STATE_IGNORE_FAIL_YES,
    STATE_CONFIRM_NO,
    STATE_CONFIRM_YES,
    # save config
    STATE_SAVE,
    STATE_SAVING,
]
SUCCESS_STATES = [
    STATE_APPLIED,
    STATE_SAVED,
]


###############################################################################
# URLs to ignore in object model

OBJECT_MODEL_IGNORE = [
    f"/{MAIN_API}/revision",
]


###############################################################################
# ANSI escape sequences

# http://ascii-table.com/ansi-escape-sequences.php
ANSI_CLEAR_SCREEN_DOWN = u"\u001b[J"
# HACK: moves cursor left 1000 columns. (We've got bigger problems if 1000
#       columns isn't enough)
ANSI_CURSOR_LEFT = u"\u001b[1000D"
