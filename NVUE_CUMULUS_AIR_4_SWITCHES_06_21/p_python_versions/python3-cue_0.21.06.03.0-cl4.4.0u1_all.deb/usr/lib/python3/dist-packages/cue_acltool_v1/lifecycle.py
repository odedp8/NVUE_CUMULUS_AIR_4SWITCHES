# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

import logging
from . import templates
from collections import OrderedDict
from cue import issues
logger = logging.getLogger(__name__)


match_key_v4v6_dict = {
    'source-ip': '-s ',
    'dest-ip': '-d ',
    'protocol': '-p ',
    'source-port': '--sports ',
    'dest-port': '--dports ',
    'icmp-type': '--icmp-type ',
    'icmpv6-type': '--icmpv6-type ',
    'dscp': '-m dscp --dscp ',
    'dscp-class': '-m dscp --dscp-class ',
    'tcp': '--tcp-flags '
}


match_key_mac_dict = {
    'source-mac': '-s ',
    'dest-mac': '-d ',
    'protocol': '-p ',
    'ipv4': {
        'source-ip': '--ip-src ',
        'dest-ip': '--ip-dst ',
        'ip-proto': '--ip-proto ',
        'source-port': '--ip-sport ',
        'dest-port': '--ip-dport'},
    'ipv6': {
        'source-ip': '--ip6-src ',
        'dest-ip': '--ip6-dst ',
        'ip-proto': '--ip6-proto ',
        'source-port': '--ip6-sport ',
        'dest-port': '--ip6-dport '}
}


action_key_dict = {
    'v4v6': {
        'permit': '-j ACCEPT',
        'deny': '-j DROP',
        'log': '-j LOG',
        'class': '-j SETCLASS --class',
        'cos': '-j SETQOS --set-cos',
        'dscp': '-j SETQOS --set-dscp',
        'dscp-class': '-j SETQOS --set-dscp-class',
        'erspan': '-j ERSPAN',
        'source-ip': '--src-ip',
        'dest-ip': '--dst-ip',
        'ttl': '--ttl',
        'span': '-j SPAN --dport',
        'police': '-j POLICE',
        'mode': '--set-mode',
        'rate': '--set-rate',
        'burst': '--set-burst'},
    'mac': {
        'permit': '-j ACCEPT',
        'deny': '-j DROP',
        'class': '-j setclass --class',
        'span': '-j span --dport',
        'erspan': '-j erspan',
        'source-ip': '--src-ip',
        'dest-ip': '--dst-ip',
        'ttl': '--ttl',
        'police': '-j police',
        'mode': '--set-mode',
        'rate': '--set-rate',
        'burst': '--set-burst'}
}


mac_proto_map = {
    'ipv4': 'IPv4',
    'ipv6': 'IPv6',
    'arp': 'ARP',
}


police_mode = {
    'packet': 'pkt',
    'kbps': 'KB',
    'mbps': 'MB',
    'gbps': 'GB'
}

dscp_class_val = ['be', 'af11', 'af12', 'af13', 'af21', 'af22', 'af23',
                  'af31', 'af32', 'af33', 'af41', 'af42', 'af43', 'cs1',
                  'cs2', 'cs3', 'cs4', 'cs5', 'cs6', 'cs7', 'ef']


tcp_flags_map = {
    'ack': 'ACK,',
    'syn': 'SYN,',
    'fin': 'FIN,',
    'rst': 'RST,',
    'urg': 'URG,',
    'psh': 'PSH,',
    'all': 'ALL,',
}


mac_map = {
    'bpdu': '01:80:c2:00:00:00',
    'cdp': '01:00:0c:cc:cc:cc',
    'cisco-pvst': '01:00:0c:cc:cc:cd',
    'lacp': '01:80:c2:00:00:02',
    'lldp': '01:80:c2:00:00:0e',
}


port_map = {
    'ftp': 21,
    'ssh': 22,
    'telnet': 23,
    'smtp': 25,
    'domain': 53,
    'bootps': 67,
    'bootpc': 68,
    'dhcp-server': 67,
    'dhcp-client': 68,
    'http': 80,
    'pop3': 110,
    'imap2': 143,
    'snmp': 161,
    'snmp-trap': 162,
    'bgp': 179,
    'ldap': 389,
    'https': 443,
    'ldaps': 636,
    'msdp': 639,
    'clag': 5342,
}


def build_tcp_flag_or_mask_str(flags):
    flag_str = ' '
    if 'ack' in flags:
        flag_str = flag_str + tcp_flags_map['ack']
    if 'syn' in flags:
        flag_str = flag_str + tcp_flags_map['syn']
    if 'fin' in flags:
        flag_str = flag_str + tcp_flags_map['fin']
    if 'rst' in flags:
        flag_str = flag_str + tcp_flags_map['rst']
    if 'urg' in flags:
        flag_str = flag_str + tcp_flags_map['urg']
    if 'psh' in flags:
        flag_str = flag_str + tcp_flags_map['psh']
    return flag_str


def get_rule_match_str(match_dict, acl_type='ipv4'):
    match_list = []
    ip_match_keys = ['source-ip', 'dest-ip', 'protocol', 'source-port',
                     'dest-port', 'icmp-type', 'icmpv6-type', 'dscp', 'tcp']
    mac_match_keys = ['source-mac', 'dest-mac', 'protocol']
    mac_ip_match_keys = ['source-ip', 'dest-ip', 'ip-proto', 'source-port',
                         'dest-port']

    if (acl_type == 'ipv4' or acl_type == 'ipv6') and 'ip' in match_dict:
        ip_m = match_dict['ip']
        for key in ip_match_keys:
            if key in ip_m and ip_m[key] != 'none' and ip_m[key] != 'ANY':
                if key == 'source-port' or key == 'dest-port':
                    if 'ANY' in ip_m[key].keys():
                        continue
                    match_list.append('-m multiport')
                    port_l = ip_m[key].keys()
                    port_l = [str(port_map[k]) if k in port_map.keys()
                              else k for k in port_l]
                    port_str = ','.join(port_l)
                    match_list.append(match_key_v4v6_dict[key]
                                      + port_str)
                    continue
                if key == 'dscp':
                    if type(ip_m[key]) is str and ip_m[key] in dscp_class_val:
                        match_key_v4v6_dict[key] = \
                            match_key_v4v6_dict['dscp-class']
                if key == 'tcp':
                    tcp_flag = ip_m['tcp']
                    if 'flags' in tcp_flag:
                        flags = tcp_flag['flags']
                        flag_str = build_tcp_flag_or_mask_str(flags)
                    if 'mask' in tcp_flag:
                        mask = tcp_flag['mask']
                        mask_str = build_tcp_flag_or_mask_str(mask)
                    if 'state' in tcp_flag:
                        if 'established' in tcp_flag['state']:
                            ip_m[key] = 'established'
                    else:
                        ip_m[key] = mask_str + flag_str

                match_list.append(match_key_v4v6_dict[key]
                                  + str(ip_m[key]))

    if acl_type == 'mac' and 'mac' in match_dict:
        if 'mac' in match_dict:
            mac_m = match_dict['mac']
            for key in mac_match_keys:
                if key in mac_m and mac_m[key] != 'none' and\
                  mac_m[key] != 'ANY':
                    if (key == 'source-mac' or key == 'dest-mac') and\
                      mac_m[key] in mac_map.keys():
                        mac_m[key] = mac_map[mac_m[key]]
                    if key == 'protocol':
                        proto = mac_m[key]
                        proto_eb = mac_proto_map[mac_m[key]]
                        match_list.append(match_key_mac_dict[key] + proto_eb)
                        continue
                    match_list.append(match_key_mac_dict[key]
                                      + str(mac_m[key]))
        if 'ip' in match_dict and (proto == 'ipv4' or proto == 'ipv6'):
            mac_ip_m = match_dict['ip']
            for key in mac_ip_match_keys:
                if key in mac_ip_m and mac_ip_m[key] != 'none' and\
                   mac_ip_m[key] != 'ANY':
                    match_list.append(match_key_mac_dict[proto][key]
                                      + str(mac_ip_m[key]))

    match_str = ' '.join(match_list)
    return match_str


def get_rule_action_str(act_dict, acl_type='ipv4'):
    act_str = ""
    table_str = ""

    if acl_type == 'ipv4' or acl_type == 'ipv6':
        acl_t = 'v4v6'
    elif acl_type == 'mac':
        acl_t = 'mac'

    if 'permit' in act_dict:
        act_str = action_key_dict[acl_t]['permit']
    if 'deny' in act_dict:
        act_str = action_key_dict[acl_t]['deny']
    if 'log' in act_dict:
        act_str = action_key_dict[acl_t]['log']
    if 'set' in act_dict:
        set_act = act_dict['set']
        if 'class' in set_act:
            act_str = action_key_dict[acl_t]['class'] + " " +\
                str(set_act['class'])
        if 'cos' in set_act:
            table_str = '-t mangle'
            act_str = action_key_dict[acl_t]['cos'] + " " +\
                str(set_act['cos'])
        if 'dscp' in set_act:
            table_str = '-t mangle'
            if type(set_act['dscp']) is str and set_act['dscp']\
                    in dscp_class_val:
                action_key_dict[acl_t]['dscp'] =\
                    action_key_dict[acl_t]['dscp-class']
            act_str = action_key_dict[acl_t]['dscp'] + " " +\
                str(set_act['dscp'])
    if 'erspan' in act_dict:
        act_str = action_key_dict[acl_t]['erspan'] + " "
        params = act_dict['erspan']
        if 'source-ip' in params:
            act_str += action_key_dict[acl_t]['source-ip'] + " " +\
                str(params['source-ip'])
        if 'dest-ip' in params:
            act_str += " " + action_key_dict[acl_t]['dest-ip'] + " " +\
                str(params['dest-ip'])
        if 'ttl' in params:
            act_str += " " + action_key_dict[acl_t]['ttl'] + " " +\
                str(params['ttl'])
    if 'span' in act_dict:
        act_str = action_key_dict[acl_t]['span'] + " " +\
            str(act_dict['span'])
    if 'police' in act_dict:
        act_str = action_key_dict[acl_t]['police'] + " "
        params = act_dict['police']
        if 'mode' in params:
            act_str += action_key_dict[acl_t]['mode'] + " " +\
                police_mode[params['mode']] + " "
        if 'rate' in params:
            act_str += action_key_dict[acl_t]['rate'] + " " +\
                str(params['rate']) + " "
        if 'burst' in params:
            act_str += action_key_dict[acl_t]['burst'] + " " +\
                str(params['burst'])

    return table_str, act_str


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("acltool_v1", handle_verify_config)
    ctx.events.ready_apply.register("acltool_v1", handle_ready_apply)
    ctx.events.check_health.register("acltool_v1", handle_check_health)


class InvalidAclUnset(issues.BadInputIssue):
    """
        ACL unset before removing refs from interfaces
    """
    def __init__(self, acl, iface):
        super().__init__("invalid_acl_unset")
        self.data['acl'] = acl
        self.data['iface'] = iface

    def _render_message(self):
        fmt = (
            "ACL {acl} in use by {iface} doesn't exist"
        )
        return fmt.format(**self.data)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """
    acl_config = evt.config_v1.getAcls()
    interfaces = evt.config_v1.getInterfaces()

    acls = list(acl_config.keys())
    for iface, v in interfaces.items():
        if 'acl' in v.keys():
            for acl in v['acl'].keys():
                if acl not in acls:
                    evt.report_issue(InvalidAclUnset(acl, iface))


def build_acl_rule_dict(acl_config):
    rule_dict = {}
    for acl_id, acl in acl_config.items():
        rule_dict[acl_id] = {}
        rule_dict[acl_id]['type'] = acl['type']
        rules_unsorted = acl['rule']
        rules = OrderedDict(sorted(rules_unsorted.items(),
                            key=lambda x: int(x[0])))
        rule_dict[acl_id]['rules'] = []
        for _n, rule in rules.items():
            rule_l = {}
            rule_l['match'] = ''
            if 'match' in rule:
                rule_l['match'] = get_rule_match_str(rule['match'],
                                                     acl['type'])
            table_s, act_s = get_rule_action_str(rule['action'], acl['type'])
            rule_l['action'] = act_s
            rule_l['table'] = table_s
            rule_dict[acl_id]['rules'].append(rule_l)
            if 'log' in rule['action']:
                rule_c = rule_l.copy()
                rule_c['action'] = '-j DROP'
                rule_dict[acl_id]['rules'].append(rule_c)
            if 'established' in rule_l['match']:
                rule_c = rule_l.copy()
                rule_l['match'] = rule_l['match'].replace('established',
                                                          'ACK ACK')
                rule_c['match'] = rule_c['match'].replace('established',
                                                          'RST RST')
                rule_dict[acl_id]['rules'].append(rule_c)

    logger.debug(rule_dict)
    return rule_dict


def build_acl_rule_strs(interfaces, rule_dict):
    rule_strs = {'ipv4': [],
                 'ipv6': [],
                 'mac': []}

    for iface, v in interfaces.items():
        if 'acl' in v.keys():
            for acl, val in v['acl'].items():
                chain_s = "-A FORWARD"
                if 'inbound' in val.keys():
                    intf_s = '-i ' + iface
                    dxn = 'inbound'
                    if 'control-plane' in val['inbound'].keys():
                        chain_s = "-A INPUT"
                if 'outbound' in val.keys():
                    intf_s = '-o ' + iface
                    dxn = 'outbound'
                    if 'control-plane' in val['outbound'].keys():
                        chain_s = "-A OUTPUT"
                if acl in rule_dict.keys():
                    rules = rule_dict[acl]['rules']
                    logger.debug(rules)
                    rule_s = "\n## ACL {} in dir {} on interface {} ##"\
                             .format(acl, dxn, iface)
                    rule_strs[rule_dict[acl]['type']].append(rule_s)
                    for rule in rules:
                        rule_l = []
                        if not rule['table']:
                            rule_l.extend([chain_s, intf_s, rule['match'],
                                          rule['action']])
                        else:
                            rule_l.extend([rule['table'], chain_s, intf_s,
                                          rule['match'], rule['action']])
                        rule_s = " ".join(rule_l)
                        rule_strs[rule_dict[acl]['type']].append(rule_s)
    return rule_strs


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    cue_rules = "/etc/cumulus/acl/policy.d/50_cue.rules"
    acl_config = evt.config_v1.getAcls()
    om_interfaces = evt.config_v1.getInterfaces()
    logger.debug(om_interfaces)
    logger.debug(acl_config)
    rule_dict = build_acl_rule_dict(acl_config)
    rule_strs = build_acl_rule_strs(om_interfaces, rule_dict)
    logger.debug(rule_strs)
    evt.render(templates, "50_cue.rules", config=rule_strs)
    evt.stage_file("50_cue.rules", cue_rules)
    evt.render(templates, "install_acls.sh")
    evt.schedule_run_script("install_acls.sh")


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
