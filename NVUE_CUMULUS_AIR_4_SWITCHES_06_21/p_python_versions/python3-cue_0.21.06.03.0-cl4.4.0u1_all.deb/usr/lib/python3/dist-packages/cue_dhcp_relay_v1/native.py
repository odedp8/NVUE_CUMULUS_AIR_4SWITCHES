# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


def dhcp_relay_config_per_vrf(ctx, relay_config_file):
    output = ctx.fileops.load_file(relay_config_file)

    show_data = {}
    s_data = {}
    intf_data = {}
    gia_data = {}

    for line in output.splitlines():
        for word in line.split():
            # decode the list of servers
            if (word.find('SERVERS') != -1):
                # Removing Initial word 'SERVERS="'
                new_line = line[9:-1]
                for server in new_line.split():
                    s_data.update({server: {}})

            # decode the list of interfaces
            if (word.find('INTF_CMD') != -1):
                # Removing Initial word 'INTF_CMD="'
                new_line = line[10:-1]
                intf_cmds = new_line.split()
                for key, val in enumerate(intf_cmds):
                    if val == '-i' and key + 1 < len(intf_cmds):
                        intf = intf_cmds[key + 1]
                        intf_data.update({intf: {}})

            if (word.find('OPTIONS') != -1):
                # Removing Initial word 'OPTIONS="'
                new_line = line[9:-1]
                options = new_line.split()
                for key, val in enumerate(options):
                    if key == 1:
                        ip_port = val
                        if ip_port.find('%') != -1:
                            w = ip_port.split('%')
                            gia_data.update({w[1]: {'address': w[0]}})
                        else:
                            gia_data.update({val: {}})

                    if val.find('giaddr-src') != -1:
                        show_data.update({'source-ip': "giaddress"})
                    else:
                        show_data.update({'source-ip': "auto"})

    show_data.update({'server': s_data})
    show_data.update({'interface': intf_data})
    show_data.update({'giaddress-interface': gia_data})
    return show_data


def dhcp_relay_config_get(ctx):
    config_data = {}
    for relay_config_file in ctx.fileops.list_files("/etc/default/"):
        # we are interested in dhcp relay config file only
        if not relay_config_file.name.startswith('isc-dhcp-relay-'):
            continue
        # extracting the VRF name from the dhcp config file
        # Ex: in isc-dhcp-relay-blue, vrf is blue
        if relay_config_file.name.startswith('isc-dhcp-relay-'):
            # handling DHCP relay V4
            vrf = relay_config_file.name[15:]
            vrf_relay_data = dhcp_relay_config_per_vrf(ctx, relay_config_file)
            config_data.update({vrf: vrf_relay_data})
    return config_data


def dhcp_relay6_config_per_vrf(ctx, relay_config_file):
    output = ctx.fileops.load_file(relay_config_file)

    show_data = {}
    upstream = {}
    downstream = {}
    intf_data = {}
    for line in output.splitlines():
        for word in line.split():
            # decode the list of servers
            if (word.find('SERVERS') != -1):
                # Removing Initial word 'SERVERS="'
                new_line = line[9:-1]
                servers = new_line.split('-u ')
                for key in servers:
                    if key == '':
                        continue
                    if key.find('%') != -1:
                        w = key.split('%')
                        upstream.update({w[1].strip(): {'address': w[0]}})
                    else:
                        upstream.update({key.strip(): {}})

            # decode the list of interfaces
            if (word.find('INTF_CMD') != -1):
                # Removing Initial word 'INTF_CMD="'
                new_line = line[10:-1]
                intf_cmds = new_line.split('-l ')
                for key in intf_cmds:
                    if key == '':
                        continue
                    if key.find('%') != -1:
                        w = key.split('%')
                        downstream.update({w[1].strip(): {'address': w[0]}})
                    else:
                        downstream.update({key.strip(): {}})
    intf_data.update({"upstream": upstream})
    intf_data.update({"downstream": downstream})
    show_data.update({'interface': intf_data})
    return show_data


def dhcp_relay6_config_get(ctx):
    config_data = {}
    for relay_config_file in ctx.fileops.list_files("/etc/default/"):
        # we are interested in dhcp relay6 config file only
        if not relay_config_file.name.startswith('isc-dhcp-relay6-'):
            continue
        # extracting the VRF name from the dhcp config file
        # Ex: in isc-dhcp-relay6-blue, vrf is blue
        if relay_config_file.name.startswith('isc-dhcp-relay6-'):
            # handling DHCP relay V4
            vrf = relay_config_file.name[16:]
            vrf_relay_data = dhcp_relay6_config_per_vrf(ctx, relay_config_file)
            config_data.update({vrf: vrf_relay_data})

    return config_data
