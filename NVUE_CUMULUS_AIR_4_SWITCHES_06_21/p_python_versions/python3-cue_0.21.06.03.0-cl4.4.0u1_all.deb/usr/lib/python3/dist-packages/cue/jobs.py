# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Job queue
# - Each job is a closure and has a name (for logging)
# - A single daemon thread will run each job in turn.


from enum import IntEnum
from queue import PriorityQueue
from dataclasses import dataclass, field
from threading import Thread, get_ident
import logging


logger = logging.getLogger(__name__)


class Priority(IntEnum):
    """
    Priority levels for Jobs. A lower number means a higher priority.
    """
    IMMEDIATE = 0
    NORMAL = 10

    # NOTE: Should exhaust the queue before stopping.
    _STOP = 9999


@dataclass(order=True)
class Job:
    """
    A queued Job. To work with the PriorityQueue, it defines its comparison
    methods in terms of its `priority` attribute.
    """

    fn: callable = field(compare=False)
    name: str = field(compare=False)
    priority: Priority = Priority.NORMAL


_queue = None
_job_thread = None


# Special job that tells the thread to exit
_stop_job = Job(
    fn=object(),
    name="STOP",
    priority=Priority._STOP,
)


def job_main():
    """
    Main loop for the job thread.  It blocks on the queue until
    it gets a job, then it runs it.
    """
    global _queue, _job_thread
    logger.info("Started the Job thread")

    while True:
        job = _queue.get()
        if job is _stop_job:
            logger.info("Stopped the Job thread")
            return

        logger.info("Running Job %s", job.name)
        job.fn()
        logger.info("Ran Job %s", job.name)


def start():
    """
    Start the job thread.
    """
    global _queue, _job_thread
    if _queue is not None:
        logger.debug("Job thread already started")
        return

    # Create the queue
    _queue = PriorityQueue()

    # Create and start the thread
    _job_thread = Thread(target=job_main, daemon=True)
    _job_thread.start()


def stop():
    """
    Stop the job thread.
    """
    global _queue, _job_thread

    # Add the stopper
    _queue.put(_stop_job)

    # Wait for the thread to die
    _job_thread.join()

    # And cleanup
    _queue = None
    _job_thread = None


def add(name, fn):
    """
    Add a new job.  When the job is run, fn() will be called with no arguments.
    name identifies the job for logging purposes.
    """
    global _queue

    priority = Priority.NORMAL
    if get_ident() == _job_thread.ident:
        # Prioritize jobs that are added by another job.
        priority = Priority.IMMEDIATE

    job = Job(
        fn=fn,
        name=name,
        priority=priority,
    )
    logger.info("Queued Job %s", job.name)
    _queue.put(job)
