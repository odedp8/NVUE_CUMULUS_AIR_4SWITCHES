# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


import functools
import re
import importlib
from datetime import datetime
from pathlib import Path
import collections
from ruamel.yaml.anchor import Anchor as RuamelAnchor


__all__ = [
    "PartialObject", "sentinel", "package_base_path",
    "relative_package_base_path", "camel_case", "upper_camel_case",
    "filter_none", "jinjafy_keys", "convert_str_vals_to_int", "sorted_dict",
    "removesuffix", "auto_inherit", "clean_none", "child_iterator",
    "copy_yamllink", "generate_branch_id", "MultiDict"
]


class PartialObject(object):
    """
    Proxy calls into an underlying object, dynmically creating a partial for
    each.
    """

    def __init__(self, tgt, *args):
        self.tgt = tgt
        self.args = args

    def __getattr__(self, attr):
        # This is a call we haven't seen before.  Create a partial for it.
        # Note that if the target doesn't have the call, we'll throw an
        # AttributeError here.
        call_ = getattr(self.tgt, attr)
        wrapper = functools.partial(call_, *self.args)
        # Add the call to ourselves so we don't need to create it again.
        self.__dict__[attr] = wrapper
        # Return it to the current caller.
        return wrapper


# Factory to create sentinels.
#
# So, instead of:
#   SOME_SENTINEL = object()
# We should:
#   SOME_SENTINEL = sentinel.SOME_SENTINEL
#
# The latter is better because the result is a smart object that knows how to
# repr itself, clone itself, etc.
#
# For now, we'll steal the implementation in unittest.mock, which is a good
# one.  It's a little weird to have non-test code depend on the unittest
# module, so we'll hide it behind a layer of indirection.  If it ever becomes a
# problem we can slot in another implementation here.
from unittest.mock import sentinel  # noqa


def camel_case(str_in):
    """
    Convert a snake case thing into a camel case thing.
    """
    # Look for "_foo" and replace each instance with "Foo".
    return re.sub(r"_([a-z])", lambda m: m.group(1).capitalize(), str_in)


def upper_camel_case(str_in):
    """
    Convert a snake case thing into a camel case thing, then upper()
    the first character.
    """
    camel = camel_case(str_in)
    return camel[0].upper() + camel[1:]


def package_base_path(pkg_name):
    """
    Given a package name, return it's base path.  This is the root of the
    package on the file system.
    """
    pkg = importlib.import_module(pkg_name)
    return Path(pkg.__file__).parent


def relative_package_base_path(pkg_name):
    """
    Given a package name, return it's relative base path.  This is the root of
    the package on the file system, relative to the current working directory.
    """
    return package_base_path(pkg_name).relative_to(Path.cwd())


def filter_none(obj, filter_val=None):
    """
    Recursivily filter `obj` to remove dictionary keys that refer to a value of
    `filter_val`.  `filter_val` should be a sentinel and defaults to `None`.  A
    shallow copy is returned.
    """
    if isinstance(obj, collections.Mapping):
        # Shallow copy obj, skipping any keys that refer to None.
        return {
            key: filter_none(val, filter_val)
            for key, val in obj.items() if val is not filter_val
        }
    else:
        return obj


def clean_none(obj, filter_val=None):
    """
    Recursivily filter `obj` to remove child objects that contain only
    `filter_val`.  Like filter_none(), except empty objects that contained just
    properties set to `filter_val` aren't left around.

    A shallow copy is returned.  `filter_val` is returned if obj was nothing
    but `filter_val`s.
    """
    if isinstance(obj, collections.Mapping):
        # Shallow copy obj, skipping any keys that refer to None.
        filtered = {}
        for key, val in obj.items():
            if val is filter_val:
                continue
            new_val = clean_none(val, filter_val)
            if new_val is filter_val:
                continue
            filtered[key] = new_val

        # If the original object wasn't empty, but the filtered object is, that
        # means it contained nothing but Nones.  Make an assumption that the
        # containing object should be filtered, too, because it was only there
        # as context for the None.
        if obj and not filtered:
            return filter_val
        else:
            return filtered
    else:
        return obj


def jinjafy_keys(obj):
    for key in list(obj.keys()):
        obj[key.replace('-', '_')] = obj.pop(key)
    return obj


def convert_str_vals_to_int(obj):
    """
    Convert any string values which can be converted
    to integers into ints
    """
    for key in list(obj.keys()):
        try:
            if type(obj[key]) == str:
                int_val = int(obj[key])
                obj[key] = int_val
        except ValueError:
            pass
    return obj


def sorted_dict(obj):
    """
    Return a shallow copy of obj, sorted by keys.
    """
    return {key: obj[key] for key in sorted(obj)}


def removesuffix(string, suffix):
    """
    Take a string and remove the provided suffix (if present.)

    NOTE:
        Starting in Python 3.9, `removesuffix` is implemented as a built-in str
        method.
        https://docs.python.org/3/library/stdtypes.html#str.removesuffix
    """
    if string.endswith(suffix):
        return string[:-len(suffix)]
    else:
        return string


def auto_inherit(sub_obj, super_obj):
    """
    Inherit "auto" parameters in `sub_obj` from `super_obj`, if
    `super_obj` has a value.  `sub_obj` will be updated.
    """
    for param in sub_obj.keys():
        if sub_obj[param] == "auto" and param in super_obj:
            sub_obj[param] = super_obj[param]


def child_iterator(obj):
    """
    Get an iterable of children.

    The children are returned as `(key|offset,value)` pairs.  If obj
    is a list, they're returned in reverse.  If obj is not a list
    or dict, None is returned.
    """
    # pydash's to_pairs() almost does this, but it never returns None.  As a
    # last resort, it will return obj.__dict__ instead.
    if isinstance(obj, list):
        return reversed(list(enumerate(obj)))
    elif isinstance(obj, collections.Mapping):
        return obj.items()
    else:
        return None


def copy_yamllink(obj):
    """
    Return a shallow, ruamel.yaml-aware copy of obj.

    Ideally, we could replace this with a normal copy.copy() or py_.clone().
    But ruamel's copy() is weird.  It doesn't work the way we need it to.
    """
    new_obj = obj

    if isinstance(obj, list) or isinstance(obj, collections.Mapping):
        # Copy the list or dict, preserving the type.
        new_obj = type(obj)(obj)

        # If it's a ruamel object, copy the attributes, including the anchor
        # and line numbers.  This needs special care because:
        # - You call copy_attributes on the original object and it copies into
        # the new object.  In other words, it's src.copy_attributes(dst), not
        # dst.copy_attributes(src).  That seems backward.
        # - We want to make sure to clone the anchor because our callers might
        # modify it.  If we don't clone now, then changing the anchor on the
        # new object will change the original, too.  There's no clean way to do
        # this.  You could trick copy_attrbutes() into a deep clone by sending
        # a Truethy second argument, e.g. `obj.copy_attributes(new_obj, True`,
        # but this is extremely slow.  What we'll do instead is delattr() the
        # anchor, disconnecting it from the source object, then set it again,
        # triggering the creation of a new instance.
        try:
            obj.copy_attributes(new_obj)

            # Force a deep clone of the anchor so that callers can modify it
            # without changing the orginal object.
            delattr(new_obj, RuamelAnchor.attrib)
            orig_anchor = obj.anchor
            new_obj.yaml_set_anchor(orig_anchor.value, orig_anchor.always_dump)
        except AttributeError:
            pass

    return new_obj


def generate_branch_id():
    """
    Generate a unique identifier that's usable in git revision names.
    """
    suffix = _gen_branch_id_suffix()
    return datetime.now().strftime(f"%Y-%m-%d_%H.%M.%S_{suffix}")


# Branch name counter.  Start with a "random" seed.  now().microsecond is
# random enough and avoids ever waiting on entropy.
_branch_index = datetime.now().microsecond


def _gen_branch_id_suffix():
    """
    Generate a 4 character string that won't repeat for 2^20 calls.
    We use a quick and dirty Crockford-style base32-ish encoding.
    https://en.wikipedia.org/wiki/Base32
    """
    global _branch_index

    # Mapping from remainder to the character we'll use in the suffix.
    char_map = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'

    # Accumulator for the suffix
    suffix = ''

    # Allocate a new branch index
    _branch_index += 1

    # Build the suffix string by using the least significant 20 bits of the
    # index.
    n = _branch_index
    for _ in range(4):
        r = n % 32
        n //= 32
        suffix = char_map[r] + suffix

    return suffix


class MultiDict(dict):
    """
    A dictionary that doesn't replace values, but instead builds a list.

    If the value is set once, then the behavior is the same as `dict`.  But if
    a value is set a second time, the original value is put in a list and
    the new value appeneded to the list.

    For example:

        a = MultiDict()
        a["foo"] = "bar"
        assert a["foo"] == "bar"
        a["foo"] = "baz"
        assert a["foo"] == ["bar", "baz"]

    Warning: Use this class with caution.  This is a memory leak waiting to
    happen.
    """

    # Sub-type list so we can distinguish our lists from normal lists
    class MultiList(list):
        pass

    def __setitem__(self, key, value):
        """add the given value to the list of values for this key"""
        cur_value = self.get(key)
        if isinstance(cur_value, self.MultiList):
            cur_value.append(value)
            return
        elif cur_value is not None:
            new_value = self.MultiList()
            new_value.append(cur_value)
            new_value.append(value)
            value = new_value

        super().__setitem__(key, value)

    def getonly(self, *args, **kwargs):
        """
        If key has one value, return it.

        If key has multiple values, raise a TypeError.  In other words, this
        behaves the same as get() when key has one value.

        For example:

            try:
                value = multi_dict.getonly('foo')
                _handle_one(value)
            except TypeError:
                value = multi_dict.get('foo')
                _handle_many(value)
        """
        val = self.get(*args, **kwargs)
        if isinstance(val, self.MultiList):
            raise TypeError()
        return val
