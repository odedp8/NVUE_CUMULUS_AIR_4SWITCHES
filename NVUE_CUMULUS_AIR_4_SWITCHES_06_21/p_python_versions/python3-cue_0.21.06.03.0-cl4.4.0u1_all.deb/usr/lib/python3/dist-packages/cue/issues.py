# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from dataclasses import dataclass, field


@dataclass
class Issue:
    """
    Abstract class for our "rich issue" concept, which is used frequently in
    the API.
    """
    severity: str
    code: str
    data: dict = field(default_factory=dict)

    @property
    def message(self):
        return self._render_message()

    def as_dict(self):
        return {
            "severity": self.severity,
            "code": self.code,
            "data": self.data,
            "message": self.message
        }


class InfoIssue(Issue):
    """
    Abstract base class for info issues.
    """

    def __init__(self, code="generic"):
        super().__init__("info", code)


class ErrorIssue(Issue):
    """
    Abstract base class for error issues.
    """

    def __init__(self, code="generic"):
        super().__init__("error", code)


class BadInputIssue(ErrorIssue):
    """
    Abstract base class for issues relating to bad input from users.
    """

    def __init__(self, code="bad_input"):
        super().__init__(code)


class WarningIssue(Issue):
    """
    Abstract base class for warning issues.
    """

    def __init__(self, code="generic"):
        super().__init__("warning", code)


class DisruptiveRestartRequiredWarning(WarningIssue):
    """
    A service will need to be restarted to apply this config.  And that will
    disrupt traffic.
    """
    def __init__(self, service, reason):
        super().__init__("disruptive_restart")
        self.data["service"] = service
        self.data["reason"] = reason

    def _render_message(self):
        reason = self.data["reason"]
        service = self.data["service"]
        return (
            f'The {service} service will need to be '
            f'restarted because {reason}.  '
            'This will disrupt traffic.'
        )


class GenericError(ErrorIssue):
    """
    Generic error issue.
    """

    def __init__(self, msg):
        super().__init__()
        self.data["msg"] = msg

    def _render_message(self):
        return self.data["msg"]


class InternalError(ErrorIssue):
    """
    We ran into a bug and couldn't complete the operation.
    """

    def __init__(self, code="bug"):
        super().__init__(code)

    def _render_message(self):
        return "Unrecoverable internal error"


class ClientTimeout(ErrorIssue):
    """
    Timeout while waiting for client input.
    """

    def __init__(self, code="client_timeout"):
        super().__init__(code)

    def _render_message(self):
        return "Timeout while waiting for client response"


class CueFileParseError(BadInputIssue):
    """
    We couldn't parse a cue file.  Filename, location, and reason strings
    provide details about the parse error.
    """

    def __init__(self, location, reason):
        super().__init__("cue_file_parse")
        self.data["location"] = location
        self.data["reason"] = reason

    def _render_message(self):
        fmt = "Parse error at {location}: {reason}"
        return fmt.format(**self.data)


class ConfigParseError(BadInputIssue):
    """
    We couldn't validate a config.  Location, and reason strings provide
    details about the parse error.
    """
    def __init__(self, location, reason):
        super().__init__("config_invalid")
        self.data["location"] = location
        self.data["reason"] = reason

    def _render_message(self):
        fmt = "Config invalid at {location}: {reason}"
        return fmt.format(**self.data)


class GenericWarning(WarningIssue):
    """
    Generic warning issue.
    """

    def __init__(self, msg):
        super().__init__()
        self.data["msg"] = msg

    def _render_message(self):
        return self.data["msg"]


def from_http_exception(ex):
    """
    Given an http exception, return the issue behind the exception.
    This will be ex.issue, if it exists, otherwise a GenericError.
    """
    try:
        return ex.issue
    except AttributeError:
        return GenericError(ex.description)
