# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


import os


# Public configuration root.  This is the "public" repository that, by
# definition, always has the running branch checked out.  Users can modify the
# config directly here and we'll avoid stomping on it.  They'll need to "apply"
# before their changes take effect, though.
PUBLIC_CONFIG_ROOT = os.environ.get("CUE_CONFIG_ROOT", "/etc/nvue.d")

# Root of our working directory.  We're free to make a mess here.
WORKING_DIRECTORY = os.environ.get("CUE_WORKING_DIRECTORY", "/var/lib/cue/")

# Keep the working directory private for now.
WORKING_DIRECTORY_PERMISSIONS = 0o700

# Package prefix for units.  If a top-level package starts with this string,
# we'll try to run it as a unit.
UNIT_PREFIX = "cue_"

# Name of the user we'll run as.
RUNTIME_USER = os.environ.get("CUE_RUNTIME_USER", "cue")

# If CUE_DEBUG is not None, we should run in debug mode.
CUE_DEBUG = os.environ.get("CUE_DEBUG")

# If CUE_TVD_FALLBACK is not None, use traditional vxlan device instead of
# single vxlan device.
TVD_FALLBACK = os.environ.get("CUE_TVD_FALLBACK")
