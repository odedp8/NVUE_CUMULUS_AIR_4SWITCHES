# Copyright (C) 2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


def _flatten_dict_tree(data, path=()):
    """
    Take a deeply nested dict and yield 2-tuples (path, value) where `path` is
    the tuple of keys to `value`.
    """
    # EARLY RETURN
    if data == {}:
        # Handle empty objects
        if len(path) != 0:
            # Only treat empty objects as "primitives" if they're leaves in the
            # tree. An empty root object should yield nothing.
            yield (path, data)
        return

    # EARLY RETURN
    if not hasattr(data, "items"):
        yield (path, data)
        return

    for key, value in data.items():
        yield from _flatten_dict_tree(value, (*path, key))


def fast_merge(*objs):
    """
    A faster version of `py_.merge({}, *objs)` that doesn't need to call
    `deep_copy`. Assumes that there are no lists in the objects and the leaves
    are immutable (safe assumptions for CUE config data.)

    Returns a new dictionary.  Inputs are not changed.
    """
    result = {}

    def _set_one(path, val):
        # EARLY RETURN
        if path == ():
            # The rest of the fn assumes len(path) > 0.
            return
        # Get the object containing val.
        cur = result
        for token in path[:-1]:
            nxt = cur.setdefault(token, {})
            if nxt is None:
                # None is valid at any point in the tree. Any values set past a
                # `None` should clobber the `None` and replace it with an empty
                # dict.
                nxt = {}
                cur[token] = nxt
            cur = nxt
        if val == {}:
            # Don't clobber existing values with empty objects.  Also, make
            # sure we start a new empty object so we don't modify the original
            # inputs.
            cur.setdefault(path[-1], {})
        else:
            # Otherwise, clobber whatever's there.
            cur[path[-1]] = val

    for obj in objs:
        for path, val in _flatten_dict_tree(obj):
            _set_one(path, val)
    return result


def fast_clone(obj):
    """
    A faster version of `py_.clone_deep(obj)`.  Assumes that there are no lists
    in the objects and the leaves are immutable (safe assumptions for CUE
    config data.)
    """
    return fast_merge({}, obj)
