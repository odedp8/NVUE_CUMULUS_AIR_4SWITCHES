# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from contextlib import contextmanager
from enum import IntEnum
from .pam_appl import PamHandle, PamConv
from .pam_appl import pam_start, pam_end, pam_authenticate, pam_acct_mgmt
from .pam_appl import PAM_SUCCESS
from .exceptions import PamError, raise_retcode
from ctypes import byref
import logging


logger = logging.getLogger(__name__)


def authenticate(user: str, authtok: str, *, service: str) -> bool:
    """
    Check a user's authentication with PAM.

    Args:
        user: The username we're attempting to authenticate
        authtok: The authentication token (ie, password)
        service: The PAM service to check against.

    Returns:
        True if the user's authtok proves identity, otherwise False.
    """

    def handle_msg(msg_style, msg):
        if msg_style == MsgStyle.PAM_PROMPT_ECHO_OFF:
            # Assume no echo means password is wanted.
            return authtok
        else:
            return ""

    try:
        with pam_transaction(service, user, handle_msg) as pam:
            pam.authenticate()
            pam.acct_mgmt()
    except PamError as exc:
        # EARLY RETURN
        logger.info(
            "Unauthenticated request attempted for %r: %r",
            user,
            exc.name,
        )
        return False

    return True


###################
# Message styles
###################

class MsgStyle(IntEnum):
    """
    Values for `msg_style` member of the `pam_message` struct.
    """

    PAM_PROMPT_ECHO_OFF = 1
    """Obtain a string without echoing any text."""

    PAM_PROMPT_ECHO_ON = 2
    """Obtain a string whilst echoing text."""

    PAM_ERROR_MSG = 3
    """Display an error message."""

    PAM_TEXT_INFO = 4
    """Display some text."""


####################
# PAM transactions
####################

class PamTransactionContext:
    """
    Context methods/state for a single PAM transaction.
    """
    def __init__(self, pamh, pam_conv):
        self._pamh = pamh
        self._pam_conv = pam_conv

    def authenticate(self, flags=0):
        raise_retcode(pam_authenticate(self._pamh, flags))

    def acct_mgmt(self, flags=0):
        raise_retcode(pam_acct_mgmt(self._pamh, flags))


def _ensure_bytes(maybe_bytes):
    if hasattr(maybe_bytes, 'encode'):
        return maybe_bytes.encode()
    else:
        return maybe_bytes


def wrap_message_handler(message_handler: callable):
    """
    Wrap a message_handler to be usable as a `pam_conv` callback.

    The pam_conv function signature has a bunch of nonsense we don't care
    about. By using a "message_handler" function, we can respond to each
    message individually without all the extra ceremony/oddity.
    """

    def conv_callback(query_list):
        for msg_style, msg in query_list:
            yield (
                _ensure_bytes(message_handler(MsgStyle(msg_style), msg)),
                0,  # Not used; should always be set to 0.
            )

    return conv_callback


@contextmanager
def pam_transaction(service: str, user: str, message_handler: callable):
    """
    Manage the context for a single PAM transaction.

    Handles calling `pam_start` and `pam_end`. Provides a PamTransactionContext
    object that provides a more Pythonic facade to C PAM functions.

    Args:
        service: The PAM service (corresponds with a file in /etc/pam.d/)
        user: The user to authenticate
        message_handler: The function used to respond to prompts. Should have
            signature `message_handler(msg_style: MsgStyle, msg: bytes) -> str`
            where `msg` is the prompt and `msg_style` is the int from a
            `pam_message` struct.
    """

    pam_conv = PamConv.from_callback(wrap_message_handler(message_handler))
    pamh = PamHandle()
    raise_retcode(pam_start(
        _ensure_bytes(service),
        _ensure_bytes(user),
        byref(pam_conv),
        byref(pamh),
    ))

    pam_status = PAM_SUCCESS
    try:
        yield PamTransactionContext(pamh, pam_conv)
    except PamError as pam_err:
        # From 'man pam_end':
        # > The pam_status argument should be set to the value returned to the
        # > application by the last PAM library call.
        # NOTE: If pam_err.code is None, we'll keep the current pam_status.
        pam_status = pam_err.code or pam_status
        # IMPORTANT: Still raise the error for callers to handle!
        raise
    finally:
        raise_retcode(pam_end(pamh, pam_status))
