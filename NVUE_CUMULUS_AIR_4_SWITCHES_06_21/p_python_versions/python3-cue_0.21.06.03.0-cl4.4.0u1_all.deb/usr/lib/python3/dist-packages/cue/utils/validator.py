# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from dataclasses import dataclass
from connexion import json_schema as connexion_validator
from jsonschema.validators import extend
from jsonschema import _validators as jsonschema_validators
from jsonschema import ValidationError, Draft4Validator
from jsonschema import exceptions as jsonschema_exceptions
import logging
from cue import utils
from .format_checker import cue_format_checker


logger = logging.getLogger(__name__)


# Indicate that all properties are allowed at an instance location
ALLOW_ALL_PROPERTIES = object()


def _handle_in_place_applicator(subschemas, whitelist):
    # Get the superset of all properties found on subschemas
    inner_whitelists = [
        _get_list_evaluated_properties(subschema, whitelist)
        for subschema in subschemas
    ]
    # EARLY RETURN
    if ALLOW_ALL_PROPERTIES in inner_whitelists:
        # Everything's valid here. Bubble it up.
        return ALLOW_ALL_PROPERTIES

    # Join all the inner whitelists together
    for inner in inner_whitelists:
        whitelist = whitelist | inner
    return whitelist


def _get_list_evaluated_properties(schema, whitelist=None):
    """
    Construct a whitelist of evaluated properties on current schema and all
    subschemas that apply to the same instance location.

    Returns:
        A whitelist of all properties that are allowed at the current instance
        location.
    """
    # EARLY RETURN
    if ("additionalProperties" in schema
            or whitelist is ALLOW_ALL_PROPERTIES):
        # additionalProperties means everything's valid. Bubble it up.
        return ALLOW_ALL_PROPERTIES

    if whitelist is None:
        whitelist = set()

    if "properties" in schema:
        properties = set(schema.get("properties").keys())
        whitelist = whitelist | properties

    for applicator in ["anyOf", "allOf", "oneOf"]:
        if applicator in schema:
            whitelist = _handle_in_place_applicator(
                schema[applicator],
                whitelist
            )
        # EARLY RETURN
        if whitelist is ALLOW_ALL_PROPERTIES:
            # Everything's valid here. Bubble it up.
            return ALLOW_ALL_PROPERTIES

    return whitelist


def _validate_unevaluated_properties(validator, uneval, instance, schema):
    """
    Validate x-unevaluatedProperties in a way that can be used to extend a
    jsonschema validator.

    Args:
        validator: Current instance of the jsonschema validator class
        uneval: Value of the keyword being evaluated
        instance: Instance being validated for the keyword.
        schema: Current schema being validated.

    Yields:
        A ValidationError every time it encounters something in violation of
        the rule being validated. This allows the jsonschema validator to throw
        an error the first time it encounters one (for efficiency) or iterate
        over all the errors (for thoroughness).
    """
    # EARLY RETURN
    if (uneval is not False or not isinstance(instance, dict)):
        return

    evaluated_properties = _get_list_evaluated_properties(schema)

    # automatically validate if we're allowing all properties
    if evaluated_properties is ALLOW_ALL_PROPERTIES:
        return

    instance_properties = set(instance.keys())
    # yield errors for unevaluated properties
    uneval_properties = instance_properties - evaluated_properties
    for uneval_prop in uneval_properties:
        expected_props = sorted(evaluated_properties)
        yield ValidationError(
            "Unevaluated properties are not allowed "
            f"('{uneval_prop}' was unexpected: "
            f"expected {expected_props})"
        )


def _string_enable_assertion(assertion):
    """
    Return a new validation function for integers that can handle a string
    formattted integer.
    """
    def _string_coerce_wrapper(validator, minimum, instance, schema):
        if validator.is_type(instance, "string"):
            try:
                instance = int(instance)
            except ValueError:
                # The string doesn't look like an integer.  That means this
                # assertion doesn't apply.
                return

        yield from assertion(validator, minimum, instance, schema)

    return _string_coerce_wrapper


BaseCueValidator = extend(
    Draft4Validator,
    {
        # Add support for "nullable" keyword
        "type": connexion_validator.validate_type,
        'enum': connexion_validator.validate_enum,

        # Draft 2019-09 features
        "x-unevaluatedProperties": _validate_unevaluated_properties,
        "x-propertyNames": jsonschema_validators.propertyNames,

        # Integer validators that work when type is string.
        "x-cue-minimum": _string_enable_assertion(
            jsonschema_validators.minimum),
        "x-cue-maximum": _string_enable_assertion(
            jsonschema_validators.maximum),
        "x-cue-exclusiveMinimum": _string_enable_assertion(
            jsonschema_validators.exclusiveMinimum),
        "x-cue-exclusiveMaximum": _string_enable_assertion(
            jsonschema_validators.exclusiveMaximum),
    }
)


@dataclass
class SelectedValidationError:
    """
    Contains a jsonschema validation error, as well as the cue-style `location`
    and the `message` that CUE has associated with this error.

    Get a JSON-ish representation of object with the `.json` property.
    """
    error: object
    message: str
    location: str

    @property
    def keyword_path(self):
        return tuple(self.error.absolute_schema_path)

    @property
    def instance_path(self):
        return tuple(self.error.absolute_path)

    def _fragmentify_pointer(self, pointer):
        from urllib.parse import urlparse
        # Always make it an explicit fragment
        return urlparse("")._replace(fragment=pointer).geturl() or "#"

    @property
    def keyword_location(self):
        return self._fragmentify_pointer(
            utils.convert_path_to_json_pointer(self.keyword_path)
        )

    @property
    def instance_location(self):
        return self._fragmentify_pointer(
            utils.convert_path_to_json_pointer(self.instance_path)
        )

    @property
    def json(self):
        return {
            "error": self.message.strip("\n"),
            "keywordLocation": self.keyword_location,
            "instanceLocation": self.instance_location,
        }


class CueValidator(BaseCueValidator):
    """
    Jsonschema validator that can work directly with the schemas in our OAS
    specs to validate data.

    Remembering that OAS 3.0 uses an "extended subset" of jsonschema, this
    validator handles the "extended" part.  (The "subset" part is handled when
    we validate the spec against the OAS meta-schema; that validation will fail
    if we try to use a jsonschema keyword not in the "subset".)

    We also add a few "x-" assertions.  Those are handled by this validator as
    well.

    Finally, we add utilities and convenience methods.
    """
    # HACK: sidestep issues with how pdoc handles jsonschema's metaprogramming
    _CREATED_WITH_DEFAULT_TYPES = False

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("format_checker", cue_format_checker)
        super().__init__(*args, **kwargs)

    def conforms(self, instance, path_prefix=None):
        """
        If `instance` is valid against the schema, return.  Otherwise, a
        ParseError is raised.  If `path_prefix` is provided, it will be
        prefixed to the path in an errors.  This is useful when validating a
        child, instead of from the root.

        Iterates through `select_errors()` and raises the first selected error
        as a ParseError.

        This is similar to jsonschema's validate(), except that best_match() is
        used to return the error most relevant to the user.  Also, instead of
        raising ValidationError, a ParseError with a location is raised.
        """
        for selected in self.select_errors(instance, path_prefix):
            # Raise the parse error.
            utils.raise_parse_error(selected.location, selected.message)

    def select_errors(self, instance, path_prefix=None):
        """
        Iterate through errors in `instance`, yielding errors most relevant to
        users.

        Yields:
            `SelectedValidationError` instances containing the encountered
            errors.

        """
        errs = list(self.iter_errors(instance))
        # Run the validation and find the best error to report
        err = jsonschema_exceptions.best_match(errs)

        # If there weren't any errors, then we can return.
        if err is None:
            return

        # Get the real location of the error.
        location = utils.find_location(instance, err.absolute_path,
                                       path_prefix=path_prefix)

        # Log the schema path that caused the problem.  This will be very
        # helpful when debugging schema issues.
        logger.dump("ValidationError:", msg=err.message, instance=instance,
                    location=location, schema_path=".".join([
                        str(item) for item in err.absolute_schema_path
                    ]))

        # Start with the normal jsonschema error message
        msg = err.message

        # Look for an x-cue-error in the error's schema.  If we have a parent,
        # recursively look there, too.  The parent is only set in anyOf and
        # oneOf, so this only helps us find an x-cue-error in some corner
        # cases, but for now, those are the cases that concern us.
        # Take the highest x-cue-error we can find, which should provide the
        # right level of detail for the user.
        candidate = err
        while candidate:
            if isinstance(candidate.schema, dict):
                if 'x-cue-error' in candidate.schema:
                    err = candidate
                    msg = candidate.schema['x-cue-error']
            candidate = candidate.parent

        # TODO: CUE-3969 - Yield multiple errors
        yield SelectedValidationError(
            error=err,
            message=msg,
            location=location,
        )
