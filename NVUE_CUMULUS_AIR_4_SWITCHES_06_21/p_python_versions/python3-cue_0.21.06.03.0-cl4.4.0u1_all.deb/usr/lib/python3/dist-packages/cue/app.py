# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Wrap connexion so we can make it sing our song.

# Before we bring connexion in, we have some monkey-patching to do.  I wish
# this could be cleaner, but connexion doesn't give us the hooks we need.  And
# this is much better than forking it.


import logging
import functools
from connexion.operations import openapi
from connexion.decorators import (
    validation as connexion_validation,
    uri_parsing,
)
from connexion import spec
from urllib.parse import urlparse, urlunparse, unquote
from flask.json import jsonify
from flask import request as flask_request
from cue.exceptions import NotFound
from cue.middleware import (
    Operation,
    content_openapi_middleware,
    content_links_middleware,
    content_templatelinks_middleware,
    no_none_response_middleware,
)
from cue.auth import AuthenticatedRequest, check_authorization
from cue import utils
from cue.utils.context import CueApiClient


logger = logging.getLogger(__name__)


_LINKS_MIMETYPE = "application/vnd.cue.links+json"
_TEMPLATE_LINKS_MIMETYPE = "application/vnd.cue.templatelinks+json"


def use_raw_path_middleware(wsgi_app, raw_uri_key):
    """
    WSGI middleware to prevent early decoding of percent-encodes in
    `environ["PATH_INFO"]`.

    The WSGI spec doesn't define an `environ` key for retrieving the raw
    (undecoded) path, but many implementations provide it through a
    non-standard key.

    https://werkzeug.palletsprojects.com/en/1.0.x/wsgi/#raw-request-uri-and-path-encoding

    Args:
        wsgi_app: The callable WSGI app to wrap.
        raw_uri_key: The `environ` key to retrieve the raw path from.

    Returns:
        A WSGI callable that overwrites `PATH_INFO` with the raw path before
        continuing into the wrapped `wsgi_app`.
    """
    def app_wrapper(environ, start_response):
        # It might have non-path URI components. We only want the path.
        raw_path = urlparse(environ[raw_uri_key]).path
        environ["PATH_INFO"] = raw_path
        return wsgi_app(environ, start_response)

    return app_wrapper


class CueParameterValidator(connexion_validation.ParameterValidator):
    """
    A ParameterValidator subclass that calls on CueValidator to do its
    heavy-lifting.
    """

    def validate_parameter(self, parameter_type, value, param,
                           param_name=None):
        """
        Replace connexion's validate_parameter() with one that calls
        CueValidator().conforms() to verify the parameter.  This allows us to
        use our schema extensions in parameter specs.  Also, it produces errors
        consistent with request body validations.
        """
        if value is not None:
            try:
                converted_value = connexion_validation.coerce_type(
                    param, value, parameter_type, param_name)
            except connexion_validation.TypeValidationError as e:
                return str(e)

            try:
                utils.CueValidator(param).conforms(converted_value)
            except utils.ParseError as ex:
                return ex.reason

        elif param.get('required'):
            param_name = param_name or param.get("name", "unnamed")
            return f"Missing {parameter_type} parameter '{param_name}'"


class CueRequestBodyValidator(connexion_validation.RequestBodyValidator):
    """
    A RequestBodyValidator subclass that calls on CueValidator to do its
    heavy-lifting.
    """

    def __init__(self, *args, **kwargs):
        # Use CueValidator, instead of Draft4Validator, as the default.  A
        # caller could still provide a custom validator, but it would need to
        # be a CueValidator subclass.
        kwargs.setdefault("validator", utils.CueValidator)
        super().__init__(*args, **kwargs)

    def validate_schema(self, data, url):
        """
        Replace connexion's validate_schema() with one that calls
        CueValidator().select_errors() to verify the request body. If any
        errors are discovered, then return them in a problem response.
        """
        selected_errors = list(self.validator.select_errors(data))
        if not selected_errors:
            return

        # Connexion wants "extension attributes" to be contained in a dict
        # mixin.
        validation_extension = {
            "validation": {
                "selected_errors": [
                    err.json
                    for err in selected_errors
                ]
            }
        }

        # Grab the best match to use as the detail message.
        best_match, *_ = selected_errors
        if best_match.location:
            detail = f"Error at {best_match.location}: {best_match.message}"
        else:
            detail = f"Error: {best_match.message}"

        return connexion_validation.problem(
            400,
            'Bad Request',
            detail,
            ext=validation_extension,
        )


# Validator map that uses our custom validators
cue_validators = {
    'parameter': CueParameterValidator,
    'body': CueRequestBodyValidator,
    # Note that we don't provide a response validator because we don't do
    # response validation.
}


class CueOpenAPIURIParser(uri_parsing.OpenAPIURIParser):

    def resolve_path(self, path_params):
        """
        Decode the path params before we use them.

        Normally, WSGI would have already done this. But we've turned that off
        to enable percent-encoded '/' inside path params. Connexion has already
        extracted the path_params by this point. We want the percent-decoded
        values to be used in our actual handler functions.
        """
        path_params = {
            key: unquote(val)
            for key, val in path_params.items()
        }
        return super().resolve_path(path_params)


class CueOpenAPIOperation(openapi.OpenAPIOperation):
    """
    Subclass of OpenAPIOperation with our special sauce.
    """

    middleware = (
        no_none_response_middleware,
        content_openapi_middleware,
        content_links_middleware,
        content_templatelinks_middleware,
    )
    """
    Middleware to use when handling operations.

    For more information, see `cue.middleware`.
    """

    def __init__(self, *args, validator_map=None, **kwargs):
        # Default the validators to our subclasses
        cue_validator_map = dict(cue_validators)
        cue_validator_map.update(validator_map or {})
        kwargs["uri_parser_class"] = CueOpenAPIURIParser

        # Continue creating the operation instance
        super().__init__(*args, validator_map=cue_validator_map, **kwargs)

    def middleware_decorator(self, function):
        """
        Wrap the operation function with our middleware.

        This decorator will be applied before the URI parsing decorator (ie, it
        will run after connexion modifies the request params.)
        """

        operation = Operation(
            path=self.path,
            method=self.method,
            full_spec=self.api.specification.raw,
            url_prefix=self.api.blueprint.url_prefix,
        )

        def _wrap_middleware(middleware, operation_func):

            @functools.wraps(operation_func)
            def middleware_wrapper(request):
                return middleware(operation, request, operation_func)

            return middleware_wrapper

        for middleware_function in self.middleware:
            function = _wrap_middleware(middleware_function, function)

        return function

    @property
    def _uri_parsing_decorator(self):
        """
        Override the uri_parsing decorator to slip in our own decorations.
        connexion doesn't give us a hook to do this any better.  We'll
        need to fix that some day, but not today.
        """
        # Get the normal URI parser decorator.  This is a copy and paste from
        # OpenAPIOperation.
        uri_decorator = self._uri_parser_class(self.parameters,
                                               self.body_definition)

        # Declare our content decorator, which will also do the URI parser
        # decoration.
        def decorator(function):
            # Put the middleware_decorator in first.
            function = self.middleware_decorator(function)
            # Then wrap the decorator like we normally would.
            uri_parser = uri_decorator(function)

            return uri_parser

        # Return the decorator.  Connexion will call it to wrap each endpoint.
        return decorator

    def get_arguments(self, path_params, query_params, body, files, arguments,
                      has_kwargs, sanitize):
        """
        Flatten the "body" argument.  On the upside, this allows endpoint
        handlers to treat all arguments the same, regardless of whether they
        came from the path, query, or body.  On the downside, it gets a little
        weird if the body is a complex object.
        """
        # Create an arguments list that includes "body", if it doesn't already.
        x_body_name = self.body_schema.get('x-body-name', 'body')
        if x_body_name in arguments:
            flatten = False
        else:
            arguments = list(arguments) + [x_body_name]
            flatten = True

        # Do what we normally do.
        ret = super().get_arguments(path_params, query_params, body, files,
                                    arguments, has_kwargs, sanitize)

        if flatten:
            # If we got a body argument, flatten it into the rest of the
            # arguments.
            body = ret.pop(x_body_name, None)
            if body is not None:
                if type(body) is dict:
                    # It's a dictionary.  We can flatten it.
                    ret.update(body)
                else:
                    # It's not a dictionary, put it back in and let Python
                    # complain.
                    ret[x_body_name] = body

        return ret

    def get_mimetype(self):
        """
        Return the endpoint's mimetype in a more CUE-friendly way.

        The default Connexion behavior isn't friendly to our raw endpoints.
        Here, we'll look for a raw-ish endpoint and return the appropriate
        mimetype.  Otherwise, we'll fallback on the default behavior.
        """
        # Does it smell raw?
        if any(mimetype == "text/plain" for mimetype in self.produces):
            return "text/plain"

        # It doesn't seem raw; let connexion decide.
        return super().get_mimetype()


class EnvelopingSpecification(spec.OpenAPISpecification):
    """
    OpenAPISpecification that uses our enveloping operation.
    """
    operation_cls = CueOpenAPIOperation

    def __init__(self, raw_spec):
        """
        Override Specification's init to improve efficiency.
        """
        # In Connexion's Specification base class, it protects itself with the
        # following lines:
        #
        #   self._raw_spec = copy.deepcopy(raw_spec)
        #   self._set_defaults(raw_spec)
        #   self._validate_spec(raw_spec)
        #   self._spec = resolve_refs(raw_spec)
        #
        # But in our case, we can assume:
        # 1. The spec was loaded specifically for the add_api() call.  It's
        # Connexion's to modify.
        # 2. All references have already been resolved.
        # 3. The spec is valid.  Rather than validate at runtime, we'll
        # validate during unittesting.
        #
        # Given those assumptions, we can streamline the init for much, much
        # faster startup.  As our schemas continue to grow, that's increasingly
        # important.
        #
        self._raw_spec = raw_spec
        self._set_defaults(raw_spec)
        self._spec = self._raw_spec


# Monkey-patch our EnvelopingSpecification into Connexion. This is the easiest
# way to get our envelope support into Connexion without forking it.
spec.OpenAPISpecification = EnvelopingSpecification


# Now, it's OK to import the rest of Connexion.
import connexion  # noqa


class CueApi(connexion.FlaskApi):
    """
    Simple FlaskApi that knows about its unit name.
    """
    @property
    def unit_name(self):
        return self.base_path.strip("/")


# Expose Connexion's FlaskApp here.  If modules come here to get it, we can be
# sure the monkey-patching has been loaded.
class CueApp(connexion.FlaskApp):
    """
    Subclass of `connexion.FlaskApp` with monkey-patched dependencies in
    addition to overridden behaviors.
    """

    def __init__(
        self,
        *args,
        ctx,
        resolver_cls=utils.Resolver,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        # So add_api can attach API clients.
        self.ctx = ctx
        # NOTE: resolver_cls is primarily useful for tweaking resolver logic in
        #       unit tests.
        self.resolver_cls = resolver_cls
        # Tell connexion to use our API subclass
        self.api_cls = CueApi
        # Make the base path aware of the top-level APIs
        self.add_url_rule("/", "cue_absolute_root", self.cue_absolute_root)
        # Apply middleware to the Flask app. While we could apply middleware
        # via `CueApp.__call__`, it wouldn't be called when using Flask's
        # `test_client`.
        self.app.wsgi_app = use_raw_path_middleware(
            self.app.wsgi_app, "RAW_URI"
        )
        self.app.request_class = AuthenticatedRequest
        self.app.before_request(check_authorization)

    def cue_absolute_root(self):
        """
        Flask view for the absolute root of our app. It's a noop, except for
        the HATEOAS behavior used in the APIs defined by OpenAPI.

        Raises:
            NotFound if "application/vnd.cue.links+json" is not an accepted
                MIME type.
        """
        if _LINKS_MIMETYPE in flask_request.accept_mimetypes:
            base_paths = self.app.blueprints.keys()
            links = {
                "self": {
                    "rel": "self",
                    "href": "/",
                    "methods": [],
                },
                **{
                    f"child:{path[1:]}": {
                        "rel": "child",
                        "href": path,
                        # HACK: hardcode methods to be empty, since base path
                        #       *shouldn't* have any accepted methods
                        "methods": [],
                    }
                    for path in base_paths
                }
            }
            return jsonify({"links": links})
        elif _TEMPLATE_LINKS_MIMETYPE in flask_request.accept_mimetypes:
            parsed_url = urlparse(flask_request.url)
            base = urlunparse(tuple([
                parsed_url.scheme,
                parsed_url.netloc,
                "", "", "", "",
            ]))
            base_paths = self.app.blueprints.keys()
            links = [
                {
                    "rel": "self",
                    "href": "/",
                },
                *[
                    {
                        "rel": "up",
                        "anchor": path,
                    }
                    for path in base_paths
                ]
            ]
            return jsonify({
                "base": base,
                "links": links,
            })
        else:
            raise NotFound

    def add_api(
        self,
        specification,
        **kwargs,
    ) -> CueApi:
        """
        Add an API to the app and attach its API client to ctx.

        If the specification has multiple entries for "servers", create an API
        for each server and attach it to ctx. Only return the first API
        created. (The multi-entry mechanism is only needed for aliasing between
        /cue_v1 and /nvue_v1. It should not be used for anything else.)
        """
        # Use the same client for all equivalent aliases.
        api_client = CueApiClient(self.ctx)
        # Create a resolver to build out the api client.
        resolver = self.resolver_cls(api_client)

        def _add_api(specification, **kwargs):
            # HACK: Need to specify info for super() to work properly, since
            #       we're inside a closure.
            api = super(type(self), self).add_api(
                specification,
                resolver=resolver,
                pythonic_params=True,
                **kwargs,
            )
            # Add the built api_client to the context.
            setattr(self.ctx, api.unit_name, api_client)
            return api

        apis = []
        original_servers = list(specification['servers'])
        for server_entry in original_servers:
            copy_spec = {
                **specification,
                "servers": [server_entry]
            }
            apis.append(_add_api(copy_spec, **kwargs))
        try:
            # Return the first one created
            return apis[0]
        except IndexError:
            # There was nothing to loop over. Create the API and let Connexion
            # figure out what to do.
            return _add_api(specification, **kwargs)
