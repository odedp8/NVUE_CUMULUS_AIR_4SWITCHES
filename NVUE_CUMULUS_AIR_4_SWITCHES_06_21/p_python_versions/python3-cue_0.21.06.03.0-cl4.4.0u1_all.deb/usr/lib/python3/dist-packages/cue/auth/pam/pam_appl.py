# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

# Portions of this module draw heavily from python-pam
# https://github.com/FirefighterBlu3/python-pam
#
# https://github.com/FirefighterBlu3/python-pam/blob/master/LICENSE

from ctypes.util import find_library
from ctypes import (
    Structure,
    c_void_p,
    CDLL,
    c_int,
    c_char_p,
    c_size_t,
    c_char,
    CFUNCTYPE,
    POINTER,
    sizeof,
    cast,
    memmove,
)


###############################################################################
# PAM structures

class PamHandle(Structure):
    """
    Wrapper class for pam_handle_t pointer.

    NOTE: This is effectively a void pointer to the actual struct.
          Linux-PAM does not want us to see inside the struct. All we have
          to do is receive the pointer and pass it around.

    ```c
    /* This is a blind structure; users aren't allowed to see inside a
     * pam_handle_t, so we don't define struct pam_handle here.  This is
     * defined in a file private to the PAM library.  (i.e., it's private
     * to PAM service modules, too!)  */

    typedef struct pam_handle pam_handle_t;
    ```
    """
    _fields_ = [("handle", c_void_p)]

    def __init__(self):
        Structure.__init__(self)
        # Init the pointer to something reasonable. We'll pass this
        # into pam_start, which will actually init this.
        self.handle = None


class PamMessage(Structure):
    """
    Wrapper class for pam_message structure

    ```c
    /* Used to pass prompting text, error messages, or other informatory
     * text to the user.  This structure is allocated and freed by the PAM
     * library (or loaded module).  */

    struct pam_message {
        int msg_style;
        const char *msg;
    };
    ```
    """
    _fields_ = [("msg_style", c_int), ("msg", c_char_p)]

    def __repr__(self):
        return f"{type(self).__name__}({self.msg_style}, {self.msg})"


class PamResponse(Structure):
    """
    Wrapper class for pam_response structure.

    ```c
    /* Used to return the user's response to the PAM library.  This
       structure is allocated by the application program, and free()'d by
       the Linux-PAM library (or calling module).  */

    struct pam_response {
        char *resp;
        int  resp_retcode;  /* currently un-used, zero expected */
    };
    ```
    """
    _fields_ = [
        ("resp", c_char_p),
        ("resp_retcode", c_int),  # "currently un-used, zero expected"
    ]

    def __repr__(self):
        return f"{type(self).__name__}({self.resp}, {self.resp_retcode})"


CONV_FUNC = CFUNCTYPE(
    c_int,  # return type
    c_int,
    POINTER(POINTER(PamMessage)),
    POINTER(POINTER(PamResponse)),
    c_void_p,
)
"""
PAM conversation function.

```c
int (*conv)(int num_msg, const struct pam_message **msg,
            struct pam_response **resp, void *appdata_ptr);
```
"""


class PamConv(Structure):
    """
    Wrapper class for pam_conv structure.

    ```c
    /* The actual conversation structure itself */

    struct pam_conv {
        int (*conv)(int num_msg, const struct pam_message **msg,
                    struct pam_response **resp, void *appdata_ptr);
        void *appdata_ptr;
    };
    ```
    """
    _fields_ = [
        ("conv", CONV_FUNC),
        ("appdata_ptr", c_void_p),
    ]

    @classmethod
    def from_callback(cls, callback):
        """
        Create a `pam_conv` from a python callback function.

        The created conversation function uses `callback` for the logic, but
        handles the allocation of memory.

        The callback is called as `callback(query_list)` where `query_list` is
        a list of 2-tuples `(msg_style, msg)` each containing the values of the
        `PamMessage` structs.

        The callback must return a list of 2-tuples `(resp, resp_retcode)` each
        corresponding with the values of a `PamResponse` struct.

        NOTE ON MEMORY MANAGEMENT:
            The conversation functions memory management responsibilities are
            relatively simple. It needs to:

            - create the array of pam_response structures; and
            - upon error, release any memory it had allocated for responses.

            The caller is responsible for releasing the responses on success.
            In this case, we avoid the need to explicitly release memory by
            validating the responses before allocating any memory.
        """

        @CONV_FUNC
        def conv_callback(num_msg, messages, p_response, app_data):
            """
            The function pointer for the pam_conv callback.
            """
            messages = [messages[i] for i in range(num_msg)]

            query_list = [
                (x.contents.msg_style, x.contents.msg)
                for x in messages
            ]
            try:
                # Coerce to list to allow using generators
                result_list = list(callback(query_list))
            except BaseException:
                # EARLY RETURN
                return PAM_CONV_ERR

            # EARLY RETURN
            if len(result_list) != num_msg:
                return PAM_CONV_ERR

            # Before we start allocating memory, make sure we can use the
            # results as responses.
            for result in result_list:
                # EARLY RETURN
                if not isinstance(result, tuple) or len(result) != 2:
                    return PAM_CONV_ERR
                answer, retcode = result
                # EARLY RETURN
                if (
                    not isinstance(answer, bytes)
                    or b'\x00' in answer
                    or not isinstance(retcode, int)
                ):
                    return PAM_CONV_ERR

            # The results look good! Time to allocate memory for them.
            cls._callback_set_response(result_list, p_response)
            return PAM_SUCCESS

        return cls(conv_callback, 0)

    @classmethod
    def _callback_set_response(
        cls, result_list, p_response,
    ):  # pragma: no cover
        """
        Set the conversation responses.

        Used in the conversation function created by `from_callback`. The main
        reason this is a separate function is so that we can mock it in unit
        tests.
        """
        # We've already verified that result_list is the right length.
        addr = calloc(len(result_list), sizeof(PamResponse))
        responses = cast(addr, POINTER(PamResponse))
        p_response[0] = responses

        for result, resp in zip(result_list, responses):
            answer, retcode = result
            dest = calloc(len(answer) + 1, sizeof(c_char))
            memmove(
                dest,
                c_char_p(answer),
                len(answer) * sizeof(c_char),
            )
            resp.resp = dest
            resp.resp_retcode = retcode


###############################################################################
# libc function wrappers

libc = CDLL(find_library("c"))
calloc = libc.calloc
calloc.restype = c_void_p
calloc.argtypes = [c_size_t, c_size_t]


###############################################################################
# PAM function wrappers

libpam = CDLL(find_library("pam"))


pam_start = libpam.pam_start
"""
initialization of PAM transaction

```c
#include <security/pam_appl.h>

int pam_start(const char *service_name, const char *user,
              const struct pam_conv *pam_conversation, pam_handle_t **pamh);
```
"""

pam_start.restype = c_int
pam_start.argtypes = [c_char_p, c_char_p, POINTER(PamConv), POINTER(PamHandle)]


pam_end = libpam.pam_end
"""
termination of PAM transaction

```c
#include <security/pam_appl.h>

int pam_end(pam_handle_t *pamh, int pam_status);
```
"""

pam_end.restype = c_int
pam_end.argtypes = [PamHandle, c_int]


pam_authenticate = libpam.pam_authenticate
"""
account authentication

```c
#include <security/pam_appl.h>

int pam_authenticate(pam_handle_t *pamh, int flags);
```
"""

pam_authenticate.restype = c_int
pam_authenticate.argtypes = [PamHandle, c_int]


pam_acct_mgmt = libpam.pam_acct_mgmt
"""
PAM account validation management

```c
#include <security/pam_appl.h>

int pam_acct_mgmt(pam_handle_t *pamh, int flags);
```
"""

pam_acct_mgmt.restype = c_int
pam_acct_mgmt.argtypes = [PamHandle, c_int]


###############################################################################
# The Linux-PAM return values

# Each item is a 3-tuple of (code: int, name: str, description: str)
PAM_DEFINE_RETURN_VALUES = [
    (
        0, "PAM_SUCCESS",
        "Successful function return"
    ),
    (
        1, "PAM_OPEN_ERR",
        "dlopen() failure when dynamically loading a service module"
    ),
    (
        2, "PAM_SYMBOL_ERR",
        "Symbol not found"
    ),
    (
        3, "PAM_SERVICE_ERR",
        "Error in service module"
    ),
    (
        4, "PAM_SYSTEM_ERR",
        "System error"
    ),
    (
        5, "PAM_BUF_ERR",
        "Memory buffer error"
    ),
    (
        6, "PAM_PERM_DENIED",
        "Permission denied"
    ),
    (
        7, "PAM_AUTH_ERR",
        "Authentication failure"
    ),
    (
        8, "PAM_CRED_INSUFFICIENT",
        "Can not access authentication data due to insufficient credentials"
    ),
    (
        9, "PAM_AUTHINFO_UNAVAIL",
        (
            "Underlying authentication service can not retrieve authentication"
            + " information"
        ),
    ),
    (
        10, "PAM_USER_UNKNOWN",
        "User not known to the underlying authentication module"
    ),
    (
        11, "PAM_MAXTRIES",
        (
            "An authentication service has maintained a retry count which has"
            + " been reached.  No further retries should be attempted"
        ),
    ),
    (
        12, "PAM_NEW_AUTHTOK_REQD",
        (
            "New authentication token required."
            + "  This is normally returned if the machine security policies"
            + " require that the password should be changed because the"
            + " password is NULL or it has aged"
        ),
    ),
    (
        13, "PAM_ACCT_EXPIRED",
        "User account has expired"
    ),
    (
        14, "PAM_SESSION_ERR",
        "Can not make/remove an entry for the specified session"
    ),
    (
        15, "PAM_CRED_UNAVAIL",
        (
            "Underlying authentication service can not retrieve user"
            + " credentials unavailable"
        ),
    ),
    (
        16, "PAM_CRED_EXPIRED",
        "User credentials expired"
    ),
    (
        17, "PAM_CRED_ERR",
        "Failure setting user credentials"
    ),
    (
        18, "PAM_NO_MODULE_DATA",
        "No module specific data is present"
    ),
    (
        19, "PAM_CONV_ERR",
        "Conversation error"
    ),
    (
        20, "PAM_AUTHTOK_ERR",
        "Authentication token manipulation error"
    ),
    (
        21, "PAM_AUTHTOK_RECOVERY_ERR",
        "Authentication information cannot be recovered"
    ),
    (
        22, "PAM_AUTHTOK_LOCK_BUSY",
        "Authentication token lock busy"
    ),
    (
        23, "PAM_AUTHTOK_DISABLE_AGING",
        "Authentication token aging disabled"
    ),
    (
        24, "PAM_TRY_AGAIN",
        "Preliminary check by password service"
    ),
    (
        25, "PAM_IGNORE",
        (
            "Ignore underlying account module regardless of whether the"
            + " control flag is required, optional, or sufficient"
        ),
    ),
    (
        26, "PAM_ABORT",
        "Critical error (?module fail now request)"
    ),
    (
        27, "PAM_AUTHTOK_EXPIRED",
        "user's authentication token has expired"
    ),
    (
        28, "PAM_MODULE_UNKNOWN",
        "module is not known"
    ),
    (
        29, "PAM_BAD_ITEM",
        "Bad item passed to pam_*_item()"
    ),
    (
        30, "PAM_CONV_AGAIN",
        "conversation function is event driven and data is not available yet"
    ),
    (
        31, "PAM_INCOMPLETE",
        (
            "please call this function again to complete authentication stack."
            + " Before calling again, verify that conversation is completed"
        ),
    ),
]


# Expose return values as module attributes too.
PAM_SUCCESS = 0
PAM_OPEN_ERR = 1
PAM_SYMBOL_ERR = 2
PAM_SERVICE_ERR = 3
PAM_SYSTEM_ERR = 4
PAM_BUF_ERR = 5
PAM_PERM_DENIED = 6
PAM_AUTH_ERR = 7
PAM_CRED_INSUFFICIENT = 8
PAM_AUTHINFO_UNAVAIL = 9
PAM_USER_UNKNOWN = 10
PAM_MAXTRIES = 11
PAM_NEW_AUTHTOK_REQD = 12
PAM_ACCT_EXPIRED = 13
PAM_SESSION_ERR = 14
PAM_CRED_UNAVAIL = 15
PAM_CRED_EXPIRED = 16
PAM_CRED_ERR = 17
PAM_NO_MODULE_DATA = 18
PAM_CONV_ERR = 19
PAM_AUTHTOK_ERR = 20
PAM_AUTHTOK_RECOVERY_ERR = 21
PAM_AUTHTOK_LOCK_BUSY = 22
PAM_AUTHTOK_DISABLE_AGING = 23
PAM_TRY_AGAIN = 24
PAM_IGNORE = 25
PAM_ABORT = 26
PAM_AUTHTOK_EXPIRED = 27
PAM_MODULE_UNKNOWN = 28
PAM_BAD_ITEM = 29
PAM_CONV_AGAIN = 30
PAM_INCOMPLETE = 31
