# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from .pam_appl import PAM_DEFINE_RETURN_VALUES


class PamError(Exception):
    """
    Base exception for PAM errors from libpam C code.

    These should not be initialized directly. Instead, use `raise_retcode`.
    """

    description = "An unidentified PAM error"
    code = None
    name = None

    def __new__(cls, code: int):
        # Look for the subclass with a matching code
        for subcls in cls.__subclasses__():
            # EARLY RETURN
            if subcls.code == code:
                return super().__new__(subcls, code)
        return super().__new__(cls, code)

    def __init__(self, code):
        # Set the code as an instance attribute, in case the retcode was
        # somehow not one of the ones defined.
        self.code = code

    def __str__(self):
        return self.description


for code, name, description in PAM_DEFINE_RETURN_VALUES:
    setattr(
        PamError,
        # NOTE: Using the ALL_CAPS names for exception subclasses isn't
        #       PEP-8 compliant. But it makes it easier to grep the
        #       codebase for the generated error classes.
        name,
        type(
            ".".join([PamError.__name__, name]),
            PamError.__mro__,
            {
                'code': code,
                'name': name,
                'description': description,
                '__doc__': description,
            },
        ),
    )


def raise_retcode(retcode: int) -> None:
    if retcode:
        raise PamError(retcode)
