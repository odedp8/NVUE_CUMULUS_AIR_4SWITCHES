# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from flask import Request
from cue import exceptions
from cue.auth import pam
import pwd
import grp


def get_user_groups(username: str) -> tuple:
    return tuple(
        group.gr_name
        for group in grp.getgrall()
        if username in group.gr_mem
    )


class AuthenticatedRequest(Request):
    """
    A request that coverts the UDS connection info embedded in `environ` into a
    format that's more immediately useful.

    Attributes:
        username: The string username of the connected user.
        is_root: Whether or not the connected user is using root privileges.
        user_groups: The string groups to which the user belongs.
    """

    def __init__(self, environ, populate_request=True, shallow=False):
        super().__init__(environ, populate_request, shallow)
        try:
            auth_type = self.authorization.type
        except AttributeError:
            auth_type = None

        self.is_root = False

        # NOTE: We're only setting the 'username' and 'user_groups' attributes
        #       if we can authenticate the request. That way we can raise an
        #       Unauthorized error upon looking up the attributes. In a perfect
        #       world, we'd raise the error here, but Flask doesn't seem
        #       capable of handling HTTPErrors in the Request constructor.
        if auth_type is None:
            # If the request didn't specify any authorization, then use the
            # credentials from the unix domain socket peer.
            # The nginx reverse proxy enforces auth, so the requesting client
            # is running locally on the box.
            pw_user = pwd.getpwuid(environ["cue.peer_uid"])
            self.username = pw_user.pw_name
            # UID 0 is always reserved for root user.
            self.is_root = (pw_user.pw_uid == 0)
            self.user_groups = get_user_groups(self.username)
        elif auth_type == "basic":
            # The nginx reverse proxy enforces authorization headers, so any
            # requests coming from nginx can be reasonably trusted. The tricky
            # part, however, is verifying whether or not a given request came
            # from nginx.

            # Other products (not naming names here) will trust the username
            # provided in the auth headers without even looking at the
            # password. In that case, the communication socket is only
            # available to root and members of the www-data group. Since they
            # limited the users who can access the socket, they're
            # "theoretically" safe.

            # We could simply check that the connected peer is www-data (the
            # default nginx worker user). But blindly trusting www-data sort of
            # defeats the purpose of running servers via less privileged users.
            # Furthermore, nginx is not the only service that uses the www-data
            # user! Blindly trusting www-data is a bit risky for my taste.

            # Instead, we will trust nothing. We'll verify the auth headers via
            # PAM (just like nginx should have done.) That way, we don't have
            # to care about whether or not people are circumventing nginx!

            # tl;dr Don't trust www-data. Verify the user's authentication.

            # EARLY RETURN
            if not pam.authenticate(
                self.authorization.username,
                self.authorization.password,
                service="cueapi",
            ):
                # Don't set the auth'd username. That will trigger an
                # Unauthorized response error when the username attribute is
                # accessed.
                return

            # The auth looks good. We'll go ahead and store it.
            self.username = self.authorization.username
            self.user_groups = get_user_groups(self.username)

    def __getattr__(self, name):
        if name in ("username", "user_groups"):
            # If we didn't authenticate the user in constructor, raise the
            # error on attribute lookup.
            # Ideally, we could raise the error in the constructor, but Flask
            # doesn't seem like it's able to handle errors in the Request
            # constructor.
            raise exceptions.Unauthorized()
        return super().__getattr__(self, name)
