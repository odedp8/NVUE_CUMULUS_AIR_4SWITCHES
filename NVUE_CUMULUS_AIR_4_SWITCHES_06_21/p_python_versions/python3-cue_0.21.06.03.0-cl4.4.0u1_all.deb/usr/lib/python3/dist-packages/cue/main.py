# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from .app import CueApp
import importlib
import pkgutil
import logging
from dataclasses import dataclass
from cue import utils, config, fileops, jobs, events, render, request
from cue.auth import get_auth_config
from cue.safe_sh import sh
import threading


logger = logging.getLogger(__name__)


server = None

# Get the context.  This is where we'll glue everything together
# so units can find each other.
ctx = utils.context
ctx.fileops = fileops
ctx.sh = sh
ctx.jobs = jobs
ctx.events = events
ctx.render = render
ctx.request = request


# Initialize the app
app = CueApp(__name__,
             ctx=ctx,
             specification_dir='openapi/',
             options={'swagger_ui': False})


@dataclass
class MainPreparedEvent(events.AbstractEvent):
    ctx: object


def find_cue_units():
    """
    Get a list of all the units we can find
    """
    return [name for _, name, _
            in pkgutil.iter_modules() if name.startswith(config.UNIT_PREFIX)]


def prepare():
    # Load/cache the auth config at the beginning of preparation. If the config
    # is invalid, it'll (politely) crash the server. We want this to happen
    # before we do/log a bunch of other stuff. Most importantly, if we don't
    # prime the cache at start, we'll be loading (and potentially crashing) at
    # the first request. That might not happen immediately. If there's
    # something that needs attention in the auth config, the user should be
    # informed ASAP.
    get_auth_config()

    failures = []

    # Loop over each and try to import it.
    for unit_name in find_cue_units():
        # Try to import it
        try:
            unit = importlib.import_module(unit_name)
            logger.dump("Imported", unit_name)
        except Exception:
            logger.exception("Could not import %s", unit_name)
            failures.append(unit_name)
            continue

        # Try to add it
        try:
            spec = unit.get_openapi()
            api = app.add_api(spec)

            # Tell the unit to prepare itself
            unit.prepare_unit(ctx)

            logger.info("Added API %s", api.unit_name)
        except Exception:
            logger.exception("Could not add %s", unit_name)
            failures.append(unit_name)

    evt = MainPreparedEvent(ctx)
    ctx.events.main_prepared(evt)

    if len(failures) > 0:
        logger.warning("Some units failed to load: %s", ",".join(failures))


def start():
    global server

    # Start the job thread
    ctx.jobs.start()

    # Create the server and store it in a global.
    # We want to be able to call server.shutdown() when tearing down.  The
    # alternative is a "production" WSGI server, but the simple (and light)
    # werkzeug server suits us just fine.
    from .serving import make_server
    server = make_server(app)

    logger.info("Started cued")
    logger.info("  configdir: %s", config.PUBLIC_CONFIG_ROOT)
    if config.TVD_FALLBACK:
        logger.info("  tvd_fallback")
    logger.info(
        " * Running on %s (Press CTRL+C to quit)",
        # NOTE: since we're hosting on a UDS, 'port' isn't applicable here.
        server.host
    )
    # Fire it up.  This will not return until stop() is called.
    server.serve_forever()


def restart(*args, **kwargs):
    # There's nothing to restart yet.
    pass


def _stopper():
    """
    Actually stop the server.  This must be called from a new thread.

    Why the thread is needed:
    - We have to call server.shutdown() and server.serve_forever() from
      different threads.  Otherwise, shutdown() will block forever.
    - The main thread is busy running server.serve_forever().
    - stop() will usually be called from a signal handler (i.e. after a
      control-c or SIGTERM).
    - Signals are also handled on the main thread (interrupting whatever it was
      doing).
    """
    logger.info("Stopping the server")
    server.shutdown()

    # Stop the job thread
    ctx.jobs.stop()

    # Exit normally
    logger.info(" * Exiting")
    exit()


def stop(*args, **kwargs):
    stopper = threading.Thread(target=_stopper)
    stopper.start()
    return stopper
