# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue import exceptions
from cue_cue_v1.root import root_patch


###############################
# MLAG
###############################
def mlag_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getMlag(rev)
    return ctx.netlink_v1.getMlag()


def mlag_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"mlag": body})
    return root.get("mlag", {})


def mlag_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getMlag, ctx.config_v1.setMlag, rev)


###############################
# Backups
###############################

def backups_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getMlag(rev, "backup")

    return mlag_get(ctx, rev)["backup"]


def backups_patch(ctx, rev, body=None):
    mlag = mlag_patch(ctx, rev, {"backup": body})
    return mlag.get("backup", {})


def backups_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getMlag, ctx.config_v1.setMlag, rev, "backup")


###############################
# Backup
###############################

def backup_get(ctx, rev, backup_id):
    backups = backups_get(ctx, rev)
    try:
        return backups[backup_id]
    except KeyError:
        raise exceptions.NotFound


def backup_patch(ctx, rev, backup_id, body=None):
    backups = backups_patch(ctx, rev, {backup_id: body})
    return backups.get(backup_id, {})


def backup_delete(ctx, rev, backup_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getMlag, ctx.config_v1.setMlag, rev, "backup", backup_id)
