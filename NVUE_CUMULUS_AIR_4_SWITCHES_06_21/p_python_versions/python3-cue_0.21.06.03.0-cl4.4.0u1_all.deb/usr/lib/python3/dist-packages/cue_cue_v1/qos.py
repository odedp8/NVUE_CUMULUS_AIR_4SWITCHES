# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue_cue_v1.root import root_patch

###############################
# Qos
###############################

import logging
logger = logging.getLogger(__name__)


def qos_roce_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getQos(rev)['roce']
    return ctx.qos_v1.getRoceSystemConfig()


def qos_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getQos(rev)
    qos = {}
    qos['roce'] = {}
    roce_config = ctx.qos_v1.getRoceSystemConfig()
    qos['roce']['mode'] = roce_config['mode']
    if 'cable-length' in roce_config:
        qos['roce']['cable-length'] = roce_config['cable-length']
    return qos


def qos_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"qos": body})
    return root.get("qos", {})


def qos_roce_patch(ctx, rev, body=None):
    qos = qos_patch(ctx, rev, {"roce": body})
    return qos.get("roce", {})


def qos_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getQos,
                             ctx.config_v1.setQos, rev)


def qos_roce_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getQos,
                             ctx.config_v1.setQos, rev, "roce")


###############################
# RoCE system status
###############################
def roce_system_pool_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    pool_info = ctx.qos_v1.getRoceSystemPools()
    return pool_info

###############################
# RoCE system configuration
##############################


def qos_roce_config_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)

    # get qos tree here
    qos = ctx.config_v1.getQos("applied")
    roce_mode = qos['roce']
    logger.debug("roce_mode config: %s", roce_mode)
    conf = {}
    conf = ctx.qos_v1.getRoceSystemConfig()
    return conf


def qos_roce_tc_map_config_get(ctx, rev):
    roce_conf = qos_roce_config_get(ctx, rev)
    if 'tc-map' in roce_conf:
        return roce_conf['tc-map']
    else:
        return {}


def qos_roce_dscp_map_config_get(ctx, rev):
    roce_conf = qos_roce_config_get(ctx, rev)
    if 'prio-map' in roce_conf:
        return roce_conf['prio-map']
    else:
        return {}


def qos_roce_pool_map_config_get(ctx, rev):
    roce_conf = qos_roce_config_get(ctx, rev)
    if 'pool-map' in roce_conf:
        return roce_conf['pool-map']
    else:
        return {}
