# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.utils import generate_branch_id


CHANGESET_NAMESPACE = "changeset"
"""
The revision namespace for user-created changeset revisions.
"""


def revisions_get(ctx):
    return ctx.versions_v1.getRevisions()


def revision_get(ctx, revision_id):
    return ctx.versions_v1.getRevision(revision_id)


def revision_patch(ctx, revision_id, state=None, auto_prompt=None,
                   state_controls=None):
    return ctx.versions_v1.updateRevision(
        revision_id, state, auto_prompt=auto_prompt,
        state_controls=state_controls
    )


def revisions_post(ctx):
    branch_creator = ctx.request.get_username()

    # For now, assume we're always creating a "pending" branch from "applied"
    branch_base = "applied"
    branch_name = _gen_branch_name(branch_creator)
    init_state = "pending"

    return ctx.versions_v1.createRevision(
        base_revision_id=branch_base, new_branch_name=branch_name,
        init_state=init_state)


def _gen_branch_name(username):
    """
    Generate a unique, but somewhat meaningful branch name.

    Each user-generated branch name will be namespaced with
    "changeset/{username}/" followed by a timestamp and then 4 random(ish)
    characters.
    """
    rev_name = generate_branch_id()
    return "/".join([CHANGESET_NAMESPACE, username, rev_name])
