# Copyright (C) 2018-2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.service import service_patch


###############################
# DHCP Relays
###############################

def dhcp_relays_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getDhcpRelays(rev)

    return ctx.dhcp_relay_v1.getRelays()


def dhcp_relays_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"dhcp-relay": body})
    return service.get("dhcp-relay", {})


def dhcp_relays_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelays,
                             ctx.config_v1.setDhcpRelays, rev)


def dhcp_relay_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getDhcpRelay(rev, vrf_id)

    return ctx.dhcp_relay_v1.getRelay(vrf_id)


def dhcp_relay_patch(ctx, rev, vrf_id, body=None):
    relays = dhcp_relays_patch(ctx, rev, {vrf_id: body})
    return relays.get(vrf_id, {})


def dhcp_relay_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id)


####################################
# DHCP Relay/server
####################################

def servers_get(ctx, rev, vrf_id):
    if rev != "operational":
        relay = ctx.config_v1.getDhcpRelay(rev, vrf_id)
        return relay["server"]

    relay = ctx.dhcp_relay_v1.getRelay(vrf_id)
    return relay["server"]


def servers_patch(ctx, rev, vrf_id, body=None):
    relay = dhcp_relay_patch(ctx, rev, vrf_id, {"server": body})
    return relay.get("server", {})


def servers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "server")


def server_get(ctx, rev, vrf_id, server_id):
    servers = servers_get(ctx, rev, vrf_id)
    try:
        return servers[server_id]
    except KeyError:
        raise NotFound


def server_patch(ctx, rev, vrf_id, server_id, body=None):
    servers = servers_patch(ctx, rev, vrf_id, {server_id: body})
    return servers.get(server_id, {})


def server_delete(ctx, rev, vrf_id, server_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "server", server_id)


####################################
# DHCP Relay/interface
####################################

def interfaces_get(ctx, rev, vrf_id):
    if rev != "operational":
        relay = ctx.config_v1.getDhcpRelay(rev, vrf_id)
        return relay["interface"]

    relay = ctx.dhcp_relay_v1.getRelay(vrf_id)
    return relay["interface"]


def interfaces_patch(ctx, rev, vrf_id, body=None):
    relay = dhcp_relay_patch(ctx, rev, vrf_id, {"interface": body})
    return relay.get("interface", {})


def interfaces_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "interface")


def interface_get(ctx, rev, vrf_id, interface_id):
    interfaces = interfaces_get(ctx, rev, vrf_id)
    try:
        return interfaces[interface_id]
    except KeyError:
        raise NotFound


def interface_patch(ctx, rev, vrf_id, interface_id, body=None):
    interfaces = interfaces_patch(ctx, rev, vrf_id, {interface_id: body})
    return interfaces.get(interface_id, {})


def interface_delete(ctx, rev, vrf_id, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "interface", interface_id)


####################################
# DHCP Relay/giaddress-interface
####################################

def giaddrintfs_get(ctx, rev, vrf_id):
    if rev != "operational":
        relay = ctx.config_v1.getDhcpRelay(rev, vrf_id)
        return relay["giaddress-interface"]

    relay = ctx.dhcp_relay_v1.getRelay(vrf_id)
    return relay["giaddress-interface"]


def giaddrintfs_patch(ctx, rev, vrf_id, body=None):
    relay = dhcp_relay_patch(ctx, rev, vrf_id, {"giaddress-interface": body})
    return relay.get("giaddress-interface", {})


def giaddrintfs_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "giaddress-interface")


def giaddrintf_get(ctx, rev, vrf_id, interface_id):
    gis = giaddrintfs_get(ctx, rev, vrf_id)
    try:
        return gis[interface_id]
    except KeyError:
        raise NotFound


def giaddrintf_patch(ctx, rev, vrf_id, interface_id, body=None):
    gis = giaddrintfs_patch(ctx, rev, vrf_id, {interface_id: body})
    return gis.get(interface_id, {})


def giaddrintf_delete(ctx, rev, vrf_id, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay,
                             ctx.config_v1.setDhcpRelay, rev, vrf_id,
                             "giaddress-interface", interface_id)
