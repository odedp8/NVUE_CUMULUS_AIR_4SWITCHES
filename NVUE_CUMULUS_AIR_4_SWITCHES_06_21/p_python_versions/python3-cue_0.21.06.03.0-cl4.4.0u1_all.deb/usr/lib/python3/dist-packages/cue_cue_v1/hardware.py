# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue import exceptions


###############################
# Hardware
###############################

def hardware_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getHardware()


###############################
# Components
###############################

def components_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getComponents()


def component_get(ctx, rev, component_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getComponent(component_id)


###############################
# Fans
###############################

def fans_get(ctx, rev, component_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getFans(component_id)


def fan_get(ctx, rev, component_id, fan_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getFan(component_id, fan_id)


###############################
# Ports
###############################

def ports_get(ctx, rev, component_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getPorts(component_id)


def port_get(ctx, rev, component_id, port_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getPort(component_id, port_id)


###############################
# Breakout modes
###############################

def breakout_modes_get(ctx, rev, component_id, port_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getPortBreakoutModes(component_id, port_id)


def breakout_mode_get(ctx, rev, component_id, port_id, mode_id):
    modes = breakout_modes_get(ctx, rev, component_id, port_id)
    try:
        return modes[mode_id]
    except KeyError:
        # The mode is not supported on this port.
        raise exceptions.NotFound


###############################
# Breakout mode speeds
###############################
# TODO: CUE-3123

# def breakout_mode_speeds_get(ctx, rev, component_id, port_id, mode_id):
#     mode = breakout_mode_get(ctx, rev, component_id, port_id, mode_id)
#     return mode["speed"]
#
#
# def breakout_mode_speed_get(ctx, rev, component_id, port_id, mode_id,
#                             speed_id):
#     speeds = breakout_mode_speeds_get(
#                   ctx, rev, component_id, port_id, mode_id)
#     try:
#         return speeds[speed_id]
#     except KeyError:
#         # The speed is not supported on this mode.
#         raise exceptions.NotFound
