# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue import exceptions
from .revman import UnknownRevisionError, get_revman


def files_get(ctx, rev_id):
    files = {}

    try:
        with get_revman(ctx, rev_id) as revman:
            for entry in revman.list_files():
                st = entry.stat()
                files[entry.name] = {
                    "size": st.st_size,
                    "mtime": st.st_mtime
                }
    except UnknownRevisionError:
        raise exceptions.NotFound(description="Unknown revision: " + rev_id)

    return files


def file_get(ctx, rev_id, file_id):
    try:
        with get_revman(ctx, rev_id) as revman:
            st = revman.stat_file(file_id)
            return {
                "size": st.st_size,
                "mtime": st.st_mtime
            }
    except UnknownRevisionError:
        raise exceptions.NotFound(description="Unknown revision: " + rev_id)
    except FileNotFoundError:
        raise exceptions.NotFound(description="Unknown file: " + file_id)


def file_raw_get(ctx, rev_id, file_id):
    try:
        with get_revman(ctx, rev_id) as revman:
            return revman.load_file(file_id)
    except UnknownRevisionError:
        raise exceptions.NotFound(description="Unknown revision: " + rev_id)
    except FileNotFoundError:
        raise exceptions.NotFound(description="Unknown file: " + file_id)


def file_raw_put(ctx, rev_id, file_id, contents):
    try:
        with get_revman(ctx, rev_id) as revman:
            revman.start_write("Saving " + file_id)
            revman.save_file(file_id, contents)
    except UnknownRevisionError:
        raise exceptions.NotFound(description="Unknown revision: " + rev_id)

    return file_get(ctx, rev_id, file_id)
