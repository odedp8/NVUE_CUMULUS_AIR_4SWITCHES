# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue.states import TransitionError
from cue.events import AbstractEvent
from .revman import get_revman
import logging
from pydash import py_


logger = logging.getLogger(__name__)


# Defaults for rev_meta.
rev_meta_defaults = {
    "state": "inactive",
    "transition": {
        "progress": "",
        "issue": {}
    }
}


def _filled_rev(raw_rev_meta):
    return py_.defaults_deep({}, raw_rev_meta, rev_meta_defaults)


def _migrate_issues(rev):
    """
    Migrate 'issues: []' to 'issue: {}'.  We used an array originally and
    migrated to a collection, like all the rest of CUE.  Rather than force QA
    and dev to rebuild their systems, we'll do a simple migration here.  This
    can be removed after summer 2021.  Also, remove startup_old and
    pending_xyz_old references.
    """
    if "issues" in rev["transition"]:
        issues = rev["transition"]["issues"]
        del rev["transition"]["issues"]
        rev["transition"]["issue"] = {
            str(issue_num): issue
            for issue_num, issue in enumerate(issues)
        }


def revisions_get(ctx):
    raw_rev_metas = ctx.versions_v1._repo.get_revisions()

    # Fill in any missing fields with defaults and return.
    revs = py_.map_values(raw_rev_metas, _filled_rev)

    for rev in revs.values():
        _migrate_issues(rev)

    return revs


def revision_get(ctx, revision_id):
    raw_rev_meta = ctx.versions_v1._repo.get_revision(revision_id)
    if raw_rev_meta is None:
        raise NotFound
    else:
        rev = _filled_rev(raw_rev_meta)
        _migrate_issues(rev)
        return rev


def revision_patch(ctx, revision_id, state=None, auto_prompt=None,
                   state_controls=None):
    if state is not None:
        set_revision_state(ctx, revision_id, state, auto_prompt=auto_prompt,
                           state_controls=state_controls)

    # Always return the updated object
    return revision_get(ctx, revision_id)


def revisions_post(ctx, base_revision_id, new_branch_name, init_state):
    with ctx.versions_v1._repo.get_revman(base_revision_id) as revman:
        revman.start_branch(new_branch_name)

    # Update the branch's meta so it's an "interesting" branch.  Start with the
    # defaults.
    meta = revision_get(ctx, new_branch_name)
    meta["state"] = init_state
    ctx.versions_v1._repo.write_revision_metadata(new_branch_name, meta)

    # Always return the new object
    return {new_branch_name: meta}


class RevisionStateEvent(AbstractEvent):
    """
    Event object for a revision state change.
    """
    def __init__(self, ctx, rev_id, old_state, new_state, auto_prompt=None,
                 state_controls=None):
        """
        Create an event object around the given global context and a rev_id.
        """
        self.ctx = ctx
        self.rev_id = rev_id
        self.old_state = old_state
        self.new_state = new_state
        self.auto_prompt = auto_prompt
        self.state_controls = state_controls

    def progress(self, new_state, progress="", issues=None):
        """
        Change the revision to yet another state, indicating progress or
        completion of a task.

        It may be called multiple times to indicate progress through the task.
        The progress and issues fields are optional.
        """
        set_revision_state(
            self.ctx,
            self.rev_id,
            new_state,
            progress,
            issues,
            auto_prompt=self.auto_prompt,
        )

    def get_revman(self, rev_id):
        """
        Return a revision manager for the given rev_id.
        """
        return get_revman(self.ctx, rev_id)


def set_revision_state(
    ctx, rev_id, new_state, progress="", issues=None, auto_prompt=None,
    state_controls=None
):
    """
    Set a revision's state, progress message, or list of issues.  Then, fire
    the revision_state event.
    """
    logger.dump("Set state", rev_id, new_state, progress, issues, auto_prompt)

    # Normalize issues into an array.
    if issues is None:
        issues = []

    # Get the old state
    meta = revision_get(ctx, rev_id)
    old_state = meta["state"]

    # Build the new set of issues
    new_issues = {
        str(issue_num): issue.as_dict()
        for issue_num, issue in enumerate(issues)
    }

    def _persist_metadata():
        meta["state"] = new_state
        meta["transition"]["progress"] = progress
        meta["transition"]["issue"] = new_issues
        ctx.versions_v1._repo.write_revision_metadata(rev_id, meta)

    # If the states are the same, it might be just a metadata update.
    if old_state == new_state:
        # If the metadata has indeed changed, persist it.
        if (meta["transition"]["progress"] != progress
                or meta["transition"]["issue"] != new_issues):
            _persist_metadata()

        # Since clients aren't interested in metadata changes, we can return.
        return

    # Make sure it's a valid transition.
    try:
        ctx.versions_v1.validate_transition(old_state, new_state)
    except TransitionError as err:  # EARLY RETURN
        # Attempting an invalid transition is a noop, not an error. It's pretty
        # easy to "double tap" a transition. Doing so should not be treated as
        # an error, since the user's intention is already being acted upon.
        # We'll log what happened and bail before doing anything.
        logger.dump("Not transitioning", rev_id, str(err))
        return

    # Now that we know it's a good transition, persist the change.
    _persist_metadata()

    # Let clients know we set the state.  However, only one client should
    # actually do something.  But we want to be loosely coupled with that
    # client, so we're using an event model.
    evt = RevisionStateEvent(ctx, rev_id, old_state, new_state, auto_prompt,
                             state_controls)
    ctx.events.revision_state(evt)
