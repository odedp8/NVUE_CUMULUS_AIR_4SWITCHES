# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue import config
from pathlib import Path


class UnknownRevisionError(FileNotFoundError):
    pass


class BadBranchNameError(FileExistsError):
    pass


class RevManager(object):
    """
    Fetch revisions inside a "with" block.
    """

    def __init__(self, ctx, root):
        """
        Create a new revision manager for the given rev_id.
        """
        self.ctx = ctx
        self.root = Path(root)

    def start_write(self, commit_msg):
        """
        Prepare to write, optionally using the given commit_msg.
        """

    def start_branch(self, branch_name):
        """
        Start a new branch from this one, using the given branch_name, and
        switch to it.
        """

    def merge_branch(self, branch_name, commit_msg):
        """
        Merge another branch, identified by branch_name, into this one, using
        the given commit_msg.
        """

    def create_tag(self, tag_name, target=None):
        """
        Create a tag with `tag_name` on `target`.
        """

    def stat_file(self, filename):
        """
        Given a relative path, stat() the file and return an os.stat_result
        object.
        """
        return self.ctx.fileops.stat_file(self._abs_path(filename))

    def file_exists(self, filename):
        """
        Given a relative path, return True if the file exists, otherwise,
        False.
        """
        return self.ctx.fileops.file_exists(self._abs_path(filename))

    def load_file(self, filename):
        """
        Given a relative path, open() the file and return it's contents.
        """
        return self.ctx.fileops.load_file(self._abs_path(filename))

    def save_file(self, filename, contents):
        """
        Given a relative filename or Path, save the contents to it.  We'll
        stream contents into a tmp file first, then move it into place, so the
        operation is atomic.

        contents can be a single object or an iterable of objects.  If an
        iterable, each object will be written in turn.  All objects are
        stringified before writing.
        """
        self.ctx.fileops.save_file(self._abs_path(filename), contents)

    def zero_file(self, filename):
        """
        Convenience method to create a zero byte file or truncate an existing
        file.

        This is equivalent to save_file(filename, "").
        """
        self.ctx.fileops.zero_file(self._abs_path(filename))

    def remove_file(self, filename):
        """
        Given a relative filename or Path, remove it.
        """
        self.ctx.fileops.remove_file(self._abs_path(filename))

    def append_file(self, filename, contents):
        """
        Given a relative filename or Path, append the contents to it.

        contents can be a single object or an iterable of objects.  If an
        iterable, each object will be written in turn.  All objects are
        stringified before writing.
        """
        self.ctx.fileops.append_file(self._abs_path(filename), contents)

    def run_file(self, filename, shell):
        """
        Given a relative filename, run it using shell.  shell is a callback and
        will be passed the absolute path to filename.

        If the file does not exist, a FileNotFoundError is raised.
        """
        # Verify the file exists before we try to run it.
        self.stat_file(filename)
        # Now that we know it exists, run it.
        shell(self._abs_path(filename))

    def list_files(self):
        """
        scandir() the root and return an iterator of os.DirEntry.  Only
        non-hidden files will be returned.
        """
        return self.ctx.fileops.list_files(self.root)

    def copy_file_out(self, filename, abs_dst, chown, chmod):
        """
        Copy a file "out" of the revision manager and to an absolute path.  It
        is assumed this must be done with sudo and needs to be chown'd and
        chmod'd.

        The file is copied to abs_dst.part first, then moved atomically into
        place.
        """
        abs_dst = Path(abs_dst)
        abs_dst_tmp = abs_dst.with_suffix(abs_dst.suffix + ".part")

        # Copy, then move
        self.ctx.fileops.copy_file(self._abs_path(filename), abs_dst_tmp,
                                   sudo=True, chown=chown, chmod=chmod)
        self.ctx.fileops.move_file(abs_dst_tmp, abs_dst, sudo=True)

    def copy_file_in(self, abs_src, filename):
        """
        Copy a file, `abs_src`, "in" to the revision manager from an absolute
        path.  It is assumed this must be done with sudo.  Permissions will be
        set appropriately so the cue user can access the destination file.

        If `abs_src` does not exist, a `FileNotFoundError` is raised.
        """
        try:
            self.ctx.fileops.copy_file(abs_src, self._abs_path(filename))
        except PermissionError:
            # Try again as root.
            chown = config.RUNTIME_USER + "."
            self.ctx.fileops.copy_file(abs_src, self._abs_path(filename),
                                       sudo=True, chown=chown, chmod="0644")

    def _abs_path(self, filename):
        """
        Given a relative filename, return the absolute path by prefixing
        this revman's root.
        """
        return self.root / filename


def get_revman(ctx, rev_id):
    # Look for special revisions and redirect appropriately.  By default, look
    # for the rev in the repo.
    if rev_id == "startup":
        return ctx.versions_v1._startup.get_revman()
    elif rev_id == "empty":
        return ctx.versions_v1._empty.get_revman()
    else:
        return ctx.versions_v1._repo.get_revman(rev_id)
