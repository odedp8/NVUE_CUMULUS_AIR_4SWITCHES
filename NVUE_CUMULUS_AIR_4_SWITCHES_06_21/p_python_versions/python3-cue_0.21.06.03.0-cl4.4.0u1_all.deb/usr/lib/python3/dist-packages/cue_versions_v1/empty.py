# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


class EmptyImpl:
    """
    Implementation class for 'empty'.

    It tells callers not to use the implementation for 'empty'.
    """

    def get_revman(self):
        """
        No revman activities are allowed for 'empty'. This is an error.
        """
        raise NotImplementedError("'empty' does not abide the revman.")


def prepare_empty(ctx):
    """
    Attach the 'empty' implementation somewhere we can get at it.
    """
    # Create the _empty implementation.
    ctx.versions_v1._empty = EmptyImpl()
