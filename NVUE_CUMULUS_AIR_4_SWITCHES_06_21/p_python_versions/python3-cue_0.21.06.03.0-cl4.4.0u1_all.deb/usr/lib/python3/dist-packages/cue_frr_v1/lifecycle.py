# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates
from . import native
import logging
import re
from pydash import py_
from cue import utils, exceptions, issues

from .auto_bgp import generate_auto_bgp_asn
from cue.utils import format_checker as check

logger = logging.getLogger(__name__)


class FrrRestartRequiredWarning(issues.DisruptiveRestartRequiredWarning):
    """
    FRR will need to be restarted to apply this config.
    """
    def __init__(self, reason):
        super().__init__("frr", reason)


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("frr_v1", handle_verify_config)
    ctx.events.ready_apply.register("frr_v1", handle_ready_apply)
    ctx.events.check_health.register("frr_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.
    """


def inherit_bgp_timers(root):
    """
    Squash the "auto" values in bgp peer timers by inheriting from the instance
    values.
    """
    # Loop through each VRF, skipping if BGP isn't enabled.
    for vrf in root["vrf"].values():
        if vrf["router"]["bgp"]["enable"] == "on":
            vrf_timers = vrf["router"]["bgp"]["timers"]
            for peer in vrf["router"]["bgp"]["peer"].values():
                utils.auto_inherit(peer["timers"], vrf_timers)
            for group in vrf["router"]["bgp"]["peer-group"].values():
                utils.auto_inherit(group["timers"], vrf_timers)


def inherit_ospf_timers(root):
    """
    Squash the "auto" values in ospf timers by inheriting from the root
    values.
    """
    if root["router"]["ospf"]["enable"] == "on":
        root_timers = root["router"]["ospf"]["timers"]

        # Loop through each VRF, skipping if OSPF isn't enabled.
        for vrf in root["vrf"].values():
            if vrf["router"]["ospf"]["enable"] == "on":
                utils.auto_inherit(vrf['router']['ospf']['timers'],
                                   root_timers)
                utils.auto_inherit(vrf['router']['ospf']['timers']['lsa'],
                                   root_timers['lsa'])
                utils.auto_inherit(vrf['router']['ospf']['timers']['spf'],
                                   root_timers['spf'])


def set_static_route_nexthop_vrf(evt, root):
    """
    Patch up the nexthop vrf where we can derive it.
    """
    def set_via_vrf(vrf_name, vias):
        """
        If this is an interface via and the interface is in a different vrf,
        set the route's vrf so that FRR knows.
        """
        for via_name, via in vias.items():
            if via["type"] == "interface":
                try:
                    iface = evt.config_v1.getInterface(via_name)
                    if iface["ip"]["vrf"] != vrf_name:
                        via["vrf"] = iface["ip"]["vrf"]
                except exceptions.NotFound:
                    pass

    # Find all the vias and call set_via_vrf() on each.
    for vrf_name, vrf in root["vrf"].items():
        for route in vrf["router"]["static"].values():
            set_via_vrf(vrf_name, route["via"])
            for distance in route["distance"].values():
                set_via_vrf(vrf_name, distance["via"])


def set_auto_bgp_asn(evt, root):
    """
    If the autoBGP 'leaf' or 'spine' values are configured, patch up the
    ASN with the auto generated values.
    """
    def replace_auto_bgp_asn(evt, base):
        asn_config = py_.get(base, "router.bgp.autonomous-system")
        # replace the 'leaf'/'spine' asn in the config with the generated one
        if asn_config is not None and asn_config in ('leaf', 'spine'):
            asn = generate_auto_bgp_asn(evt, asn_config)
            py_.set(base, "router.bgp.autonomous-system", asn)

    # Check the global asn config for autoBGP leaf/spine values and replace
    # with an auto generated ASN.
    replace_auto_bgp_asn(evt, root)

    # Check the asn config in the vrf context for autoBGP leaf/spine config
    # and replace with an auto generated ASN.
    if 'vrf' in root:
        for _, vrf in root["vrf"].items():
            replace_auto_bgp_asn(evt, vrf)


def has_asn_changed(running_config, root):
    """
    Returns true if this apply wants to change the ASN on the default VRF in a
    way that requires a restart.
    """
    found_non_default = False
    found_default_changed = False

    # Look for VRFs
    for instance in re.finditer(r'router +bgp +(\d+)( +vrf +(.*))?$',
                                running_config, re.MULTILINE):
        running_asn = int(instance.group(1))

        # Get the VRF name
        vrf = instance.group(3)
        if vrf is not None:
            # This is a non-default VRF.  Remember that we found one.
            found_non_default = True
        else:
            # This is the default VRF.  See if it's ASN has changed.
            vrf = "default"

            if vrf not in root["vrf"]:
                # This VRF is no longer in the desired config.
                # So, it doesn't matter what it's ASN is.
                continue

            if root["vrf"][vrf]["router"]["bgp"]["enable"] == "on":
                # Dig out the desired ASN
                asn = root["vrf"][vrf]["router"]["bgp"]["autonomous-system"]
                if asn == "auto":
                    asn = root["router"]["bgp"]["autonomous-system"]

                # Do we have an ASN change?
                if running_asn != asn:
                    found_default_changed = True

    return (found_default_changed and found_non_default)


def has_default_removed(running_config, root):
    """
    Returns true if this apply wants to remove the default VRF.
    """
    # Look for the default instance
    if re.search(r'router bgp (\d+)$', running_config, re.MULTILINE):
        # default is immutable.  So, just check to see if it's off.
        if root["vrf"]["default"]["router"]["bgp"]["enable"] == "off":
            # The default instance is running, but desired to be off.
            return True

    return False


def _get_frr_running_config(ctx):
    running = native.running_config_get(ctx)
    return running


def _stage_frr_conf(evt):
    return evt.stage_file("frr.conf", "/etc/frr/frr.conf")


def _stage_frr_daemons(evt):
    return evt.stage_file("frr-daemons", "/etc/frr/daemons")


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.
    """
    snippets = evt.config_v1.getSnippets()
    frr_conf_snippet = snippets.get("frr.conf", "")
    frr_daemons = snippets.get("frr-daemons", "")
    frr_daemons_append = snippets.get("frr-daemons-append", "")

    if frr_daemons_append:
        frr_daemons_append = "\n# Snippet overrides\n" + frr_daemons_append

    root = {
        "nve": {
            "vxlan": evt.config_v1.getNveVxlan()
        },
        "vrf": evt.config_v1.getVrfs(),
        "evpn": evt.config_v1.getEvpn(),
        "router": evt.config_v1.getRouter(),
        "interface": evt.config_v1.getInterfaces(),
        "system": evt.config_v1.getSystem()
    }

    inherit_bgp_timers(root)
    inherit_ospf_timers(root)
    set_static_route_nexthop_vrf(evt, root)

    set_auto_bgp_asn(evt, root)

    def frr_daemons_to_enable(root):
        daemons = set()

        if root["router"]["bgp"]["enable"] == "on":
            daemons.add('bgpd')
        if root["router"]["ospf"]["enable"] == "on":
            daemons.add('ospfd')
#        if root["router"]["ospf6"]["enable"] == "on":
#            daemons.add('ospf6d')
        if root["router"]["pbr"]["enable"] == "on":
            daemons.add('pbrd')
#        if root["router"]["pim"]["enable"] == "on":
#            daemons.add('pimd')
#        if root["router"]["vrrp"]["enable"] == "on":
#            daemons.add('vrrpd')

        return daemons

    def postprocess(rendered):
        """
        Completely remove insignificant whitespace.
        """
        text = rendered
        text = re.sub(r"\s+$", "", "".join(list(text)), flags=re.MULTILINE)
        text = re.sub(r"$\s+", "\n", "".join(list(text)), flags=re.MULTILINE)
        text += '\n'
        return text

    # Generate /etc/frr/frr.conf
    frr_conf = evt.render(
        templates,
        template_name="frr.conf",
        snippet=frr_conf_snippet,
        root=root,
        py_=py_,
        check=check
    )
    frr_conf = postprocess(frr_conf)
    evt.save("frr.conf", frr_conf)

    # Generate /etc/frr/daemons
    evt.render(
        templates,
        "frr-daemons",
        frr_daemons=frr_daemons,
        frr_daemons_append=frr_daemons_append,
        daemons=frr_daemons_to_enable(root),
    )

    conf_staged = _stage_frr_conf(evt)
    daemons_staged = _stage_frr_daemons(evt)

    conf_running = _get_frr_running_config(evt)
    cached_conf = None
    try:
        cached_conf = evt.load("vtysh_run.conf")
    except Exception:
        logger.info(("vtysh_run.conf could not be loaded.  This could be "
                     "the first time running frr_v1 lifecycle."))

    if daemons_staged:
        evt.report_warning(
            FrrRestartRequiredWarning(
                'the list of router services has changed')
        )
        evt.schedule_restart('frr')
    elif has_asn_changed(conf_running, root):
        evt.report_warning(
            FrrRestartRequiredWarning('a bgp autonomous-system has changed'))
        evt.schedule_restart('frr')
    elif has_default_removed(conf_running, root):
        evt.report_warning(
            FrrRestartRequiredWarning('the default instance has been removed'))
        evt.schedule_restart('frr')
    elif conf_staged:
        evt.schedule_reload_or_restart("frr")
    elif not conf_running or conf_running != cached_conf:
        logger.info(("Running frr conf differs from cached configuration."
                     " Scheduling reload/restart of frr"))
        evt.schedule_reload_or_restart("frr")

    evt.save("vtysh_run.conf", conf_running)


def handle_check_health(evt):
    """
    Handle an check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
