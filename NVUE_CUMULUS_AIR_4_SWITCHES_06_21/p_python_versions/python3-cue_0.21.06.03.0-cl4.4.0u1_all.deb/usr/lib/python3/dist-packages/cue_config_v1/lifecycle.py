# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import schema, repo, startup
from . import apply_config, save_config
from pydash import py_
from cue import issues


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    schema.prepare_schema(ctx)
    repo.prepare_repo(ctx)
    startup.prepare_startup(ctx)
    ctx.events.revision_state.register("config_v1", handle_revision_state)
    ctx.events.verify_config.register("config_v1", handle_verify_config)
    ctx.events.init_revision_transitions.register(
        "config_v1", handle_init_revision_transitions
    )
    ctx.events.cleanup_revisions.register(
        "config_v1", handle_cleanup_revisions
    )


def handle_init_revision_transitions(evt):
    apply_config.handle_init_revision_transitions(evt)
    save_config.handle_init_revision_transitions(evt)


def handle_cleanup_revisions(evt):
    apply_config.handle_cleanup_revisions(evt)
    save_config.handle_cleanup_revisions(evt)


def handle_revision_state(evt):
    apply_config.handle_revision_state(evt)
    save_config.handle_revision_state(evt)


class Feature:
    """
    The Feature class captures the relationship between a feature, which is
    represented as a deep path in the config tree, and its dependencies (also
    deep paths).

    It has two primary function:
        check_enabled: checks if a feature is enabled.
        verify: if enabled, verify that a features dependencies are satisfied.
    """
    def __init__(self, feature, dependencies, enabled_ext=''):
        """
        Args:
            feature - A deep path string to the feature object.  Collection
                items are represented with brackets.
                Ex. 'interface.{}.ip.vrr'
            dependencies - A list of deep paths corresponding to dependency.
                properties.  Lists within the list will be treated as "one of".
                Ex. [ 'interface.peerlink.bond.member',
                      [ 'system.global.anycast-id',
                        'system.global.anycast-mac',
                        'mlag.mac-address'
                      ]
                    ]
            enabled_ext - Extension to the 'feature' deep path used to check if
                the feature is enabled.
                Ex. If the 'feature' is "mlag" and 'enabled_ext' is "backup",
                    then the deep path "mlag.backup" will be checked for
                    existence & !none.
        """
        self.feature = feature
        self.dependencies = dependencies
        self.enabled_path = feature if not enabled_ext else \
            f"{feature}.{enabled_ext}"

    def verify(self, evt):
        """
        Verify that all of the feature's dependencies are configured

        Reports 1 or more issues if there are dependencies missing.
        In the case of a collection, the first collection item for
        which the error was found will be used to report the issue.

        Args:
            evt - the verify_config event.
        """
        root = evt.config_v1.getRoot()
        enabled, collection_item = self.check_enabled(root)
        if enabled:
            feat_str = self.feature.format(collection_item).replace('.', ' ')
            for dep in self.dependencies:
                # If dep is a list then there are multiple config options.
                # I.e. mlag's mac-address can come from global.anycast-id,
                # global.anycast-mac, and mlag.mac-address
                if type(dep) == list:
                    dep_configured = False
                    dep_str = ""
                    for property_path in dep:
                        property_path = property_path.format(collection_item)
                        dep_val = py_.get(root,
                                          property_path.format(
                                              collection_item
                                          ))
                        # The check for 'auto' is to handle properties such as
                        # mlag mac-address, which is an override for the
                        # anycast-mac.
                        # Its default is auto, in which case we're relying on
                        # the anycast-mac.  I imagine this paradigm will pop up
                        # elsewhere in such cases where the feature has a
                        # dependency that can be configured in several ways.
                        if dep_val and dep_val != 'auto' and dep_val != 'none':
                            dep_configured = True
                            break
                        dep_str += (f"\t"
                                    f"'{property_path.replace('.', ' ')}'"
                                    f"\n")
                    if not dep_configured:
                        # TODO: These errors should be an Issue class that
                        # includes the feature, dependency data as well as an
                        # error message
                        evt.report_issue(
                            (f"'{feat_str}' requires one of the following "
                             f"to be configured:\n"
                             f"{dep_str}"))
                else:
                    dep = dep.format(collection_item)
                    dep_val = py_.get(root, dep)
                    if not dep_val or dep_val == 'none':
                        evt.report_issue(
                            (f"'{feat_str}' requires '{dep.replace('.', ' ')}'"
                             " to be configured."))

    def check_enabled(self, root):
        """
        Check if the feature is enabled.

        Uses the '{feature}.{enabled_ext}' to check if the feature is enabled.

        Args:
            root - The root of the CUE config.
        """
        enabled_val = py_.get(root, self.enabled_path)
        enabled = True if enabled_val and enabled_val != 'none' else False
        return enabled, None


class VrrFeature(Feature):
    def __init__(self):
        feat = 'interface.{}.ip.vrr'
        deps = [
            [
                'system.global.anycast-id',
                'system.global.anycast-mac',
                'interface.{}.ip.vrr.mac-id',
                'interface.{}.ip.vrr.mac-address'
            ]
        ]
        super().__init__(feat, deps)

    def check_enabled(self, root):
        """
        Override Feature's 'check_enabled' to check each svi's 'ip.vrr.state'.
        """
        for iface, config in root['interface'].items():
            state = py_.get(config, 'ip.vrr.state')
            if (state
                and 'up' in state
                    and config.get('type') == 'svi'):
                return (True, iface)
        return (False, None)


FEATURES = [Feature('mlag',
                    [
                        'interface.peerlink.bond.member',
                        'mlag.backup',
                        [
                            'system.global.anycast-id',
                            'system.global.anycast-mac',
                            'mlag.mac-address'
                        ],
                    ],
                    'backup'),
            VrrFeature()]


def handle_verify_config(evt):
    """
    Handle a verify_config event.
    """
    for feature in FEATURES:
        feature.verify(evt)

    # Special Handling
    interfaces = evt.config_v1.getInterfaces()
    vrfs = evt.config_v1.getVrfs()
    bridges = evt.config_v1.getBridge()
    router = evt.config_v1.getRouter()
    _verify_vxlan(evt, interfaces)
    _verify_peerlink_sub(evt, interfaces)
    _verify_route_map(evt, interfaces)
    _verify_prefix_list(evt, interfaces)
    _verify_vni(evt, vrfs, bridges)
    _verify_bgp_instances(evt, vrfs)
    _verify_bgp_convergence_wait(evt, router)


def _verify_peerlink_sub(evt, interfaces):
    # TODO CUE-3667: This should be handled by mlag Feature,
    # but Feature needs to be refactored to support
    # list paths.
    mlag = evt.config_v1.getMlag()
    if (py_.get(mlag, 'backup')
            and not py_.get(interfaces, ['peerlink.4094'])):
        evt.report_issue(("'mlag' requires 'interface peerlink.4094'"
                         " to be configured."))


class MissingVxlanAddress(issues.BadInputIssue):
    """
    We can't find a VXLAN address to use.
    """
    def __init__(self):
        super().__init__("missing_vxlan_address")

    def _render_message(self):
        return ('Loopback address required when vxlan address is "auto"')


def _verify_vxlan(evt, interfaces):
    """
    Verify VXLAN Configuration
    """
    vxlan = evt.config_v1.getNveVxlan()

    if vxlan["enable"] == "on":
        if "auto" in vxlan["source"]["address"]:
            # Make sure we have a loopback address we can use for auto.
            addresses = interfaces["lo"]["ip"]["address"].keys()
            got_one = next(filter(
                lambda addr: (addr != "127.0.0.1/8" and addr != "::1/128"),
                addresses), None)

            if not got_one:
                evt.report_issue(MissingVxlanAddress())


class InvalidRouteMapSourceIp(issues.BadInputIssue):
    """
    We found non-unique distances in a route.
    """
    def __init__(self, rmap_name, addr):
        super().__init__("invalid_source_ip")
        self.data["rmap_name"] = rmap_name
        self.data["addr"] = addr

    def _render_message(self):
        fmt = (
            "Source IP {addr} in route map {rmap_name} does not match"
            " with any interface IP address"
        )
        return fmt.format(**self.data)


def _verify_route_map(evt, interfaces):
    """
    Verify route map Configuration
    """
    router = evt.config_v1.getRouter()
    route_maps = py_.get(router, "policy.route-map")
    if not route_maps:
        return
    # iterate through all the route maps
    for rmap_name, rmap in route_maps.items():
        try:
            for _rule_id, rule in py_.get(rmap, "rule").items():
                if "set" in rule and "source-ip" in rule["set"]:
                    for _if_name, intf in interfaces.items():
                        for address in py_.get(intf, "ip.address").keys():
                            parts = address.split("/", 1)
                            if len(parts) != 2:
                                continue
                            addr, prefix = parts
                            if rule["set"]["source-ip"] == addr:
                                raise StopIteration
                    # We didn't find a interface IP address that matches
                    # source IP
                    evt.report_issue(InvalidRouteMapSourceIp(
                        rmap_name, rule["set"]["source-ip"]))
                    return
        except StopIteration:
            continue


class DuplicateVNI(issues.BadInputIssue):
    """
    We found a duplicate VNI.
    """
    def __init__(self, instance, name, vni):
        super().__init__("duplicate_vni")
        self.data["instance"] = instance
        self.data["name"] = name
        self.data["vni"] = vni

    def _render_message(self):
        fmt = (
            "VNI {vni} configured for {instance} {name} already in use"
        )
        return fmt.format(**self.data)


def _check_duplicate_vni(vrfs, domains, vni):
    exists = 0
    for _br_name, bridge in domains.items():
        vlan = py_.get(bridge, "vlan")
        if vlan:
            for _vlan_id, vlan in vlan.items():
                vnis = py_.get(vlan, "vni")
                if vnis:
                    for local_vni, _data in vnis.items():
                        if vni == local_vni:
                            exists = exists + 1
    for _vrf_name, vrf in vrfs.items():
        vnis = py_.get(vrf, "evpn.vni")
        if vnis:
            for local_vni, _data in vnis.items():
                if vni == local_vni:
                    exists = exists + 1
    if exists > 1:
        return True
    else:
        return False


def _verify_vni(evt, vrfs, bridges):
    """
    Verify vni Configuration
    """
    domains = bridges["domain"]

    # iterate through all the bridges
    for br_name, bridge in domains.items():
        vlan = py_.get(bridge, "vlan")
        if vlan:
            for _vlan_id, vlan in vlan.items():
                vnis = py_.get(vlan, "vni")
                if vnis:
                    for vni, _data in vnis.items():
                        if vni == "auto":
                            continue
                        if _check_duplicate_vni(vrfs, domains, vni):
                            # We found a duplicate VNI
                            evt.report_issue(DuplicateVNI("bridge", br_name,
                                                          vni))
                            return
    for vrf_name, vrf in vrfs.items():
        vnis = py_.get(vrf, "evpn.vni")
        if vnis:
            for vni, _data in vnis.items():
                if _check_duplicate_vni(vrfs, domains, vni):
                    # We found a duplicate VNI
                    evt.report_issue(DuplicateVNI("vrf", vrf_name, vni))
                    return


class DuplicateDistanceIssue(issues.BadInputIssue):
    """
    We found non-unique distances in a route.
    """
    def __init__(self, vrf_name, prefix):
        super().__init__("dup_distance")
        self.data["vrf_name"] = vrf_name
        self.data["prefix"] = prefix

    def _render_message(self):
        fmt = (
            "Each path requires a unique distance in "
            "`vrf {vrf_name} router static {prefix}`"
        )
        return fmt.format(**self.data)


class InvalidPrefixListMatchLen(issues.BadInputIssue):
    """
    We found invalid prefix length match condition
    """
    def __init__(self, plist_name, rule_id, match_id, min_len, max_len):
        super().__init__("invalid_prefix_list_len")
        self.data["plist_name"] = plist_name
        self.data["rule_id"] = rule_id
        self.data["match_id"] = match_id
        self.data["max_len"] = max_len
        self.data["min_len"] = min_len

    def _render_message(self):
        fmt = (
            "Prefix list {plist_name} rule {rule_id} prefix {match_id}"
            " min {min_len} length is greater than max {max_len} length"
        )
        return fmt.format(**self.data)


class InvalidPrefixListMaxLen(issues.BadInputIssue):
    """
    We found invalid prefix length match condition
    """
    def __init__(self, plist_name, rule_id, match_id, max_len):
        super().__init__("invalid_prefix_list_max_len")
        self.data["plist_name"] = plist_name
        self.data["rule_id"] = rule_id
        self.data["match_id"] = match_id
        self.data["max_len"] = max_len

    def _render_message(self):
        fmt = (
            "Prefix list {plist_name} rule {rule_id} prefix {match_id}"
            " max {max_len} length is less than prefix mask"
        )
        return fmt.format(**self.data)


class InvalidPrefixListMinLen(issues.BadInputIssue):
    """
    We found invalid prefix length match condition
    """
    def __init__(self, plist_name, rule_id, match_id, min_len):
        super().__init__("invalid_prefix_list_min_len")
        self.data["plist_name"] = plist_name
        self.data["rule_id"] = rule_id
        self.data["match_id"] = match_id
        self.data["min_len"] = min_len

    def _render_message(self):
        fmt = (
            "Prefix list {plist_name} rule {rule_id} prefix {match_id}"
            " min {min_len} length is less than or equal to prefix mask"
        )
        return fmt.format(**self.data)


def _verify_prefix_list(evt, interfaces):
    """
    Verify prefix list Configuration
    """
    router = evt.config_v1.getRouter()
    prefix_lists = py_.get(router, "policy.prefix-list")
    if not prefix_lists:
        return

    # iterate through all the Prefix lists
    for plist_name, plist in prefix_lists.items():
        for rule_id, rule in py_.get(plist, "rule").items():
            match = rule["match"]
            match_id = list(match.keys())[0]
            if "min-prefix-len" in match[match_id] and \
               "max-prefix-len" in match[match_id]:
                if match[match_id]["min-prefix-len"] > \
                   match[match_id]["max-prefix-len"]:
                    evt.report_issue(InvalidPrefixListMatchLen(
                        plist_name, rule_id, match_id,
                        match[match_id]["min-prefix-len"],
                        match[match_id]["max-prefix-len"]))
                    return
            if "max-prefix-len" in match[match_id]:
                parts = match_id.split("/", 1)
                if len(parts) != 2:
                    continue
                addr, prefix = parts
                if match[match_id]["max-prefix-len"] < int(prefix):
                    evt.report_issue(InvalidPrefixListMaxLen(
                        plist_name, rule_id, match_id,
                        match[match_id]["max-prefix-len"]))
                    return
            if "min-prefix-len" in match[match_id]:
                parts = match_id.split("/", 1)
                if len(parts) != 2:
                    continue
                addr, prefix = parts
                if match[match_id]["min-prefix-len"] <= int(prefix):
                    evt.report_issue(InvalidPrefixListMinLen(
                        plist_name, rule_id, match_id,
                        match[match_id]["min-prefix-len"]))
                    return


class MissingRemoteAs(issues.BadInputIssue):
    """
    We need a remote-as for a bgp peer.
    """
    def __init__(self, vrf_name, peer):
        super().__init__("missing_remote_as")
        self.data["vrf_name"] = vrf_name
        self.data["peer"] = peer

    def _render_message(self):
        fmt = (
            "`remote-as` must be set in "
            "`vrf {vrf_name} router bgp peer {peer}` "
            "or in the peer's peer-group"
        )
        return fmt.format(**self.data)


class ExtendedNexthHopOffUnnumbered(issues.BadInputIssue):
    """
    We cannot disable extended-nexthop for unnumbered peers.
    """
    def __init__(self, vrf_name, peer):
        super().__init__("extended_nexthop_needed_unnumbered")
        self.data["vrf_name"] = vrf_name
        self.data["peer"] = peer

    def _render_message(self):
        fmt = (
            "`extended-nexthop` must be on for unnumbered peers in "
            "`vrf {vrf_name} router bgp peer {peer} capabilities` "
            "or in the peer's peer-group"
        )
        return fmt.format(**self.data)


def _verify_bgp_peers(evt, vrf_name, bgp_instance):
    """
    Verify bgp configuration of each BGP peer.
    """
    # Note that the peer-group values will be filled in for us, so we don't
    # need to fetch them separately.
    peers = bgp_instance["peer"]

    # Loop through the peers in this instance.
    for peer_name, peer in peers.items():
        # remote-as must be set in the peer or it's group.
        if "remote-as" not in peer:
            evt.report_issue(MissingRemoteAs(vrf_name, peer_name))

        # capabilities.extended-nexthop cannot be "off" for unnumbered peers.
        # It defaults to "auto", so we just need to look for an explicit "off".
        if peer["type"] == "unnumbered":
            if py_.get(peer, "capabilities.extended-nexthop") == "off":
                evt.report_issue(
                    ExtendedNexthHopOffUnnumbered(vrf_name, peer_name))


def _verify_bgp_instances(evt, vrfs):
    """
    Verify bgp configuration of each BGP instance.  This gets complicated in
    some cases because of peer-groups.  We need to look not only at the peer
    but also in the peer-group.
    """
    for vrf_name, vrf in vrfs.items():
        bgp_instance = py_.get(vrf, "router.bgp")
        if bgp_instance["enable"] == "on":
            _verify_bgp_peers(evt, vrf_name, bgp_instance)


class InvalidConvergeWaitEstWaitTime(issues.BadInputIssue):
    """
    Convergence wait cannot be less than establish-wait time.
    """
    def __init__(self, upd_delay_time, est_wait_time):
        super().__init__("invalid_convergence_wait_time")
        self.data["upd_delay"] = upd_delay_time
        self.data["est_wait_time"] = est_wait_time

    def _render_message(self):
        fmt = (
            "`convergence-wait {upd_delay}` must not be less than "
            "`establish-wait-time {est_wait_time}` "
        )
        return fmt.format(**self.data)


def _verify_bgp_convergence_wait(evt, router):
    """
    Verify global bgp convergence wait parameters
    """
    if py_.get(router, 'bgp.enable') == 'on':
        upd_delay_time = py_.get(router, 'bgp.convergence-wait.time')
        est_wait_time = py_.get(router,
                                'bgp.convergence-wait.establish-wait-time')
        if upd_delay_time < est_wait_time:
            evt.report_issue(
                InvalidConvergeWaitEstWaitTime(upd_delay_time, est_wait_time))
