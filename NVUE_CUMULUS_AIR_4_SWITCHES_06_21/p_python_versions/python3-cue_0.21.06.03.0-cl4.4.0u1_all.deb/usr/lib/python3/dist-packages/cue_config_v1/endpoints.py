# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Bring in the endpoint factories.
from .endpoint_factories import (
    endpoint_objs_get, endpoint_objs_put,
    endpoint_obj_get, endpoint_obj_put,
    endpoint_singleton_get, endpoint_singleton_put
)


###############################
# Build configuration endpoints
###############################
# root | This config contains "opinions" expressed by the user
root_get = endpoint_singleton_get(".")
root_put = endpoint_singleton_put(".")

# bridge
bridge_get = endpoint_singleton_get("bridge")
bridge_put = endpoint_singleton_put("bridge")

# bridge domains
bridge_domains_get = endpoint_objs_get("bridge.domain")
bridge_domains_put = endpoint_objs_put("bridge.domain")
bridge_domain_get = endpoint_obj_get("bridge.domain")
bridge_domain_put = endpoint_obj_put("bridge.domain")

# mlag
mlag_get = endpoint_singleton_get("mlag")
mlag_put = endpoint_singleton_put("mlag")

# interface
interfaces_get = endpoint_objs_get("interface")
interfaces_put = endpoint_objs_put("interface")
interface_get = endpoint_obj_get("interface")
interface_put = endpoint_obj_put("interface")

# router
router_get = endpoint_singleton_get("router")
router_put = endpoint_singleton_put("router")

# bgp
bgp_get = endpoint_singleton_get("router.bgp")
bgp_put = endpoint_singleton_put("router.bgp")

# ospf
ospf_get = endpoint_singleton_get("router.ospf")
ospf_put = endpoint_singleton_put("router.ospf")

# pbr
pbr_get = endpoint_singleton_get("router.pbr")
pbr_put = endpoint_singleton_put("router.pbr")

# pbr map {pbr-map-id}
pbr_map_get = endpoint_obj_get("router.pbr.map")
pbr_map_put = endpoint_obj_put("router.pbr.map")

# pbr map
pbr_maps_get = endpoint_objs_get("router.pbr.map")
pbr_maps_put = endpoint_objs_put("router.pbr.map")

# nve
nve_get = endpoint_singleton_get("nve", from_root=True)
nve_put = endpoint_singleton_put("nve")

# vxlan
nve_vxlan_get = endpoint_singleton_get("nve.vxlan", from_root=True)
nve_vxlan_put = endpoint_singleton_put("nve.vxlan")

# evpn
evpn_get = endpoint_singleton_get("evpn")
evpn_put = endpoint_singleton_put("evpn")

# platform
platform_get = endpoint_singleton_get("platform")
platform_put = endpoint_singleton_put("platform")

# hostname
hostname_get = endpoint_singleton_get("platform.hostname")
hostname_put = endpoint_singleton_put("platform.hostname")

# platform config
platform_config_get = endpoint_singleton_get("platform.config")
platform_config_put = endpoint_singleton_put("platform.config")

# platform config apply
platform_config_apply_get = endpoint_singleton_get("platform.config.apply")
platform_config_apply_put = endpoint_singleton_put("platform.config.apply")

# snippets
snippets_get = endpoint_objs_get("platform.config.snippet")
snippets_put = endpoint_objs_put("platform.config.snippet")

# service
service_get = endpoint_singleton_get("service")
service_put = endpoint_singleton_put("service")

# dhcp-relays
dhcp_relays_get = endpoint_objs_get("service.dhcp-relay")
dhcp_relays_put = endpoint_objs_put("service.dhcp-relay")
dhcp_relay_get = endpoint_obj_get("service.dhcp-relay")
dhcp_relay_put = endpoint_obj_put("service.dhcp-relay")

# dhcp-relays6
dhcp_relays6_get = endpoint_objs_get("service.dhcp-relay6")
dhcp_relays6_put = endpoint_objs_put("service.dhcp-relay6")
dhcp_relay6_get = endpoint_obj_get("service.dhcp-relay6")
dhcp_relay6_put = endpoint_obj_put("service.dhcp-relay6")

# syslog
syslogs_get = endpoint_objs_get("service.syslog")
syslogs_put = endpoint_objs_put("service.syslog")
syslog_get = endpoint_obj_get("service.syslog")
syslog_put = endpoint_obj_put("service.syslog")

# ptps
ptps_get = endpoint_objs_get("service.ptp")
ptps_put = endpoint_objs_put("service.ptp")
ptp_get = endpoint_obj_get("service.ptp")
ptp_put = endpoint_obj_put("service.ptp")

# system
system_get = endpoint_singleton_get("system")
system_put = endpoint_singleton_put("system")

# qos
qos_get = endpoint_singleton_get("qos")
qos_put = endpoint_singleton_put("qos")

# qos.roce
roce_get = endpoint_singleton_get("qos.roce")
roce_put = endpoint_singleton_put("qos.roce")

# dhcp-server
dhcp_servers_get = endpoint_objs_get("service.dhcp-server")
dhcp_servers_put = endpoint_objs_put("service.dhcp-server")
dhcp_server_get = endpoint_obj_get("service.dhcp-server")
dhcp_server_put = endpoint_obj_put("service.dhcp-server")

# dhcp-server6
dhcp_servers6_get = endpoint_objs_get("service.dhcp-server6")
dhcp_servers6_put = endpoint_objs_put("service.dhcp-server6")
dhcp_server6_get = endpoint_obj_get("service.dhcp-server6")
dhcp_server6_put = endpoint_obj_put("service.dhcp-server6")

# dns
dnss_get = endpoint_objs_get("service.dns")
dnss_put = endpoint_objs_put("service.dns")
dns_get = endpoint_obj_get("service.dns")
dns_put = endpoint_obj_put("service.dns")

# port-mirror
port_mirror_get = endpoint_singleton_get("system.port-mirror")
port_mirror_put = endpoint_singleton_put("system.port-mirror")
port_mirror_sessions_get = endpoint_objs_get("system.port-mirror.session")
port_mirror_sessions_put = endpoint_objs_put("system.port-mirror.session")
port_mirror_session_get = endpoint_obj_get("system.port-mirror.session")
port_mirror_session_put = endpoint_obj_put("system.port-mirror.session")

# lldp
lldp_get = endpoint_singleton_get("service.lldp")
lldp_put = endpoint_singleton_put("service.lldp")

# global
global_get = endpoint_singleton_get("system.global")
global_put = endpoint_singleton_put("system.global")

# reserved
reserved_get = endpoint_singleton_get("system.global.reserved")
reserved_put = endpoint_singleton_put("system.global.reserved")

# ntp
ntps_get = endpoint_objs_get("service.ntp")
ntps_put = endpoint_objs_put("service.ntp")
ntp_get = endpoint_obj_get("service.ntp")
ntp_put = endpoint_obj_put("service.ntp")

# vrfs
vrfs_get = endpoint_objs_get("vrf")
vrfs_put = endpoint_objs_put("vrf")
vrf_get = endpoint_obj_get("vrf")
vrf_put = endpoint_obj_put("vrf")

# acls
acls_get = endpoint_objs_get("acl")
acls_put = endpoint_objs_put("acl")
acl_get = endpoint_obj_get("acl")
acl_put = endpoint_obj_put("acl")
