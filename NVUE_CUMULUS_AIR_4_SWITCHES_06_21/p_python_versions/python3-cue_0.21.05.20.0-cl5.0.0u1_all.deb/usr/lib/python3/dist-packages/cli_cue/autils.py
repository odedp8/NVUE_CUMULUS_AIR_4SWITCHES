# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

"""
Utilities for asyncio.
"""


import asyncio
from functools import wraps


def _ensure_awaitable(maybe_awaitable, *args, **kwargs):
    import inspect
    if inspect.isawaitable(maybe_awaitable):
        return maybe_awaitable

    @wraps(maybe_awaitable)
    async def awaitable_wrapper():
        result = maybe_awaitable(*args, **kwargs)
        if inspect.isawaitable(result):
            return await result
        else:
            return result
    return awaitable_wrapper()


async def achain(start, *steps):
    """
    Run awaitables in sequence, passing the completed task in as an argument to
    the next awaitable in the sequence.

    This can also handle synchronous functions.

    Returns:
        The final Task object in the sequence.
    """
    # The start doesn't get passed any args.
    cur_task = asyncio.create_task(_ensure_awaitable(start))
    await cur_task
    for awaitable in steps:
        cur_task = asyncio.create_task(
            # Everything else gets passed the previous task as the arg.
            _ensure_awaitable(awaitable, cur_task),
        )
        try:
            await cur_task
        except Exception:
            # Let the next step in the chain handle the exception.
            pass
    return cur_task.result()


async def deathrace(*aws):
    """
    Schedule and run each awaitable in `aws` concurrently, and block until the
    first task finishes. Then cancel all pending tasks.

    There can be only one.

    Args:
        aws: The sequence of awaitables to be run.

    Returns:
        The sequence of completed tasks (including cancelled tasks) in the
        order provided by `aws`.
    """
    # Schedule all the awaitables
    all_tasks = tuple(
        asyncio.create_task(awaitable)
        for awaitable in aws
    )
    await asyncio.wait(
        all_tasks, return_when=asyncio.FIRST_COMPLETED
    )
    for task in all_tasks:
        task.cancel()
    # Cancelled tasks won't receive their CancellationErrors until we pass
    # control back to the event loop.
    # Guarantee that each task.result() will have its CancellationError (if
    # applicable.)
    await asyncio.wait(all_tasks, return_when=asyncio.ALL_COMPLETED)
    return all_tasks
