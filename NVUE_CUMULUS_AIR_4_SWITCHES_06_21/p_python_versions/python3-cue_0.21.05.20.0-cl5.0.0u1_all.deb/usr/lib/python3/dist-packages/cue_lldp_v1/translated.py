# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


from cue.exceptions import NotFound


#############################
# Neighbors
#############################
def nbrs_get(ctx):
    """
    Get the list of nbrs from lldpctl and translate the neighbor info.
    """
    nbr_list = ctx.lldp_v1.getLldpCtls()

    nbrs = {}
    # Translate the set of nbrs.
    for name, nbr in nbr_list.items():
        nbrs[name] = _make_nbr(nbr)

    return nbrs


def nbr_get(ctx, interface_id):
    """
    Get a neighbor for an interface, swp_id and translate to OM.
    """
    try:
        # Get the LLDP data
        nbr_list = ctx.lldp_v1.getLldpCtl(interface_id)

        return _make_nbr(nbr_list)
    except NotFound:
        # We can't tell if the interface is unknown or if it doesn't
        # have neighbors.  Leave the "unknown" case to the upper layers
        # of CUE and assume the "no neighbors" case.
        return {
            "neighbor": {}
        }


def _make_nbr(nbr_list):
    """
    Translate the nbr object from lldpctl lldp neighbor OM
    """
    trans_nbr_list = {}

    for nbr in nbr_list:
        # Pluck out what we need, defaulting as appropriate.
        chassis_id = nbr["chassis"][0]["name"][0]["value"]

        # convert age day, HH:MM:SS format to seconds
        age_str = nbr["age"]
        split = "days," if "days" in age_str else "day,"
        day, time_str = age_str.split(split)
        h, m, s = time_str.split(':')
        age = int(day) * 24 * 3600 + int(h) * 3600 + int(m) * 60 + int(s)

        ttl = nbr["port"][0]["ttl"][0]["value"]
        port_id = nbr["port"][0]["id"][0]["value"]
        port_id_type = nbr["port"][0]["id"][0]["type"]
        port_descr = nbr["port"][0]["descr"][0]["value"]
        chassis_mgmt_ip = nbr["chassis"][0]["mgmt-ip"][0]["value"]

        trans_nbr = {
            "age": age,
            "ttl": int(ttl),
            "port-id": port_id,
            "port-id-type": port_id_type,
            "port-description": port_descr,
            "management-address": chassis_mgmt_ip,
        }
        bridge = {'vlan': {}}
        if "vlan" in nbr:
            for vlan in nbr['vlan']:
                if vlan['pvid'] is True:
                    bridge['untagged'] = int(vlan['vlan-id'])
                else:
                    bridge['vlan'][vlan['vlan-id']] = {}
            trans_nbr["bridge"] = bridge
        trans_nbr_list[chassis_id] = trans_nbr

    # Put it in neighbor OM format and return it
    return {
        "neighbor": trans_nbr_list
    }


#############################
# Global Show LLDP Config
#############################
def config_get(ctx):
    """
    Get the global LLDP config
    """

    config = ctx.lldp_v1.getLldpcliConfig()

    if config:
        result = {
            'tx-interval': config['tx-delay'],
            'tx-hold-multiplier': config['tx-hold'],
            'dot1-tlv': 'on' if config['dot1-tlv'] == 'yes' else 'off'
        }
    else:
        result = {}

    return result
