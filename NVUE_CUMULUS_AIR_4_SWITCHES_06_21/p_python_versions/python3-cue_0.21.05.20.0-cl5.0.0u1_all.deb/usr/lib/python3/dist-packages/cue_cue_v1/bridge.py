# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue_cue_v1.root import root_patch
from cue.exceptions import NotFound
from cue import utils


###############################
# Bridge
###############################

def bridge_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getBridge(rev)
    else:
        return ctx.netlink_v1.getBridge()


def bridge_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"bridge": body})
    return root.get("bridge", {})


def bridge_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridge, ctx.config_v1.setBridge, rev)


###############################
# Bridge Domains
###############################

def domains_get(ctx, rev):
    output = bridge_get(ctx, rev)
    try:
        return output["domain"]
    except KeyError:
        raise NotFound


def domains_patch(ctx, rev, body=None):
    root = bridge_patch(ctx, rev, {"domain": body})
    return root.get("domain", {})


def domains_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomains, ctx.config_v1.setBridgeDomains, rev)


###############################
# Bridge Domain
###############################

def domain_get(ctx, rev, domain_id):
    domains = domains_get(ctx, rev)
    try:
        return domains[domain_id]
    except KeyError:
        raise NotFound


def domain_patch(ctx, rev, domain_id, body=None):
    domains = domains_patch(ctx, rev, {domain_id: body})
    return domains.get(domain_id, {})


def domain_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id)


###############################
# Bridge Domain STP
###############################

def stp_get(ctx, rev, domain_id):
    return domain_get(ctx, rev, domain_id)["stp"]


def stp_patch(ctx, rev, domain_id, body=None):
    domain = domain_patch(ctx, rev, domain_id, {"stp": body})
    return domain.get("stp", {})


def stp_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "stp")


###############################
# STP State
###############################

def stp_state_get(ctx, rev, domain_id):
    return stp_get(ctx, rev, domain_id)["state"]


def stp_state_patch(ctx, rev, domain_id, body=None):
    stp = stp_patch(ctx, rev, domain_id, {"state": body})
    return stp.get("state", {})


def stp_state_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "stp", "state")


###############################
# Bridge Domain Multicast
###############################

def multicast_get(ctx, rev, domain_id):
    return domain_get(ctx, rev, domain_id)["multicast"]


def multicast_patch(ctx, rev, domain_id, body=None):
    domain = domain_patch(ctx, rev, domain_id, {"multicast": body})
    return domain.get("multicast", {})


def multicast_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "multicast")


###############################
# Bridge Domain Snooping
###############################

def snooping_get(ctx, rev, domain_id):
    return multicast_get(ctx, rev, domain_id)["snooping"]


def snooping_patch(ctx, rev, domain_id, body=None):
    multicast = multicast_patch(ctx, rev, domain_id, {"snooping": body})
    return multicast.get("snooping", {})


def snooping_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "multicast", "snooping")


###############################
# Bridge Domain Querier
###############################

def querier_get(ctx, rev, domain_id):
    return snooping_get(ctx, rev, domain_id)["querier"]


def querier_patch(ctx, rev, domain_id, body=None):
    snooping = snooping_patch(ctx, rev, domain_id, {"querier": body})
    return snooping.get("querier", {})


def querier_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "multicast", "snooping",
        "querier")


###############################
# Bridge Domain VLANs
###############################

def vlans_get(ctx, rev, domain_id):
    changed = False
    if rev == 'operational':
        operational_output = domain_get(ctx, rev, domain_id)
        if 'vlan' in operational_output:
            operational_output = operational_output["vlan"]
            changed = True
        else:
            operational_output = {}
        # Bridge VLAN config has to be patched with operational revision
        rev = 'applied'

    applied = domain_get(ctx, rev, domain_id)
    try:
        output = applied['vlan']
    except KeyError:
        raise NotFound

    if changed:
        return utils.fast_merge(output, operational_output)

    return output


def vlans_patch(ctx, rev, domain_id, body=None):
    domain = domain_patch(ctx, rev, domain_id, {"vlan": body})
    return domain.get("vlan", {})


def vlans_delete(ctx, rev, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "vlan")


###############################
# Bridge Domain VLAN
###############################

def vlan_get(ctx, rev, domain_id, vid):
    vlans = vlans_get(ctx, rev, domain_id)
    try:
        return vlans[vid]
    except KeyError:
        raise NotFound


def vlan_patch(ctx, rev, domain_id, vid, body=None):
    vlans = vlans_patch(ctx, rev, domain_id, {vid: body})
    return vlans.get(vid, {})


def vlan_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid)


###############################
# Bridge Domain VNIs
###############################

def vnis_get(ctx, rev, domain_id, vid):
    output = vlan_get(ctx, rev, domain_id, vid)
    try:
        return output["vni"]
    except KeyError:
        raise NotFound


def vnis_patch(ctx, rev, domain_id, vid, body=None):
    vlan = vlan_patch(ctx, rev, domain_id, vid, {"vni": body})
    return vlan.get("vni", {})


def vnis_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "vlan", vid, "vni")


###############################
# Bridge Domain VNI
###############################

def vni_get(ctx, rev, domain_id, vid, vni_id):
    vnis = vnis_get(ctx, rev, domain_id, vid)
    try:
        return vnis[vni_id]
    except KeyError:
        raise NotFound


def vni_patch(ctx, rev, domain_id, vid, vni_id, body=None):
    vnis = vnis_patch(ctx, rev, domain_id, vid, {vni_id: body})
    return vnis.get(vni_id, {})


def vni_delete(ctx, rev, domain_id, vid, vni_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "vni", vni_id)


###############################
# VNI Flooding
###############################

def vni_flooding_get(ctx, rev, domain_id, vid, vni_id):
    output = vni_get(ctx, rev, domain_id, vid, vni_id)
    try:
        return output["flooding"]
    except KeyError:
        raise NotFound


def vni_flooding_patch(ctx, rev, domain_id, vid, vni_id, body=None):
    vni = vni_patch(ctx, rev, domain_id, vid, vni_id, {"flooding": body})
    return vni.get("flooding", {})


def vni_flooding_delete(ctx, rev, domain_id, vid, vni_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "vni", vni_id, "flooding")


###############################
# VNI Flooding head-end-replication
###############################

def vni_flooding_hreps_get(ctx, rev, domain_id, vid, vni_id):
    output = vni_flooding_get(ctx, rev, domain_id, vid, vni_id)
    try:
        return output["head-end-replication"]
    except KeyError:
        raise NotFound


def vni_flooding_hreps_patch(ctx, rev, domain_id, vid, vni_id, body=None):
    flooding = vni_flooding_patch(ctx, rev, domain_id, vid, vni_id,
                                  {"head-end-replication": body})
    return flooding.get("head-end-replication", {})


def vni_flooding_hreps_delete(ctx, rev, domain_id, vid, vni_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "vni", vni_id, "flooding",
        "head-end-replication")


###############################
# VNI Flooding head-end-replication-id
###############################

def vni_flooding_hrep_get(ctx, rev, domain_id, vid, vni_id, hrep_id):

    hreps = vni_flooding_hreps_get(ctx, rev, domain_id, vid, vni_id)
    try:
        return hreps[hrep_id]
    except KeyError:
        raise NotFound


def vni_flooding_hrep_patch(ctx, rev, domain_id, vid, vni_id, hrep_id,
                            body=None):

    hreps = vni_flooding_hreps_patch(ctx, rev, domain_id, vid,
                                     vni_id, {hrep_id: body})
    return hreps.get(hrep_id, {})


def vni_flooding_hrep_delete(ctx, rev, domain_id, vid, vni_id, hrep_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "vni", vni_id, "flooding",
        "head-end-replication", hrep_id)


###############################
# VLAN Service
###############################

def vlan_service_get(ctx, rev, domain_id, vid):
    if rev != "operational":
        return vlan_get(ctx, rev, domain_id, vid)["service"]

    # There's nothing to get here yet.
    return {}


def vlan_service_patch(ctx, rev, domain_id, vid, body=None):
    vlan = vlan_patch(ctx, rev, domain_id, vid, {"service": body})
    return vlan.get("service", {})


def vlan_service_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "service")


###############################
# VLAN PTP
###############################

def vlan_ptp_get(ctx, rev, domain_id, vid):
    if rev == 'operational':
        # PTP under bridge.vlan is purely a config concept.  Return the last
        # applied config as the operational state.
        rev = 'applied'

    return vlan_service_get(ctx, rev, domain_id, vid)["ptp"]


def vlan_ptp_patch(ctx, rev, domain_id, vid, body=None):
    service = vlan_service_patch(ctx, rev, domain_id, vid, {"ptp": body})
    return service.get("ptp", {})


def vlan_ptp_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "service", "ptp")


###############################
# PTP Timers
###############################

def vlan_ptp_timers_get(ctx, rev, domain_id, vid):
    return vlan_ptp_get(ctx, rev, domain_id, vid)["timers"]


def vlan_ptp_timers_patch(ctx, rev, domain_id, vid, body=None):
    ptp = vlan_ptp_patch(ctx, rev, domain_id, vid, {"timers": body})
    return ptp.get("timers", {})


def vlan_ptp_timers_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain, ctx.config_v1.setBridgeDomain, rev,
        domain_id, "vlan", vid, "service", "ptp", "timers")


###############################
# VLAN Multicast
###############################

def vlan_multicast_get(ctx, rev, domain_id, vid):
    return vlan_get(ctx, rev, domain_id, vid)["multicast"]


def vlan_multicast_patch(ctx, rev, domain_id, vid, body=None):
    vlan = vlan_patch(ctx, rev, domain_id, vid, {"multicast": body})
    return vlan.get("multicast", {})


def vlan_multicast_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "vlan", vid,
        "multicast")


###############################
# VLAN Snooping
###############################

def vlan_snooping_get(ctx, rev, domain_id, vid):
    return vlan_multicast_get(ctx, rev, domain_id, vid)["snooping"]


def vlan_snooping_patch(ctx, rev, domain_id, vid, body=None):
    multicast = vlan_multicast_patch(
        ctx, rev, domain_id, vid, {"snooping": body})
    return multicast.get("snooping", {})


def vlan_snooping_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "vlan", vid,
        "multicast", "snooping")


###############################
# VLAN Querier
###############################

def vlan_querier_get(ctx, rev, domain_id, vid):
    return vlan_snooping_get(ctx, rev, domain_id, vid)["querier"]


def vlan_querier_patch(ctx, rev, domain_id, vid, body=None):
    snooping = vlan_snooping_patch(ctx, rev, domain_id, vid, {"querier": body})
    return snooping.get("querier", {})


def vlan_querier_delete(ctx, rev, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBridgeDomain,
        ctx.config_v1.setBridgeDomain, rev, domain_id, "vlan", vid,
        "multicast", "snooping", "querier")


###############################
# Bridge Domain MAC Table
###############################
def mac_table_get(ctx, rev, domain_id):
    # MAC Table does not have a config side
    if rev != "operational":
        raise NotFound

    res = ctx.netlink_v1.getMacTable(domain_id)
    if not res:
        raise NotFound

    return res
