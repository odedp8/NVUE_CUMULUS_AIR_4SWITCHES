# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.root import root_patch


###############################
# Router
###############################

def router_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getRouter(rev)

    # We will not show the operational state as of now.
    raise NotFound


def router_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"router": body})
    return root.get("router", {})


def router_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev)


###############################
# Router/pbr
###############################

def pbr_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPbr(rev)

    # We will not show the operational state as of now.
    raise NotFound


def pbr_patch(ctx, rev, body=None):
    router = router_patch(ctx, rev, {"pbr": body})
    return router.get("pbr", {})


def pbr_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbr, ctx.config_v1.setPbr, rev)


###############################
# Router/pbr/nexthop-group
###############################

nhgs_path = ('nexthop-group',)


def pbr_nhgs_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPbr(rev).get('nexthop-group', {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_nhgs_patch(ctx, rev, body=None):
    pbr = pbr_patch(ctx, rev, {"nexthop-group": body})
    return pbr.get("nexthop-group", {})


def pbr_nhgs_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbr, ctx.config_v1.setPbr, rev,
        *nhgs_path)


###############################
# Router/pbr/nexthop-group/{nexthop-group-id}
###############################


def pbr_nhg_get(ctx, rev, nexthop_group_id):
    if rev != "operational":
        return pbr_nhgs_get(ctx, rev).get(nexthop_group_id, {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_nhg_patch(ctx, rev, nexthop_group_id, body=None):
    pbr_nhgs = pbr_nhgs_patch(ctx, rev, {nexthop_group_id: body})
    return pbr_nhgs.get(nexthop_group_id, {})


def pbr_nhg_delete(ctx, rev, nexthop_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbr, ctx.config_v1.setPbr, rev,
        *(*nhgs_path, nexthop_group_id))


###############################
# Router/pbr/nexthop-group/{nexthop-group-id}/via
###############################


def pbr_nhg_vias_get(ctx, rev, nexthop_group_id):
    if rev != "operational":
        return pbr_nhg_get(ctx, rev, nexthop_group_id).get(
            'via', {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_nhg_vias_patch(ctx, rev, nexthop_group_id, body=None):
    pbr_nhg = pbr_nhg_patch(ctx, rev, nexthop_group_id, {'via': body})
    return pbr_nhg.get('via', {})


def pbr_nhg_vias_delete(ctx, rev, nexthop_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbr, ctx.config_v1.setPbr, rev,
        *(*nhgs_path, nexthop_group_id, 'via'))


###############################
# Router/pbr/nexthop-group/{nexthop-group-id}/via/{nhg-via-id}
###############################


def pbr_nhg_via_get(ctx, rev, nexthop_group_id, nhg_via_id):
    if rev != "operational":
        return pbr_nhg_vias_get(ctx, rev, nexthop_group_id).get(
            nhg_via_id, {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_nhg_via_patch(ctx, rev, nexthop_group_id, nhg_via_id, body=None):
    pbr_nhg_vias = pbr_nhg_vias_patch(ctx, rev, nexthop_group_id,
                                      {nhg_via_id: body})
    return pbr_nhg_vias.get(nhg_via_id, {})


def pbr_nhg_via_delete(ctx, rev, nexthop_group_id, nhg_via_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbr, ctx.config_v1.setPbr, rev,
        *(*nhgs_path, nexthop_group_id, 'via', nhg_via_id))


###############################
# Router/pbr/map
###############################

pbr_map_path = ("pbr", "map")


def pbr_maps_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPbrMaps(rev)

    # We will not show the operational state as of now.
    raise NotFound


def pbr_maps_patch(ctx, rev, body=None):
    pbr = pbr_patch(ctx, rev, {"map": body})
    return pbr.get("map", {})


def pbr_maps_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMaps, ctx.config_v1.setPbrMaps, rev)


###############################
# Router/pbr/map/{pbr-map-id}
###############################

def pbr_map_get(ctx, rev, pbr_map_id):
    if rev != "operational":
        return ctx.config_v1.getPbrMap(rev, pbr_map_id)

    # We will not show the operational state as of now.
    raise NotFound


def pbr_map_patch(ctx, rev, pbr_map_id, body=None):
    pbr_maps = pbr_maps_patch(ctx, rev, {pbr_map_id: body})
    return pbr_maps.get(pbr_map_id, {})


def pbr_map_delete(ctx, rev, pbr_map_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMap, ctx.config_v1.setPbrMap, rev, pbr_map_id)


###############################
# Router/pbr/map/{pbr-map-id}/rule
###############################

def pbr_map_rules_get(ctx, rev, pbr_map_id):
    if rev != "operational":
        return ctx.config_v1.getPbrMap(rev, pbr_map_id).get('rule', {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_map_rules_patch(ctx, rev, pbr_map_id, body=None):
    pbr_map = pbr_map_patch(ctx, rev, pbr_map_id, {'rule': body})
    return pbr_map.get('rule', {})


def pbr_map_rules_delete(ctx, rev, pbr_map_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMap, ctx.config_v1.setPbrMap, rev,
        *(pbr_map_id, 'rule'))


###############################
# Router/pbr/map/{pbr-map-id}/rule/{rule-id}
###############################

def pbr_map_rule_get(ctx, rev, pbr_map_id, rule_id):
    if rev != "operational":
        return pbr_map_rules_get(ctx, rev, pbr_map_id).get(rule_id, {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_map_rule_patch(ctx, rev, pbr_map_id, rule_id, body=None):
    pbr_map_rules = pbr_map_rules_patch(ctx, rev, pbr_map_id,
                                        {rule_id: body})
    return pbr_map_rules.get(rule_id, {})


def pbr_map_rule_delete(ctx, rev, pbr_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMap, ctx.config_v1.setPbrMap, rev,
        *(pbr_map_id, 'rule', rule_id))


###############################
# Router/pbr/map/{pbr-map-id}/rule/{rule-id}/match
###############################

def pbr_map_rule_match_get(ctx, rev, pbr_map_id, rule_id):
    if rev != "operational":
        return pbr_map_rule_get(ctx, rev, pbr_map_id, rule_id).get('match', {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_map_rule_match_patch(ctx, rev, pbr_map_id, rule_id, body=None):
    pbr_map_rule = pbr_map_rule_patch(ctx, rev, pbr_map_id, rule_id,
                                      {'match': body})
    return pbr_map_rule.get('match', {})


def pbr_map_rule_match_delete(ctx, rev, pbr_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMap, ctx.config_v1.setPbrMap, rev,
        *(pbr_map_id, 'rule', rule_id, 'match'))


###############################
# Router/pbr/map/{pbr-map-id}/rule/{rule-id}/action
###############################

def pbr_map_rule_action_get(ctx, rev, pbr_map_id, rule_id):
    if rev != "operational":
        return pbr_map_rule_get(ctx, rev, pbr_map_id, rule_id).get('action',
                                                                   {})

    # We will not show the operational state as of now.
    raise NotFound


def pbr_map_rule_action_patch(ctx, rev, pbr_map_id, rule_id, body=None):
    pbr_map_rule = pbr_map_rule_patch(ctx, rev, pbr_map_id, rule_id,
                                      {'action': body})
    return pbr_map_rule.get('action', {})


def pbr_map_rule_action_delete(ctx, rev, pbr_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPbrMap, ctx.config_v1.setPbrMap, rev,
        *(pbr_map_id, 'rule', rule_id, 'action'))


###############################
# Router/policy
###############################

def policy_get(ctx, rev):
    return router_get(ctx, rev)["policy"]


def policy_patch(ctx, rev, body=None):
    router = router_patch(ctx, rev, {"policy": body})
    return router.get("policy", {})


def policy_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev, "policy")


###############################
# Router/policy/community-lists
###############################

def community_lists_get(ctx, rev):
    return policy_get(ctx, rev)["community-list"]


def community_lists_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"community-list": body})
    return policy.get("community-list", {})


def community_lists_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list")


#####################################################
# Router/policy/community-lists/{list-id}
####################################################

def community_list_get(ctx, rev, list_id):
    clists = community_lists_get(ctx, rev)
    try:
        return clists[list_id]
    except KeyError:
        raise NotFound


def community_list_patch(ctx, rev, list_id, body=None):
    clists = community_lists_patch(ctx, rev,
                                   {list_id: body})
    return clists.get(list_id, {})


def community_list_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list", list_id)


####################################################################
# Router/policy/community-lists/{list-id}/rule
###################################################################

def community_list_rules_get(ctx, rev, list_id):
    clist = community_list_get(ctx, rev, list_id)
    return clist["rule"]


def community_list_rules_patch(ctx, rev, list_id, body=None):
    clist = community_list_patch(ctx, rev, list_id,
                                 {"rule": body})
    return clist.get("rule", {})


def community_list_rules_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list", list_id, "rule")


####################################################################
# Router/policy/community-lists/{list-id}/rule/{rule-id}
###################################################################

def community_list_rule_get(ctx, rev, list_id, rule_id):
    rules = community_list_rules_get(ctx, rev, list_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def community_list_rule_patch(ctx, rev, list_id, rule_id, body=None):
    rules = community_list_rules_patch(ctx, rev, list_id,
                                       {rule_id: body})
    return rules.get(rule_id, {})


def community_list_rule_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list", list_id, "rule", rule_id)


############################################################################
# Router/policy/community-lists/{list-id}/rule/{rule-id}/community
############################################################################

def rule_communities_get(ctx, rev, list_id, rule_id):
    rule = community_list_rule_get(ctx, rev, list_id, rule_id)
    return rule["community"]


def rule_communities_patch(ctx, rev, list_id, rule_id, body=None):
    rule = community_list_rule_patch(ctx, rev, list_id, rule_id,
                                     {"community": body})
    return rule.get("community", {})


def rule_communities_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list", list_id, "rule",
        rule_id, "community")


############################################################################
# Router/policy/community-lists/{list-id}/rule/{rule-id}/community/{community-id}
############################################################################

def rule_community_get(ctx, rev, list_id, rule_id, community_id):
    communities = rule_communities_get(ctx, rev, list_id, rule_id)
    try:
        return communities[community_id]
    except KeyError:
        raise NotFound


def rule_community_patch(ctx, rev, list_id, rule_id, community_id, body=None):
    communities = rule_communities_patch(
        ctx, rev, list_id, rule_id, {community_id: body})
    return communities.get(community_id, {})


def rule_community_delete(ctx, rev, list_id, rule_id, community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "community-list", list_id, "rule",
        rule_id, "community", community_id)


###############################
# Router/policy/as-path-lists
###############################

def aspath_lists_get(ctx, rev):
    return policy_get(ctx, rev)["as-path-list"]


def aspath_lists_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"as-path-list": body})
    return policy.get("as-path-list", {})


def aspath_lists_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "as-path-list")


#####################################################
# Router/policy/as-path-lists/{list-id}
####################################################

def aspath_list_get(ctx, rev, list_id):
    clists = aspath_lists_get(ctx, rev)
    try:
        return clists[list_id]
    except KeyError:
        raise NotFound


def aspath_list_patch(ctx, rev, list_id, body=None):
    clists = aspath_lists_patch(ctx, rev,
                                {list_id: body})
    return clists.get(list_id, {})


def aspath_list_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "as-path-list", list_id)


####################################################################
# Router/policy/as-path-lists/{list-id}/rule
###################################################################

def aspath_list_rules_get(ctx, rev, list_id):
    clist = aspath_list_get(ctx, rev, list_id)
    return clist["rule"]


def aspath_list_rules_patch(ctx, rev, list_id, body=None):
    clist = aspath_list_patch(ctx, rev, list_id,
                              {"rule": body})
    return clist.get("rule", {})


def aspath_list_rules_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "as-path-list", list_id, "rule")


####################################################################
# Router/policy/as-path-lists/{list-id}/rule/{rule-id}
###################################################################

def aspath_list_rule_get(ctx, rev, list_id, rule_id):
    rules = aspath_list_rules_get(ctx, rev, list_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def aspath_list_rule_patch(ctx, rev, list_id, rule_id, body=None):
    rules = aspath_list_rules_patch(ctx, rev, list_id,
                                    {rule_id: body})
    return rules.get(rule_id, {})


def aspath_list_rule_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "as-path-list", list_id, "rule", rule_id)


######################################
# Router/policy/ext-community-lists
######################################

def ext_community_lists_get(ctx, rev):
    return policy_get(ctx, rev)["ext-community-list"]


def ext_community_lists_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"ext-community-list": body})
    return policy.get("ext-community-list", {})


def ext_community_lists_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list")


##############################################################
# Router/policy/ext-community-lists/{list-id}
##############################################################

def ext_community_list_get(ctx, rev, list_id):
    clists = ext_community_lists_get(ctx, rev)
    try:
        return clists[list_id]
    except KeyError:
        raise NotFound


def ext_community_list_patch(ctx, rev, list_id, body=None):
    clists = ext_community_lists_patch(ctx, rev,
                                       {list_id: body})
    return clists.get(list_id, {})


def ext_community_list_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id)


####################################################################
# Router/policy/ext-community-lists/{list-id}/rule
###################################################################

def ext_community_list_rules_get(ctx, rev, list_id):
    clist = ext_community_list_get(ctx, rev, list_id)
    return clist["rule"]


def ext_community_list_rules_patch(ctx, rev, list_id, body=None):
    clist = ext_community_list_patch(ctx, rev, list_id,
                                     {"rule": body})
    return clist.get("rule", {})


def ext_community_list_rules_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id, "rule")


####################################################################
# Router/policy/community-lists/{community-list-id}/rule/{rule-id}
###################################################################

def ext_community_list_rule_get(ctx, rev, list_id, rule_id):
    rules = ext_community_list_rules_get(ctx, rev, list_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def ext_community_list_rule_patch(ctx, rev, list_id, rule_id,
                                  body=None):
    rules = ext_community_list_rules_patch(ctx, rev, list_id,
                                           {rule_id: body})
    return rules.get(rule_id, {})


def ext_community_list_rule_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id, "rule", rule_id)


############################################################################
# Router/policy/ext-community-lists/{list-id}/
# rule/{rule-id}/ext-community
############################################################################

def rule_ext_community_get(ctx, rev, list_id, rule_id):
    rule = ext_community_list_rule_get(ctx, rev, list_id,
                                       rule_id)
    return rule["ext-community"]


def rule_ext_community_patch(ctx, rev, list_id, rule_id,
                             body=None):
    rule = ext_community_list_rule_patch(ctx, rev, list_id,
                                         rule_id, {"ext-community": body})
    return rule.get("ext-community", {})


def rule_ext_community_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id,
        "rule", rule_id, "ext-community")


############################################################################
# Router/policy/ext-community-lists/{list-id}/
# rule/{rule-id}/ext-community/rt
############################################################################

def rule_ext_community_rts_get(ctx, rev, list_id, rule_id):
    ext_com = rule_ext_community_get(ctx, rev, list_id, rule_id)
    return ext_com["rt"]


def rule_ext_community_rts_patch(ctx, rev, list_id, rule_id,
                                 body=None):
    ext_com = rule_ext_community_patch(ctx, rev, list_id,
                                       rule_id, {"rt": body})
    return ext_com.get("rt", {})


def rule_ext_community_rts_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id,
        "rule", rule_id, "ext-community", "rt")


############################################################################
# Router/policy/ext-community-lists/{list-id}/
# rule/{rule-id}/ext-community/rt/{ext-community-id}
############################################################################

def rule_ext_community_rt_get(ctx, rev, list_id, rule_id, ext_community_id):
    rts = rule_ext_community_rts_get(ctx, rev, list_id, rule_id)
    try:
        return rts[ext_community_id]
    except KeyError:
        raise NotFound


def rule_ext_community_rt_patch(ctx, rev, list_id, rule_id, ext_community_id,
                                body=None):
    rts = rule_ext_community_rts_patch(
        ctx, rev, list_id, rule_id, {ext_community_id: body})
    return rts.get(ext_community_id, {})


def rule_ext_community_rt_delete(ctx, rev, list_id, rule_id, ext_community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id,
        "rule", rule_id, "ext-community", "rt", ext_community_id)


############################################################################
# Router/policy/ext-community-lists/{list-id}/
# rule/{rule-id}/ext-community/soo
############################################################################

def rule_ext_community_soos_get(ctx, rev, list_id, rule_id):
    ext_com = rule_ext_community_get(ctx, rev, list_id, rule_id)
    return ext_com["soo"]


def rule_ext_community_soos_patch(ctx, rev, list_id, rule_id, body=None):
    ext_com = rule_ext_community_patch(
        ctx, rev, list_id, rule_id, {"soo": body})
    return ext_com.get("soo", {})


def rule_ext_community_soos_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id,
        "rule", rule_id, "ext-community", "soo")


############################################################################
# Router/policy/ext-community-lists/{list-id}/
# rule/{rule-id}/ext-community/soo/{ext-community-id}
############################################################################

def rule_ext_community_soo_get(ctx, rev, list_id, rule_id, ext_community_id):
    soos = rule_ext_community_soos_get(ctx, rev, list_id, rule_id)
    try:
        return soos[ext_community_id]
    except KeyError:
        raise NotFound


def rule_ext_community_soo_patch(ctx, rev, list_id, rule_id, ext_community_id,
                                 body=None):
    soos = rule_ext_community_soos_patch(
        ctx, rev, list_id, rule_id, {ext_community_id: body})
    return soos.get(ext_community_id, {})


def rule_ext_community_soo_delete(ctx, rev, list_id, rule_id,
                                  ext_community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "ext-community-list", list_id,
        "rule", rule_id, "ext-community", "soo", ext_community_id)


############################################
# Router/policy/large-community-lists
###########################################

def large_community_lists_get(ctx, rev):
    return policy_get(ctx, rev)["large-community-list"]


def large_community_lists_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"large-community-list": body})
    return policy.get("large-community-list", {})


def large_community_lists_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list")


##################################################################
# Router/policy/large-community-lists/{list-id}
#################################################################

def large_community_list_get(ctx, rev, list_id):
    clists = large_community_lists_get(ctx, rev)
    try:
        return clists[list_id]
    except KeyError:
        raise NotFound


def large_community_list_patch(ctx, rev, list_id, body=None):
    clists = large_community_lists_patch(ctx, rev,
                                         {list_id: body})
    return clists.get(list_id, {})


def large_community_list_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list", list_id)


####################################################################
# Router/policy/large-community-lists/{list-id}/rule
###################################################################

def large_community_list_rules_get(ctx, rev, list_id):
    clist = large_community_list_get(ctx, rev, list_id)
    return clist["rule"]


def large_community_list_rules_patch(ctx, rev, list_id,
                                     body=None):
    clist = large_community_list_patch(ctx, rev, list_id,
                                       {"rule": body})
    return clist.get("rule", {})


def large_community_list_rules_delete(ctx, rev, list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list", list_id, "rule")


##############################################################################
# Router/policy/large-community-lists/{list-id}/rule/{rule-id}
##############################################################################

def large_community_list_rule_get(ctx, rev, list_id, rule_id):
    rules = large_community_list_rules_get(ctx, rev, list_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def large_community_list_rule_patch(ctx, rev, list_id, rule_id,
                                    body=None):
    rules = large_community_list_rules_patch(ctx, rev, list_id,
                                             {rule_id: body})
    return rules.get(rule_id, {})


def large_community_list_rule_delete(ctx, rev, list_id,
                                     rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list", list_id, "rule",
        rule_id)


###########################################################################
# Router/policy/large-community-lists/{list-id}/
# rule/{rule-id}/large-community
#########################################################################

def rule_large_communities_get(ctx, rev, list_id, rule_id):
    rule = large_community_list_rule_get(ctx, rev, list_id,
                                         rule_id)
    return rule["large-community"]


def rule_large_communities_patch(ctx, rev, list_id, rule_id, body=None):
    rule = large_community_list_rule_patch(ctx, rev, list_id,
                                           rule_id, {"large-community": body})
    return rule.get("large-community", {})


def rule_large_communities_delete(ctx, rev, list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list", list_id, "rule",
        rule_id, "large-community")


###########################################################################
# Router/policy/large-community-lists/{list-id}/
# rule/{rule-id}/large-community/{large-community-id}
#########################################################################

def rule_large_community_get(ctx, rev, list_id, rule_id, large_community_id):
    communities = rule_large_communities_get(ctx, rev, list_id, rule_id)
    try:
        return communities[large_community_id]
    except KeyError:
        raise NotFound


def rule_large_community_patch(ctx, rev, list_id, rule_id, large_community_id,
                               body=None):
    communities = rule_large_communities_patch(
        ctx, rev, list_id, rule_id, {large_community_id: body})
    return communities.get(large_community_id, {})


def rule_large_community_delete(ctx, rev, list_id, rule_id,
                                large_community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "large-community-list", list_id, "rule",
        rule_id, "large-community", large_community_id)


###############################
# Router/policy/prefix-lists
###############################

def prefix_lists_get(ctx, rev):
    return policy_get(ctx, rev)["prefix-list"]


def prefix_lists_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"prefix-list": body})
    return policy.get("prefix-list", {})


def prefix_lists_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list")


##############################################
# Router/policy/prefix-list/{prefix-list-id}
#############################################

def prefix_list_get(ctx, rev, prefix_list_id):
    lists = prefix_lists_get(ctx, rev)
    try:
        return lists[prefix_list_id]
    except KeyError:
        raise NotFound


def prefix_list_patch(ctx, rev, prefix_list_id, body=None):
    p_list = prefix_lists_patch(ctx, rev, {prefix_list_id: body})
    return p_list.get(prefix_list_id, {})


def prefix_list_delete(ctx, rev, prefix_list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list", prefix_list_id)


####################################################
# Router/policy/prefix-list/{prefix-list-id}/rules
####################################################

def prefix_list_rules_get(ctx, rev, prefix_list_id):
    return prefix_list_get(ctx, rev, prefix_list_id)["rule"]


def prefix_list_rules_patch(ctx, rev, prefix_list_id, body=None):
    p_list = prefix_list_patch(ctx, rev, prefix_list_id, {"rule": body})
    return p_list.get("rule", {})


def prefix_list_rules_delete(ctx, rev, prefix_list_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list", prefix_list_id, "rule")


#############################################################
# Router/policy/prefix-list/{prefix-list-id}/rule/{rule-id}
#############################################################

def prefix_list_rule_get(ctx, rev, prefix_list_id, rule_id):
    rules = prefix_list_rules_get(ctx, rev, prefix_list_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def prefix_list_rule_patch(ctx, rev, prefix_list_id, rule_id, body=None):
    rules = prefix_list_rules_patch(ctx, rev, prefix_list_id, {rule_id: body})
    return rules.get(rule_id, {})


def prefix_list_rule_delete(ctx, rev, prefix_list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list", prefix_list_id, "rule", rule_id)


#################################################################
# Router/policy/prefix-list/{prefix-list-id}/rule/{rule-id}/match
#################################################################

def prefix_list_rule_matches_get(ctx, rev, prefix_list_id, rule_id):
    return prefix_list_rule_get(ctx, rev, prefix_list_id, rule_id)["match"]


def prefix_list_rule_matches_patch(ctx, rev, prefix_list_id, rule_id,
                                   body=None):
    rule = prefix_list_rule_patch(ctx, rev, prefix_list_id, rule_id,
                                  {"match": body})
    return rule.get("match", {})


def prefix_list_rule_matches_delete(ctx, rev, prefix_list_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list", prefix_list_id, "rule", rule_id, "match")


############################################################################
# Router/policy/prefix-list/{prefix-list-id}/rule/{rule-id}/match/{match-id}
###########################################################################

def prefix_list_rule_match_get(ctx, rev, prefix_list_id, rule_id, match_id):
    matches = prefix_list_rule_matches_get(ctx, rev, prefix_list_id, rule_id)
    try:
        return matches[match_id]
    except KeyError:
        raise NotFound


def prefix_list_rule_match_patch(ctx, rev, prefix_list_id, rule_id, match_id,
                                 body=None):
    matches = prefix_list_rule_matches_patch(ctx, rev, prefix_list_id, rule_id,
                                             {match_id: body})
    return matches.get(match_id, {})


def prefix_list_rule_match_delete(ctx, rev, prefix_list_id, rule_id, match_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "prefix-list", prefix_list_id, "rule", rule_id,
        "match", match_id)


###############################
# Router/policy/route-maps
###############################

def routemaps_get(ctx, rev):
    return policy_get(ctx, rev)["route-map"]


def routemaps_patch(ctx, rev, body=None):
    policy = policy_patch(ctx, rev, {"route-map": body})
    return policy.get("route-map", {})


def routemaps_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map")


#########################################
# Router/policy/route-map/{route-map-id}
#########################################

def routemap_get(ctx, rev, route_map_id):
    maps = routemaps_get(ctx, rev)
    try:
        return maps[route_map_id]
    except KeyError:
        raise NotFound


def routemap_patch(ctx, rev, route_map_id, body=None):
    rtmaps = routemaps_patch(ctx, rev, {route_map_id: body})
    return rtmaps.get(route_map_id, {})


def routemap_delete(ctx, rev, route_map_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id)


###############################################
# Router/policy/route-map/{route-map-id}/rule
###############################################

def routemap_rules_get(ctx, rev, route_map_id):
    return routemap_get(ctx, rev, route_map_id)["rule"]


def routemap_rules_patch(ctx, rev, route_map_id, body=None):
    rtmap = routemap_patch(ctx, rev, route_map_id, {"rule": body})
    return rtmap.get("rule", {})


def routemap_rules_delete(ctx, rev, route_map_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule")


#######################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id
######################################################

def routemap_rule_get(ctx, rev, route_map_id, rule_id):
    rules = routemap_rules_get(ctx, rev, route_map_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def routemap_rule_patch(ctx, rev, route_map_id, rule_id, body=None):
    rules = routemap_rules_patch(ctx, rev, route_map_id, {rule_id: body})
    return rules.get(rule_id, {})


def routemap_rule_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id)


############################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/match
############################################################

def routemap_rule_match_get(ctx, rev, route_map_id, rule_id):
    return routemap_rule_get(ctx, rev, route_map_id, rule_id)["match"]


def routemap_rule_match_patch(ctx, rev, route_map_id, rule_id, body=None):
    rule = routemap_rule_patch(ctx, rev, route_map_id, rule_id,
                               {"match": body})
    return rule.get("match", {})


def routemap_rule_match_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "match")


############################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/set
############################################################

def routemap_rule_set_get(ctx, rev, route_map_id, rule_id):
    return routemap_rule_get(ctx, rev, route_map_id, rule_id)["set"]


def routemap_rule_set_patch(ctx, rev, route_map_id, rule_id, body=None):
    rule = routemap_rule_patch(ctx, rev, route_map_id, rule_id, {"set": body})
    return rule.get("set", {})


def routemap_rule_set_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "set")


###########################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/as-path-prepend
###########################################################################

def routemap_as_path_prepend_get(ctx, rev, route_map_id, rule_id):
    rule_set = routemap_rule_set_get(ctx, rev, route_map_id, rule_id)
    return rule_set["as-path-prepend"]


def routemap_as_path_prepend_patch(ctx, rev, route_map_id, rule_id, body=None):
    set_rule = routemap_rule_set_patch(ctx, rev, route_map_id,
                                       rule_id, {"as-path-prepend": body})
    return set_rule.get("as-path-prepend", {})


def routemap_as_path_prepend_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "as-path-prepend")


####################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/community
####################################################################

def routemap_communities_get(ctx, rev, route_map_id, rule_id):
    rule_set = routemap_rule_set_get(ctx, rev, route_map_id, rule_id)
    return rule_set["community"]


def routemap_communities_patch(ctx, rev, route_map_id, rule_id, body=None):
    set_rule = routemap_rule_set_patch(ctx, rev, route_map_id,
                                       rule_id, {"community": body})
    return set_rule.get("community", {})


def routemap_communities_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "community")


####################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/
# community/{community-id}
####################################################################

def routemap_community_get(ctx, rev, route_map_id, rule_id, community_id):
    comms = routemap_communities_get(ctx, rev, route_map_id, rule_id)
    try:
        return comms[community_id]
    except KeyError:
        raise NotFound


def routemap_community_patch(ctx, rev, route_map_id, rule_id, community_id,
                             body=None):
    comms = routemap_communities_patch(
        ctx, rev, route_map_id,
        rule_id, {community_id: body})
    return comms.get(community_id, {})


def routemap_community_delete(ctx, rev, route_map_id, rule_id, community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "community", community_id)


############################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/large-community
############################################################################

def routemap_large_communities_get(ctx, rev, route_map_id, rule_id):
    rule_set = routemap_rule_set_get(ctx, rev, route_map_id, rule_id)
    return rule_set["large-community"]


def routemap_large_communities_patch(ctx, rev, route_map_id, rule_id,
                                     body=None):
    set_rule = routemap_rule_set_patch(ctx, rev, route_map_id,
                                       rule_id, {"large-community": body})
    return set_rule.get("large-community", {})


def routemap_large_communities_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "large-community")


#########################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/
# large-community/{large-community-id}
#########################################################################

def routemap_large_community_get(ctx, rev, route_map_id, rule_id,
                                 large_community_id):
    comms = routemap_large_communities_get(ctx, rev, route_map_id, rule_id)
    try:
        return comms[large_community_id]
    except KeyError:
        raise NotFound


def routemap_large_community_patch(
        ctx, rev, route_map_id, rule_id, large_community_id, body=None):
    comms = routemap_large_communities_patch(
        ctx, rev, route_map_id,
        rule_id, {large_community_id: body})
    return comms.get(large_community_id, {})


def routemap_large_community_delete(ctx, rev, route_map_id, rule_id,
                                    large_community_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "large-community", large_community_id)


############################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/aggregator-as
############################################################################

def routemap_aggregator_ases_get(ctx, rev, route_map_id, rule_id):
    rule_set = routemap_rule_set_get(ctx, rev, route_map_id, rule_id)
    return rule_set["aggregator-as"]


def routemap_aggregator_ases_patch(ctx, rev, route_map_id, rule_id,
                                   body=None):
    set_rule = routemap_rule_set_patch(ctx, rev, route_map_id,
                                       rule_id, {"aggregator-as": body})
    return set_rule.get("aggregator-as", {})


def routemap_aggregator_ases_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "aggregator-as")


#########################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/
# aggregator-as/{asn-id}
#########################################################################

def routemap_aggregator_as_get(ctx, rev, route_map_id, rule_id, asn_id):
    aggs = routemap_aggregator_ases_get(ctx, rev, route_map_id, rule_id)
    try:
        return aggs[asn_id]
    except KeyError:
        raise NotFound


def routemap_aggregator_as_patch(
        ctx, rev, route_map_id, rule_id, asn_id, body=None):
    aggs = routemap_aggregator_ases_patch(
        ctx, rev, route_map_id,
        rule_id, {asn_id: body})
    return aggs.get(asn_id, {})


def routemap_aggregator_as_delete(ctx, rev, route_map_id, rule_id, asn_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "aggregator-as", asn_id)


#########################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/
# aggregator-as/{asn-id}/address
#########################################################################

def routemap_aggregator_as_addrs_get(ctx, rev, route_map_id, rule_id, asn_id):
    aggs = routemap_aggregator_as_get(ctx, rev, route_map_id, rule_id, asn_id)
    return aggs["address"]


def routemap_aggregator_as_addrs_patch(
        ctx, rev, route_map_id, rule_id, asn_id, body=None):
    aggs = routemap_aggregator_as_patch(
        ctx, rev, route_map_id,
        rule_id, asn_id, {"address": body})
    return aggs.get("address", {})


def routemap_aggregator_as_addrs_delete(ctx, rev, route_map_id, rule_id,
                                        asn_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "aggregator-as", asn_id, "address")


#########################################################################
# Router/policy/route-map/{route-map-id}/rule/{rule-id}/set/
# aggregator-as/{asn-id}/address/{addr-id}
#########################################################################

def routemap_aggregator_as_addr_get(ctx, rev, route_map_id, rule_id,
                                    asn_id, addr_id):
    aggs = routemap_aggregator_as_addrs_get(ctx, rev, route_map_id,
                                            rule_id, asn_id)
    try:
        return aggs[addr_id]
    except KeyError:
        raise NotFound


def routemap_aggregator_as_addr_patch(
        ctx, rev, route_map_id, rule_id, asn_id, addr_id, body=None):
    aggs = routemap_aggregator_as_addrs_patch(
        ctx, rev, route_map_id,
        rule_id, asn_id, {addr_id: body})
    return aggs.get(addr_id, {})


def routemap_aggregator_as_addr_delete(ctx, rev, route_map_id, rule_id,
                                       asn_id, addr_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule",
        rule_id, "set", "aggregator-as", asn_id, "address", addr_id)


############################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/action
############################################################

def routemap_rule_action_get(ctx, rev, route_map_id, rule_id):
    return routemap_rule_get(ctx, rev, route_map_id, rule_id)["action"]


def routemap_rule_action_patch(ctx, rev, route_map_id, rule_id, body=None):
    rule = routemap_rule_patch(ctx, rev, route_map_id, rule_id,
                               {"action": body})
    return rule.get("action", {})


def routemap_rule_action_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "action")


####################################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/action/permit
####################################################################

def action_deny_get(ctx, rev, route_map_id, rule_id):
    return routemap_rule_action_get(ctx, rev, route_map_id, rule_id)["deny"]


def action_deny_patch(ctx, rev, route_map_id, rule_id, body=None):
    action = routemap_rule_action_patch(ctx, rev, route_map_id, rule_id,
                                        {"deny": body})
    return action.get("deny", {})


def action_deny_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "action",
        "deny")


####################################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/action/permit
####################################################################

def action_permit_get(ctx, rev, route_map_id, rule_id):
    return routemap_rule_action_get(ctx, rev, route_map_id, rule_id)["permit"]


def action_permit_patch(ctx, rev, route_map_id, rule_id, body=None):
    action = routemap_rule_action_patch(ctx, rev, route_map_id, rule_id,
                                        {"permit": body})
    return action.get("permit", {})


def action_permit_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "action",
        "permit")


###############################################################################
# Router/policy/route-map/{route-map-id}/rule/rule-id/action/permit/exit-policy
###############################################################################

def action_permit_exit_policy_get(ctx, rev, route_map_id, rule_id):
    return action_permit_get(ctx, rev, route_map_id, rule_id)["exit-policy"]


def action_permit_exit_policy_patch(ctx, rev, route_map_id, rule_id,
                                    body=None):
    permit = action_permit_patch(ctx, rev, route_map_id, rule_id,
                                 {"exit-policy": body})
    return permit.get("exit-policy", {})


def action_permit_exit_policy_delete(ctx, rev, route_map_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRouter, ctx.config_v1.setRouter, rev,
        "policy", "route-map", route_map_id, "rule", rule_id, "action",
        "permit", "exit-policy")


###############################
# BGP
###############################

def bgp_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getBgp(rev)

    # We will not show the operational state as of now.
    raise NotFound


def bgp_patch(ctx, rev, body=None):
    router = router_patch(ctx, rev, {"bgp": body})
    return router.get("bgp", {})


def bgp_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBgp, ctx.config_v1.setBgp, rev)


###############################
# Router/BGP/graceful-restart
###############################

def bgp_graceful_restart_get(ctx, rev):
    return bgp_get(ctx, rev)["graceful-restart"]


def bgp_graceful_restart_patch(ctx, rev, body=None):
    bgp = bgp_patch(ctx, rev, {"graceful-restart": body})
    return bgp.get("graceful-restart", {})


def bgp_graceful_restart_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getBgp, ctx.config_v1.setBgp, rev,
        "graceful-restart")


###############################
# Router/BGP/graceful-restart
###############################

# TODO: CUE-3808
def bgp_convergence_wait_get(ctx, rev):
    return bgp_get(ctx, rev)["convergence-wait"]


def bgp_convergence_wait_patch(ctx, rev, body=None):
    bgp = bgp_patch(ctx, rev, {"convergence-wait": body})
    return bgp["convergence-wait"]


def bgp_convergence_wait_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
       ctx.config_v1.getBgp, ctx.config_v1.setBgp, rev,
       "convergence-wait")


###############################
# OSPF
###############################

def ospf_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getOspf(rev)

    # We will not show the operational state as of now.
    raise NotFound


def ospf_patch(ctx, rev, body=None):
    router = router_patch(ctx, rev, {"ospf": body})
    return router.get("ospf", {})


def ospf_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getOspf, ctx.config_v1.setOspf, rev)


###############################
# OSPF/timers
###############################

def ospf_timers_get(ctx, rev):
    return ospf_get(ctx, rev)["timers"]


def ospf_timers_patch(ctx, rev, body=None):
    ospf = ospf_patch(ctx, rev, {"timers": body})
    return ospf.get("timers", {})


def ospf_timers_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getOspf, ctx.config_v1.setOspf, rev, "timers")


###############################
# OSPF/lsa-timers
###############################

def ospf_lsa_timers_get(ctx, rev):
    return ospf_timers_get(ctx, rev)["lsa"]


def ospf_lsa_timers_patch(ctx, rev, body=None):
    timers = ospf_timers_patch(ctx, rev, {"lsa": body})
    return timers.get("lsa", {})


def ospf_lsa_timers_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getOspf, ctx.config_v1.setOspf, rev, "timers", "lsa")


###############################
# OSPF/spf-timers
###############################

def ospf_spf_timers_get(ctx, rev):
    return ospf_timers_get(ctx, rev)["spf"]


def ospf_spf_timers_patch(ctx, rev, body=None):
    timers = ospf_timers_patch(ctx, rev, {"spf": body})
    return timers.get("spf", {})


def ospf_spf_timers_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getOspf, ctx.config_v1.setOspf, rev, "timers", "spf")
