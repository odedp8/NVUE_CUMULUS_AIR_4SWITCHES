# Copyright (C) 2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from pydash import py_
from cue_cue_v1.root import root_patch


###############################
# port-mirror
###############################

def mirror_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPortMirror(rev)

    return ctx.switchd_v1.getPortMirror()


def mirror_patch(ctx, rev, body=None):
    body = {'system':
            {'port-mirror': body}}
    root = root_patch(ctx, rev, body)
    return py_.get(root, 'system.port-mirror', default={})


def mirror_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirror,
                             ctx.config_v1.setPortMirror,
                             rev)


########################################
# port-mirror/sessions
########################################

def sessions_get(ctx, rev):
    mirror = mirror_get(ctx, rev)
    return mirror.get('session', {})


def sessions_patch(ctx, rev, body=None):
    mirror = mirror_patch(ctx, rev, {'session': body})
    return mirror.get('session', {})


def sessions_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSessions,
                             ctx.config_v1.setPortMirrorSessions,
                             rev)

########################################
# port-mirror/session/{session_id}
########################################


def session_get(ctx, rev, session_id):
    sessions = sessions_get(ctx, rev)
    return sessions.get(session_id, {})


def session_patch(ctx, rev, session_id, body=None):
    sessions = sessions_patch(ctx, rev, {session_id: body})
    return sessions.get(session_id, {})


def session_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id)

##########################################
# port-mirror/session/{session_id}/span
##########################################


def span_get(ctx, rev, session_id):
    session = session_get(ctx, rev, session_id)
    return session.get('span', {})


def span_patch(ctx, rev, session_id, body=None):
    # patch the session.  Return the span object from the patch
    session = session_patch(ctx, rev, session_id,
                            {'span': body})
    return session.get('span', {})


def span_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "span")

#################################################
# port-mirror/session/{session_id}/span/src-port
#################################################


def span_src_port_get(ctx, rev, session_id):
    span = span_get(ctx, rev, session_id)
    return span.get('src-port', {})


def span_src_port_patch(ctx, rev, session_id, body=None):
    # patch the span src-port object
    span = span_patch(ctx, rev, session_id,
                      {'src-port': body})
    return span.get('src-port', {})


def span_src_port_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "span",
                             "src-port")

####################################################
# port-mirror/session/{session_id}/span/destination
####################################################


def span_destination_get(ctx, rev, session_id):
    span = span_get(ctx, rev, session_id)
    return span.get('destination', {})


def span_destination_patch(ctx, rev, session_id, body=None):
    # patch the span/destination object
    span = span_patch(ctx, rev, session_id,
                      {'destination': body})
    return span.get('destination', {})


def span_destination_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "span", "destination")


####################################################
# port-mirror/session/{session_id}/span/truncate
####################################################


def span_truncate_get(ctx, rev, session_id):
    span = span_get(ctx, rev, session_id)
    return span.get('truncate', {})


def span_truncate_patch(ctx, rev, session_id, body=None):
    # patch the span/truncate object
    span = span_patch(ctx, rev, session_id,
                      {'truncate': body})
    return span.get('truncate', {})


def span_truncate_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "span", "truncate")


##########################################
# port-mirror/session/{session_id}/erspan
##########################################

def erspan_get(ctx, rev, session_id):
    session = session_get(ctx, rev, session_id)
    return session.get('erspan', {})


def erspan_patch(ctx, rev, session_id, body=None):
    # patch the session.  Return the erspan object from the patch
    session = session_patch(ctx, rev, session_id,
                            {'erspan': body})
    return session.get('erspan', {})


def erspan_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan")


##########################################
# port-mirror/session/{session_id}/erspan/src-port
##########################################

def erspan_src_port_get(ctx, rev, session_id):
    erspan = erspan_get(ctx, rev, session_id)
    return erspan.get('src-port', {})


def erspan_src_port_patch(ctx, rev, session_id, body=None):
    # patch the session.  Return the erspan object from the patch
    erspan = erspan_patch(ctx, rev, session_id,
                          {'src-port': body})
    return erspan.get('src-port', {})


def erspan_src_port_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan", "src-port")


##########################################
# port-mirror/session/{session_id}/erspan/destination
##########################################

def erspan_destination_get(ctx, rev, session_id):
    erspan = erspan_get(ctx, rev, session_id)
    return erspan.get('destination', {})


def erspan_destination_patch(ctx, rev, session_id, body=None):
    # patch the session.  Return the erspan object from the patch
    erspan = erspan_patch(ctx, rev, session_id,
                          {'destination': body})
    return erspan.get('destination', {})


def erspan_destination_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan", "destination")


##########################################
# port-mirror/session/{session_id}/erspan/truncate
##########################################

def erspan_truncate_get(ctx, rev, session_id):
    erspan = erspan_get(ctx, rev, session_id)
    return erspan.get('truncate', {})


def erspan_truncate_patch(ctx, rev, session_id, body=None):
    # patch the session.  Return the erspan object from the patch
    erspan = erspan_patch(ctx, rev, session_id,
                          {'truncate': body})
    return erspan.get('truncate', {})


def erspan_truncate_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan", "truncate")


##########################################
# port-mirror/session/{session_id}/erspan/destination/src-ip
##########################################

def erspan_destination_src_ip_get(ctx, rev, session_id):
    erspan_destination = erspan_destination_get(ctx, rev, session_id)
    return erspan_destination.get('src-ip', {})


def erspan_destination_src_ip_patch(ctx, rev, session_id, body=None):
    erspan_destination = erspan_destination_patch(ctx, rev, session_id,
                                                  {'src-ip': body})
    return erspan_destination.get('src-ip', {})


def erspan_destination_src_ip_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan", "destination", "src-ip")


##########################################
# port-mirror/session/{session_id}/erspan/destination/dst-ip
##########################################

def erspan_destination_dst_ip_get(ctx, rev, session_id):
    erspan_destination = erspan_destination_get(ctx, rev, session_id)
    return erspan_destination.get('dst-ip', {})


def erspan_destination_dst_ip_patch(ctx, rev, session_id, body=None):
    erspan_destination = erspan_destination_patch(ctx, rev, session_id,
                                                  {'dst-ip': body})
    return erspan_destination.get('dst-ip', {})


def erspan_destination_dst_ip_delete(ctx, rev, session_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPortMirrorSession,
                             ctx.config_v1.setPortMirrorSession,
                             rev,
                             session_id,
                             "erspan", "destination", "dst-ip")
