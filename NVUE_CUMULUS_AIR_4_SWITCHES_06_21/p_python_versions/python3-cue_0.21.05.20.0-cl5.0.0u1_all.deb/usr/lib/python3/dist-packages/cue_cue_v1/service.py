# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux services: /usr/share/cumulus/EULA.txt


from cue_cue_v1.root import root_patch
from cue.exceptions import NotFound


###############################
# Service
###############################

def service_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getService(rev)

    # Todo
    return {}


def service_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"service": body})
    return root.get("service", {})


def service_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getService,
                             ctx.config_v1.setService, rev)


###############################
# syslog
###############################

def syslogs_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getSyslogs(rev)

    # Todo
    return {}


def syslogs_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"syslog": body})
    return service["syslog"]


def syslogs_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getSyslogs,
                             ctx.config_v1.setSyslogs,
                             rev)


###############################
# syslog/{vrf-id}
###############################

def syslog_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getSyslog(rev, vrf_id)

    # Todo
    return {}


def syslog_patch(ctx, rev, vrf_id, body=None):
    syslogs = syslogs_patch(ctx, rev, {vrf_id: body})
    return syslogs[vrf_id]


def syslog_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getSyslog, ctx.config_v1.setSyslog,
                             rev, vrf_id)


###############################
# syslog/{vrf-id}/servers
###############################

def syslog_servers_get(ctx, rev, vrf_id):
    if rev != "operational":
        slog = syslog_get(ctx, rev, vrf_id)
        return slog["server"]
    return ctx.rsyslog_v1.getRsyslogServers(vrf_id)


def syslog_servers_patch(ctx, rev, vrf_id, body=None):
    slog = syslog_patch(ctx, rev, vrf_id,
                        {"server": body})
    return slog["server"]


def syslog_servers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getSyslog, ctx.config_v1.setSyslog,
        rev, vrf_id, "server")


###############################
# syslog/{vrf-id}/server
###############################

def syslog_server_get(ctx, rev, vrf_id, syslog_server_id):
    servers = syslog_servers_get(ctx, rev, vrf_id)
    try:
        return servers[syslog_server_id]
    except KeyError:
        raise NotFound


def syslog_server_patch(ctx, rev, vrf_id, syslog_server_id, body=None):
    servers = syslog_servers_patch(ctx, rev, vrf_id,
                                   {syslog_server_id: body})
    return servers[syslog_server_id]


def syslog_server_delete(ctx, rev, vrf_id, syslog_server_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getSyslog, ctx.config_v1.setSyslog, rev,
        vrf_id, "server", syslog_server_id)


###############################
# LLDP
###############################

def lldp_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getLldp(rev)
    return ctx.lldp_v1.getLldpConfig()


def lldp_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getLldp, ctx.config_v1.setLldp, rev,
        patch=body)


def lldp_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getLldp, ctx.config_v1.setLldp, rev)


###############################
# DNS
###############################

def dnss_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getDnss(rev)

    # Todo
    return {}


def dnss_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getDnss, ctx.config_v1.setDnss, rev, patch=body)


def dnss_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDnss, ctx.config_v1.setDnss, rev)


###############################
# DNS/{vrf_id}
###############################

def dns_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getDns(rev, vrf_id)

    # Todo
    return {}


def dns_patch(ctx, rev, vrf_id, body=None):
    dnss = dnss_patch(ctx, rev, {vrf_id: body})
    return dnss[vrf_id]


def dns_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDns,
                             ctx.config_v1.setDns, rev, vrf_id)


###############################
# DNS/{vrf_id}/server
###############################

def dns_servers_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getDns(rev, vrf_id)["server"]

    return ctx.dns_v1.getServers()[vrf_id]["server"]


def dns_servers_patch(ctx, rev, vrf_id, body=None):
    dns = dns_patch(ctx, rev, vrf_id, {"server": body})
    return dns["server"]


def dns_servers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getDns, ctx.config_v1.setDns, rev,
        vrf_id, "server")


def dns_server_get(ctx, rev, vrf_id, dns_server_id):
    if rev != "operational":
        dns = ctx.config_v1.getDns(rev, vrf_id)
        return dns["server"][dns_server_id]


def dns_server_patch(ctx, rev, vrf_id, dns_server_id, body=None):
    s = dns_servers_patch(ctx, rev, vrf_id, {dns_server_id: body})
    return s[dns_server_id]


def dns_server_delete(ctx, rev, vrf_id, dns_server_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getDns, ctx.config_v1.setDns, rev, vrf_id,
        "server", dns_server_id)


# def host_entries_get(ctx, rev):
#    if rev != "operational":
#        return ctx.config_v1.getHostEntries(rev)
#
#    return ctx.dns_v1.getHostEntries()
#
#
# def host_entries_patch(ctx, rev, body=None):
#    ops = ctx.cue_v1._ops
#    body = ops.pre_patch(rev, body)
#    return ops.patch_config(
#        ctx.config_v1.getHostEntries, ctx.config_v1.setHostEntries, rev,
#        patch=body)
#
#
# def host_entries_delete(ctx, rev):
#    ops = ctx.cue_v1._ops
#    ops.pre_delete(rev)
#    return ops.delete_config(ctx.config_v1.setHostEntries, rev)
#
#
# def host_entry_get(ctx, rev, host_entry_id):
#    if rev != "operational":
#        return ctx.config_v1.getHostEntry(rev, host_entry_id)
#
#    return ctx.dns_v1.getHostEntry(host_entry_id)
#
#
# def host_entry_patch(ctx, rev, host_entry_id, body=None):
#    ops = ctx.cue_v1._ops
#    body = ops.pre_patch(rev, body)
#    return ops.patch_config(
#        ctx.config_v1.getHostEntry, ctx.config_v1.setHostEntry, rev,
#        host_entry_id, patch=body)
#
#
# def host_entry_delete(ctx, rev, host_entry_id):
#    ops = ctx.cue_v1._ops
#    ops.pre_delete(rev)
#    return ops.delete_config(ctx.config_v1.setHostEntry, rev, host_entry_id)
