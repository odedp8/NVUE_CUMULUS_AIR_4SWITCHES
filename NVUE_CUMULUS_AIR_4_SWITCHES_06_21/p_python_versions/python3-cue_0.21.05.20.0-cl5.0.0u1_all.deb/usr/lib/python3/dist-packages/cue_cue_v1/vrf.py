# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from pydash import py_
from cue_cue_v1.root import root_patch


###############################
# Vrfs
###############################
def vrfs_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getVrfs(rev)

    vrfs = py_.clone_deep(ctx.netlink_v1.getVrfs())

    # Fill in an empty router and service object for now.  Later, we'll start
    # calling FUnits to get real data.
    for vrf in vrfs.values():
        vrf["router"] = {}
        vrf["service"] = {}

    return vrfs


def vrfs_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"vrf": body})
    return root.get("vrf", {})


def vrfs_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrfs, ctx.config_v1.setVrfs, rev)


###############################
# Vrf
###############################
def vrf_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getVrf(rev, vrf_id)

    vrf = py_.clone_deep(ctx.netlink_v1.getVrf(vrf_id))

    # Fill in an empty router and service object for now.  Later, we'll start
    # calling FUnits to get real data.
    vrf["router"] = {}
    vrf["service"] = {}

    return vrf


def vrf_patch(ctx, rev, vrf_id, body=None):
    vrfs = vrfs_patch(ctx, rev, {vrf_id: body})
    return vrfs.get(vrf_id, {})


def vrf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (vrf_id,)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, *path)


###############################
# Loopback
###############################
def loopback_get(ctx, rev, vrf_id):
    return vrf_get(ctx, rev, vrf_id)["loopback"]


def loopback_patch(ctx, rev, vrf_id, body=None):
    vrf = vrf_patch(ctx, rev, vrf_id, {"loopback": body})
    return vrf.get("loopback", {})


def loopback_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, vrf_id, "loopback")


###############################
# Router
###############################
def router_get(ctx, rev, vrf_id):
    return vrf_get(ctx, rev, vrf_id)["router"]


def router_patch(ctx, rev, vrf_id, body=None):
    vrf = vrf_patch(ctx, rev, vrf_id, {"router": body})
    return vrf.get("router", {})


def router_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, vrf_id, "router")


###############################
# BGP
###############################

def bgp_get(ctx, rev, vrf_id):
    if rev != "operational":
        return router_get(ctx, rev, vrf_id)["bgp"]

    # We will not show the operational state as of now.
    raise NotFound


def bgp_patch(ctx, rev, vrf_id, body=None):
    route = router_patch(ctx, rev, vrf_id, {"bgp": body})
    return route.get("bgp", {})


def bgp_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp")


###############################
# BGP/AddressFamily
###############################

def bgp_addr_family_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["address-family"]


def bgp_addr_family_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"address-family": body})
    return bgp.get("address-family", {})


def bgp_addr_family_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family")


###############################
# BGP/AddressFamily/ipv4-unicast
###############################

def addr_family_v4_ucast_get(ctx, rev, vrf_id):
    return bgp_addr_family_get(ctx, rev, vrf_id)["ipv4-unicast"]


def addr_family_v4_ucast_patch(ctx, rev, vrf_id, body=None):
    af = bgp_addr_family_patch(ctx, rev, vrf_id, {"ipv4-unicast": body})
    return af.get("ipv4-unicast", {})


def addr_family_v4_ucast_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast")


###############################
# BGP/AddressFamily/ipv4-unicast/redistribute
###############################

def route_redistribution_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["redistribute"]


def route_redistribution_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"redistribute": body})
    return v4_ucast.get("redistribute", {})


def route_redistribution_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "redistribute")


##############################################
# BGP/AddressFamily/ipv4-unicast/route-export
##############################################

def route_export_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["route-export"]


def route_export_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"route-export": body})
    return v4_ucast.get("route-export", {})


def route_export_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "route-export")


################################################
# BGP/AddressFamily/ipv4-unicast/route-import
################################################

def route_import_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["route-import"]


def route_import_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"route-import": body})
    return v4_ucast.get("route-import", {})


def route_import_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "route-import")


#######################################################
# BGP/AddressFamily/ipv4-unicast/route-import/from-vrf
######################################################

def route_import_from_vrf_get(ctx, rev, vrf_id):
    return route_import_get(ctx, rev, vrf_id)["from-vrf"]


def route_import_from_vrf_patch(ctx, rev, vrf_id, body=None):
    rt_import = route_import_patch(
        ctx, rev, vrf_id, {"from-vrf": body})
    return rt_import.get("from-vrf", {})


def route_import_from_vrf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "route-import", "from-vrf")


##################################################################
# BGP/AddressFamily/ipv4-unicast/route-import/from-vrf/list
##################################################################

def route_import_from_vrf_list_get(ctx, rev, vrf_id):
    return route_import_from_vrf_get(ctx, rev, vrf_id)["list"]


def route_import_from_vrf_list_patch(ctx, rev, vrf_id, body=None):
    rt_import = route_import_from_vrf_patch(
        ctx, rev, vrf_id, {"list": body})
    return rt_import.get("list", {})


def route_import_from_vrf_list_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "route-import", "from-vrf", "list")


################################################
# BGP/AddressFamily/ipv4-unicast/aggregate-routes
################################################

def aggregate_routes_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["aggregate-route"]


def aggregate_routes_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"aggregate-route": body})
    return v4_ucast.get("aggregate-route", {})


def aggregate_routes_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "aggregate-route")


################################################################
# BGP/AddressFamily/ipv4-unicast/aggregate-routes/{aggregate-route-id}
################################################################

def aggregate_route_get(ctx, rev, vrf_id, aggregate_route_id):
    return aggregate_routes_get(ctx, rev, vrf_id)[aggregate_route_id]


def aggregate_route_patch(ctx, rev, vrf_id, aggregate_route_id, body=None):
    agg_rts = aggregate_routes_patch(
        ctx, rev, vrf_id, {aggregate_route_id: body})
    return agg_rts.get(aggregate_route_id, {})


def aggregate_route_delete(ctx, rev, vrf_id, aggregate_route_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "aggregate-route", aggregate_route_id)


################################################
# BGP/AddressFamily/ipv4-unicast/static-networks
################################################

def static_networks_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["static-network"]


def static_networks_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"static-network": body})
    return v4_ucast.get("static-network", {})


def static_networks_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "static-network")


##################################################################
# BGP/AddressFamily/ipv4-unicast/static-network/{static-network-id}
####################################################################

def static_network_get(ctx, rev, vrf_id, static_network_id):
    return static_networks_get(ctx, rev, vrf_id)[static_network_id]


def static_network_patch(ctx, rev, vrf_id, static_network_id, body=None):
    st_nws = static_networks_patch(
        ctx, rev, vrf_id, {static_network_id: body})
    return st_nws.get(static_network_id, {})


def static_network_delete(ctx, rev, vrf_id, static_network_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "static-network", static_network_id)


################################################
# BGP/AddressFamily/ipv4-unicast/multipaths
################################################

def multipaths_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["multipaths"]


def multipaths_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"multipaths": body})
    return v4_ucast.get("multipaths", {})


def multipaths_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "multipaths")


################################################
# BGP/AddressFamily/ipv4-unicast/admin-distance
################################################

def admin_distance_get(ctx, rev, vrf_id):
    return addr_family_v4_ucast_get(ctx, rev, vrf_id)["admin-distance"]


def admin_distance_patch(ctx, rev, vrf_id, body=None):
    v4_ucast = addr_family_v4_ucast_patch(
        ctx, rev, vrf_id, {"admin-distance": body})
    return v4_ucast.get("admin-distance", {})


def admin_distance_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "admin-distance")


######################################################
# BGP/AddressFamily/ipv4-unicast/route-export/to-evpn
#####################################################

def route_export_to_evpn_get(ctx, rev, vrf_id):
    return route_export_get(ctx, rev, vrf_id)["to-evpn"]


def route_export_to_evpn_patch(ctx, rev, vrf_id, body=None):
    route_export = route_export_patch(
        ctx, rev, vrf_id, {"to-evpn": body})
    return route_export.get("to-evpn", {})


def route_export_to_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "route-export", "to-evpn")


###############################
# BGP/AddressFamily/ipv4-unicast/redistribute/static
###############################

def static_get(ctx, rev, vrf_id):
    return route_redistribution_get(ctx, rev, vrf_id)["static"]


def static_patch(ctx, rev, vrf_id, body=None):
    rr = route_redistribution_patch(ctx, rev, vrf_id, {"static": body})
    return rr.get("static", {})


def static_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "redistribute", "static")


###############################
# BGP/AddressFamily/ipv4-unicast/redistribute/connected
###############################

def connected_get(ctx, rev, vrf_id):
    return route_redistribution_get(ctx, rev, vrf_id)["connected"]


def connected_patch(ctx, rev, vrf_id, body=None):
    rr = route_redistribution_patch(ctx, rev, vrf_id, {"connected": body})
    return rr.get("connected", {})


def connected_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "redistribute", "connected")


###############################
# BGP/AddressFamily/ipv4-unicast/redistribute/kernel
###############################

def kernel_get(ctx, rev, vrf_id):
    return route_redistribution_get(ctx, rev, vrf_id)["kernel"]


def kernel_patch(ctx, rev, vrf_id, body=None):
    rr = route_redistribution_patch(ctx, rev, vrf_id, {"kernel": body})
    return rr.get("kernel", {})


def kernel_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "redistribute", "kernel")


###############################
# BGP/AddressFamily/ipv4-unicast/redistribute/ospf
###############################

def v4_ospf_get(ctx, rev, vrf_id):
    return route_redistribution_get(ctx, rev, vrf_id)["ospf"]


def v4_ospf_patch(ctx, rev, vrf_id, body=None):
    rr = route_redistribution_patch(ctx, rev, vrf_id, {"ospf": body})
    return rr.get("ospf", {})


def v4_ospf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv4-unicast",
        "redistribute", "ospf")


###############################
# BGP/AddressFamily/ipv6-unicast
###############################

def addr_family_v6_ucast_get(ctx, rev, vrf_id):
    return bgp_addr_family_get(ctx, rev, vrf_id)["ipv6-unicast"]


def addr_family_v6_ucast_patch(ctx, rev, vrf_id, body=None):
    af = bgp_addr_family_patch(ctx, rev, vrf_id, {"ipv6-unicast": body})
    return af.get("ipv6-unicast", {})


def addr_family_v6_ucast_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast")


######################################################
# BGP/AddressFamily/ipv6-unicast/aggregate-routes
######################################################

def v6_aggregate_routes_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["aggregate-route"]


def v6_aggregate_routes_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"aggregate-route": body})
    return v6_ucast.get("aggregate-route", {})


def v6_aggregate_routes_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "aggregate-route")


################################################################
# BGP/AddressFamily/ipv6-unicast/aggregate-routes/{aggregate-route-id}
################################################################

def v6_aggregate_route_get(ctx, rev, vrf_id, aggregate_route_id):
    return v6_aggregate_routes_get(ctx, rev, vrf_id)[aggregate_route_id]


def v6_aggregate_route_patch(ctx, rev, vrf_id, aggregate_route_id, body=None):
    agg_rts = v6_aggregate_routes_patch(
        ctx, rev, vrf_id, {aggregate_route_id: body})
    return agg_rts.get(aggregate_route_id, {})


def v6_aggregate_route_delete(ctx, rev, vrf_id, aggregate_route_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "aggregate-route", aggregate_route_id)


#####################################################################
# BGP/AddressFamily/ipv6-unicast/static-networks
####################################################################

def v6_static_networks_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["static-network"]


def v6_static_networks_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"static-network": body})
    return v6_ucast.get("static-network", {})


def v6_static_networks_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "static-network")


################################################################
# BGP/AddressFamily/ipv6-unicast/static-network/{static-network_id}
################################################################

def v6_static_network_get(ctx, rev, vrf_id, static_network_id):
    return v6_static_networks_get(ctx, rev, vrf_id)[static_network_id]


def v6_static_network_patch(ctx, rev, vrf_id, static_network_id, body=None):
    st_nws = v6_static_networks_patch(
        ctx, rev, vrf_id, {static_network_id: body})
    return st_nws.get(static_network_id, {})


def v6_static_network_delete(ctx, rev, vrf_id, static_network_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "static-network", static_network_id)


######################################################
# BGP/AddressFamily/ipv6-unicast/route-import
######################################################

def v6_route_import_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["route-import"]


def v6_route_import_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"route-import": body})
    return v6_ucast.get("route-import", {})


def v6_route_import_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "route-import")


#######################################################
# BGP/AddressFamily/ipv6-unicast/route-import/from-vrf
######################################################

def v6_route_import_from_vrf_get(ctx, rev, vrf_id):
    return v6_route_import_get(ctx, rev, vrf_id)["from-vrf"]


def v6_route_import_from_vrf_patch(ctx, rev, vrf_id, body=None):
    rt_import = v6_route_import_patch(
        ctx, rev, vrf_id, {"from-vrf": body})
    return rt_import.get("from-vrf", {})


def v6_route_import_from_vrf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "route-import", "from-vrf")


###################################################################
# BGP/AddressFamily/ipv6-unicast/route-import/from-vrf/list
##################################################################

def v6_route_import_from_vrf_list_get(ctx, rev, vrf_id):
    return v6_route_import_from_vrf_get(ctx, rev, vrf_id)["list"]


def v6_route_import_from_vrf_list_patch(ctx, rev, vrf_id, body=None):
    rt_import = v6_route_import_from_vrf_patch(
        ctx, rev, vrf_id, {"list": body})
    return rt_import.get("list", {})


def v6_route_import_from_vrf_list_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "route-import", "from-vrf", "list")


######################################################
# BGP/AddressFamily/ipv6-unicast/multipaths
######################################################

def v6_multipaths_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["multipaths"]


def v6_multipaths_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"multipaths": body})
    return v6_ucast.get("multipaths", {})


def v6_multipaths_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "multipaths")


######################################################
# BGP/AddressFamily/ipv6-unicast/admin-distance
######################################################

def v6_admin_distance_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["admin-distance"]


def v6_admin_distance_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"admin-distance": body})
    return v6_ucast.get("admin-distance", {})


def v6_admin_distance_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "admin-distance")


######################################################
# BGP/AddressFamily/ipv6-unicast/route-export
######################################################

def v6_route_export_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["route-export"]


def v6_route_export_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"route-export": body})
    return v6_ucast.get("route-export", {})


def v6_route_export_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "route-export")


######################################################
# BGP/AddressFamily/ipv6-unicast/route-export/to-evpn
######################################################

def v6_route_export_to_evpn_get(ctx, rev, vrf_id):
    return v6_route_export_get(ctx, rev, vrf_id)["to-evpn"]


def v6_route_export_to_evpn_patch(ctx, rev, vrf_id, body=None):
    v6_rt_export = v6_route_export_patch(
        ctx, rev, vrf_id, {"to-evpn": body})
    return v6_rt_export.get("to-evpn", {})


def v6_route_export_to_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "route-export", "to-evpn")


######################################################
# BGP/AddressFamily/ipv6-unicast/redistribute
######################################################

def v6_route_redistribution_get(ctx, rev, vrf_id):
    return addr_family_v6_ucast_get(ctx, rev, vrf_id)["redistribute"]


def v6_route_redistribution_patch(ctx, rev, vrf_id, body=None):
    v6_ucast = addr_family_v6_ucast_patch(
        ctx, rev, vrf_id, {"redistribute": body})
    return v6_ucast.get("redistribute", {})


def v6_route_redistribution_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "redistribute")


###############################
# BGP/AddressFamily/ipv6-unicast/redistribute/static
###############################

def v6_static_get(ctx, rev, vrf_id):
    return v6_route_redistribution_get(ctx, rev, vrf_id)["static"]


def v6_static_patch(ctx, rev, vrf_id, body=None):
    rr = v6_route_redistribution_patch(ctx, rev, vrf_id, {"static": body})
    return rr.get("static", {})


def v6_static_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "redistribute", "static")


###############################
# BGP/AddressFamily/ipv6-unicast/redistribute/connected
###############################

def v6_connected_get(ctx, rev, vrf_id):
    return v6_route_redistribution_get(ctx, rev, vrf_id)["connected"]


def v6_connected_patch(ctx, rev, vrf_id, body=None):
    rr = v6_route_redistribution_patch(ctx, rev, vrf_id, {"connected": body})
    return rr.get("connected", {})


def v6_connected_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "redistribute", "connected")


###############################
# BGP/AddressFamily/ipv6-unicast/redistribute/kernel
###############################

def v6_kernel_get(ctx, rev, vrf_id):
    return v6_route_redistribution_get(ctx, rev, vrf_id)["kernel"]


def v6_kernel_patch(ctx, rev, vrf_id, body=None):
    rr = v6_route_redistribution_patch(ctx, rev, vrf_id, {"kernel": body})
    return rr.get("kernel", {})


def v6_kernel_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "redistribute", "kernel")


###############################
# BGP/AddressFamily/ipv6-unicast/redistribute/ospf
###############################

def v6_ospf_get(ctx, rev, vrf_id):
    return v6_route_redistribution_get(ctx, rev, vrf_id)["ospf6"]


def v6_ospf_patch(ctx, rev, vrf_id, body=None):
    rr = v6_route_redistribution_patch(ctx, rev, vrf_id, {"ospf6": body})
    return rr.get("ospf6", {})


def v6_ospf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "ipv6-unicast",
        "redistribute", "ospf6")


###############################
# BGP/AddressFamily/l2vpn-evpn
###############################

def l2vpn_evpn_get(ctx, rev, vrf_id):
    return bgp_addr_family_get(ctx, rev, vrf_id)["l2vpn-evpn"]


def l2vpn_evpn_patch(ctx, rev, vrf_id, body=None):
    af = bgp_addr_family_patch(ctx, rev, vrf_id, {"l2vpn-evpn": body})
    return af.get("l2vpn-evpn", {})


def l2vpn_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "address-family", "l2vpn-evpn")


###############################
# BGP/path-selection
###############################

def bgp_path_selection_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["path-selection"]


def bgp_path_selection_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"path-selection": body})
    return bgp.get("path-selection", {})


def bgp_path_selection_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "path-selection")


###############################
# BGP/path-selection/aspath
###############################

def bgp_path_selection_aspath_get(ctx, rev, vrf_id):
    return bgp_path_selection_get(ctx, rev, vrf_id)["aspath"]


def bgp_path_selection_aspath_patch(ctx, rev, vrf_id, body=None):
    ps = bgp_path_selection_patch(ctx, rev, vrf_id, {"aspath": body})
    return ps.get("aspath", {})


def bgp_path_selection_aspath_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "path-selection", "aspath")


###############################
# BGP/path-selection/med
###############################

def bgp_path_selection_med_get(ctx, rev, vrf_id):
    return bgp_path_selection_get(ctx, rev, vrf_id)["med"]


def bgp_path_selection_med_patch(ctx, rev, vrf_id, body=None):
    ps = bgp_path_selection_patch(ctx, rev, vrf_id, {"med": body})
    return ps.get("med", {})


def bgp_path_selection_med_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "path-selection", "med")


###############################
# BGP/path-selection/multipath
###############################

def bgp_path_selection_multipath_get(ctx, rev, vrf_id):
    return bgp_path_selection_get(ctx, rev, vrf_id)["multipath"]


def bgp_path_selection_multipath_patch(ctx, rev, vrf_id, body=None):
    ps = bgp_path_selection_patch(ctx, rev, vrf_id, {"multipath": body})
    return ps.get("multipath", {})


def bgp_path_selection_multipath_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "path-selection", "multipath")


###############################
# BGP/route-reflection
###############################

def bgp_route_reflection_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["route-reflection"]


def bgp_route_reflection_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"route-reflection": body})
    return bgp.get("route-reflection", {})


def bgp_route_reflection_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-reflection")


###############################
# BGP/peer-groups
###############################

def bgp_peer_groups_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["peer-group"]


def bgp_peer_groups_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"peer-group": body})
    return bgp.get("peer-group", {})


def bgp_peer_groups_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group")


###############################
# BGP/peer-group
###############################

def bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id):
    peer_groups = bgp_peer_groups_get(ctx, rev, vrf_id)
    try:
        return peer_groups[peer_group_id]
    except KeyError:
        raise NotFound


def bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peer_groups = bgp_peer_groups_patch(ctx, rev, vrf_id,
                                        {peer_group_id: body})
    return peer_groups.get(peer_group_id, {})


def bgp_peer_group_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id)


##############################################
# BGP/peer-group/{peer-group-id}/local-as
##############################################

def bgp_local_as_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id)["local-as"]


def bgp_local_as_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"local-as": body})
    return peerg.get("local-as", {})


def bgp_local_as_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "local-as")


##############################################
# BGP/peer-group/{peer-group-id}/capabilities
##############################################

def bgp_capabilities_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id)["capabilities"]


def bgp_capabilities_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"capabilities": body})
    return peerg.get("capabilities", {})


def bgp_capabilities_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "capabilities")


##############################################
# BGP/peer-group/{peer-group-id}/ttl-security
##############################################

def bgp_ttl_security_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id)["ttl-security"]


def bgp_ttl_security_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"ttl-security": body})
    return peerg.get("ttl-security", {})


def bgp_ttl_security_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "ttl-security")


#####################################
# BGP/peer-group/{peer-group-id}/bfd
####################################

def bgp_peer_group_bfd_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id)["bfd"]


def bgp_peer_group_bfd_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"bfd": body})
    return peerg.get("bfd", {})


def bgp_peer_group_bfd_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id, "bfd")


###############################
# BGP/peer-group/timers
###############################

def bgp_peer_group_timers_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id, peer_group_id)["timers"]


def bgp_peer_group_timers_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"timers": body})
    return peerg.get("timers", {})


def bgp_peer_group_timers_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id, "timers")


###############################
# BGP/peer-group/address-family
###############################

def bgp_peer_group_addr_family_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_get(ctx, rev, vrf_id,
                              peer_group_id)["address-family"]


def bgp_peer_group_addr_family_patch(ctx, rev, vrf_id, peer_group_id,
                                     body=None):
    peerg = bgp_peer_group_patch(ctx, rev, vrf_id, peer_group_id,
                                 {"address-family": body})
    return peerg.get("address-family", {})


def bgp_peer_group_addr_family_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id, "address-family")


##############################################
# BGP/peer-group/address-family/ipv4-unicast
##############################################

def peer_group_af_v4_ucast_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_addr_family_get(ctx, rev, vrf_id,
                                          peer_group_id)["ipv4-unicast"]


def peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    af = bgp_peer_group_addr_family_patch(ctx, rev, vrf_id, peer_group_id,
                                          {"ipv4-unicast": body})
    return af.get("ipv4-unicast", {})


def peer_group_af_v4_ucast_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast")


############################################################
# BGP/peer-group/address-family/ipv4-unicast/attribute-mod
###########################################################

def peer_group_v4_attribute_mod_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["attribute-mod"]


def peer_group_v4_attribute_mod_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"attribute-mod": body})
    return v4_ucast.get("attribute-mod", {})


def peer_group_v4_attribute_mod_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "attribute-mod")


#####################################################################
# BGP/peer-group/address-family/ipv4-unicast/community-advertise
#####################################################################

def peer_group_af_v4_comm_advts_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["community-advertise"]


def peer_group_af_v4_comm_advts_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"community-advertise": body})
    return af.get("community-advertise", {})


def peer_group_af_v4_comm_advts_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "community-advertise")


############################################################
# BGP/peer-group/address-family/ipv4-unicast/aspath
###########################################################

def peer_group_v4_aspath_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["aspath"]


def peer_group_v4_aspath_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"aspath": body})
    return v4_ucast.get("aspath", {})


def peer_group_v4_aspath_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "aspath")


#################################################################
# BGP/peer-group/address-family/ipv4-unicast/aspath/allow-my-asn
#################################################################

def peer_group_v4_allow_my_as_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_v4_aspath_get(ctx, rev, vrf_id,
                                    peer_group_id)["allow-my-asn"]


def peer_group_v4_allow_my_as_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    as_patch = peer_group_v4_aspath_patch(ctx, rev, vrf_id, peer_group_id,
                                          {"allow-my-asn": body})
    return as_patch.get("allow-my-asn", {})


def peer_group_v4_allow_my_as_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "aspath", "allow-my-asn")


############################################################
# BGP/peer-group/address-family/ipv4-unicast/prefix-limits
###########################################################

def peer_group_v4_prefix_limits_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["prefix-limits"]


def peer_group_v4_prefix_limits_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"prefix-limits": body})
    return v4_ucast.get("prefix-limits", {})


def peer_group_v4_prefix_limits_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "prefix-limits")


####################################################################
# BGP/peer-group/address-family/ipv4-unicast/prefix-limits/inbound
###################################################################

def peer_group_v4_prefix_limits_inbound_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_v4_prefix_limits_get(ctx, rev, vrf_id,
                                           peer_group_id)["inbound"]


def peer_group_v4_prefix_limits_inbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_v4_prefix_limits_patch(
        ctx, rev, vrf_id, peer_group_id, {"inbound": body})
    return v4_ucast.get("inbound", {})


def peer_group_v4_prefix_limits_inbound_delete(
        ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "prefix-limits", "inbound")


############################################################
# BGP/peer-group/address-family/ipv4-unicast/policy
###########################################################

def peer_group_v4_policy_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["policy"]


def peer_group_v4_policy_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"policy": body})
    return v4_ucast.get("policy", {})


def peer_group_v4_policy_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "policy")


############################################################
# BGP/peer-group/address-family/ipv4-unicast/policy/inbound
###########################################################

def peer_group_v4_policy_inbound_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_v4_policy_get(ctx, rev, vrf_id,
                                    peer_group_id)["inbound"]


def peer_group_v4_policy_inbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    policy = peer_group_v4_policy_patch(ctx, rev, vrf_id, peer_group_id,
                                        {"inbound": body})
    return policy.get("inbound", {})


def peer_group_v4_policy_inbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "policy", "inbound")


###############################################################
# BGP/peer-group/address-family/ipv4-unicast/policy/outbound
##############################################################

def peer_group_v4_policy_outbound_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_v4_policy_get(ctx, rev, vrf_id,
                                    peer_group_id)["outbound"]


def peer_group_v4_policy_outbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    policy = peer_group_v4_policy_patch(ctx, rev, vrf_id, peer_group_id,
                                        {"outbound": body})
    return policy.get("outbound", {})


def peer_group_v4_policy_outbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "policy", "outbound")


#######################################################################
# BGP/peer-group/address-family/ipv4-unicast/default-route-origination
#######################################################################

def peer_group_v4_def_rt_origin_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(
        ctx, rev, vrf_id, peer_group_id)["default-route-origination"]


def peer_group_v4_def_rt_origin_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(
        ctx, rev, vrf_id, peer_group_id, {"default-route-origination": body})
    return v4_ucast.get("default-route-origination", {})


def peer_group_v4_def_rt_origin_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "default-route-origination")


#######################################################################
# BGP/peer-group/address-family/ipv4-unicast/conditional-advertise
#######################################################################

def peer_group_af_v4_cond_advts_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v4_ucast_get(
        ctx, rev, vrf_id, peer_group_id)["conditional-advertise"]


def peer_group_af_v4_cond_advts_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v4_ucast = peer_group_af_v4_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"conditional-advertise": body})
    return v4_ucast.get("conditional-advertise", {})


def peer_group_af_v4_cond_advts_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv4-unicast", "conditional-advertise")


##############################################
# BGP/peer-group/address-family/ipv6-unicast
##############################################

def peer_group_af_v6_ucast_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_addr_family_get(ctx, rev, vrf_id,
                                          peer_group_id)["ipv6-unicast"]


def peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    af = bgp_peer_group_addr_family_patch(ctx, rev, vrf_id, peer_group_id,
                                          {"ipv6-unicast": body})
    return af.get("ipv6-unicast", {})


def peer_group_af_v6_ucast_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast")


#########################################################
# BGP/peer-group/address-family/ipv6-unicast/aspath
##########################################################

def peer_group_af_v6_aspath_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["aspath"]


def peer_group_af_v6_aspath_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"aspath": body})
    return af.get("aspath", {})


def peer_group_af_v6_aspath_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "aspath")


#################################################################
# BGP/peer-group/address-family/ipv6-unicast/aspath/allow-my-asn
################################################################

def peer_group_af_v6_allow_my_as_get(
        ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_aspath_get(ctx, rev, vrf_id,
                                       peer_group_id)["allow-my-asn"]


def peer_group_af_v6_allow_my_as_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_aspath_patch(ctx, rev, vrf_id, peer_group_id,
                                       {"allow-my-asn": body})
    return af.get("allow-my-asn", {})


def peer_group_af_v6_allow_my_as_delete(
        ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "aspath", "allow-my-asn")


#########################################################
# BGP/peer-group/address-family/ipv6-unicast/policy
##########################################################

def peer_group_af_v6_policy_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["policy"]


def peer_group_af_v6_policy_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"policy": body})
    return af.get("policy", {})


def peer_group_af_v6_policy_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "policy")


##############################################################
# BGP/peer-group/address-family/ipv6-unicast/policy/inbound
##############################################################

def peer_group_af_v6_policy_inbound_get(
        ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_policy_get(ctx, rev, vrf_id,
                                       peer_group_id)["inbound"]


def peer_group_af_v6_policy_inbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_policy_patch(ctx, rev, vrf_id, peer_group_id,
                                       {"inbound": body})
    return af.get("inbound", {})


def peer_group_af_v6_policy_inbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "policy", "inbound")


##############################################################
# BGP/peer-group/address-family/ipv6-unicast/policy/outbound
##############################################################

def peer_group_af_v6_policy_outbound_get(
        ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_policy_get(ctx, rev, vrf_id,
                                       peer_group_id)["outbound"]


def peer_group_af_v6_policy_outbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_policy_patch(ctx, rev, vrf_id, peer_group_id,
                                       {"outbound": body})
    return af.get("outbound", {})


def peer_group_af_v6_policy_outbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "policy", "outbound")


###############################################################
# BGP/peer-group/address-family/ipv6-unicast/prefix-limits
###############################################################

def peer_group_af_v6_prefix_limits_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["prefix-limits"]


def peer_group_af_v6_prefix_limits_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"prefix-limits": body})
    return af.get("prefix-limits", {})


def peer_group_af_v6_prefix_limits_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "prefix-limits")


#####################################################################
# BGP/peer-group/address-family/ipv6-unicast/prefix-limits/inbound
####################################################################

def peer_group_af_v6_prefix_limits_inbound_get(
        ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_prefix_limits_get(
        ctx, rev, vrf_id, peer_group_id)["inbound"]


def peer_group_af_v6_prefix_limits_inbound_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_prefix_limits_patch(ctx, rev, vrf_id, peer_group_id,
                                              {"inbound": body})
    return af.get("inbound", {})


def peer_group_af_v6_prefix_limits_inbound_delete(
        ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "prefix-limits", "inbound")


###################################################################
# BGP/peer-group/address-family/ipv6-unicast/attribute-mod
##################################################################

def peer_group_af_v6_attribute_mod_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["attribute-mod"]


def peer_group_af_v6_attribute_mod_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"attribute-mod": body})
    return af.get("attribute-mod", {})


def peer_group_af_v6_attribute_mod_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "attribute-mod")


########################################################################
# BGP/peer-group/address-family/ipv6-unicast/default-route-origination
#######################################################################

def peer_group_af_v6_def_rt_origin_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(
        ctx, rev, vrf_id, peer_group_id)["default-route-origination"]


def peer_group_af_v6_def_rt_origin_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"default-route-origination": body})
    return af.get("default-route-origination", {})


def peer_group_af_v6_def_rt_origin_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "default-route-origination")


#####################################################################
# BGP/peer-group/address-family/ipv6-unicast/community-advertise
#####################################################################

def peer_group_af_v6_comm_advts_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(ctx, rev, vrf_id,
                                      peer_group_id)["community-advertise"]


def peer_group_af_v6_comm_advts_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    af = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                      {"community-advertise": body})
    return af.get("community-advertise", {})


def peer_group_af_v6_comm_advts_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "community-advertise")


#######################################################################
# BGP/peer-group/address-family/ipv6-unicast/conditional-advertise
#######################################################################

def peer_group_af_v6_cond_advts_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_v6_ucast_get(
        ctx, rev, vrf_id, peer_group_id)["conditional-advertise"]


def peer_group_af_v6_cond_advts_patch(
        ctx, rev, vrf_id, peer_group_id, body=None):
    v6_ucast = peer_group_af_v6_ucast_patch(ctx, rev, vrf_id, peer_group_id,
                                            {"conditional-advertise": body})
    return v6_ucast.get("conditional-advertise", {})


def peer_group_af_v6_cond_advts_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "ipv6-unicast", "conditional-advertise")


##############################################
# BGP/peer-group/address-family/l2vpn-evpn
##############################################

def peer_group_af_l2vpn_evpn_get(ctx, rev, vrf_id, peer_group_id):
    return bgp_peer_group_addr_family_get(ctx, rev, vrf_id,
                                          peer_group_id)["l2vpn-evpn"]


def peer_group_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    af = bgp_peer_group_addr_family_patch(ctx, rev, vrf_id, peer_group_id,
                                          {"l2vpn-evpn": body})
    return af.get("l2vpn-evpn", {})


def peer_group_af_l2vpn_evpn_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/attribute-mod
################################################################

def l2vpn_attribute_mod_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_group_id)["attribute-mod"]


def l2vpn_attribute_mod_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = peer_group_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_group_id,
                                         {"attribute-mod": body})
    return vpn.get("attribute-mod", {})


def l2vpn_attribute_mod_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "attribute-mod")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/aspath
################################################################

def l2vpn_aspath_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_group_id)["aspath"]


def l2vpn_aspath_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = peer_group_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_group_id,
                                         {"aspath": body})
    return vpn.get("aspath", {})


def l2vpn_aspath_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "aspath")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/aspath/allow-my-asn
################################################################

def l2vpn_allow_my_as_get(ctx, rev, vrf_id, peer_group_id):
    return l2vpn_aspath_get(
        ctx, rev, vrf_id, peer_group_id)["allow-my-asn"]


def l2vpn_allow_my_as_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = l2vpn_aspath_patch(ctx, rev, vrf_id, peer_group_id,
                             {"allow-my-asn": body})
    return vpn.get("allow-my-asn", {})


def l2vpn_allow_my_as_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "aspath", "allow-my-asn")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/policy
################################################################

def l2vpn_policy_get(ctx, rev, vrf_id, peer_group_id):
    return peer_group_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_group_id)["policy"]


def l2vpn_policy_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = peer_group_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_group_id,
                                         {"policy": body})
    return vpn.get("policy", {})


def l2vpn_policy_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "policy")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/policy/inbound
################################################################

def l2vpn_policy_inbound_get(ctx, rev, vrf_id, peer_group_id):
    return l2vpn_policy_get(
        ctx, rev, vrf_id, peer_group_id)["inbound"]


def l2vpn_policy_inbound_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = l2vpn_policy_patch(ctx, rev, vrf_id, peer_group_id,
                             {"inbound": body})
    return vpn.get("inbound", {})


def l2vpn_policy_inbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "policy", "inbound")


################################################################
# BGP/peer-group/address-family/l2vpn-evpn/policy/outbound
################################################################

def l2vpn_policy_outbound_get(ctx, rev, vrf_id, peer_group_id):
    return l2vpn_policy_get(
        ctx, rev, vrf_id, peer_group_id)["outbound"]


def l2vpn_policy_outbound_patch(ctx, rev, vrf_id, peer_group_id, body=None):
    vpn = l2vpn_policy_patch(ctx, rev, vrf_id, peer_group_id,
                             {"outbound": body})
    return vpn.get("outbound", {})


def l2vpn_policy_outbound_delete(ctx, rev, vrf_id, peer_group_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer-group", peer_group_id,
        "address-family", "l2vpn-evpn", "policy", "outbound")


###############################
# BGP/route-export
###############################

def bgp_route_export_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["route-export"]


def bgp_route_export_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"route-export": body})
    return bgp.get("route-export", {})


def bgp_route_export_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-export")


###############################
# BGP/route-export/to-evpn
###############################

def bgp_rt_export_to_evpn_get(ctx, rev, vrf_id):
    return bgp_route_export_get(ctx, rev, vrf_id)["to-evpn"]


def bgp_rt_export_to_evpn_patch(ctx, rev, vrf_id, body=None):
    rt_exp = bgp_route_export_patch(ctx, rev, vrf_id, {"to-evpn": body})
    return rt_exp.get("to-evpn", {})


def bgp_rt_export_to_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-export", "to-evpn")


###########################################
# BGP/route-export/to-evpn/route-target
##########################################

def bgp_rt_export_to_evpn_rt_targets_get(ctx, rev, vrf_id):
    return bgp_rt_export_to_evpn_get(ctx, rev, vrf_id)["route-target"]


def bgp_rt_export_to_evpn_rt_targets_patch(ctx, rev, vrf_id, body=None):
    rt_exp = bgp_rt_export_to_evpn_patch(ctx, rev, vrf_id,
                                         {"route-target": body})
    return rt_exp.get("route-target", {})


def bgp_rt_export_to_evpn_rt_targets_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-export", "to-evpn", "route-target")


###########################################
# BGP/route-export/to-evpn/route-target/{rt-id}
##########################################

def bgp_rt_export_to_evpn_rt_target_get(ctx, rev, vrf_id, rt_id):
    rts = bgp_rt_export_to_evpn_rt_targets_get(ctx, rev, vrf_id)
    try:
        return rts[rt_id]
    except KeyError:
        raise NotFound


def bgp_rt_export_to_evpn_rt_target_patch(ctx, rev, vrf_id, rt_id, body=None):
    rt_exp = bgp_rt_export_to_evpn_rt_targets_patch(
        ctx, rev, vrf_id, {rt_id: body})
    return rt_exp.get(rt_id, {})


def bgp_rt_export_to_evpn_rt_target_delete(ctx, rev, vrf_id, rt_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-export", "to-evpn", "route-target",
        rt_id)


############################################
# vrf/{vrf-id}/router/bgp/route-import
############################################

def bgp_route_import_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["route-import"]


def bgp_route_import_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"route-import": body})
    return bgp.get("route-import", {})


def bgp_route_import_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-import")


#######################################################
# vrf/{vrf-id}/router/bgp/route-import/from-evpn
#######################################################

def bgp_from_evpn_get(ctx, rev, vrf_id):
    return bgp_route_import_get(ctx, rev, vrf_id)["from-evpn"]


def bgp_from_evpn_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_route_import_patch(ctx, rev, vrf_id, {"from-evpn": body})
    return bgp.get("from-evpn", {})


def bgp_from_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-import", "from-evpn")


################################################################
# vrf/{vrf-id}/router/bgp/route-import/from-evpn/route-target
#################################################################

def bgp_from_evpn_rt_targets_get(ctx, rev, vrf_id):
    return bgp_from_evpn_get(ctx, rev, vrf_id)["route-target"]


def bgp_from_evpn_rt_targets_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_from_evpn_patch(ctx, rev, vrf_id, {"route-target": body})
    return bgp.get("route-target", {})


def bgp_from_evpn_rt_targets_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-import", "from-evpn", "route-target")


################################################################
# vrf/{vrf-id}/router/bgp/route-import/from-evpn/route-target/{rt-id}
#################################################################

def bgp_from_evpn_rt_target_get(ctx, rev, vrf_id, rt_id):
    rts = bgp_from_evpn_rt_targets_get(ctx, rev, vrf_id)
    try:
        return rts[rt_id]
    except KeyError:
        raise NotFound


def bgp_from_evpn_rt_target_patch(ctx, rev, vrf_id, rt_id, body=None):
    bgp = bgp_from_evpn_rt_targets_patch(ctx, rev, vrf_id, {rt_id: body})
    return bgp.get(rt_id, {})


def bgp_from_evpn_rt_target_delete(ctx, rev, vrf_id, rt_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "route-import", "from-evpn", "route-target",
        rt_id)


############################################
# vrf/{vrf-id}/router/bgp/timers
############################################

def bgp_timers_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["timers"]


def bgp_timers_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"timers": body})
    return bgp.get("timers", {})


def bgp_timers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "timers")


############################################
# vrf/{vrf-id}/router/bgp/confederation
############################################

def bgp_confederation_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["confederation"]


def bgp_confederation_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"confederation": body})
    return bgp.get("confederation", {})


def bgp_confederation_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "confederation")


####################################################
# vrf/{vrf-id}/router/bgp/confederation/member-as
####################################################

def bgp_confederation_member_as_get(ctx, rev, vrf_id):
    return bgp_confederation_get(ctx, rev, vrf_id)["member-as"]


def bgp_confederation_member_as_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_confederation_patch(ctx, rev, vrf_id, {"member-as": body})
    return bgp.get("member-as", {})


def bgp_confederation_member_as_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "confederation", "member-as")


###############################
# BGP/peers
###############################

def bgp_peers_get(ctx, rev, vrf_id):
    return bgp_get(ctx, rev, vrf_id)["peer"]


def bgp_peers_patch(ctx, rev, vrf_id, body=None):
    bgp = bgp_patch(ctx, rev, vrf_id, {"peer": body})
    return bgp.get("peer", {})


def bgp_peers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer")


###############################
# BGP/peer
###############################

def bgp_peer_get(ctx, rev, vrf_id, peer_id):
    peers = bgp_peers_get(ctx, rev, vrf_id)
    try:
        return peers[peer_id]
    except KeyError:
        raise NotFound


def bgp_peer_patch(ctx, rev, vrf_id, peer_id, body=None):
    peers = bgp_peers_patch(ctx, rev, vrf_id, {peer_id: body})
    return peers.get(peer_id, {})


def bgp_peer_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id)


###############################
# BGP/peer/address-familty
###############################

def bgp_peer_addr_family_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["address-family"]


def bgp_peer_addr_family_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"address-family": body})
    return peer.get("address-family", {})


def bgp_peer_addr_family_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family")


###############################
# BGP/peer/{peer-id}/bfd
###############################

def bgp_peer_bfd_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["bfd"]


def bgp_peer_bfd_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"bfd": body})
    return peer.get("bfd", {})


def bgp_peer_bfd_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "bfd")


###############################
# BGP/peer/{peer-id}/capabilities
###############################

def bgp_peer_capabilities_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["capabilities"]


def bgp_peer_capabilities_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"capabilities": body})
    return peer.get("capabilities", {})


def bgp_peer_capabilities_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "capabilities")


###############################
# BGP/peer/{peer-id}/local-as
###############################

def bgp_peer_local_as_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["local-as"]


def bgp_peer_local_as_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"local-as": body})
    return peer.get("local-as", {})


def bgp_peer_local_as_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "local-as")


##################################
# BGP/peer/{peer-id}/ttl-security
##################################

def bgp_peer_ttl_security_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["ttl-security"]


def bgp_peer_ttl_security_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"ttl-security": body})
    return peer.get("ttl-security", {})


def bgp_peer_ttl_security_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "ttl-security")


#########################################
# BGP/peer/address-familty/ipv4-unicast
#########################################

def bgp_peer_af_v4ucast_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_addr_family_get(ctx, rev, vrf_id, peer_id)["ipv4-unicast"]


def bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer_af = bgp_peer_addr_family_patch(ctx, rev, vrf_id, peer_id,
                                         {"ipv4-unicast": body})
    return peer_af.get("ipv4-unicast", {})


def bgp_peer_af_v4ucast_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast")


#######################################################
# BGP/peer/address-familty/ipv4-unicast/attribute-mod
######################################################

def bgp_peer_v4_attribute_mod_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(ctx, rev, vrf_id, peer_id)["attribute-mod"]


def bgp_peer_v4_attribute_mod_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"attribute-mod": body})
    return v4_ucast.get("attribute-mod", {})


def bgp_peer_v4_attribute_mod_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "attribute-mod")


#######################################################
# BGP/peer/address-familty/ipv4-unicast/aspath
######################################################

def bgp_peer_v4_aspath_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(ctx, rev, vrf_id, peer_id)["aspath"]


def bgp_peer_v4_aspath_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"aspath": body})
    return v4_ucast.get("aspath", {})


def bgp_peer_v4_aspath_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "aspath")


############################################################
# BGP/peer/address-familty/ipv4-unicast/aspath/allow-my-asn
###########################################################

def bgp_peer_v4_allow_my_as_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v4_aspath_get(ctx, rev, vrf_id, peer_id)["allow-my-asn"]


def bgp_peer_v4_allow_my_as_patch(ctx, rev, vrf_id, peer_id, body=None):
    aspath = bgp_peer_v4_aspath_patch(ctx, rev, vrf_id, peer_id,
                                      {"allow-my-asn": body})
    return aspath.get("allow-my-asn", {})


def bgp_peer_v4_allow_my_as_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "aspath", "allow-my-asn")


###################################################################
# BGP/peer/address-familty/ipv4-unicast/default-route-origination
####################################################################

def bgp_peer_v4_def_rt_origin_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(
        ctx, rev, vrf_id, peer_id)["default-route-origination"]


def bgp_peer_v4_def_rt_origin_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"default-route-origination": body})
    return v4_ucast.get("default-route-origination", {})


def bgp_peer_v4_def_rt_origin_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "default-route-origination")


#######################################################
# BGP/peer/address-familty/ipv4-unicast/policy
######################################################

def bgp_peer_v4_policy_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(ctx, rev, vrf_id, peer_id)["policy"]


def bgp_peer_v4_policy_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"policy": body})
    return v4_ucast.get("policy", {})


def bgp_peer_v4_policy_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "policy")


#########################################################
# BGP/peer/address-familty/ipv4-unicast/policy/inbound
#########################################################

def bgp_peer_v4_policy_inbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v4_policy_get(ctx, rev, vrf_id, peer_id)["inbound"]


def bgp_peer_v4_policy_inbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_v4_policy_patch(ctx, rev, vrf_id, peer_id,
                                        {"inbound": body})
    return v4_ucast.get("inbound", {})


def bgp_peer_v4_policy_inbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "policy", "inbound")


#########################################################
# BGP/peer/address-familty/ipv4-unicast/policy/outbound
#########################################################

def bgp_peer_v4_policy_outbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v4_policy_get(ctx, rev, vrf_id, peer_id)["outbound"]


def bgp_peer_v4_policy_outbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_v4_policy_patch(ctx, rev, vrf_id, peer_id,
                                        {"outbound": body})
    return v4_ucast.get("outbound", {})


def bgp_peer_v4_policy_outbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "policy", "outbound")


#######################################################
# BGP/peer/address-familty/ipv4-unicast/prefix-limits
######################################################

def bgp_peer_v4_prefix_limits_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(ctx, rev, vrf_id, peer_id)["prefix-limits"]


def bgp_peer_v4_prefix_limits_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"prefix-limits": body})
    return v4_ucast.get("prefix-limits", {})


def bgp_peer_v4_prefix_limits_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "prefix-limits")


###############################################################
# BGP/peer/address-familty/ipv4-unicast/prefix-limits/inbound
##############################################################

def bgp_peer_v4_prefix_limits_inbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v4_prefix_limits_get(ctx, rev, vrf_id, peer_id)["inbound"]


def bgp_peer_v4_prefix_limits_inbound_patch(
        ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_v4_prefix_limits_patch(ctx, rev, vrf_id, peer_id,
                                               {"inbound": body})
    return v4_ucast.get("inbound", {})


def bgp_peer_v4_prefix_limits_inbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "prefix-limits", "inbound")


#############################################################
# BGP/peer/address-familty/ipv4-unicast/community-advertise
############################################################

def bgp_peer_v4_comm_advertise_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(
        ctx, rev, vrf_id, peer_id)["community-advertise"]


def bgp_peer_v4_comm_advertise_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"community-advertise": body})
    return v4_ucast.get("community-advertise", {})


def bgp_peer_v4_comm_advertise_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "community-advertise")


#############################################################
# BGP/peer/address-familty/ipv4-unicast/conditional-advertise
############################################################

def bgp_peer_af_v4_cond_advts_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v4ucast_get(
        ctx, rev, vrf_id, peer_id)["conditional-advertise"]


def bgp_peer_af_v4_cond_advts_patch(ctx, rev, vrf_id, peer_id, body=None):
    v4_ucast = bgp_peer_af_v4ucast_patch(ctx, rev, vrf_id, peer_id,
                                         {"conditional-advertise": body})
    return v4_ucast.get("conditional-advertise", {})


def bgp_peer_af_v4_cond_advts_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv4-unicast", "conditional-advertise")


#########################################
# BGP/peer/address-familty/ipv6-unicast
#########################################

def bgp_peer_af_v6ucast_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_addr_family_get(ctx, rev, vrf_id, peer_id)["ipv6-unicast"]


def bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer_af = bgp_peer_addr_family_patch(ctx, rev, vrf_id, peer_id,
                                         {"ipv6-unicast": body})
    return peer_af.get("ipv6-unicast", {})


def bgp_peer_af_v6ucast_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/attribute-mod
#######################################################

def bgp_peer_v6_attribute_mod_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["attribute-mod"]


def bgp_peer_v6_attribute_mod_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"attribute-mod": body})
    return v6ucast.get("attribute-mod", {})


def bgp_peer_v6_attribute_mod_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "attribute-mod")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/aspath
#######################################################

def bgp_peer_v6_aspath_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["aspath"]


def bgp_peer_v6_aspath_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"aspath": body})
    return v6ucast.get("aspath", {})


def bgp_peer_v6_aspath_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "aspath")


#############################################################
# BGP/peer/address-familty/ipv6-unicast/aspath/allow-my-asn
#############################################################

def bgp_peer_v6_allow_my_as_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v6_aspath_get(
        ctx, rev, vrf_id, peer_id)["allow-my-asn"]


def bgp_peer_v6_allow_my_as_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_v6_aspath_patch(ctx, rev, vrf_id, peer_id,
                                       {"allow-my-asn": body})
    return v6ucast.get("allow-my-asn", {})


def bgp_peer_v6_allow_my_as_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "aspath", "allow-my-asn")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/policy
#######################################################

def bgp_peer_v6_policy_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["policy"]


def bgp_peer_v6_policy_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"policy": body})
    return v6ucast.get("policy", {})


def bgp_peer_v6_policy_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "policy")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/policy/inbound
#######################################################

def bgp_peer_v6_policy_inbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v6_policy_get(
        ctx, rev, vrf_id, peer_id)["inbound"]


def bgp_peer_v6_policy_inbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_v6_policy_patch(ctx, rev, vrf_id, peer_id,
                                       {"inbound": body})
    return v6ucast.get("inbound", {})


def bgp_peer_v6_policy_inbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "policy", "inbound")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/policy/outbound
#######################################################

def bgp_peer_v6_policy_outbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v6_policy_get(
        ctx, rev, vrf_id, peer_id)["outbound"]


def bgp_peer_v6_policy_outbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_v6_policy_patch(ctx, rev, vrf_id, peer_id,
                                       {"outbound": body})
    return v6ucast.get("outbound", {})


def bgp_peer_v6_policy_outbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "policy", "outbound")


#######################################################
# BGP/peer/address-familty/ipv6-unicast/prefix-limits
#######################################################

def bgp_peer_v6_prefix_limits_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["prefix-limits"]


def bgp_peer_v6_prefix_limits_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"prefix-limits": body})
    return v6ucast.get("prefix-limits", {})


def bgp_peer_v6_prefix_limits_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "prefix-limits")


##############################################################
# BGP/peer/address-familty/ipv6-unicast/prefix-limits/inbound
##############################################################

def bgp_peer_v6_prefix_limits_inbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_v6_prefix_limits_get(
        ctx, rev, vrf_id, peer_id)["inbound"]


def bgp_peer_v6_prefix_limits_inbound_patch(
        ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_v6_prefix_limits_patch(ctx, rev, vrf_id, peer_id,
                                              {"inbound": body})
    return v6ucast.get("inbound", {})


def bgp_peer_v6_prefix_limits_inbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "prefix-limits", "inbound")


####################################################################
# BGP/peer/address-familty/ipv6-unicast/default-route-origination
###################################################################

def bgp_peer_v6_def_rt_origin_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["default-route-origination"]


def bgp_peer_v6_def_rt_origin_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"default-route-origination": body})
    return v6ucast.get("default-route-origination", {})


def bgp_peer_v6_def_rt_origin_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "default-route-origination")


###############################################################
# BGP/peer/address-familty/ipv6-unicast/community-advertise
###############################################################

def bgp_peer_v6_comm_advts_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["community-advertise"]


def bgp_peer_v6_comm_advts_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"community-advertise": body})
    return v6ucast.get("community-advertise", {})


def bgp_peer_v6_comm_advts_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "community-advertise")


###############################################################
# BGP/peer/address-familty/ipv6-unicast/conditional-advertise
###############################################################

def bgp_peer_af_v6_cond_advts_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_v6ucast_get(
        ctx, rev, vrf_id, peer_id)["conditional-advertise"]


def bgp_peer_af_v6_cond_advts_patch(ctx, rev, vrf_id, peer_id, body=None):
    v6ucast = bgp_peer_af_v6ucast_patch(ctx, rev, vrf_id, peer_id,
                                        {"conditional-advertise": body})
    return v6ucast.get("conditional-advertise", {})


def bgp_peer_af_v6_cond_advts_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "ipv6-unicast", "conditional-advertise")


#########################################
# BGP/peer/address-familty/l2vpn-evpn
#########################################

def bgp_peer_af_l2vpn_evpn_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_addr_family_get(ctx, rev, vrf_id, peer_id)["l2vpn-evpn"]


def bgp_peer_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer_af = bgp_peer_addr_family_patch(ctx, rev, vrf_id, peer_id,
                                         {"l2vpn-evpn": body})
    return peer_af.get("l2vpn-evpn", {})


def bgp_peer_af_l2vpn_evpn_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/attribute-mod
######################################################

def bgp_peer_attribute_mod_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_id)["attribute-mod"]


def bgp_peer_attribute_mod_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_id,
                                               {"attribute-mod": body})
    return l2_vpn_evpn.get("attribute-mod", {})


def bgp_peer_attribute_mod_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "attribute-mod")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/aspath
######################################################

def bgp_peer_aspath_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_id)["aspath"]


def bgp_peer_aspath_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_id,
                                               {"aspath": body})
    return l2_vpn_evpn.get("aspath", {})


def bgp_peer_aspath_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "aspath")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/aspath/allow-my-asn
######################################################

def bgp_peer_allow_my_as_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_aspath_get(
        ctx, rev, vrf_id, peer_id)["allow-my-asn"]


def bgp_peer_allow_my_as_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_aspath_patch(ctx, rev, vrf_id, peer_id,
                                        {"allow-my-asn": body})
    return l2_vpn_evpn.get("allow-my-asn", {})


def bgp_peer_allow_my_as_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "aspath", "allow-my-asn")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/policy
######################################################

def bgp_peer_policy_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_af_l2vpn_evpn_get(
        ctx, rev, vrf_id, peer_id)["policy"]


def bgp_peer_policy_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_af_l2vpn_evpn_patch(ctx, rev, vrf_id, peer_id,
                                               {"policy": body})
    return l2_vpn_evpn.get("policy", {})


def bgp_peer_policy_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "policy")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/policy/inbound
######################################################

def bgp_peer_policy_inbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_policy_get(
        ctx, rev, vrf_id, peer_id)["inbound"]


def bgp_peer_policy_inbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_policy_patch(ctx, rev, vrf_id, peer_id,
                                        {"inbound": body})
    return l2_vpn_evpn.get("inbound", {})


def bgp_peer_policy_inbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "policy", "inbound")


######################################################
# BGP/peer/address-familty/l2vpn-evpn/policy/outbound
######################################################

def bgp_peer_policy_outbound_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_policy_get(
        ctx, rev, vrf_id, peer_id)["outbound"]


def bgp_peer_policy_outbound_patch(ctx, rev, vrf_id, peer_id, body=None):
    l2_vpn_evpn = bgp_peer_policy_patch(ctx, rev, vrf_id, peer_id,
                                        {"outbound": body})
    return l2_vpn_evpn.get("outbound", {})


def bgp_peer_policy_outbound_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "address-family",
        "l2vpn-evpn", "policy", "outbound")


###############################
# BGP/peer/timers
###############################

def bgp_peer_timers_get(ctx, rev, vrf_id, peer_id):
    return bgp_peer_get(ctx, rev, vrf_id, peer_id)["timers"]


def bgp_peer_timers_patch(ctx, rev, vrf_id, peer_id, body=None):
    peer = bgp_peer_patch(ctx, rev, vrf_id, peer_id, {"timers": body})
    return peer.get("timers", {})


def bgp_peer_timers_delete(ctx, rev, vrf_id, peer_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "bgp", "peer", peer_id, "timers")


###############################
# Static/routes
###############################

def static_routes_get(ctx, rev, vrf_id):
    if rev != "operational":
        return router_get(ctx, rev, vrf_id)["static"]

    # We will not show the operational state as of now.
    raise NotFound


def static_routes_patch(ctx, rev, vrf_id, body=None):
    route = router_patch(ctx, rev, vrf_id, {"static": body})
    return route.get("static", {})


def static_routes_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static")


###############################
# Static/route
###############################

def static_route_get(ctx, rev, vrf_id, route_id):
    static_routes = static_routes_get(ctx, rev, vrf_id)
    try:
        return static_routes[route_id]
    except KeyError:
        raise NotFound


def static_route_patch(ctx, rev, vrf_id, route_id, body=None):
    static_routes = static_routes_patch(ctx, rev, vrf_id, {route_id: body})
    return static_routes.get(route_id, {})


def static_route_delete(ctx, rev, vrf_id, route_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id)


###############################
# Static/route/vias
###############################

def static_route_vias_get(ctx, rev, vrf_id, route_id):
    static_route = static_route_get(ctx, rev, vrf_id, route_id)
    return static_route.get("via", {})


def static_route_vias_patch(ctx, rev, vrf_id, route_id, body=None):
    static_route = static_route_patch(ctx, rev, vrf_id, route_id,
                                      {"via": body})
    return static_route.get("via", {})


def static_route_vias_delete(ctx, rev, vrf_id, route_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "via")


###############################
# Static/route/via
###############################

def static_route_via_get(ctx, rev, vrf_id, route_id, via_id):
    next_hops = static_route_vias_get(ctx, rev, vrf_id, route_id)
    try:
        return next_hops[via_id]
    except KeyError:
        raise NotFound


def static_route_via_patch(
        ctx, rev, vrf_id, route_id, via_id, body=None):
    nhs = static_route_vias_patch(
        ctx, rev, vrf_id, route_id, {via_id: body})
    return nhs.get(via_id, {})


def static_route_via_delete(ctx, rev, vrf_id, route_id, via_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "via", via_id)


###############################
# Static/route/via/flag
###############################

def static_route_via_flag_get(ctx, rev, vrf_id, route_id, via_id):
    next_hop = static_route_via_get(
        ctx, rev, vrf_id, route_id, via_id)
    return next_hop.get("flag", {})


def static_route_via_flag_patch(
        ctx, rev, vrf_id, route_id, via_id, body=None):
    nh = static_route_via_patch(
        ctx, rev, vrf_id, route_id, via_id, {"flag": body})
    return nh.get("flag", {})


def static_route_via_flag_delete(ctx, rev, vrf_id, route_id, via_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "via", via_id, "flag")


##################################
# Static/route/distances
##################################

def static_route_distances_get(ctx, rev, vrf_id, route_id):
    static_route = static_route_get(ctx, rev, vrf_id, route_id)
    return static_route.get("distance", {})


def static_route_distances_patch(ctx, rev, vrf_id, route_id, body=None):
    static_route = static_route_patch(ctx, rev, vrf_id, route_id,
                                      {"distance": body})
    return static_route.get("distance", {})


def static_route_distances_delete(ctx, rev, vrf_id, route_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "distance")


###############################
# Static/route/distance
###############################

def static_route_distance_get(ctx, rev, vrf_id, route_id, distance_id):
    distances = static_route_distances_get(ctx, rev, vrf_id, route_id)
    try:
        return distances[distance_id]
    except KeyError:
        raise NotFound


def static_route_distance_patch(ctx, rev, vrf_id, route_id, distance_id,
                                body=None):
    distances = static_route_distances_patch(ctx, rev, vrf_id, route_id,
                                             {distance_id: body})
    return distances.get(distance_id, {})


def static_route_distance_delete(ctx, rev, vrf_id, route_id, distance_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "distance", distance_id)


#########################################
# Static/route/distance/vias
########################################

def static_route_distance_vias_get(ctx, rev, vrf_id, route_id, distance_id):

    distance = static_route_distance_get(
        ctx, rev, vrf_id, route_id, distance_id)
    return distance.get("via", {})


def static_route_distance_vias_patch(ctx, rev, vrf_id, route_id, distance_id,
                                     body=None):
    distance = static_route_distance_patch(ctx, rev, vrf_id, route_id,
                                           distance_id, {"via": body})
    return distance.get("via", {})


def static_route_distance_vias_delete(ctx, rev, vrf_id, route_id, distance_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id,
        "distance", distance_id, "via")


#########################################
# Static/route/distance/via
########################################

def static_route_distance_via_get(
        ctx, rev, vrf_id, route_id, distance_id, via_id):
    nhs = static_route_distance_vias_get(
        ctx, rev, vrf_id, route_id, distance_id)
    try:
        return nhs[via_id]
    except KeyError:
        raise NotFound


def static_route_distance_via_patch(
        ctx, rev, vrf_id, route_id, distance_id, via_id, body=None):
    nhs = static_route_distance_vias_patch(
        ctx, rev, vrf_id, route_id, distance_id, {via_id: body})
    return nhs.get(via_id, {})


def static_route_distance_via_delete(
        ctx, rev, vrf_id, route_id, distance_id, via_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id,
        "distance", distance_id, "via", via_id)


##############################################
# Static/route/alternatepath/via/flag
##############################################

def static_route_distance_via_flag_get(
        ctx, rev, vrf_id, route_id, distance_id, via_id):
    next_hop = static_route_distance_via_get(
        ctx, rev, vrf_id, route_id, distance_id, via_id)
    return next_hop.get("flag", {})


def static_route_distance_via_flag_patch(
        ctx, rev, vrf_id, route_id, distance_id, via_id, body=None):
    nh = static_route_distance_via_patch(
        ctx, rev, vrf_id, route_id, distance_id, via_id, {"flag": body})
    return nh.get("flag", {})


def static_route_distance_via_flag_delete(
        ctx, rev, vrf_id, route_id, distance_id, via_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "static", route_id, "distance", distance_id,
        "via", via_id, "flag")


###############################
# IP
###############################

def ip_get(ctx, rev, vrf_id):
    return loopback_get(ctx, rev, vrf_id)["ip"]


def ip_patch(ctx, rev, vrf_id, body=None):
    iface = loopback_patch(ctx, rev, vrf_id, {"ip": body})
    return iface.get("ip", {})


def ip_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "loopback", "ip")


###############################
# IP Addresses
###############################

def ip_addresses_get(ctx, rev, vrf_id):
    return ip_get(ctx, rev, vrf_id)["address"]


def ip_addresses_patch(ctx, rev, vrf_id, body=None):
    ip = ip_patch(ctx, rev, vrf_id, {"address": body})
    return ip.get("address", {})


def ip_addresses_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "loopback", "ip", "address")


###############################
# IP Address
###############################

def ip_address_get(ctx, rev, vrf_id, ip_prefix_id):
    addresses = ip_addresses_get(ctx, rev, vrf_id)
    try:
        return addresses[ip_prefix_id]
    except KeyError:
        raise NotFound


def ip_address_patch(ctx, rev, vrf_id, ip_prefix_id, body=None):
    addresses = ip_addresses_patch(ctx, rev, vrf_id, {ip_prefix_id: body})
    return addresses.get(ip_prefix_id, {})


def ip_address_delete(ctx, rev, vrf_id, ip_prefix_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "loopback", "ip", "address", ip_prefix_id)


###############################
# Evpn
###############################
def vrf_evpn_get(ctx, rev, vrf_id):
    output = vrf_get(ctx, rev, vrf_id)
    try:
        return output["evpn"]
    except KeyError:
        raise NotFound


def vrf_evpn_patch(ctx, rev, vrf_id, body=None):
    vrf = vrf_patch(ctx, rev, vrf_id, {"evpn": body})
    return vrf.get("evpn", {})


def vrf_evpn_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "evpn")


###############################
# L3 VNIs
###############################

def vrf_vnis_get(ctx, rev, vrf_id):
    output = vrf_evpn_get(ctx, rev, vrf_id)
    try:
        return output["vni"]
    except KeyError:
        raise NotFound


def vrf_vnis_patch(ctx, rev, vrf_id, body=None):
    vrf = vrf_evpn_patch(ctx, rev, vrf_id, {"vni": body})
    return vrf.get("vni", {})


def vrf_vnis_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "evpn", "vni")


###############################
# L3 VNI
###############################

def vrf_vni_get(ctx, rev, vrf_id, vni_id):
    vnis = vrf_vnis_get(ctx, rev, vrf_id)
    try:
        return vnis[vni_id]
    except KeyError:
        raise NotFound


def vrf_vni_patch(ctx, rev, vrf_id, vni_id, body=None):
    vnis = vrf_vnis_patch(ctx, rev, vrf_id, {vni_id: body})
    return vnis.get(vni_id, {})


def vrf_vni_delete(ctx, rev, vrf_id, vni_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "vni", vni_id)


###############################
# Service
###############################

def service_get(ctx, rev, vrf_id):
    return vrf_get(ctx, rev, vrf_id)["service"]


def service_patch(ctx, rev, vrf_id, body=None):
    vrf = vrf_patch(ctx, rev, vrf_id, {"service": body})
    return vrf.get("service", {})


def service_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, vrf_id, "service")


###############################
# PTP
###############################

def ptp_get(ctx, rev, vrf_id):
    if rev == 'operational':
        # PTP under bridge.vlan is purely a config concept.  Return the last
        # applied config as the operational state.
        rev = 'applied'

    return service_get(ctx, rev, vrf_id)["ptp"]


def ptp_patch(ctx, rev, vrf_id, body=None):
    service = service_patch(ctx, rev, vrf_id, {"ptp": body})
    return service.get("ptp", {})


def ptp_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, vrf_id,
        "service", "ptp")


###############################
# PTP Timers
###############################

def ptp_timers_get(ctx, rev, vrf_id):
    return ptp_get(ctx, rev, vrf_id)["timers"]


def ptp_timers_patch(ctx, rev, vrf_id, body=None):
    ptp = ptp_patch(ctx, rev, vrf_id, {"timers": body})
    return ptp.get("timers", {})


def ptp_timers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev, vrf_id,
        "service", "ptp", "timers")


###############################
# OSPF
###############################

def ospf_get(ctx, rev, vrf_id):
    if rev != "operational":
        return router_get(ctx, rev, vrf_id)["ospf"]

    # We will not show the operational state as of now.
    raise NotFound


def ospf_patch(ctx, rev, vrf_id, body=None):
    route = router_patch(ctx, rev, vrf_id, {"ospf": body})
    return route.get("ospf", {})


def ospf_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf")


###############################
# OSPF/Areas
###############################

def ospf_areas_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["area"]


def ospf_areas_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"area": body})
    return ospf.get("area", {})


def ospf_areas_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "area")


###############################
# OSPF/area
###############################

def ospf_area_get(ctx, rev, vrf_id, area_id):
    areas = ospf_areas_get(ctx, rev, vrf_id)
    try:
        return areas[area_id]
    except KeyError:
        raise NotFound


def ospf_area_patch(ctx, rev, vrf_id, area_id, body=None):
    areas = ospf_areas_patch(ctx, rev, vrf_id, {area_id: body})
    return areas.get(area_id, {})


def ospf_area_delete(ctx, rev, vrf_id, area_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "area", area_id)


##################################
# OSPF/area/{area-id}/filter-list
##################################

def ospf_area_filter_list_get(ctx, rev, vrf_id, area_id):
    return ospf_area_get(ctx, rev, vrf_id, area_id)["filter-list"]


def ospf_area_filter_list_patch(ctx, rev, vrf_id, area_id, body=None):
    area = ospf_area_patch(ctx, rev, vrf_id, area_id, {"filter-list": body})
    return area.get("filter-list", {})


def ospf_area_filter_list_delete(ctx, rev, vrf_id, area_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "area", area_id, "filter-list")


###############################
# OSPF/area/{area-id}/ranges
###############################

def ospf_area_ranges_get(ctx, rev, vrf_id, area_id):
    return ospf_area_get(ctx, rev, vrf_id, area_id)["range"]


def ospf_area_ranges_patch(ctx, rev, vrf_id, area_id, body=None):
    area = ospf_area_patch(ctx, rev, vrf_id, area_id, {"range": body})
    return area.get("range", {})


def ospf_area_ranges_delete(ctx, rev, vrf_id, area_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "area", area_id, "range")


####################################
# OSPF/area/{area-id}/ranges/range
####################################

def ospf_area_range_get(ctx, rev, vrf_id, area_id, range_id):
    ranges = ospf_area_ranges_get(ctx, rev, vrf_id, area_id)
    try:
        return ranges[range_id]
    except KeyError:
        raise NotFound


def ospf_area_range_patch(ctx, rev, vrf_id, area_id, range_id, body=None):
    ranges = ospf_area_ranges_patch(ctx, rev, vrf_id,
                                    area_id, {range_id: body})
    return ranges.get(range_id, {})


def ospf_area_range_delete(ctx, rev, vrf_id, area_id, range_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "area", area_id, "range", range_id)


###############################
# OSPF/default-originate
###############################

def ospf_default_originate_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["default-originate"]


def ospf_default_originate_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"default-originate": body})
    return ospf.get("default-originate", {})


def ospf_default_originate_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "default-originate")


###############################
# OSPF/distance
###############################

def ospf_distance_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["distance"]


def ospf_distance_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"distance": body})
    return ospf.get("distance", {})


def ospf_distance_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "distance")


###############################
# OSPF/log
###############################

def ospf_log_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["log"]


def ospf_log_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"log": body})
    return ospf.get("log", {})


def ospf_log_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "log")


###############################
# OSPF/max-metric
###############################

def ospf_max_metric_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["max-metric"]


def ospf_max_metric_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"max-metric": body})
    return ospf.get("max-metric", {})


def ospf_max_metric_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "max-metric")


###############################
# OSPF/route-redistribute
###############################

def ospf_route_redistribute_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["redistribute"]


def ospf_route_redistribute_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"redistribute": body})
    return ospf.get("redistribute", {})


def ospf_route_redistribute_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "redistribute")


#################################
# OSPF/route-redistribute/static
#################################

def ospf_redistribute_static_get(ctx, rev, vrf_id):
    return ospf_route_redistribute_get(ctx, rev, vrf_id)["static"]


def ospf_redistribute_static_patch(ctx, rev, vrf_id, body=None):
    rr = ospf_route_redistribute_patch(ctx, rev, vrf_id, {"static": body})
    return rr.get("static", {})


def ospf_redistribute_static_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "redistribute", "static")


####################################
# OSPF/route-redistribute/connected
####################################

def ospf_redistribute_connected_get(ctx, rev, vrf_id):
    return ospf_route_redistribute_get(ctx, rev, vrf_id)["connected"]


def ospf_redistribute_connected_patch(ctx, rev, vrf_id, body=None):
    rr = ospf_route_redistribute_patch(ctx, rev, vrf_id, {"connected": body})
    return rr.get("connected", {})


def ospf_redistribute_connected_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "redistribute", "connected")


##################################
# OSPF/route-redistribute/kernel
##################################

def ospf_redistribute_kernel_get(ctx, rev, vrf_id):
    return ospf_route_redistribute_get(ctx, rev, vrf_id)["kernel"]


def ospf_redistribute_kernel_patch(ctx, rev, vrf_id, body=None):
    rr = ospf_route_redistribute_patch(ctx, rev, vrf_id, {"kernel": body})
    return rr.get("kernel", {})


def ospf_redistribute_kernel_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "redistribute", "kernel")


##################################
# OSPF/route-redistribute/bgp
##################################

def ospf_redistribute_bgp_get(ctx, rev, vrf_id):
    return ospf_route_redistribute_get(ctx, rev, vrf_id)["bgp"]


def ospf_redistribute_bgp_patch(ctx, rev, vrf_id, body=None):
    rr = ospf_route_redistribute_patch(ctx, rev, vrf_id, {"bgp": body})
    return rr.get("bgp", {})


def ospf_redistribute_bgp_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "redistribute", "bgp")


###############################
# OSPF/timers
###############################

def ospf_timers_get(ctx, rev, vrf_id):
    return ospf_get(ctx, rev, vrf_id)["timers"]


def ospf_timers_patch(ctx, rev, vrf_id, body=None):
    ospf = ospf_patch(ctx, rev, vrf_id, {"timers": body})
    return ospf.get("timers", {})


def ospf_timers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "timers")


###############################
# OSPF/lsa-timers
###############################

def ospf_lsa_timers_get(ctx, rev, vrf_id):
    return ospf_timers_get(ctx, rev, vrf_id)["lsa"]


def ospf_lsa_timers_patch(ctx, rev, vrf_id, body=None):
    timers = ospf_timers_patch(ctx, rev, vrf_id, {"lsa": body})
    return timers.get("lsa", {})


def ospf_lsa_timers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "timers", "lsa")


###############################
# OSPF/spf-timers
###############################

def ospf_spf_timers_get(ctx, rev, vrf_id):
    return ospf_timers_get(ctx, rev, vrf_id)["spf"]


def ospf_spf_timers_patch(ctx, rev, vrf_id, body=None):
    timers = ospf_timers_patch(ctx, rev, vrf_id, {"spf": body})
    return timers.get("spf", {})


def ospf_spf_timers_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getVrf, ctx.config_v1.setVrf, rev,
        vrf_id, "router", "ospf", "timers", "spf")
