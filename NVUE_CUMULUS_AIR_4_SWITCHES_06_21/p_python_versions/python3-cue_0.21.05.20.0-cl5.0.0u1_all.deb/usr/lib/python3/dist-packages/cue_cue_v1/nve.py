# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue_cue_v1.root import root_patch


###############################
# Nve
###############################
def nve_get(ctx, rev):
    if rev == 'operational':
        # NVE config does not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getNve(rev)


def nve_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"nve": body})
    return root.get("nve", {})


def nve_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getNve, ctx.config_v1.setNve, rev)
