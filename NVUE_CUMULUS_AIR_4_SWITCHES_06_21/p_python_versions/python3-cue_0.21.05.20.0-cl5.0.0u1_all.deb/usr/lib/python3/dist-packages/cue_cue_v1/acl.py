# Copyright (C) 2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.root import root_patch

###############################
# Acl
###############################


def acls_get(ctx, rev):
    if rev == 'operational':
        # Add the operational state when FUnit is ready
        rev = 'applied'
    return ctx.config_v1.getAcls(rev)


def acls_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"acl": body})
    return root.get("acl", {})


def acls_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getAcls, ctx.config_v1.setAcls, rev)


def acl_get(ctx, rev, acl_id):
    if rev != "operational":
        return ctx.config_v1.getAcl(rev, acl_id)

    # Add the operational state when FUnit is ready
    return {}


def acl_patch(ctx, rev, acl_id, body=None):
    acl = acls_patch(ctx, rev, {acl_id: body})
    return acl.get(acl_id, {})


def acl_delete(ctx, rev, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getAcl, ctx.config_v1.setAcl, rev, acl_id)

####################################
# ACL rules
####################################


def acl_rules_get(ctx, rev, acl_id):
    if rev == 'operational':
        # Add the operational state when FUnit is ready
        rev = 'applied'

    acl = acl_get(ctx, rev, acl_id)
    return acl["rule"]


def acl_rules_patch(ctx, rev, acl_id, body=None):
    acl = acl_patch(ctx, rev, acl_id, {"rule": body})
    return acl.get("rule", {})


def acl_rules_delete(ctx, rev, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule")


####################################
# ACL rule
####################################

def acl_rule_get(ctx, rev, acl_id, rule_id):
    rules = acl_rules_get(ctx, rev, acl_id)
    try:
        return rules[rule_id]
    except KeyError:
        raise NotFound


def acl_rule_patch(ctx, rev, acl_id, rule_id, body=None):
    rules = acl_rules_patch(ctx, rev, acl_id, {rule_id: body})
    return rules.get(rule_id, {})


def acl_rule_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id)


####################################
# ACL rule match
####################################

def acl_match_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        rule = acl_rule_get(ctx, rev, acl_id, rule_id)
        return rule["match"]

    return {}


def acl_match_patch(ctx, rev, acl_id, rule_id, body=None):
    rule = acl_rule_patch(ctx, rev, acl_id, rule_id, {"match": body})
    return rule.get("match", {})


def acl_match_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match")


####################################
# ACL rule match ip
####################################

def acl_match_ip_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        match = acl_match_get(ctx, rev, acl_id, rule_id)
        return match["ip"]

    return {}


def acl_match_ip_patch(ctx, rev, acl_id, rule_id, body=None):
    match = acl_match_patch(ctx, rev, acl_id, rule_id, {"ip": body})
    return match.get("ip", {})


def acl_match_ip_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip")


####################################
# ACL rule match ip source ports
####################################

def acl_match_ip_sports_get(ctx, rev, acl_id, rule_id):
    if rev == 'operational':
        # Add the operational state when FUnit is ready
        rev = 'applied'
    ip_match = acl_match_ip_get(ctx, rev, acl_id, rule_id)
    return ip_match["source-port"]


def acl_match_ip_sports_patch(ctx, rev, acl_id, rule_id, body=None):
    ip_match = acl_match_ip_patch(ctx, rev, acl_id, rule_id,
                                  {"source-port": body})
    return ip_match.get("source-port", {})


def acl_match_ip_sports_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "source-port")


####################################
# ACL rule match ip source port
####################################

def acl_match_ip_sport_get(ctx, rev, acl_id, rule_id, ip_port_id):
    if rev != "operational":
        sports = acl_match_ip_sports_get(ctx, rev, acl_id, rule_id)
        try:
            return sports[ip_port_id]
        except KeyError:
            raise NotFound

    return {}


def acl_match_ip_sport_patch(ctx, rev, acl_id, rule_id, ip_port_id, body=None):
    sports = acl_match_ip_sports_patch(ctx, rev, acl_id, rule_id,
                                       {ip_port_id: body})
    return sports.get(ip_port_id, {})


def acl_match_ip_sport_delete(ctx, rev, acl_id, rule_id, ip_port_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip",
                             "source-port", ip_port_id)


####################################
# ACL rule match ip dest ports
####################################

def acl_match_ip_dports_get(ctx, rev, acl_id, rule_id):
    if rev == 'operational':
        # Add the operational state when FUnit is ready
        rev = 'applied'
    ip_match = acl_match_ip_get(ctx, rev, acl_id, rule_id)
    return ip_match["dest-port"]


def acl_match_ip_dports_patch(ctx, rev, acl_id, rule_id, body=None):
    ip_match = acl_match_ip_patch(ctx, rev, acl_id, rule_id,
                                  {"dest-port": body})
    return ip_match.get("dest-port", {})


def acl_match_ip_dports_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "dest-port")


#####################################
# ACL rule match ip dest port
####################################

def acl_match_ip_dport_get(ctx, rev, acl_id, rule_id, ip_port_id):
    if rev != "operational":
        dports = acl_match_ip_dports_get(ctx, rev, acl_id, rule_id)
        try:
            return dports[ip_port_id]
        except KeyError:
            raise NotFound

    return {}


def acl_match_ip_dport_patch(ctx, rev, acl_id, rule_id, ip_port_id, body=None):
    dports = acl_match_ip_dports_patch(ctx, rev, acl_id, rule_id,
                                       {ip_port_id: body})
    return dports.get(ip_port_id, {})


def acl_match_ip_dport_delete(ctx, rev, acl_id, rule_id, ip_port_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip",
                             "dest-port", ip_port_id)


####################################
# ACL rule match ip fragment
####################################

def acl_match_ip_fragment_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        ip_match = acl_match_ip_get(ctx, rev, acl_id, rule_id)
        return ip_match["fragment"]

    return {}


def acl_match_ip_fragment_patch(ctx, rev, acl_id, rule_id, body=None):
    ip_match = acl_match_ip_patch(ctx, rev, acl_id, rule_id,
                                  {"fragment": body})
    return ip_match.get("fragment", {})


def acl_match_ip_fragment_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "fragment")


####################################
# ACL rule match ip tcp
####################################

def acl_match_ip_tcp_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        ip_match = acl_match_ip_get(ctx, rev, acl_id, rule_id)
        return ip_match["tcp"]

    return {}


def acl_match_ip_tcp_patch(ctx, rev, acl_id, rule_id, body=None):
    ip_match = acl_match_ip_patch(ctx, rev, acl_id, rule_id,
                                  {"tcp": body})
    return ip_match.get("tcp", {})


def acl_match_ip_tcp_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "tcp")


####################################
# ACL rule match ip tcp flags
####################################

def acl_match_ip_tcp_flags_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        tcp_match = acl_match_ip_tcp_get(ctx, rev, acl_id, rule_id)
        return tcp_match["flags"]

    return {}


def acl_match_ip_tcp_flags_patch(ctx, rev, acl_id, rule_id, body=None):
    tcp_match = acl_match_ip_tcp_patch(ctx, rev, acl_id, rule_id,
                                       {"flags": body})
    return tcp_match.get("flags", {})


def acl_match_ip_tcp_flags_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "tcp", "flags")


####################################
# ACL rule match ip tcp flags mask
####################################

def acl_match_ip_tcp_mask_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        tcp_match = acl_match_ip_tcp_get(ctx, rev, acl_id, rule_id)
        return tcp_match["mask"]

    return {}


def acl_match_ip_tcp_mask_patch(ctx, rev, acl_id, rule_id, body=None):
    tcp_match = acl_match_ip_tcp_patch(ctx, rev, acl_id, rule_id,
                                       {"mask": body})
    return tcp_match.get("mask", {})


def acl_match_ip_tcp_mask_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "ip", "tcp", "mask")


###################################
# ACL rule match mac
####################################

def acl_match_mac_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        match = acl_match_get(ctx, rev, acl_id, rule_id)
        return match["mac"]

    return {}


def acl_match_mac_patch(ctx, rev, acl_id, rule_id, body=None):
    match = acl_match_patch(ctx, rev, acl_id, rule_id, {"mac": body})
    return match.get("mac", {})


def acl_match_mac_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "match", "mac")


####################################
# ACL rule action
####################################

def acl_action_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        rule = acl_rule_get(ctx, rev, acl_id, rule_id)
        return rule["action"]

    return {}


def acl_action_patch(ctx, rev, acl_id, rule_id, body=None):
    rule = acl_rule_patch(ctx, rev, acl_id, rule_id, {"action": body})
    return rule.get("action", {})


def acl_action_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action")


####################################
# ACL rule action permit
####################################

def acl_action_permit_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["permit"]

    return {}


def acl_action_permit_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"permit": body})
    return action.get("permit", {})


def acl_action_permit_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "permit")


####################################
# ACL rule action deny
####################################

def acl_action_deny_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["deny"]

    return {}


def acl_action_deny_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"deny": body})
    return action.get("deny", {})


def acl_action_deny_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "deny")


####################################
# ACL rule action log
####################################

def acl_action_log_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["log"]

    return {}


def acl_action_log_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"log": body})
    return action.get("log", {})


def acl_action_log_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "log")


####################################
# ACL rule action set
####################################

def acl_action_set_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["set"]

    return {}


def acl_action_set_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"set": body})
    return action.get("set", {})


def acl_action_set_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "set")


####################################
# ACL rule action erspan
####################################

def acl_action_erspan_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["erspan"]

    return {}


def acl_action_erspan_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"erspan": body})
    return action.get("erspan", {})


def acl_action_erspan_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "erspan")


####################################
# ACL rule action police
####################################

def acl_action_police_get(ctx, rev, acl_id, rule_id):
    if rev != "operational":
        action = acl_action_get(ctx, rev, acl_id, rule_id)
        return action["police"]

    return {}


def acl_action_police_patch(ctx, rev, acl_id, rule_id, body=None):
    action = acl_action_patch(ctx, rev, acl_id, rule_id, {"police": body})
    return action.get("police", {})


def acl_action_police_delete(ctx, rev, acl_id, rule_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getAcl,
                             ctx.config_v1.setAcl, rev, acl_id,
                             "rule", rule_id, "action", "police")
