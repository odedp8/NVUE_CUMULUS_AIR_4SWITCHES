# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from pydash import py_
from cue.exceptions import NotFound
from cue import utils
from cue.expansion import expand_name_range
from cue_cue_v1.root import root_patch


###############################
# Interfaces
###############################

def interfaces_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getInterfaces(rev)

    return ctx.netlink_v1.getInterfaces()


def interfaces_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"interface": body})
    return root.get("interface", {})


def interfaces_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterfaces, ctx.config_v1.setInterfaces, rev)


###############################
# Interface
###############################

def interface_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id)

    iface = ctx.netlink_v1.getInterface(interface_id)

    # Get FEC encoding
    fec = ctx.netlink_v1.getInterfaceLinkFec(interface_id)
    if fec and 'link' in iface:
        iface = py_.merge({'link': {'fec': fec}},
                          iface)

    return iface


def interface_patch(ctx, rev, interface_id, body=None):
    response = interfaces_patch(ctx, rev, {interface_id: body})
    # HACK: Return the first interface of the glob, since we can only return
    #       one interface here.
    # TODO: CUE-2604
    expanded_id = expand_name_range(interface_id)
    return response.get(expanded_id[0], {})


def interface_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id,)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge
###############################

def bridge_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "bridge")

    try:
        bridge = ctx.netlink_v1.getInterface(interface_id)["bridge"]

        # Hack!  Assume one bridge domain.
        stp = {"domain": {"br_default": {
            "stp": ctx.netlink_v1.getInterfaceBridgeStp(interface_id)
        }}}

        vlan = ctx.netlink_v1.getInterfaceBridgeVlan(interface_id)

        full_bridge = py_.merge({}, bridge, vlan, stp)
        return full_bridge
    except KeyError:
        raise NotFound


def bridge_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"bridge": body})
    return iface.get("bridge", {})


def bridge_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge Domains
###############################

def domains_get(ctx, rev, interface_id):
    return bridge_get(ctx, rev, interface_id)["domain"]


def domains_patch(ctx, rev, interface_id, body=None):
    bridge = bridge_patch(ctx, rev, interface_id, {"domain": body})
    return bridge.get("domain", {})


def domains_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge", "domain")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge Domain
###############################

def domain_get(ctx, rev, interface_id, domain_id):
    domains = domains_get(ctx, rev, interface_id)
    try:
        return domains[domain_id]
    except KeyError:
        raise NotFound


def domain_patch(ctx, rev, interface_id, domain_id, body=None):
    domains = domains_patch(ctx, rev, interface_id, {domain_id: body})
    return domains.get(domain_id, {})


def domain_delete(ctx, rev, interface_id, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge", "domain", domain_id)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge domain STP
###############################

def stp_get(ctx, rev, interface_id, domain_id):
    return domain_get(ctx, rev, interface_id, domain_id)["stp"]


def stp_patch(ctx, rev, interface_id, domain_id, body=None):
    domain = domain_patch(ctx, rev, interface_id, domain_id, {"stp": body})
    return domain.get("stp", {})


def stp_delete(ctx, rev, interface_id, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge", "domain", domain_id, "stp")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge Domain VLAN
###############################

def vlans_get(ctx, rev, interface_id, domain_id):
    try:
        return domain_get(ctx, rev, interface_id, domain_id)["vlan"]
    except KeyError:
        raise NotFound


def vlans_patch(ctx, rev, interface_id, domain_id, body=None):
    domain = domain_patch(ctx, rev, interface_id, domain_id, {"vlan": body})
    return domain.get("vlan", {})


def vlans_delete(ctx, rev, interface_id, domain_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge", "domain", domain_id, "vlan")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Bridge Domain VLAN
###############################

def vlan_get(ctx, rev, interface_id, domain_id, vid):
    vlans = vlans_get(ctx, rev, interface_id, domain_id)
    try:
        return vlans[vid]
    except KeyError:
        raise NotFound


def vlan_patch(ctx, rev, interface_id, domain_id, vid, body=None):
    vlans = vlans_patch(ctx, rev, interface_id, domain_id, {vid: body})
    return vlans.get(vid, {})


def vlan_delete(ctx, rev, interface_id, domain_id, vid):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bridge", "domain", domain_id, "vlan", vid)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# IP
###############################

def ip_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "ip")

    return ctx.netlink_v1.getInterfaceIp(interface_id)


def ip_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"ip": body})
    return iface.get("ip", {})


def ip_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "ip")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# IP Addresses
###############################

ip_address_path = ("ip", "address")


def ip_addresses_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *ip_address_path)

    ip = ctx.netlink_v1.getInterfaceIp(interface_id)

    # netlink_v1 always fills in "address" for us, even if it is empty.
    return ip["address"]


def ip_addresses_patch(ctx, rev, interface_id, body=None):
    ip = ip_patch(ctx, rev, interface_id, {"address": body})
    return ip.get("address", {})


def ip_addresses_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ip_address_path)


###############################
# IP Address
###############################

def ip_address_get(ctx, rev, interface_id, ip_prefix_id):
    addresses = ip_addresses_get(ctx, rev, interface_id)
    try:
        return addresses[ip_prefix_id]
    except KeyError:
        raise NotFound


def ip_address_patch(ctx, rev, interface_id, ip_prefix_id, body=None):
    addrs = ip_addresses_patch(ctx, rev, interface_id, {ip_prefix_id: body})
    return addrs.get(ip_prefix_id, {})


def ip_address_delete(ctx, rev, interface_id, ip_prefix_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ip_address_path, ip_prefix_id)


###############################
# IP Neighbors
###############################

def ip_neighbors_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)

    return {
        "ipv4": ctx.netlink_v1.getInterfaceIpv4Neighbors(interface_id),
        "ipv6": ctx.netlink_v1.getInterfaceIpv6Neighbors(interface_id),
    }


def ipv4_neighbors_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)

    return ctx.netlink_v1.getInterfaceIpv4Neighbors(interface_id)


def ipv4_neighbor_get(ctx, rev, interface_id, neighbor_id):
    neighbors = ipv4_neighbors_get(ctx, rev, interface_id)
    try:
        return neighbors[neighbor_id]
    except KeyError:
        raise NotFound


def ipv6_neighbors_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)

    return ctx.netlink_v1.getInterfaceIpv6Neighbors(interface_id)


def ipv6_neighbor_get(ctx, rev, interface_id, neighbor_id):
    neighbors = ipv6_neighbors_get(ctx, rev, interface_id)
    try:
        return neighbors[neighbor_id]
    except KeyError:
        raise NotFound


###############################
# VRR
###############################

def vrr_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "ip", "vrr")

    return ctx.netlink_v1.getInterfaceVrr(interface_id)


def vrr_patch(ctx, rev, interface_id, body=None):
    ip = ip_patch(ctx, rev, interface_id, {"vrr": body})
    return ip.get("vrr", {})


def vrr_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "ip", "vrr")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# VRR Addresses
###############################

vrr_address_path = ("ip", "vrr", "address")


def vrr_addresses_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *vrr_address_path)

    vrr = ctx.netlink_v1.getInterfaceVrr(interface_id)
    try:
        return vrr["address"]
    except KeyError:
        return {}


def vrr_addresses_patch(ctx, rev, interface_id, body=None):
    vrr = vrr_patch(ctx, rev, interface_id, {"address": body})
    return vrr.get("address", {})


def vrr_addresses_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *vrr_address_path)


###############################
# VRR Address
###############################

def vrr_address_get(ctx, rev, interface_id, ip_prefix_id):
    addresses = vrr_addresses_get(ctx, rev, interface_id)
    try:
        return addresses[ip_prefix_id]
    except KeyError:
        raise NotFound


def vrr_address_patch(ctx, rev, interface_id, ip_prefix_id, body=None):
    addrs = vrr_addresses_patch(ctx, rev, interface_id, {ip_prefix_id: body})
    return addrs.get(ip_prefix_id, {})


def vrr_address_delete(ctx, rev, interface_id, ip_prefix_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *vrr_address_path, ip_prefix_id)


###############################
# VRR State
###############################

vrr_state_path = ("ip", "vrr", "state")


def vrr_state_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *vrr_state_path)

    return ctx.netlink_v1.getInterfaceVrr(interface_id)["state"]


def vrr_state_patch(ctx, rev, interface_id, body=None):
    vrr = vrr_patch(ctx, rev, interface_id, {"state": body})
    return vrr.get("state", {})


def vrr_state_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *vrr_state_path)


###############################
# IP Gateways
###############################

ip_gateway_path = ("ip", "gateway")


def ip_gateways_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *ip_gateway_path)

    # TODO CUE-1900
    return {}


def ip_gateways_patch(ctx, rev, interface_id, body=None):
    ip = ip_patch(ctx, rev, interface_id, {"gateway": body})
    return ip.get("gateway", {})


def ip_gateways_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ip_gateway_path)


###############################
# IP Gateway
###############################

def ip_gateway_get(ctx, rev, interface_id, ip_address_id):
    gateways = ip_gateways_get(ctx, rev, interface_id)
    try:
        return gateways[ip_address_id]
    except KeyError:
        raise NotFound


def ip_gateway_patch(ctx, rev, interface_id, ip_address_id, body=None):
    gateways = ip_gateways_patch(ctx, rev, interface_id, {ip_address_id: body})
    return gateways.get(ip_address_id, {})


def ip_gateway_delete(ctx, rev, interface_id, ip_address_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ip_gateway_path, ip_address_id)


###############################
# IPv4
###############################

ipv4_path = ("ip", "ipv4")


def ipv4_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *ipv4_path)

    ip = ctx.netlink_v1.getInterfaceIp(interface_id)

    # TODO CUE-1928
    return ip.get('ipv4', {})


def ipv4_patch(ctx, rev, interface_id, body=None):
    ip = ip_patch(ctx, rev, interface_id, {"ipv4": body})
    return ip.get("ipv4", {})


def ipv4_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ipv4_path)


###############################
# IPv6
###############################

ipv6_path = ("ip", "ipv6")


def ipv6_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *ipv6_path)

    ip = ctx.netlink_v1.getInterfaceIp(interface_id)

    # TODO CUE-1928
    return ip.get('ipv6', {})


def ipv6_patch(ctx, rev, interface_id, body=None):
    ip = ip_patch(ctx, rev, interface_id, {"ipv6": body})
    return ip.get("ipv6", {})


def ipv6_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ipv6_path)


###############################
# Link
###############################

def link_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "link")

    iflink = {}

    # getInterface() fills in part of the link object.
    iface = ctx.netlink_v1.getInterface(interface_id)

    # Get FEC encoding
    fec = ctx.netlink_v1.getInterfaceLinkFec(interface_id)
    if fec:
        iflink['fec'] = fec

    # Depending on the type, we can fill in more from ifLinkSettings.
    if iface["type"] in ["eth", "swp", "bond"]:
        py_.merge(iflink, ctx.netlink_v1.getIfLinkSettings(interface_id))

    return py_.merge({}, iface["link"], iflink)


def link_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"link": body})
    return iface.get("link", {})


def link_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "link")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Router
###############################
router_path = ("router",)


def router_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *router_path)

    # We will not show the operational state as of now.
    raise NotFound


def router_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"router": body})
    return iface.get("router", {})


def router_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *router_path)


###############################
# PBR
###############################

pbr_path = ('router', 'pbr')


def pbr_get(ctx, rev, interface_id):
    if rev != 'operational':
        return ctx.config_v1.getInterface(rev, interface_id, *pbr_path)

    # Operational data not supported yet
    raise NotFound


def pbr_patch(ctx, rev, interface_id, body):
    router = router_patch(ctx, rev, interface_id, body={'pbr': body})
    return router.get('pbr', {})


def pbr_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *pbr_path)


###############################
# OSPF
###############################

ospf_path = ('router', 'ospf')


def ospf_get(ctx, rev, interface_id):
    if rev != 'operational':
        return ctx.config_v1.getInterface(rev, interface_id, *ospf_path)

    # Operational data not supported yet
    raise NotFound


def ospf_patch(ctx, rev, interface_id, body=None):
    router = router_patch(ctx, rev, interface_id, body={'ospf': body})
    return router.get("ospf", {})


def ospf_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *ospf_path)


###############################
# OSPF/timers
###############################

def ospf_timers_get(ctx, rev, interface_id):
    return ospf_get(ctx, rev, interface_id)["timers"]


def ospf_timers_patch(ctx, rev, interface_id, body=None):
    ospf = ospf_patch(ctx, rev, interface_id, {"timers": body})
    return ospf.get("timers", {})


def ospf_timers_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, "router", "ospf", "timers")


###############################
# OSPF/authentication
###############################

def ospf_authentication_get(ctx, rev, interface_id):
    return ospf_get(ctx, rev, interface_id)["authentication"]


def ospf_authentication_patch(ctx, rev, interface_id, body=None):
    ospf = ospf_patch(ctx, rev, interface_id, {"authentication": body})
    return ospf.get("authentication", {})


def ospf_authentication_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, "router", "ospf", "authentication")


###############################
# OSPF/bfd
###############################

def ospf_bfd_get(ctx, rev, interface_id):
    return ospf_get(ctx, rev, interface_id)["bfd"]


def ospf_bfd_patch(ctx, rev, interface_id, body=None):
    ospf = ospf_patch(ctx, rev, interface_id, {"bfd": body})
    return ospf.get("bfd", {})


def ospf_bfd_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, "router", "ospf", "bfd")


###############################
# Bond
###############################

bond_path = ("bond",)


def bond_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *bond_path)

    try:
        return ctx.netlink_v1.getInterface(interface_id)["bond"]
    except KeyError:
        raise NotFound


def bond_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"bond": body})
    return iface.get("bond", {})


def bond_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *bond_path)


###############################
# Bond Members
###############################

bond_member_path = ("bond", "member")


def bond_members_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *bond_member_path)

    # netlink_v1 always fills in "member" for us, if we have a bond.
    return bond_get(ctx, rev, interface_id)["member"]


def bond_members_patch(ctx, rev, interface_id, body=None):
    bond = bond_patch(ctx, rev, interface_id, {"member": body})
    return bond.get("member", {})


def bond_members_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *bond_member_path)


###############################
# Bond Member
###############################

def bond_member_get(ctx, rev, interface_id, member_id):
    members = bond_members_get(ctx, rev, interface_id)
    try:
        return members[member_id]
    except KeyError:
        raise NotFound


def bond_member_patch(ctx, rev, interface_id, member_id, body=None):
    members = bond_members_patch(ctx, rev, interface_id, {member_id: body})
    return members.get(member_id, {})


def bond_member_delete(ctx, rev, interface_id, member_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *bond_member_path, member_id)


###############################
# Mlag
###############################

def mlag_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "bond", "mlag")

    try:
        return ctx.netlink_v1.getInterface(interface_id)["bond"]["mlag"]
    except KeyError:
        raise NotFound


def mlag_patch(ctx, rev, interface_id, body=None):
    bond = bond_patch(ctx, rev, interface_id, {"mlag": body})
    return bond.get("mlag", {})


def mlag_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "bond", "mlag")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# Link Dot1x
###############################

link_dot1x_path = ("link", "dot1x")


def dot1x_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *link_dot1x_path)

    # TODO CUE-1903
    return {}


def dot1x_patch(ctx, rev, interface_id, body=None):
    link = link_patch(ctx, rev, interface_id, {"dot1x": body})
    return link.get("dot1x", {})


def dot1x_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *link_dot1x_path)


###############################
# Link State
###############################

link_state_path = ("link", "state")


def link_state_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, *link_state_path)

    return ctx.netlink_v1.getInterface(interface_id)["link"]["state"]


def link_state_patch(ctx, rev, interface_id, body=None):
    link = link_patch(ctx, rev, interface_id, {"state": body})
    return link.get("state", {})


def link_state_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev,
        interface_id, *link_state_path)


###############################
# LLDP
###############################

def lldp_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)

    # nbr_get() will always return, even if the interface doesn't support LLDP.
    # So, we need to check the type before continuing.
    if_type = ctx.netlink_v1.getInterface(interface_id)["type"]
    if if_type in ["swp", "eth", "bond"]:
        return ctx.lldp_v1.getNbr(interface_id)
    else:
        raise NotFound


def lldp_neighbors_get(ctx, rev, interface_id):
    # We always get a neighbor object from lldp_v1.
    return lldp_get(ctx, rev, interface_id)["neighbor"]


def lldp_neighbor_get(ctx, rev, interface_id, neighbor_id):
    neighbors = lldp_neighbors_get(ctx, rev, interface_id)
    try:
        return neighbors[neighbor_id]
    except KeyError:
        raise NotFound


def lldp_neighbor_bridge_get(ctx, rev, interface_id, neighbor_id):
    neighbor = lldp_neighbor_get(ctx, rev, interface_id, neighbor_id)
    try:
        return neighbor["bridge"]
    except KeyError:
        return {}


def lldp_neighbor_bridge_vlans_get(ctx, rev, interface_id, neighbor_id):
    dot1tlv = lldp_neighbor_bridge_get(ctx, rev, interface_id, neighbor_id)
    try:
        return dot1tlv["vlan"]
    except KeyError:
        return {}


def lldp_neighbor_bridge_vlan_get(ctx, rev, interface_id, neighbor_id, vid):
    vlans = lldp_neighbor_bridge_vlans_get(ctx, rev, interface_id, neighbor_id)
    try:
        return vlans[vid]
    except KeyError:
        raise NotFound

###############################
# Service
###############################


def service_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "service")

    # We will not show the operational state as of now.
    raise NotFound


def service_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"service": body})
    return iface.get("service", {})


def service_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "service")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# PTP
###############################

def ptp_get(ctx, rev, interface_id):
    if rev != "operational":
        service = service_get(ctx, rev, interface_id)
        return service["ptp"]

    if_ptps = ctx.linuxptp_v1.getCuev1Ptp4lConfIfPtps()

    try:
        if_ptp = if_ptps[interface_id]["service"]["ptp"]
    except KeyError:
        raise NotFound

    return utils.fast_merge(
        if_ptp,
        ctx.linuxptp_v1.getIfServicePTPInstance(interface_id)
    )


def ptp_patch(ctx, rev, interface_id, body=None):
    service = service_patch(ctx, rev, interface_id, {"ptp": body})
    return service.get("ptp", {})


def ptp_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "service", "ptp")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# PTP timers
###############################

def ptp_timers_get(ctx, rev, interface_id):
    ptp = ptp_get(ctx, rev, interface_id)
    return ptp["timers"]


def ptp_timers_patch(ctx, rev, interface_id, body=None):
    ptp = ptp_patch(ctx, rev, interface_id, {"timers": body})
    return ptp.get("timers", {})


def ptp_timers_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "service", "ptp", "timers")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# PTP stats
###############################

def ptp_counters_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.linuxptp_v1.getPTPPortStats(interface_id)


###############################
# Stats
###############################

def stats_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    swp = ctx.netlink_v1.getInterface(interface_id)
    stats = py_.get(swp, 'link.stats')
    if stats:
        return stats
    else:
        return {}


def roce_stats_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    stats = ctx.qos_v1.getInterfaceRoceStats(interface_id)
    return stats


def roce_status_tc_map_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    status = ctx.qos_v1.getInterfaceRoceStatusTcMap(interface_id)
    return status


def roce_status_prio_map_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    status = ctx.qos_v1.getInterfaceRoceStatusPrioMap(interface_id)
    return status


def roce_status_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    status = ctx.qos_v1.getInterfaceRoceStatus(interface_id)
    return status


###############################
# RoCE system status
###############################

def roce_system_pool_get(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    pool_info = ctx.qos_v1.getRoceInterfacePools(interface_id)
    return pool_info


###############################
# EVPN
###############################

def evpn_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(rev, interface_id, "evpn")

    raise NotFound


def evpn_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"evpn": body})
    return iface.get("evpn", {})


def evpn_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "evpn")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# EVPN MH
###############################

def evpn_mh_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(
            rev, interface_id, "evpn", "multihoming")

    raise NotFound


def evpn_mh_patch(ctx, rev, interface_id, body=None):
    evpn = evpn_patch(ctx, rev, interface_id, {"multihoming": body})
    return evpn.get("multihoming", {})


def evpn_mh_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "evpn", "multihoming")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# EVPN MH Segment
###############################

def evpn_mh_segment_get(ctx, rev, interface_id):
    if rev != "operational":
        return ctx.config_v1.getInterface(
            rev, interface_id, "evpn", "multihoming", "segment")

    raise NotFound


def evpn_mh_segment_patch(ctx, rev, interface_id, body=None):
    evpn_mh = evpn_mh_patch(ctx, rev, interface_id, {"segment": body})
    return evpn_mh.get("segment", {})


def evpn_mh_segment_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "evpn", "multihoming", "segment")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACLs
###############################

def acls_get(ctx, rev, interface_id):
    if rev == 'operational':
        # Add the operational state when FUnit is ready
        rev = 'applied'

    res = ctx.config_v1.getInterface(rev, interface_id)
    return res['acl']


def acls_patch(ctx, rev, interface_id, body=None):
    iface = interface_patch(ctx, rev, interface_id, {"acl": body})
    return iface.get("acl", {})


def acls_delete(ctx, rev, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACL
###############################

def acl_get(ctx, rev, interface_id, acl_id):
    acls = acls_get(ctx, rev, interface_id)
    try:
        return acls[acl_id]
    except KeyError:
        raise NotFound


def acl_patch(ctx, rev, interface_id, acl_id, body=None):
    acls = acls_patch(ctx, rev, interface_id, {acl_id: body})
    return acls.get(acl_id, {})


def acl_delete(ctx, rev, interface_id, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl", acl_id)
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACL inbound
###############################

def acl_inbound_get(ctx, rev, interface_id, acl_id):
    return acl_get(ctx, rev, interface_id, acl_id)["inbound"]


def acl_inbound_patch(ctx, rev, interface_id, acl_id, body=None):
    acl = acl_patch(ctx, rev, interface_id, acl_id, {"inbound": body})
    return acl.get("inbound", {})


def acl_inbound_delete(ctx, rev, interface_id, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl", acl_id, "inbound")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACL inbound control plane
###############################

def acl_in_control_plane_get(ctx, rev, interface_id, acl_id):
    return acl_inbound_get(ctx, rev, interface_id, acl_id)["control-plane"]


def acl_in_control_plane_patch(ctx, rev, interface_id, acl_id, body=None):
    acl = acl_inbound_patch(ctx, rev, interface_id, acl_id,
                            {"control-plane": body})
    return acl.get("control-plane", {})


def acl_in_control_plane_delete(ctx, rev, interface_id, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl", acl_id, "inbound", "control-plane")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACL outbound
###############################

def acl_outbound_get(ctx, rev, interface_id, acl_id):
    return acl_get(ctx, rev, interface_id, acl_id)["outbound"]


def acl_outbound_patch(ctx, rev, interface_id, acl_id, body=None):
    acl = acl_patch(ctx, rev, interface_id, acl_id, {"outbound": body})
    return acl.get("outbound", {})


def acl_outbound_delete(ctx, rev, interface_id, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl", acl_id, "outbound")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)


###############################
# ACL inbound control plane
###############################

def acl_out_control_plane_get(ctx, rev, interface_id, acl_id):
    return acl_outbound_get(ctx, rev, interface_id, acl_id)["control-plane"]


def acl_out_control_plane_patch(ctx, rev, interface_id, acl_id, body=None):
    acl = acl_outbound_patch(ctx, rev, interface_id, acl_id,
                             {"control-plane": body})
    return acl.get("control-plane", {})


def acl_out_control_plane_delete(ctx, rev, interface_id, acl_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    path = (interface_id, "acl", acl_id, "outbound", "control-plane")
    return ops.delete_config(
        ctx.config_v1.getInterface, ctx.config_v1.setInterface, rev, *path)
