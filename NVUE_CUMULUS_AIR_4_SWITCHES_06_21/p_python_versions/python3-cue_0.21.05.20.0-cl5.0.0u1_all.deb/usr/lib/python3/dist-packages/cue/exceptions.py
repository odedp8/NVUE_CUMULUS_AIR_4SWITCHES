# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Set of exceptions that CUE endpoints can raise.  If these come out of an
# endpoint, they'll be handled properly by the runtime container.  Any other
# exception will be treated as a bug and turned into a 501.


from cue import issues


#    200 OK - Response to a successful GET, PUT, PATCH or DELETE. Can also be
#    used for a POST that doesn't result in a creation.

#    201 Created - Response to a POST that results in a creation. Should be
#    combined with a Location header pointing to the location of the new
#    resource

#    204 No Content - Response to a successful request that won't be returning
#    a body (like a DELETE request)

#    304 Not Modified - Used when HTTP caching headers are in play

#    400 Bad Request - The request is malformed, such as if the body does not
#    parse
from werkzeug.exceptions import BadRequest  # noqa

#    401 Unauthorized - When no or invalid authentication details are provided.
#    Also useful to trigger an auth popup if the API is used from a browser

# 403 Forbidden - When authentication succeeded but authenticated user
# doesn't have access to the resource
from werkzeug.exceptions import Forbidden  # noqa


# 404 Not Found - When a non-existent resource is requested
from werkzeug.exceptions import NotFound  # noqa


# 405 Method Not Allowed - The request was well-formed, but attempting to do
# something that is not allowed.  For example, writing to a readonly field.
from werkzeug.exceptions import MethodNotAllowed  # noqa


# 409 Conflict - The request was well-formed, but could not be completed due to
# a conflict with the current state of the target resource.
from werkzeug.exceptions import Conflict  # noqa


#    410 Gone - Indicates that the resource at this end point is no longer
#    available. Useful as a blanket response for old API versions

#    415 Unsupported Media Type - If incorrect content type was provided as
#    part of the request


# 422 Used if the request is well formed, but the instructions are otherwise
# incorrect.
from werkzeug.exceptions import UnprocessableEntity  # noqa


#    429 Too Many Requests - When a request is rejected due to rate limiting


# 500 Internal Server Error - Raise if an internal server error occurred.  This
# is a good fallback if an unknown error occurred in the dispatcher.
from werkzeug.exceptions import InternalServerError  # noqa


# 503 Service Unavailable - The server is temporarily unable to service your
# request due to maintenance downtime or capacity problems.  Please try again
# later.
from werkzeug.exceptions import ServiceUnavailable  # noqa


def from_issue(issue):
    """
    Given an issue, raise the appropriate HTTP exception.
    """
    if isinstance(issue, issues.BadInputIssue):
        # User errors indicate bad input.
        ex = UnprocessableEntity(issue.message)
    else:
        # When in doubt, call it a bug.
        ex = InternalServerError(issue.message)

    ex.issue = issue

    return ex
