# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# File operation utilities.
# - Each utility should be a simple abstraction over the real implementation.
# - During unittesting, they can be easily stubbed.
# - Since these utilities make direct calls, they're hard to test. So, this
# isn't the place to do real work.


import contextlib
import os
import sh
import shutil
from pathlib import Path
import logging


logger = logging.getLogger(__name__)


@contextlib.contextmanager
def cd(path):
    """
    A context manager which changes the working directory to the given
    path, and then changes it back to its previous value on exit.

    Raises FileNotFoundError if path does not exist.
    """
    prev_cwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev_cwd)


def open_file(filename, mode="r"):
    """
    Given an absolute path, open() the file and return it.
    """
    logger.dump('Opening', filename, mode)
    return open(filename, mode)


def stat_file(filename, sudo=False):
    """
    Given an absolute path, stat() the file and return an os.stat_result
    object.  Raises FileNotFoundError if filename doesn't exist.
    """
    logger.dump('Stat', filename)
    try:
        if sudo:
            return str(sh.sudo.stat(filename))
        return os.stat(filename)
    except sh.ErrorReturnCode:
        raise FileNotFoundError(filename)
    except FileNotFoundError:
        raise


def file_exists(filename, sudo=False):
    """
    Given a relative path, return True if the file exists, otherwise,
    False.
    """
    try:
        stat_file(filename, sudo)
        return True
    except FileNotFoundError:
        return False


def load_file(filename, default=None, sudo=False):
    """
    Given an absolute path, open() the file and return it's contents.
    """
    logger.info('Loading %s', filename)
    try:
        if sudo:
            return str(sh.sudo.cat(filename))
        with open_file(filename, "rt") as f:
            return f.read()
    except Exception:
        if default is not None:
            logger.dump('Loaded default')
            return default
        else:
            raise


def list_files(path):
    """
    Given an absolute path, scandir() it and return an iterator of os.DirEntry
    items. Only non-hidden files will be returned.
    """
    logger.dump('Scan', path)
    with os.scandir(path) as dirs:
        for entry in dirs:
            # entry is DirEntry, which is a PathLike object.
            if not entry.name.startswith('.') and entry.is_file():
                yield entry


def walk(path):
    """
    Given an absolute path, walk() the directory and subdirectories.

    Does not traverse hidden files/directories.

    Yields:
        A Path item for each file found.
    """
    # NOTE: When topdown=True, we can modify 'dirnames' in place to change how
    #       os.walk traverses subdirectories.
    for dirpath, dirnames, filenames in os.walk(path, topdown=True):
        dirpath = Path(dirpath)
        visible_dirnames = [
            dirname
            for dirname in dirnames
            if not dirname.startswith(".")
        ]
        # HACK: We have to mutate 'dirnames' for walk to see it. Clear it out
        #       and add back the subset of dirs we care about.
        dirnames.clear()
        dirnames.extend(visible_dirnames)

        for fname in filenames:
            if not fname.startswith("."):
                yield dirpath.joinpath(fname)


def _write_file(file_path, contents, mode):
    """
    Given an absolute filename or Path, write the contents to it.
    The file is opened with the given mode, so it can be used to
    zero a file or append.

    If necessary, the path to the file will be created.

    contents can be a single object or an iterable of objects.  If an iterable,
    each object will be written in turn.  All objects are stringified before
    writing.
    """
    # Create parent directories
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Write the file.
    with open_file(file_path, mode) as f:
        # If contents is a string, just write it.
        if type(contents) is str:
            f.write(contents)

        # Otherwise, assume contents is an iterable
        else:
            try:
                chunks = iter(contents)
            except TypeError:
                # Not an iterable.  Make it one and continue.
                chunks = [contents]

            for chunk in chunks:
                f.write(str(chunk))


def _save_file(filename, contents):
    file_path = Path(filename)
    tmp_path = file_path.parent / (file_path.name + ".tmp")

    # Write into the tmp file
    _write_file(tmp_path, contents, "wt")

    # Move the tmp file into the desired destination.
    move_file(tmp_path, file_path)


def save_file(filename, contents):
    """
    Given an absolute filename or Path, save the contents to it.  We'll stream
    contents into a tmp file first, then move it into place, so the operation
    is atomic.

    contents can be a single object or an iterable of objects.  If an iterable,
    each object will be written in turn.  All objects are stringified before
    writing.
    """
    logger.dump('Saving', filename)
    _save_file(filename, contents)


def zero_file(filename):
    """
    Convenience method to create a zero byte file or truncate an existing file.

    This is equivalent to save_file(filename, "").
    """
    logger.dump('Zeroing', filename)
    _save_file(filename, "")


def remove_file(filename, sudo=False):
    """
    Remove a file.  If sudo is True, do it as root.  This is an atomic
    operation.
    """
    logger.dump('Remove', filename)
    if sudo:
        try:
            sh.sudo.rm(filename)
        except sh.ErrorReturnCode:
            raise FileNotFoundError(filename)
    else:
        os.remove(filename)


def append_file(filename, contents):
    """
    Given an absolute filename or Path, append the contents to it.

    contents can be a single object or an iterable of objects.  If an iterable,
    each object will be written in turn.  All objects are stringified before
    writing.
    """
    logger.dump('Appending', filename)
    file_path = Path(filename)

    # Write into the tmp file
    _write_file(file_path, contents, "at")


def move_file(src, dst, sudo=False):
    """
    Move a file into place.  If sudo is True, do it as root.  This is an atomic
    operation.
    """
    logger.dump('Moving', src, dst, sudo)
    if sudo:
        try:
            sh.sudo.mv(src, dst)
        except sh.ErrorReturnCode:
            raise FileNotFoundError([src, dst])
    else:
        os.replace(src, dst)


def copy_file(src, dst, sudo=False, chown="root.", chmod="0644"):
    """
    Copy a file from src to dst.  If sudo is True, do it as root and
    chmod/chown it after.  If src does not exist, a `FileNotFoundError`
    is raised.
    """
    logger.dump('Copy', src, dst, sudo, chown, chmod)
    if sudo:
        # Force a FileNotFoundError now, if it doesn't exist.  The erorr
        # coming out of cp could mean a few different things.
        stat_file(src, sudo)

        # It exists.  OK to copy.
        sh.sudo.cp(src, dst)
        sh.sudo.chown(chown, dst)
        sh.sudo.chmod(chmod, dst)
    else:
        shutil.copyfile(src, dst)
