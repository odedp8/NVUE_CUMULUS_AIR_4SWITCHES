# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Given an instance (blob of data) and a schema, collect the defaults for that
# instance from the schema.  This is complicated because defaults are sometimes
# conditional.  For example, under /interface, the defaults depend on the type
# field.  We'll use jsonschema assertions to describe the conditions.
#
# We'll treat defaults as "annotations" in the jsonschema sense.  The rules for
# collecting annotations are pretty well defined by the 2019-09 spec.  However,
# python-jsonschema doesn't have support for 2019-09 or annotations yet.  So,
# we'll do the best we can here.
#
# A schema's defaults are "collected" when it doesn't return any assertion
# errors.  Defaults are merged together as the schemas are processed.  As they
# are merged, they can be overridden.  Finally, if a default ends up with a
# value of "null," it will be filtered out.  This allows defaults to be masked.


from cue import utils
from jsonschema.validators import extend
from jsonschema import exceptions as jsonschema_exceptions
from functools import wraps
from pydash import py_
import logging
from .format_checker import cue_format_checker


logger = logging.getLogger(__name__)


class DefaultsError(utils.ParseError):
    """
    Exception that indicates we could not generate defaults.
    """
    @property
    def description(self):
        if self.location is not None and len(self.location) > 0:
            return "Could not collect defaults: Error at {}: {}".format(
                self.location, self.reason)
        else:
            return "Could not collect defaults: Error: {}".format(self.reason)


def _accumulate_candidate_peer(candidate, subframe):
    """
    Accumulate the peer results into a candidate frame.  We put these into a
    candidate frame because we're not sure we'll keep them yet.
    """
    def _flat(tgt, src):
        if src is not None:
            tgt = utils.fast_merge(tgt, src)
        return tgt

    # Flatten the collected defaults and default-objects into the accumulators
    candidate["defaults"] = _flat(candidate["defaults"], subframe["defaults"])
    candidate["objects"] = _flat(candidate["objects"], subframe["objects"])

    # Remember if we ran into an x-cue-defaults.
    candidate["static"] |= subframe["static"]

    # Add to the whitelist.
    if subframe["whitelist"] is not None:
        candidate["whitelist"] = candidate["whitelist"] or []
        candidate["whitelist"].extend(subframe["whitelist"])


def _accumulate_candidate_child(candidate, subframe, key):
    """
    Accumulate the child results into a candidate frame.  We put these into a
    candidate frame because we're not sure we'll keep them yet.
    """
    def _flat(tgt, src):
        if src is not None:
            tgt = tgt or {}
            tgt[key] = src
        return tgt

    # Flatten the collected defaults and default-objects into the accumulators
    candidate["defaults"] = _flat(candidate["defaults"], subframe["defaults"])
    candidate["objects"] = _flat(candidate["objects"], subframe["objects"])

    # Remember if we ran into an x-cue-defaults.
    candidate["static"] |= subframe["static"]


def _accumulate_frame(frame, candidate, instance):
    """
    Accumulate the results from a candidate into the current frame.  We've
    decided to keep these results.
    """
    # If we ran into an x-cue-defaults or have non-empty defaults, add them to
    # our defaults.
    if candidate["static"] or candidate["defaults"]:
        frame["defaults"] = utils.fast_merge(
            frame["defaults"], candidate["defaults"])

    # Add to the default-objects, if we found some
    if candidate["objects"]:
        frame["objects"] = utils.fast_merge(
            frame["objects"], candidate["objects"])

    # Add to the whitelist.
    if candidate["whitelist"] is not None:
        frame["whitelist"] = frame["whitelist"] or []
        frame["whitelist"].extend(candidate["whitelist"])

    # Apply the whitelist
    if frame["whitelist"] is not None:
        frame["defaults"] = py_.pick(frame["defaults"], *instance.keys(),
                                     *frame["whitelist"])


def defaults_oneof(validator, oneof, instance, schema):
    """
    On a oneOf, check assertions in every subschema.  If one subschema passes,
    return its defaults.  Any null properties will be filtered out, allowing
    defaults to be "masked" when they aren't applicable.

    If no subschemas pass or more than one passes, raise an error.
    """
    frame = validator._peek_stack()
    candidate = validator._stack_frame()

    # True if at least one subschema passed
    passes_found = 0
    errors = []

    # Loop through each subschema and collect the defaults.
    for index, subschema in enumerate(oneof):
        # Check the subschema.  Suck in all the errors so that we pop the stack
        # at the right time.
        validator._push_stack()
        errors = list(validator.descend(instance, subschema,
                                        schema_path=index))
        subframe = validator._pop_stack()

        if not errors:
            # No errors.  Remember these defaults, but we might not keep them.
            passes_found += 1
            _accumulate_candidate_peer(candidate, subframe)

    # If one thing passed, keep the candidate frame.  We want these defaults.
    if passes_found == 1:
        _accumulate_frame(frame, candidate, instance)
    elif passes_found == 0:
        # Nothing passed.  Return a set of errors.
        yield from errors
    else:
        # More than one thing passed.  Generate an error.
        yield jsonschema_exceptions.ValidationError(
            "Multiple oneOf subschemas are valid")


def defaults_anyof(validator, anyof, instance, schema):
    """
    On an anyOf, check assertions in every subschema.  If the subschema passes,
    merge the collected defaults into our own.  Order matters, so later
    subschemas can override earlier subschemas.  Any null properties will be
    filtered out, allowing defaults to be "masked" when they aren't applicable.

    Note that this is a little different from jsonschema's anyOf, which would
    return after one subschema passes.  We'll process all of them to make sure
    we get all the defaults, even if they keep passing.  When jsonschema adds
    support for annotations, they'll probably have to do the same.

    If no subschemas pass, raise an error.
    """
    frame = validator._peek_stack()
    candidate = validator._stack_frame()

    # True if at least one subschema passed
    pass_found = False
    errors = []

    # Loop through each subschema and collect the defaults.
    for index, subschema in enumerate(anyof):
        # Check the subschema.  Suck in all the errors so that we pop the stack
        # at the right time.
        validator._push_stack()
        errors = list(validator.descend(instance, subschema,
                                        schema_path=index))
        subframe = validator._pop_stack()

        if not errors:
            # No errors.  Remember these defaults, but we might not keep them.
            pass_found = True
            _accumulate_candidate_peer(candidate, subframe)

    # If something passed, keep the candidate frame.  We want these defaults.
    if pass_found:
        _accumulate_frame(frame, candidate, instance)
    else:
        # Nothing passed.  Make sure our parent knows.
        yield from errors


def defaults_allof(validator, allof, instance, schema):
    """
    On an allOf, collect defaults from children and merge them together.  Order
    matters, so later subschemas can override earlier subschemas.  Any null
    properties will be filtered out, allowing defaults to be "masked"
    when they aren't applicable.

    For example, under the interface object, the breakout property only applies
    to certain types of interfaces.  At the top-level, the interface object
    will have assertions that decide if breakout should be masked but the
    actual breakout default come up from a properties subschema.

    If any subschema fails, raise an error.
    """
    frame = validator._peek_stack()
    candidate = validator._stack_frame()
    errors = []

    # Loop through each subschema and collect the defaults, allowing
    # later subschemas to override.
    for index, subschema in enumerate(allof):
        # Check the subschema.  Suck in all the errors so that we pop the stack
        # at the right time.
        validator._push_stack()
        errors = list(validator.descend(instance, subschema,
                                        schema_path=index))
        subframe = validator._pop_stack()

        # If we run into an error, we won't return defaults.  We can stop.
        if errors:
            break

        # No errors.  Remember these defaults, but we might not keep them.
        _accumulate_candidate_peer(candidate, subframe)

    if errors:
        # Something didn't pass.  Make sure our parent knows.
        yield from errors
    else:
        # Everything passed, keep the candidate frame.  We want these defaults.
        _accumulate_frame(frame, candidate, instance)


def defaults_properties(validator, props, instance, schema):
    """
    Descend into each property.  If its assertions pass, add its defaults to
    our own under the property's name.

    Unlike jsonschema, we descend into properties subschemas even when the
    property doesn't exist in the instance.  This is necessary to collect
    defaults.  However, we ignore errors raised by schemas for properties
    that didn't exist.

    If any subschema fails and the property was in the instance, raise an error
    and do not return the defaults.  This allows properties schemas to be used
    to conditionally collect defaults.
    """
    frame = validator._peek_stack()
    candidate = validator._stack_frame()
    errors = []

    for prop_name, subschema in props.items():
        if prop_name in instance:
            # The instance contains the property.  Run the schema as normal.
            prop_value = instance.get(prop_name, {})
            ignore_errors = False
        else:
            # The property doesn't exist.  Use an empty dictionary so that we
            # can keep descending and collectiong defaults.
            prop_value = {}
            ignore_errors = True

        # Check the subschema.  Suck in all the errors so that we pop the stack
        # at the right time.
        validator._push_stack()
        errors = list(validator.descend(prop_value, subschema,
                                        path=prop_name,
                                        schema_path=prop_name))
        subframe = validator._pop_stack()

        # Ignore errors for properties that didn't exist.
        errors = [] if ignore_errors else errors

        # If we run into an error, we won't return defaults.  We can stop.
        if errors:
            break

        # No errors.  Remember these defaults, but we might not keep them.
        _accumulate_candidate_child(candidate, subframe, prop_name)

    if errors:
        # Something didn't pass.  Make sure our parent knows.
        yield from errors
    else:
        # Everything passed, keep the candidate frame.  We want these defaults.
        _accumulate_frame(frame, candidate, instance)


def defaults_additionalproperties(validator, addprops, instance, schema):
    """
    Descend into the additionalProperties schema for each entry in the instance
    and collect defaults for it.  The defaults could be different for each
    entry.

    Note that we cheat here and assume that additionalProperties is only used
    to describe a mapping.  We don't worry about cases were
    additionalProperties is mixed with properties, allOf, etc.
    """
    frame = validator._peek_stack()
    candidate = validator._stack_frame()
    errors = []

    for key, subinstance in instance.items():
        validator._push_stack()
        errors = list(validator.descend(subinstance, addprops,
                                        path=key))
        subframe = validator._pop_stack()

        # If we run into an error, we won't return defaults.  We can stop.
        if errors:
            break

        # No errors.  Remember these defaults, but we might not keep them.
        _accumulate_candidate_child(candidate, subframe, key)

    if errors:
        # Something didn't pass.  Make sure our parent knows.
        yield from errors
    else:
        _accumulate_frame(frame, candidate, instance)


def defaults_static(validator, cue_defaults, instance, schema):
    """
    On an x-cue-defaults, we just want to return the child as is.  This is a
    handy way to just get to the point and return a structured set of defaults.
    """
    frame = validator._peek_stack()
    frame["defaults"] = utils.fast_merge(frame["defaults"], cue_defaults)
    # Remember that we ran into static defaults.  If so, we want to keep them
    # even if they are empty.  After all, the schema developer said so.
    frame["static"] = True


def defaults_marker(validator, cue_marker, instance, schema):
    """
    If this is a collection, make sure it always exists, even if it's empty.
    """
    if cue_marker == "collection":
        defaults_static(validator, {}, instance, schema)


def defaults_only(validator, cue_only, instance, schema):
    """
    Mask all collected defaults, except the ones in instance and the ones in
    cue_only, where cue_only is an array of keys.

    This is crude, but it exists to make "state" objects easier.  In those
    objects, we collect defaults for each state and each state is represented
    as a property.  However, only one property can be set at a time, so we need
    to mask all collected defaults except the one we need.

    We can't do this with schema assertions, because we need to operate on
    annotations (the collected defaults), not on the instance.  So, we need a
    magic keyword.
    """
    # Make sure cue_only is a list.  We could raise an exception here, but it
    # would be about the schema not about the data.  Awkward.
    cue_only = cue_only if isinstance(cue_only, list) else []

    # Add the list to our whitelist
    frame = validator._peek_stack()
    frame["whitelist"] = frame["whitelist"] or []
    frame["whitelist"].extend(cue_only)


def default_objects(validator, cue_objects, instance, schema):
    """
    This is like an x-cue-defaults, except we'll run it back through the
    defaults collector, fill it in as if it was an instance, and then mix it
    with the rest of the defaults.

    Use this when you want to add a whole object as a default.  Then you don't
    have to manually fill in the object's defaults.
    """
    frame = validator._peek_stack()
    frame["objects"] = utils.fast_merge(frame["objects"], cue_objects)


def defaults_default(validator, default, instance, schema):
    """
    When we see a property's default, just return it.
    """
    frame = validator._peek_stack()
    frame["defaults"] = default


def defaults_unevaluatedproperties(*args):
    """
    No-op the unevaluatedProperties check.  It doesn't apply to defaults
    collection.
    """
    pass


def defaults_propertynames(*args):
    """
    No-op the x-propertyNames check.  It doesn't apply to defaults collection.
    """
    pass


############################
# Injection vocabulary
############################

def make_inject_keyword(keyword):
    """
    Make a keyword validator function that injects a relative JSON pointer's
    instance value as a value of the given keyword.
    """

    def inject_keyword(validator, pointer_tmpl, instance, schema):
        current_location = utils.convert_path_to_json_pointer(
            validator._instance_path
        )
        # Grab any provided variable definitions.
        inject_vars = schema.get("x-injectVariables", {})
        try:
            # Dereference the values for each variable.
            template_vars = {
                var_name: utils.dereference_relative_json_pointer(
                    current_location,
                    rel_pointer,
                    validator._root_instance,
                )
                for var_name, rel_pointer in inject_vars.items()
            }
        except utils.JsonPointerError:
            # EARLY RETURN
            # If any of the provided variables couldn't be dereferenced, it's
            # fine. The "x-inject:" keyword becomes a noop.
            return

        # Resolve the template to a relative JSON pointer using the provided
        # variables.
        injected_pointer = pointer_tmpl.format(**template_vars)
        try:
            injected_value = utils.dereference_relative_json_pointer(
                current_location,
                injected_pointer,
                validator._root_instance,
            )
        except utils.JsonPointerError:
            # EARLY RETURN
            # If there's nothing there, then that's fine. Make it a noop!
            return
        else:
            # Delegate to the actual keyword handler using the injected value.
            validator.VALIDATORS[keyword].__wrapped__(
                validator, injected_value, instance, schema
            )

    return inject_keyword


INJECT_KEYWORDS = ["default", "x-cue-defaults"]
"""These keywords will get `x-inject:` variants."""


# Extend the CueValidator so we pick up all the fancy assertions we've added.
# But override some of the basic stuff to hack in the defaults collecting.
BaseDefaultsCollector = extend(
    utils.CueValidator,
    {
        "default": defaults_default,
        "oneOf": defaults_oneof,
        "anyOf": defaults_anyof,
        "allOf": defaults_allof,
        "properties": defaults_properties,
        "additionalProperties": defaults_additionalproperties,
        "x-cue-marker": defaults_marker,
        "x-cue-defaults": defaults_static,
        "x-cue-defaults-only": defaults_only,
        "x-cue-default-objects": default_objects,
        "x-unevaluatedProperties": defaults_unevaluatedproperties,
        "x-propertyNames": defaults_propertynames,
        # Mix in the `x-inject:` keywords.
        **{
            f"x-inject:{keyword}": make_inject_keyword(keyword)
            for keyword in INJECT_KEYWORDS
        }
    }
)


def decorate_keyword_validator(keyword, user_function):
    """
    Decorate a keyword/validator function pair so that the validator function
    updates the validator class's schema path with the keyword.
    """

    @wraps(user_function)
    def wrapper(validator, *args, **kwargs):
        validator._schema_path = (*validator._schema_path, keyword)
        try:
            yield from user_function(validator, *args, **kwargs) or ()
        finally:
            validator._schema_path = validator._schema_path[:-1]

    return wrapper


class DecorateValidatorsMetaClass(type(BaseDefaultsCollector)):
    """
    Decorate all the VALIDATORS items on created classes using the passed-in
    `validator_decorator` function.
    """

    def __new__(cls, name, bases, attrs, validator_decorator):
        new = type(BaseDefaultsCollector).__new__(cls, name, bases, attrs)
        new.VALIDATORS = {
            keyword: validator_decorator(keyword, validator)
            for keyword, validator in new.VALIDATORS.items()
        }
        return new


class DefaultsCollector(
    BaseDefaultsCollector,
    metaclass=DecorateValidatorsMetaClass,
    validator_decorator=decorate_keyword_validator,
):
    """
    Jsonschema "validator" that collects defaults for the given schema and
    instance.  It doesn't actually validate, but instead just collects the
    "x-cue-defaults" annotations.  "Annotations collection" is a concept
    defined in later drafts of jsonschema, but not in Draft4, so we need to do
    some of the heavy-lifting ourselves.

    In CUE, the defaults are "conditional," meaning they depend on the actual
    data.  For example, an interface's defaults will depend on its type.
    That's annoying because it means you can't generate defaults "in a vacuum."
    You always have to be generating "defaults for something."  But it's a
    reality we've decided we have to live with.

    Using jsonschema, we can deal with conditional defaults by handing the
    "validator" the "instance" for which we are collecting defaults.  Then we
    can use jsonschema assertions to test the conditions and decide which
    defaults apply.  It's exactly what "annotations" in jsonschema was designed
    to do.
    """

    # HACK: sidestep issues with how pdoc handles jsonschema's metaprogramming
    _CREATED_WITH_DEFAULT_TYPES = False

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("format_checker", cue_format_checker)
        super().__init__(*args, **kwargs)
        self._collector_stack = []

        # Track the instance/schema paths in a place where keyword validators
        # can access them.
        self._instance_path = ()
        self._schema_path = ()

    def descend(self, instance, schema, path=None, schema_path=None):
        # This is where keyword handlers update the instance path and schema
        # path. The superclass only exposes the paths via reported errors. We
        # need to expose the paths to keyword handlers.
        # To expose the paths to keyword handlers, we take any path updates
        # passed into this method and update the tracked paths.
        if path is not None:
            self._instance_path = (*self._instance_path, path)
        if schema_path is not None:
            self._schema_path = (*self._schema_path, schema_path)
        try:
            yield from super().descend(instance, schema, path, schema_path)
        finally:
            if path is not None:
                self._instance_path = self._instance_path[:-1]
            if schema_path is not None:
                self._schema_path = self._schema_path[:-1]

    def iter_errors(self, instance, _schema=None):
        """
        Delegate to the superclass, but grab the root instance that's being
        validated. Keyword handlers need it for resolving relative JSON
        pointers.
        """
        is_validation_root = not hasattr(self, "_root_instance")
        if is_validation_root:
            # Grab the instance and put it where keyword handlers can find it.
            self._root_instance = instance
        try:
            yield from super().iter_errors(instance, _schema)
        finally:
            if is_validation_root:
                # Delete the attribute so the next call knows that it's the
                # root.
                delattr(self, "_root_instance")

    def _stack_frame(self):
        """
        Return a new stack frame.
        """
        return {
            "whitelist": None,
            "defaults": None,
            "objects": None,
            "static": False,
        }

    def _push_stack(self):
        """
        Push onto the stack, going "down" another level.
        """
        self._collector_stack.append(self._stack_frame())

    def _peek_stack(self):
        """
        Return the last frame on the stack, but don't pop it.
        """
        return self._collector_stack[-1]

    def _pop_stack(self):
        """
        Pop off the stack, going "up" a level.
        """
        return self._collector_stack.pop()

    def _collect_pass(self, instance):
        self._push_stack()

        # Run the validation and find the best error to report
        errs = self.iter_errors(instance)
        err = jsonschema_exceptions.best_match(errs)

        # If we were able to collect defaults, clean-up and return them.
        if err is None:
            return self._pop_stack()

        # We ran into an error, raise it.  But also reset the state of
        # the collector so we can re-use it.
        self._collector_stack = []

        # Generate the location from the schema instead of the instance since
        # our instance is typically sparse.  Here, we usually care about what
        # part of the schema is rejecting us.
        location = utils.find_location(instance, err.absolute_schema_path)

        # Log the schema path that caused the problem.  This will be very
        # helpful when debugging schema issues.
        logger.dump("DefaultsError:", msg=err.message, instance=instance,
                    location=location)

        raise DefaultsError(location, err.message) from None

    def collect(self, instance):
        """
        Collect defaults for the given instance.
        """
        # Run a first pass.  We'll collect defaults and any additional
        # objects that need to be expanded.
        first_pass = self._collect_pass(instance)
        defaults = first_pass["defaults"] or {}

        if first_pass["objects"]:
            # The first pass identified some objects that need to be
            # expanded.  Add them to the instance and collect defaults
            # again.  Note that we'll again get a list of objects that need
            # to be expanded, but we'll ignore it.  Otherwise, we'll end up
            # in a resursive, infinite loop.
            second_pass = self._collect_pass(
                utils.fast_merge(instance, first_pass["objects"]))
            defaults = second_pass["defaults"]

        # Put it all together and return it
        return utils.filter_none(defaults)
