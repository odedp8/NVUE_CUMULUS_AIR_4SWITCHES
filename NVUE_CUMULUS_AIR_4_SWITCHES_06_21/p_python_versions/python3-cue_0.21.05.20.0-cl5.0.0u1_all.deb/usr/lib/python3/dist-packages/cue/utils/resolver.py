# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from connexion.resolver import Resolver as BaseResolver


# The OpenAPI guys like to use operationId to point at the code that implements
# an endpoint.  For example, 'operationId: foo.bar.get' would run the get()
# method in the "foo.bar" module.  This is exposing your internal code
# structure and there are a couple problems with that:
#   1) Security.  If they know, they can target their attacks.
#   2) If you refactor your code, you're changing the API.
#
# For those reasons, we'll reserve operationId for the clients.  We'll populate
# it with something they can use in their code generation tools.  For example,
# 'operationId: getFooBar' could be rendered into a "cue.getFooBar()" client
# method that knows how to call our "GET /foo/bar/<id>" endpoint.
#
# On the server side, we'll use x-cue-controller to point to the
# implementation.


class ControllerLookupError(LookupError):
    pass


class Resolver(BaseResolver):
    """
    Custom resolver that looks for our x-cue-controller extension.  In
    Connexion, a resolver's job is to return a Resolution, which points to the
    code that can implement an operation.
    """

    def __init__(self, api_client):
        """
        Create a new resolver.  As we resolve operations, build up the given
        api client accessor object.
        """
        super().__init__()
        self._api_client = api_client

    def resolve_operation_id(self, operation):
        """
        Return the implementation "path" in Python dotted notation.  The super
        class will find the function and return it to Connexion as part of the
        Resolution.

        Note that operation_id here is not the operationId passed to the client
        with the specification.  Instead, it's the controller function that
        implements the endpoint.  Connexion will resolve this into a real
        function for us and pass it into resolve().
        """
        # Connexion doesn't expose the raw schema publicly, but stashes it on a
        # private variable.  Break the rules and use it.
        controller = operation._operation.get('x-cue-controller')

        # If we don't find an x-cue-controller, freak out.  We require one.
        if controller is None:
            msg = 'x-cue-controller is required on "{}:{}"'.format(
                operation.method, operation.path)
            raise ControllerLookupError(msg)

        return controller

    def resolve(self, operation):
        """
        After the super class builds the resolution, wrap the function in a
        partial that provides the runtime context.
        """
        # Do what we normally do
        res = super().resolve(operation)

        # This is the raw controller.  This is the function pointed to by
        # x-cue-controller.  Connexion resolved it for us.
        ep = res.function

        # Get the operationId, which is a client facing unique string for the
        # endpoint.  Note that res.operation_id is not what we want; that's the
        # private controller.  Thanks, Connexion for using awesome, confusing
        # names.
        operation_id = operation._operation.get('operationId')

        # Build a partial that injects ctx into the controller.
        ep_partial = self._api_client.new_endpoint(ep, operation_id)

        # And use the partial instead.
        res.function = ep_partial

        # Finally, give connexion the operationId, which is what it expects.
        # It will use this name to build Flask blueprints and it must be
        # unique.  Our operationIds are unique, but our controllers may not be.
        res.operation_id = operation_id

        return res
