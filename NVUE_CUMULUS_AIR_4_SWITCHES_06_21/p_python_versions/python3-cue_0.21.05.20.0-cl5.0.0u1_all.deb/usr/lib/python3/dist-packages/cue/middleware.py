# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
Middleware for CUE operations.

Each operation middleware will be called as
`middleware(operation, request, function)` where:

- `operation` is an `Operation` instance;
- `request` is the request object processed by connexion; and
- `function` is the wrapped endpoint function. (Call it as `function(request)`
    to continue handling the request.)
"""

from urllib.parse import urlparse, urlunparse
from functools import wraps
from cue.exceptions import NotFound, InternalServerError
from cue import utils


OPENAPI_MIMETYPE = "application/vnd.oai.openapi+json"

LINKS_MIMETYPE = "application/vnd.cue.links+json"

TEMPLATELINKS_MIMETYPE = "application/vnd.cue.templatelinks+json"


###############################################################################
# Generic middleware utilities

class Operation:
    """
    Information about an OpenAPI operation.
    """

    __slots__ = ("path", "method", "full_spec", "url_prefix")

    def __init__(self, path, method, full_spec, url_prefix):
        self.path = path
        """The OpenAPI path template key for the current operation."""

        self.method = method
        """The OpenAPI method key for the current operation."""

        self.full_spec = full_spec
        """The full OpenAPI spec containing the current operation."""

        self.url_prefix = url_prefix
        """The URL prefix for the app containing the current operation."""


def get_accept(request):
    """
    Get the list of "Accept" values from request.
    """
    return tuple(request.headers.getlist('accept'))


def when_accept(mimetype):
    """
    Decorated middleware only applies when request accepts `mimetype`.
    """

    def decorator(middleware_function):

        @wraps(middleware_function)
        def when_accept_wrapper(operation, request, function):
            # Only match it if it's the first "Accept" item.
            if mimetype in get_accept(request)[:1]:
                return middleware_function(operation, request, function)
            else:
                return function(request)

        return when_accept_wrapper

    return decorator


def when_method(method):
    """
    Decorated middleware only applies when operation method equals `method`.
    """

    def decorator(middleware_function):

        @wraps(middleware_function)
        def when_method_wrapper(operation, request, function):
            if operation.method == method:
                return middleware_function(operation, request, function)
            else:
                return function(request)

        return when_method_wrapper

    return decorator


###############################################################################
# Middleware implementations

@when_method("get")
@when_accept(OPENAPI_MIMETYPE)
def content_openapi_middleware(operation, request, function):
    """
    Return the OpenAPI Path Item Object for the current operation.
    """

    # Get the path definition
    res = operation.full_spec["paths"][operation.path]
    try:
        query_pointers = request.query["pointers"]
    except KeyError:
        # EARLY RETURN
        # If the client didn't specify, then give them the whole thing.
        return res

    # NOTE: Connexion aggregates all duplicates of a query parameter and
    #       handles the duplicates based off the spec. The "pointers" param
    #       isn't in the spec, so we need to handle the duplicates
    #       ourselves.
    pointers = {}
    for pointers_json in query_pointers:
        decoded_pointers = utils.json_load(pointers_json)
        pointers.update(dict.fromkeys(decoded_pointers))

    pointed = {}
    for ptr in pointers.keys():
        try:
            pointed[ptr] = utils.dereference_json_pointer(ptr, res)
        except utils.JsonPointerLookupError:
            # Ignore any pointers we couldn't lookup.  Other pointer errors
            # will find their way back to the client.
            pass
    return pointed


@when_method("get")
@when_accept(LINKS_MIMETYPE)
def content_links_middleware(operation, request, function):
    """
    Return links related to this operation.
    """
    request_path = urlparse(request.url).path.rstrip("/")
    spec_paths = operation.full_spec["paths"]

    links = {}
    links["self"] = {
        "rel": "self",
        "href": request_path,
        "methods": list(spec_paths[operation.path].keys())
    }

    # Only look at paths that have one more level than current path.
    self_slashes = operation.path.rstrip("/").count("/")
    paths = {
        path: obj
        for path, obj in spec_paths.items()
        if (path.startswith(operation.path)
            and path.rstrip("/").count("/") == self_slashes + 1)
    }

    wildcard_path = None
    # Add child links for explicit children
    for child_path, path_obj in paths.items():
        token = child_path[len(operation.path):].lstrip("/")
        if "{" in token:
            wildcard_path = child_path
        else:
            links["child:" + token] = {
                "rel": "child",
                "href": request_path + "/" + token,
                "methods": list(path_obj.keys())
            }

    # Fill out possible values for wildcard by recursively calling the
    # current endpoint and grabbing the keys.
    if wildcard_path is not None:
        wildcard_path_methods = list(spec_paths[wildcard_path].keys())
        data = function(request)
        for key in data.keys():
            links[f"child:{key}"] = {
                "rel": "child",
                "href": request_path + "/" + key,
                "methods": wildcard_path_methods,
            }

    return {"links": links}


@when_method("get")
@when_accept(TEMPLATELINKS_MIMETYPE)
def content_templatelinks_middleware(operation, request, function):
    """
    Return template links related to the current operation.
    """
    parsed_url = urlparse(request.url)
    base = urlunparse(tuple([
        parsed_url.scheme,
        parsed_url.netloc,
        "", "", "", "",
    ]))
    request_path = parsed_url.path.rstrip("/")
    spec_paths = operation.full_spec["paths"]
    links = []
    template_filled = {}
    template_suggested = {}

    url_prefix = operation.url_prefix

    self_href = url_prefix + operation.path

    self_link = {
        "rel": "self",
        "href": self_href,
        "targetHints": {
            "allow": list(map(
                # Use uppercase, since that's the norm for the "Allow" HTTP
                # header.
                lambda method: method.upper(),
                spec_paths[operation.path].keys()
            ))
        }
    }
    links.append(self_link)

    for tmpl_token, path_token in zip(
        self_href.split("/"), request_path.split("/")
    ):
        if tmpl_token.startswith("{"):
            filled_token = tmpl_token[1:-1]
            template_filled[filled_token] = path_token

    # Any path that starts with the path and one trailing slash is a
    # subpath. (The trailing slash is necessary to prevent /foo-name from
    # being considered a subpath of /foo.)
    child_path_prefix = operation.path.rstrip("/") + "/"

    # Only look at paths that have one more level than current path.
    self_slashes = operation.path.rstrip("/").count("/")
    child_paths = {
        path: obj
        for path, obj in spec_paths.items()
        if (
            path.startswith(child_path_prefix)
            and path.rstrip("/").count("/") == self_slashes + 1
        )
    }

    wildcard_token = None
    wildcard_path = None
    # Add child links for explicit children
    for child_path, path_obj in child_paths.items():
        token = child_path[len(operation.path):].lstrip("/")
        if "{" in token:
            wildcard_token = token[1:-1]
            wildcard_path = child_path
        links.append({
            "rel": "up",
            "anchor": url_prefix + child_path,
            "contextHints": {
                "allow": list(map(
                    lambda method: method.upper(),
                    path_obj.keys()
                )),
            },
        })

    # Fill out possible values for wildcard by recursively calling the
    # current endpoint and grabbing the keys.
    if wildcard_path is not None:
        try:
            data = function(request)
        except NotFound:
            # Don't explode if there's no data for it right now.
            data = {}
        template_suggested[wildcard_token] = list(data.keys())

    template_container = {}
    if template_suggested:
        template_container["suggested"] = template_suggested
    if template_filled:
        template_container["filled"] = template_filled

    result = {
        "base": base,
        "links": links,
    }
    if template_container:
        result["template"] = template_container

    return result


def no_none_response_middleware(operation, request, function):
    """
    Don't let endpoints respond with `None`.

    There's never a case where a `None` response on its own makes sense. Treat
    it as a 500 error instead.
    """
    response = function(request)
    if response is None:
        raise InternalServerError("Cannot return 'None' from an endpoint.")
    return response
