# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
The `cue` module defines the core of cue. It finds the units, prepares them,
and runs them all as HTTP APIs.


Sub-modules of interest
-----------------------
- `cue.events` defines the [events] that units can [register]
  [handlers] for in their `prepare_unit` function.


[events]: events.html#available-events
[register]: events.html#how-to-register-for-an-event
[handlers]: events.html#handler-functions
"""


import logging


def logger_dump(self, *args, **kws):
    """
    logger.debug() alternative that's easier to use.  The thought here is that
    most of the time, you just want to inspect variables and not mess with
    formatting a log message.  Formatting is appropriate for info, warning, and
    error, but for debug, you don't care if it's pretty.

    Further, it needs to be efficient.  If debug is disabled, the debug call
    should be a no-op.  That means we don't even waste time computing the
    arguments before calling it.  In other words, commas are good, pluses are
    bad.

    dump() works by simply str()'ing every arg and joining them with a space
    between.  If you use kwargs, it will output key=str(value).

    Examples:
      logger.dump("Start:", param1, parm2)
      logger.dump("Failed:", reason=reason, args=args)
      logger.dump("Config:", *config)
      logger.dump("roses", red, "violets", blue)
    """
    def limited_stringify(obj):
        str_obj = str(obj)
        # If it's too long, clip it.
        if len(str_obj) > 200:
            str_obj = str_obj[:200] + "..."
        return str_obj

    if self.isEnabledFor(logging.DEBUG):
        # str() all the arguments, limiting each to 100 characters to avoid
        # excessive output.
        argstrs = [limited_stringify(arg) for arg in args]
        # If we got kws, then we'll do the same, but give each thing a name.
        kwstrs = [k + "=" + limited_stringify(v) for k, v in kws.items()]
        # Generate the log message
        # Just str() every argument and concat the results.
        self._log(logging.DEBUG, " ".join(argstrs + kwstrs), [])


# Patch it into the base Logger.  Share and enjoy.
logging.Logger.dump = logger_dump


audit_logger = logging.getLogger("audit")
"""
Special logger for logging audit messages.  This makes it convenient to find
where we audit log and allows us to easily reformat and redirect audit messages
later.

Should always be called with:
  audit_logger.info("The audit message")
"""
