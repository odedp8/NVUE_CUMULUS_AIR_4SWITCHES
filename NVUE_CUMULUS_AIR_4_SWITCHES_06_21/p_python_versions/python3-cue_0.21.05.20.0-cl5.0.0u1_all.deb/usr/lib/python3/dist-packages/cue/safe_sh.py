# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Make python-sh safe for cued.  We subclass Command and RunningCommand, then
# monkey-patch our classes back into the module so all of cued uses them.


import sh
import shlex
from cue import audit_logger


class RunningCommand(sh.RunningCommand):
    """
    Subclass RunningCommand to add cued specific features.
    """
    def __init__(self, cmd, *args, **kwargs):
        """
        Create a new RunningCommand as usual, but generate an audit log first
        to record the command that's to be run.  Every run command results in a
        new instance of RunningCommand, so we'll always write an audit log.
        """
        # Generate a log message and log it.  cmd comes in as an array of bytes
        # objects.  We need to convert that into a nice, friendly string.
        msg = "Running: " + " ".join(
            map(lambda arg: shlex.quote(arg.decode("UTF-8")), cmd)
        )
        audit_logger.info(msg[:200])

        # Create the instance as normal.
        super().__init__(cmd, *args, **kwargs)

    def wait(self):
        """
        Wait for the command to finish as usual, but write an audit log if it
        failed.  Every run command ends with a wait().
        """
        try:
            super().wait()
        except sh.ErrorReturnCode as ex:
            # The command failed with a return code.  Log the return code to
            # INFO and dump any captured output to DEBUG.
            audit_logger.info("Failed: rc=%d", ex.exit_code)

            clean_stdout = ex.stdout.decode("UTF-8").strip()
            clean_stdout = clean_stdout.replace("\n", ".").replace("\r", ".")

            clean_stderr = ex.stderr.decode("UTF-8").strip()
            clean_stderr = clean_stderr.replace("\n", ".").replace("\r", ".")

            audit_logger.dump(stdout=clean_stdout, stderr=clean_stderr)
            raise
        except Exception as ex:
            # Generic failure.  Try to stringify the error and log it.
            msg = str(ex)
            audit_logger.info("Failed: %s", msg)
            raise


# Monkey-patch our wrappers into place.  This isn't as easy as you might think
# because sh wraps itself behind the SelfWrapper class.  It keeps the original
# module, the one we need to monkey-patch, in self.__selfmodule.  Because of
# double-underscore mangling, that becomes _SelfWrapper__self_module.  Maybe we
# should take the hint and stay away, but well, we really want to use sh and to
# do so, we must extend it.
sh.__dict__["_SelfWrapper__self_module"].RunningCommand = RunningCommand
