# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Manage loading and rendering of templates.  Our templates are spread out
# across the units.  Each will have one or more template packages.  As we learn
# about them, we'll add them to the jinja environment so that it can manage
# caching.  We'll use a PrefixLoader to "route" into each template package.

import jinja2
from pathlib import Path
import logging


logger = logging.getLogger(__name__)


_loader_mapping = {}
"""
Mapping behind our PrefixLoader.  It maps from a template package's name
to a FileSystemLoader rooted at that packages's location on the filesystem.
We'll populate the mapping as we learn about template packages.
"""

_loader = jinja2.PrefixLoader(_loader_mapping, delimiter=":")
"""
PrefixLoader that "routes" to each template package's loader.
"""

_env = jinja2.Environment(
    loader=_loader,
    autoescape=jinja2.select_autoescape(['html', 'xml']),
    trim_blocks=True,
    lstrip_blocks=True,
    keep_trailing_newline=True
)
"""
Jinja's environment.  It finds, loads, and caches templates for us.
"""


def register_package(pkg):
    """
    Register the given package as a templates package.
    """
    if pkg.__name__ not in _loader_mapping:
        # The package's file will actually be it's __init__.py.  Go up a
        # parent to get the package's root.
        pkg_path = Path(pkg.__file__).parent

        logger.dump("Registering", pkg.__name__, "->", pkg_path)

        # Create the loader
        _loader = jinja2.FileSystemLoader(str(pkg_path))

        # And map it in.
        _loader_mapping[pkg.__name__] = _loader


def render_template(pkg, name, **kwargs):
    """
    Render a template using kwargs as the context.  pkg is the package that
    contains the template and name is the template's name within pkg.

    For now, we assume pkg is a directory package.  Zip file aren't supported.

    Returns a generator that yields a series of strings so the output can be
    streamed to a file.
    """
    # All templates should have a '.j2' extension but we supply the filename
    # without the '.j2' extension to the render function
    if not name.endswith('.j2'):
        name = name + '.j2'

    # Generate an "absolute" name for the template.  This is the package name
    # plus the template name.
    abs_name = pkg.__name__ + ":" + name

    logger.dump("Rendering", abs_name)

    # Fetch the template.
    try:
        tmpl = _env.get_template(abs_name)
    except jinja2.exceptions.TemplateSyntaxError as err:
        # jinja2 rewrites the traceback to make it look as if the error is
        # coming from the jinja template file, as if it were part of the python
        # call stack.
        # Questionably, if the exception sees that this translation happened,
        # the `__str__` method will drop the line number, filename, and source
        # line out of the message. After all, if the developer wants that
        # information, they can find it in the traceback, right?
        # This sucks because the important information is now buried deep
        # inside a traceback.
        # To fix this, we'll tell the exception that it hasn't been translated
        # and force it to print the actionable information in the error
        # message.
        err.translated = False
        raise

    # Render into a generator
    return tmpl.generate(**kwargs)
