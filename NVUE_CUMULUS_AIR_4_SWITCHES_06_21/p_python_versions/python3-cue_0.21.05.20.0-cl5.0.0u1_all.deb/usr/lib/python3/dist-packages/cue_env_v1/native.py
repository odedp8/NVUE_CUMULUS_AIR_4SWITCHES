# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from textwrap import dedent
import logging


logger = logging.getLogger(__name__)


# translate the pretty keys to something a bit more predictable
def _normalize_key(key):
    return key.lower().replace(" ", "-")


def hostnamectl_get(ctx):
    logger.info("Running 'hostnamectl'")
    output = ctx.sh.sudo.hostnamectl()
    lines = output.splitlines()

    result = {}

    for line in lines:
        split = line.split(":", 1)

        key = _normalize_key(split[0].strip())
        value = split[1].strip()

        result[key] = value

    return result


"""
These are defined in `man dpkg-query` under `--showformat`:

"This option is used to specify  the  format  of  the  output  --show  will
produce  (short  option  since  dpkg 1.13.1).  The format is a string that
will be output for each package listed."
"""
_SHOWFORMAT_SPECIFIERS = [
    "Architecture",
    "Bugs",
    "Conffiles",
    "Config-Version",
    "Conflicts",
    "Breaks",
    "Depends",
    "Description",
    "Enhances",
    "Essential",
    "Filename",
    "Homepage",
    "Installed-Size",
    "MD5sum",
    "MSDOS-Filename",
    "Maintainer",
    "Origin",
    "Package",
    "Pre-Depends",
    "Priority",
    "Provides",
    "Recommends",
    "Replaces",
    "Section",
    "Size",
    "Source",
    "Status",
    "Suggests",
    "Tag",
    "Triggers-Awaited",
    "Triggers-Pending",
    "Version",
    "binary:Package",
    "binary:Synopsis",
    "binary:Summary",
    "db:Status-Abbrev",
    "db:Status-Want",
    "db:Status-Status",
    "db:Status-Eflag",
    "db-fsys:Files",
    "db-fsys:Last-Modified",
    "source:Package",
    "source:Version",
    "source:Upstream-Version",
]


def dpkg_query_show_get(ctx):
    format_fields = [specifier + "==${" + specifier + "}"
                     for specifier in _SHOWFORMAT_SPECIFIERS]
    format_string = "\\t".join(format_fields) + "\\n\\n\\t"

    output = ctx.sh.sudo("dpkg-query", "--show", "--showformat", format_string)

    entries = output.split("\n\n\t")[:-1]
    result = []

    for entry in entries:
        item = {}
        split_entry = entry.split("\t")
        for row in split_entry:
            key, _, value = row.partition("==")
            # some fields need extra parsing
            if key == "Conffiles" or key == "db-fsys:Files":
                value = dedent(value).splitlines()
            elif key == "Description":
                summary_and_detail = value.split("\n", 1)
                summary = summary_and_detail[0]
                detail = (
                    # detail is indented a single space when we get it
                    dedent(summary_and_detail[1])
                    if len(summary_and_detail) > 1
                    else None
                )
                value = {
                    "summary": summary,
                    "detail": detail
                }

            item[key] = value

        result.append(item)

    return result
