# Copyright (C) 2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


PTP4L_SERVICE = "ptp4l"


def cuev1_ptp_get(ctx):
    """
    Fill in the global ptp object using systemctl.
    """
    is_active = ctx.platform_v1.getSystemctlIsActive("PTP4L_SERVICE")

    ptp = {
        "enable": "on" if is_active == "active" else "off"
    }

    return ptp
