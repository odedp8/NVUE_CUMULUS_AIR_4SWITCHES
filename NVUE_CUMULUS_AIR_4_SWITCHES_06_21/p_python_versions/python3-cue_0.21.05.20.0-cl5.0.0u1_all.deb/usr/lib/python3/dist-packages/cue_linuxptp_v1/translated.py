# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


def ptp_default_ds_attribs_get(ctx, instance_id):
    ds_attribs = {}
    ds = ctx.linuxptp_v1.getDefaultDS(instance_id)
    ds_attribs['clock-id'] = ds['clock-id']
    ds_attribs['number-ports'] = ds['number-ports']
    return ds_attribs


def ptp_default_ds_clock_quality_get(ctx, instance_id):
    clock_quality = {}
    ds = ctx.linuxptp_v1.getDefaultDS(instance_id)
    clock_quality = ds['clock-quality']
    return clock_quality


def ptp_if_instance_get(ctx, interface_id):
    ptp_if_inst = {}

    port_ds = ctx.linuxptp_v1.getPTPPortDS(interface_id)
    ptp_if_inst['port-state'] = port_ds['port-state']
    ptp_if_inst['peer-mean-path-delay'] = port_ds['peer-mean-path-delay']
    ptp_if_inst['protocol-version'] = port_ds['protocol-version']
    ptp_if_counters = ctx.linuxptp_v1.getPTPPortStats(interface_id)

    ptp_if_inst['counters'] = ptp_if_counters

    return ptp_if_inst
