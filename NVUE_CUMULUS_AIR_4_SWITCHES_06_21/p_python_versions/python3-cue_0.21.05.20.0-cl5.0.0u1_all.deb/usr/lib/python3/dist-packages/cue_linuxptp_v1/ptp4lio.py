
# Copyright (C) 2020, 2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

import socket
import os
import binascii
import struct
from cue_linuxptp_v1 import ptp4lconstants as ptp4lconst

ptp_sequence_id = 1
ptp_domain = 0

ptp4lsys_port_map = {}


def ptp_build_portid(port):
    port_id = '{0:04x}'.format(port)
    port_id = ptp4lconst.PTP_DEFAULT_CLOCK_ID + ':' +  \
        ':'.join(port_id[i:i + 2] for i in range(0, 4, 2))
    return port_id


# PTP Messages Header
class PTPHeader:
    def __init__(self,
                 tsmt=0,
                 ver=0,
                 domain=0,
                 source_port_id='00:00:00:00:00:00:00:00:00:00',
                 seq=0,
                 control=0,
                 log_msg_interval=0):
        self.tsmt = tsmt
        self.version = ver
        self.domain_number = domain
        self.source_port_id = source_port_id
        self.sequence_id = seq
        self.control = control
        self.log_msg_interval = log_msg_interval

    def build(self):
        port_id = binascii.unhexlify(self.source_port_id.replace(':', ''))
        hdr = struct.pack('!BBHBBHQL10sHBB',
                          self.tsmt & 0x0F,
                          self.version & 0x0F,
                          struct.calcsize('!BBHBBHQLBBBBBBBBHHBB'),
                          self.domain_number,
                          0,
                          0,
                          0,
                          0,
                          port_id,
                          self.sequence_id,
                          self.control,
                          self.log_msg_interval,)

        return hdr

    def size(self):
        return struct.calcsize('!BBHBBHQL10sHBB')

    def hdr_unpack(self, data):
        return struct.unpack('>BBHBBHQL10sHBB')


# PTP Management messages - follows the PTP Messages Header
class PTPManagementMsg:
    def __init__(self,
                 target_port_id='00:00:00:00:00:00:00:00:00:00',
                 starting_boundary_hops=0,
                 boundary_hops=0,
                 action=0):
        self.target_port_id = target_port_id
        self.starting_boundary_hops = starting_boundary_hops
        self.boundary_hops = boundary_hops
        self.action = action

    def build(self):
        port_id = binascii.unhexlify(self.target_port_id.replace(':', ''))
        mgmt_msg = struct.pack('!10sBBBB',
                               port_id,
                               self.starting_boundary_hops,
                               self.boundary_hops,
                               self.action, 0)
        return mgmt_msg

    def size(self):
        return struct.calcsize('!10sBBBB')


# TLV portion of the PTP Management Message
class PTPManagementTLV:
    def __init__(self,
                 tlv_type=0,
                 tlv_length=0,
                 tlv_id=0,):
        self.type = tlv_type
        self.length = tlv_length
        self.mgmt_tlv_id = tlv_id

    def build(self):
        mgmt_tlv = struct.pack('!HHH',
                               self.type,
                               self.length,
                               self.mgmt_tlv_id,)
        return mgmt_tlv

    def size(self):
        return struct.calcsize('!HHH')


class PTPdefaultDS:
    def __init__(self,
                 flags=0,
                 number_of_ports=0,
                 priority1=0,
                 clock_class=0,
                 clock_accuracy=0,
                 offset_sclaled_log_variance=0,
                 priority2=0,
                 clock_id='00:00:00:00:00:00:00:00',
                 domain_number=0,):
        self.flags = flags
        self.numberOfPorts = number_of_ports
        self.priority1 = priority1
        self.clockClass = clock_class
        self.clockAccuracy = clock_accuracy
        self.offsetSclaledLogVariance = offset_sclaled_log_variance
        self.priority2 = priority2
        self.clockId = clock_id
        self.domainNumber = domain_number

    def build(self):
        clock_id = binascii.unhexlify(self.clockId.replace(':', ''))
        default_ds = struct.pack('!BBHBBBHB8sBB',
                                 self.flags, 0,
                                 self.numberOfPorts,
                                 self.priority1,
                                 self.clockClass,
                                 self.clockAccuracy,
                                 self.offsetSclaledLogVariance,
                                 self.priority2,
                                 clock_id,
                                 self.domainNumber, 0, )
        return default_ds

    def size(self):
        return struct.calcsize('!BBHBBBHB8sBB')

    def build_dict(self, data, offset):
        ds = {}
        clockquality = {}
        if (len(data) - offset) < (self.size()):
            return ds
        def_tup = struct.unpack_from('>BBHBBBHB8sBB', data, offset)
        ds['two-step'] = 'on' \
            if (def_tup[0] & ptp4lconst.DDS_TWO_STEP_FLAG) else 'off'
        ds['slave-only'] = 'on' \
            if (def_tup[0] & ptp4lconst.DDS_SLAVE_ONLY) else 'off'
        ds['number-ports'] = def_tup[2]
        ds['priority1'] = def_tup[3]
        clockquality['clock-class'] = def_tup[4]
        clockquality['clock-accuracy'] = def_tup[5]
        clockquality['offset-sclaled-log-variance'] = def_tup[6]
        ds['clock-quality'] = clockquality

        ds['priority2'] = def_tup[7]

        off = offset + 10
        clkid_tup = struct.unpack_from('>BBBBBBBB', data, off)
        clkid = ''
        for x in clkid_tup:
            clkid += '{0:02x}'.format(x)
        clkid_str = ':'.join(clkid[i:i + 2] for i in range(0, 16, 2))
        ds['clock-id'] = clkid_str

        off += 8
        dtup = struct.unpack_from('>BB', data, off)
        ds['domain'] = dtup[0]
        return ds


class PTPparentDS:
    def __init__(self,
                 parent_port_id='00:00:00:00:00:00:00:00:00:00',
                 parent_stats=0,
                 obs_parent_off_log_var=0,
                 obs_arent_phase_change_rate=0,
                 gm_priority1=0,
                 gm_clock_class=0,
                 gm_clock_accuracy=0,
                 gm_clk_off_log_variance=0,
                 gm_priority2=0,
                 gm_clock_id='00:00:00:00:00:00:00:00'):
        self.parentPortId = parent_port_id
        self.parentStats = parent_stats
        self.observedParentOffsetScaledLogVariance = obs_parent_off_log_var
        self.observedParentClockPhaseChangeRate = obs_arent_phase_change_rate
        self.grandmasterPriority1 = gm_priority1
        self.grandmasterClockClass = gm_clock_class
        self.grandmasterClockAccuracy = gm_clock_accuracy
        self.grandmasterClockoffsetScaledLogVariance = gm_clk_off_log_variance
        self.grandmasterPriority2 = gm_priority2
        self.grandmasterClockId = gm_clock_id

    def build(self):
        pp_id = binascii.unhexlify(self.parentPortId.replace(':', ''))
        clock_id = binascii.unhexlify(self.grandmasterClockId.replace(':', ''))
        parent_ds = struct.pack('!10sBBHIBBBHB8s',
                                pp_id,
                                self.parentStats, 0,
                                self.observedParentOffsetScaledLogVariance,
                                self.observedParentClockPhaseChangeRate,
                                self.grandmasterPriority1,
                                self.grandmasterClockClass,
                                self.grandmasterClockAccuracy,
                                self.grandmasterClockoffsetScaledLogVariance,
                                self.grandmasterPriority2,
                                clock_id,)
        return parent_ds

    def size(self):
        return struct.calcsize('!10sBBHIBBBHB8s')

    def build_dict(self, data, offset):
        ds = {}
        clockquality = {}
        par_port_id = ''
        gm_id = ''

        if (len(data) - offset) < (self.size()):
            return ds
        # Unpack the Parent port ID
        par_port_tup = struct.unpack_from('>BBBBBBBBBB', data, offset)
        for x in par_port_tup:
            par_port_id += '{0:02x}'.format(x)
        clkid_str = ':'.join(par_port_id[i:i + 2] for i in range(0, 16, 2))
        pid_str = ':'.join(par_port_id[i:i + 2] for i in range(16, 20, 2))
        portid_str = clkid_str + '-' + pid_str

        off = offset + 10

        # Unpack remaining except GM ID
        par_tup = struct.unpack_from('>BBHIBBBHB8s', data, off)
        ds['parent-port-id'] = portid_str
        ds['parent-stats'] = 'on' if (par_tup[0] == 1) else 'off'
        ds['obs-parent-offset-scaled-log-variance'] = par_tup[2]
        ds['obs-parent-clock-phase-change-rate'] = par_tup[3]
        ds['grandmaster-priority1'] = par_tup[4]

        clockquality['clock-class'] = par_tup[5]
        clockquality['clock-accuracy'] = par_tup[6]
        clockquality['offset-scaled-log-variance'] = par_tup[7]
        ds['grandmaster-clock-quality'] = clockquality

        ds['grandmaster-priority2'] = par_tup[8]

        # Unpack the GM ID
        off = off + 14
        gm_id_tup = struct.unpack_from('>BBBBBBBB', data, off)
        for x in gm_id_tup:
            gm_id += '{0:02x}'.format(x)
        clkid_str = ':'.join(gm_id[i:i + 2] for i in range(0, 16, 2))
        ds['grandmaster-id'] = clkid_str

        return ds


class PTPcurrentDS:
    def __init__(self,
                 steps_removed=0,
                 offset_from_master=0,
                 mean_path_delay=0,):
        self.stepsRemoved = steps_removed
        self.offsetFromMaster = offset_from_master
        self.meanPathDelay = mean_path_delay

    def build(self):
        current_ds = struct.pack('!Hqq',
                                 self.stepsRemoved,
                                 self.offsetFromMaster,
                                 self.meanPathDelay,)
        return current_ds

    def size(self):
        return struct.calcsize('!Hqq')

    def build_dict(self, data, offset):
        ds = {}
        if (len(data) - offset) < (self.size()):
            return ds
        cur_tup = struct.unpack_from('>Hqq', data, offset)
        ds['steps-removed'] = cur_tup[0]
        ds['offset-from-master'] = cur_tup[1]
        ds['mean-path-delay'] = cur_tup[2]
        return ds


class PTPtimePropertiesDS:
    def __init__(self,
                 current_utc_offset=0,
                 flags=0,
                 time_source=0,):
        self.currentUtcOffset = current_utc_offset
        self.flags = flags
        self.timeSource = time_source

    def build(self):
        time_properties_ds = struct.pack('!HBB',
                                         self.currentUtcOffset,
                                         self.flags,
                                         self.timeSource,)
        return time_properties_ds

    def size(self):
        return struct.calcsize('!HBB')

    def build_dict(self, data, offset):
        ds = {}
        if (len(data) - offset) < (self.size()):
            return ds
        time_tup = struct.unpack_from('>HBB', data, offset)
        ds['current-utc-offset'] = time_tup[0]
        ds['current-utc-offset-valid'] = \
            'on' if (time_tup[1] & ptp4lconst.UTC_OFF_VALID) else 'off'
        ds['leap59'] = 'on' if (time_tup[1] & ptp4lconst.LEAP_59) else 'off'
        ds['leap61'] = 'on' if (time_tup[1] & ptp4lconst.LEAP_61) else 'off'
        ds['time-traceable'] = 'on' \
            if (time_tup[1] & ptp4lconst.TIME_TRACEABLE) else 'off'
        ds['freq-traceable'] = 'on' \
            if (time_tup[1] & ptp4lconst.FREQ_TRACEABLE) else 'off'
        if (time_tup[1] & ptp4lconst.PTP_TIMESCALE):
            ds['ptp-time-scale'] = 'on'
        else:
            ds['ptp-time-scale'] = 'off'
        if (time_tup[2] == 0):
            ds['time-source'] = 'atomic'
        elif (time_tup[2] == 1):
            ds['time-source'] = 'gnss'
        elif (time_tup[2] == 2):
            ds['time-source'] = 'terrestrial-radio'
        elif (time_tup[2] == 3):
            ds['time-source'] = 'serial-timecode'
        elif (time_tup[2] == 4):
            ds['time-source'] = 'ptp'
        elif (time_tup[2] == 5):
            ds['time-source'] = 'ntp'
        elif (time_tup[2] == 6):
            ds['time-source'] = 'handset'
        elif (time_tup[2] == 7):
            ds['time-source'] = 'other'
        elif (time_tup[2] == 8):
            ds['time-source'] = 'internal-oscillator'
        return ds


class PTPportDS:
    def __init__(self, port_id='00:00:00:00:00:00:00:00:00:00'):
        self.portId = port_id
        self.portState = 0
        self.logMinDelayReqInterval = 0
        self.peerMeanPathDelay = 0
        self.logAnnounceInterval = 0
        self.announceReceiptTimeout = 0
        self.logSyncInterval = 0
        self.delayMechanism = 0
        self.logMinPdelayReqInterval = 0
        self.versionNumber = 0

    def build(self):
        port_id = binascii.unhexlify(self.portId.replace(':', ''))
        port_ds = struct.pack('!10sBbQbBbBbB',
                              port_id,
                              self.portState,
                              self.logMinDelayReqInterval,
                              self.peerMeanPathDelay,
                              self.logAnnounceInterval,
                              self.announceReceiptTimeout,
                              self.logSyncInterval,
                              self.delayMechanism,
                              self.logMinPdelayReqInterval,
                              self.versionNumber,)
        return port_ds

    def size(self):
        return struct.calcsize('!10sBbQbBbBbB')

    def build_dict(self, data, offset):
        ds = {}
        par_port_id = ''
        if (len(data) - offset) < (self.size()):
            return ds
        t1 = struct.unpack_from('>10sBbQbBbBbB', data, offset)
        par_port_tup = struct.unpack_from('>BBBBBBBBBB', data, offset)
        for x in par_port_tup:
            par_port_id += '{0:02x}'.format(x)
        clkid_str = ':'.join(par_port_id[i:i + 2] for i in range(0, 16, 2))
        pid_str = ':'.join(par_port_id[i:i + 2] for i in range(16, 20, 2))
        portid_str = clkid_str + '-' + pid_str
        ds['port-id'] = portid_str
        if (t1[1] == 1):
            ds['port-state'] = 'initializing'
        elif (t1[1] == 2):
            ds['port-state'] = 'faulty'
        elif (t1[1] == 3):
            ds['port-state'] = 'disabled'
        elif (t1[1] == 4):
            ds['port-state'] = 'pre-master'
        elif (t1[1] == 5):
            ds['port-state'] = 'master'
        elif (t1[1] == 6):
            ds['port-state'] = 'passive'
        elif (t1[1] == 7):
            ds['port-state'] = 'uncalibrated'
        elif (t1[1] == 8):
            ds['port-state'] = 'slave'
        ds['delay-req-interval'] = t1[2]
        ds['peer-mean-path-delay'] = t1[3]
        ds['announce-interval'] = t1[4]
        ds['announce-timeout'] = t1[5]
        ds['sync-interval'] = t1[6]
        ds['delay-mechanism'] = t1[7]
        ds['peer-delay-req-interval'] = t1[8]
        ds['protocol-version'] = t1[9]

        return ds


class PTPportStatsNP:
    def __init__(self,
                 port_identity='00:00:00:00:00:00:00:00:00:00',
                 rx_sync=0,
                 tx_sync=0,
                 rx_delay_req=0,
                 tx_delay_req=0,
                 rx_peer_delay_req=0,
                 tx_peer_delay_rsp=0,
                 rx_rsvd4=0,
                 tx_rsvd4=0,
                 rx_rsvd5=0,
                 tx_rsvd5=0,
                 rx_rsvd6=0,
                 tx_rsvd6=0,
                 rx_rsvd7=0,
                 tx_rsvd7=0,
                 rx_followup=0,
                 tx_followup=0,
                 rx_delay_rsp=0,
                 tx_delay_rsp=0,
                 rx_pdelay_rsp_followup=0,
                 tx_pdelay_rsp_followup=0,
                 rx_announce=0,
                 tx_announce=0,
                 rx_signaling=0,
                 tx_signaling=0,
                 rx_management=0,
                 tx_management=0,):
        self.portIdentity = port_identity
        self.rxSync = rx_sync
        self.txSync = tx_sync
        self.rxDelayReq = rx_delay_req
        self.txDelayReq = tx_delay_req
        self.rxPeerDelayReq = rx_peer_delay_req
        self.txPeerDelayRsp = tx_peer_delay_rsp
        self.rxRsvd4 = rx_rsvd4
        self.txRsvd4 = tx_rsvd4
        self.rxRsvd5 = rx_rsvd5
        self.txRsvd5 = tx_rsvd5
        self.rxRsvd6 = rx_rsvd6
        self.txRsvd6 = tx_rsvd6
        self.rxRsvd7 = rx_rsvd7
        self.txRsvd7 = tx_rsvd7
        self.rxFollowup = rx_followup
        self.txFollowup = tx_followup
        self.rxDelayRsp = rx_delay_rsp
        self.txDelayRsp = tx_delay_rsp
        self.rxPDelayRspFollowup = rx_pdelay_rsp_followup
        self.txPDelayRspFollowup = tx_pdelay_rsp_followup
        self.rxAnnounce = rx_announce
        self.txAnnounce = tx_announce
        self.rxSignaling = rx_signaling
        self.txSignaling = tx_signaling
        self.rxManagement = rx_management
        self.txManagement = tx_management

    def build(self):
        port_id = binascii.unhexlify(self.portIdentity.replace(':', ''))
        port_ds = struct.pack('!10sQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ',
                              port_id,
                              self.portState,
                              self.rxSync,
                              self.txSync,
                              self.rxDelayReq,
                              self.txDelayReq,
                              self.rxPeerDelayReq,
                              self.txPeerDelayRsp,
                              self.rxRsvd4,
                              self.txRsvd4,
                              self.rxRsvd5,
                              self.txRsvd5,
                              self.rxRsvd6,
                              self.txRsvd6,
                              self.rxRsvd7,
                              self.txRsvd7,
                              self.rxFollowup,
                              self.txFollowup,
                              self.rxDelayRsp,
                              self.txDelayRsp,
                              self.rxPDelayRspFollowup,
                              self.txPDelayRspFollowup,
                              self.rxSignaling,
                              self.txSignaling,
                              self.rxManagement,
                              self.txManagement,)
        return port_ds

    def size(self):
        return struct.calcsize('!10sQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ')

    def build_dict(self, data, offset):
        par_port_id = ''
        stats = {}
        tup = struct.unpack_from('<10sQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ',
                                 data, offset)
        if (len(data) - offset) < (self.size()):
            return stats
        par_port_tup = struct.unpack_from('>BBBBBBBBBB', data, offset)
        for x in par_port_tup:
            par_port_id += '{0:02x}'.format(x)
        clkid_str = ':'.join(par_port_id[i:i + 2] for i in range(0, 16, 2))
        pid_str = ':'.join(par_port_id[i:i + 2] for i in range(16, 20, 2))
        portid_str = clkid_str + '-' + pid_str
        stats['port_id'] = portid_str
        stats['rx-sync'] = tup[1]
        stats['tx-sync'] = tup[2]
        stats['rx-delay-req'] = tup[3]
        stats['tx-delay-req'] = tup[4]
        stats['rx-peer-delay-req'] = tup[5]
        stats['tx-peer-delay-req'] = tup[6]
        stats['rx-follow-up'] = tup[15]
        stats['tx-follow-up'] = tup[16]
        stats['rx-delay-resp'] = tup[17]
        stats['tx-delay-resp'] = tup[18]
        stats['rx-delay-resp-follow-up'] = tup[19]
        stats['tx-delay-resp-follow-up'] = tup[20]
        stats['rx-announce'] = tup[21]
        stats['tx-announce'] = tup[22]
        stats['rx-signaling'] = tup[23]
        stats['tx-signaling'] = tup[24]
        stats['tx-management'] = tup[25]
        stats['rx-management'] = tup[26]

        return stats


class PTPportPropertiesNP:
    def __init__(self,
                 port_identity='00:00:00:00:00:00:00:00:00:00',
                 port_state=0,
                 timestamping=0,
                 text_length=0,
                 interface=''):
        self.portIdentity = port_identity
        self.port_state = port_state
        self.timestamping = timestamping
        self.textLength = text_length
        self.interface = interface
        return

    def size(self):
        return struct.calcsize('!10sBBB')

    def build_dict(self, data, offset):
        pnp = {}
        par_port_id = ''
        if (len(data) - offset) < (self.size()):
            return pnp
        tup = struct.unpack_from('<10sBBB',
                                 data, offset)
        par_port_tup = struct.unpack_from('>BBBBBBBBBB', data, offset)
        for x in par_port_tup:
            par_port_id += '{0:02x}'.format(x)
        pid_str = ':'.join(par_port_id[i:i + 2] for i in range(0, 20, 2))
        pnp['port-id'] = pid_str
        pnp['port-state'] = tup[1]
        pnp['timestamping'] = tup[2]
        if (tup[3] > 0):
            off = struct.calcsize('!10sBBB') + offset
            fm = '{:d}'.format(tup[3]) + 's'
            ptup_txt = struct.unpack_from(fm, data, off)
            pnp['name'] = ptup_txt[0].decode('ascii')
        else:
            pnp['name'] = 'Unknown'

        return pnp


class PTPportDSNP:
    def __init__(self,
                 nbr_prop_delay_thresh=0,
                 as_capable=0,):
        self.neighborPropDelayThresh = nbr_prop_delay_thresh
        self.asCapable = as_capable

    def size(self):
        return struct.calcsize('!LL')

    def build_dict(self, data, offset):
        ds = {}
        pup = struct.unpack_from('>LL', data, offset)
        ds['neighbor-prop-delay-thresh'] = pup[0]
        ds['as-capable'] = pup[1]
        return ds


class PTPforeignMastersDS:
    def __init__(self,
                 priority1=0,
                 priority2=0,
                 steps_removed=0,
                 is_gmc=0,
                 reserved=0,
                 identity='00:00:00:00:00:00:00:00',
                 clock_class=0,
                 clock_accuracy=0,
                 offset_scaled_log_variance=0,):
        self.priority1 = priority1
        self.priority2 = priority2
        self.stepsRemoved = steps_removed
        self.isGmc = is_gmc
        self.reserved = reserved
        self.identity = identity
        self.clockClass = clock_class
        self.clockAccuracy = clock_accuracy
        self.offsetScaledLogVariance = offset_scaled_log_variance

    def size(self):
        return struct.calcsize('!BBHB3B8sBBH')

    def build_dict(self, data, offset):
        ds = {}
        clk_quality = {}
        fup = struct.unpack_from('>BB', data, offset)
        ds['priority1'] = fup[0]
        ds['priority2'] = fup[1]

        off = offset + 2
        clkid_tup = struct.unpack_from('>BBBBBBBBB', data, off)
        clkid = ''
        for x in clkid_tup:
            clkid += '{0:02x}'.format(x)
        clkid_str = ':'.join(clkid[i:i + 2] for i in range(0, 16, 2))
        ds['clock-id'] = clkid_str

        off = off + 8
        clq = struct.unpack_from('>BBHHBL', data, off)
        clk_quality['clock-class'] = clq[0]
        clk_quality['clock-accuracy'] = clq[1]
        clk_quality['offset-scaled-log-variance'] = clq[2]
        ds['clock-quality'] = clk_quality
        ds['steps-removed'] = clq[3]
        ds['is-grandmaster-clock'] = 'on' if (clq[4] == 1) else 'off'
        ds['if-index'] = clq[5]

        return ds


class PTPacceptableMastersTbl:
    def __init__(self,
                 tbl_size=0,
                 clock_id='00:00:00:00:00:00:00:00',
                 alt_priority=0):
        self.tableSize = tbl_size
        self.clock_id = clock_id
        self.alt_priority = alt_priority
        return

    def size(self):
        return struct.calcsize('!H')

    def build_dict(self, data, offset):
        ds = {}
        if len(data) >= 2:
            tbl_size = aup = struct.unpack_from('<H', data, offset)
            if tbl_size[0] == 0:
                return ds
        else:
            return ds

        aup = struct.unpack_from('<HBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB',
                                 data, offset)
        self.tableSize = aup[0]
        off = offset + 2
        i = 0
        while i < self.tableSize:
            clk_tup = struct.unpack_from('<BBBBBBBB', data, off)
            clk_id = ''
            for x in clk_tup:
                clk_id += '{0:02x}'.format(x)
            clkid_str = ':'.join(clk_id[i:i + 2] for i in range(0, 16, 2))
            off += 8
            ap_tup = struct.unpack_from('<B', data, off)
            off += 4
            i += 1
            ds[clkid_str] = ap_tup[0]
        return ds


def ptp_do_get(domain, tgt_port, mgmt_id):

    global ptp_sequence_id

    # Create a UDS socket
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)

    try:
        os.unlink(ptp4lconst.client_address)
    except OSError:
        if os.path.exists(ptp4lconst.client_address):
            raise

    sock.bind(ptp4lconst.client_address)

    ptp_sequence_id = ptp_sequence_id + 1

    port_id = ptp_build_portid(tgt_port)

    # Build PTP message - Header part
    ptp_hdr = PTPHeader(ptp4lconst.PTP_MSG_MANAGEMENT,
                        ptp4lconst.PTP_VERSION, domain,
                        ptp4lconst.PTP_SOURCE_PORT_ID, ptp_sequence_id,
                        ptp4lconst.PTP_MSG_CTL_MANAGEMENT, 0x7F)

    # Build PTP message - Management message part
    mgmt_msg = PTPManagementMsg(port_id, ptp4lconst.PTP_DEFAULT_BNDRY_HOPS,
                                ptp4lconst.PTP_DEFAULT_BNDRY_HOPS,
                                ptp4lconst.PTP_MANAGEMENT_ACTION_GET)

    # Build PTP message - Command specific PTP message part
    if (mgmt_id == ptp4lconst.TLV_DEFAULT_DATA_SET):
        cmd = PTPdefaultDS()
        data = cmd.build()
        cmdsz = cmd.size()
    elif (mgmt_id == ptp4lconst.TLV_PARENT_DATA_SET):
        cmd = PTPparentDS()
        data = cmd.build()
        cmdsz = cmd.size()
    elif (mgmt_id == ptp4lconst.TLV_CURRENT_DATA_SET):
        cmd = PTPcurrentDS()
        data = cmd.build()
        cmdsz = cmd.size()
    elif (mgmt_id == ptp4lconst.TLV_TIME_PROPERTIES_DATA_SET):
        cmd = PTPtimePropertiesDS()
        data = cmd.build()
        cmdsz = cmd.size()
    elif (mgmt_id == ptp4lconst.TLV_PORT_DATA_SET):
        port_id = ptp_build_portid(tgt_port)
        cmd = PTPportDS(port_id)
        data = cmd.build()
        cmdsz = cmd.size()
    elif (mgmt_id == ptp4lconst.TLV_PORT_STATS_NP):
        cmd = PTPportStatsNP()
        data, cmdsz = '', 0
    elif (mgmt_id == ptp4lconst.TLV_PORT_PROPERTIES_NP):
        cmd = PTPportPropertiesNP()
        data, cmdsz = '', 0
    elif (mgmt_id == ptp4lconst.TLV_PORT_DATA_SET_NP):
        cmd = PTPportDSNP()
        data, cmdsz = '', 0
    elif (mgmt_id == ptp4lconst.TLV_FOREIGN_MASTERS_DATA_SET):
        cmd = PTPforeignMastersDS()
    elif (mgmt_id == ptp4lconst.TLV_ACCEPTABLE_MASTER_TABLE):
        cmd = PTPacceptableMastersTbl()
        data, cmdsz = '', 0

    # Build PTP message - Management tlv part
    mgmt_tlv = PTPManagementTLV(ptp4lconst.TLV_MANAGEMENT, cmdsz + 2, mgmt_id)

    if cmdsz != 0:
        mgt_pkt = ptp_hdr.build() + mgmt_msg.build() + mgmt_tlv.build() + data
    else:
        mgt_pkt = ptp_hdr.build() + mgmt_msg.build() + mgmt_tlv.build()

    sock.sendto(mgt_pkt, ptp4lconst.server_address)

    hdr_size = ptp_hdr.size() + mgmt_msg.size() + mgmt_tlv.size()

    sock.settimeout(20000)

    try:
        data, address = sock.recvfrom(1024)
    except sock.timeout:
        return {}

    sock.close()
    d = cmd.build_dict(data, hdr_size)
    return d


def ptp4lsys_port_map_build():
    def_ds = ptp_do_get(ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                        ptp4lconst.TLV_DEFAULT_DATA_SET)
    num_ports = def_ds['number-ports']
    for port in range(1, num_ports + 1):
        pp_ds = ptp_do_get(ptp_domain, port, ptp4lconst.TLV_PORT_PROPERTIES_NP)
        ptp4lsys_port_map[pp_ds['name']] = pp_ds


def get_ptp4l_portid(port_name):
    # Portmap is built if port_name is in the portmap else rebuild
    if port_name not in ptp4lsys_port_map:
        ptp4lsys_port_map_build()

    # Portmap is rebuilt check if port_name exists
    if port_name in ptp4lsys_port_map:
        pp_ds = ptp4lsys_port_map[port_name]
        pp_lst = (pp_ds['port-id'].split(':'))
        port = ((int(pp_lst[8])) << 8) | (int(pp_lst[9]))
        return port
    return 0
