# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.
import re

UNICAST_EGRESS_QUEUE = 8


def intf_roce_stats_get(ctx, port):
    roce_stats = ctx.qos_v1.getIntfRoceCounters(port)
    roce_counters = {}
    if 'exception' in roce_stats:
        return roce_counters
    else:
        roce_counters['rx-stats'] = {}
        roce_counters['rx-stats']['rx-pfc-stats'] = {}
        roce_counters['rx-stats']['rx-roce-stats'] = {}
        roce_counters['rx-stats']['rx-non-roce-stats'] = {}
        roce_counters['tx-stats'] = {}
        roce_counters['tx-stats']['tx-pfc-stats'] = {}
        roce_counters['tx-stats']['tx-roce-stats'] = {}
        roce_counters['tx-stats']['tx-cnp-stats'] = {}
        roce_counters['tx-stats']['tx-ecn-stats'] = {}
    # RoCE Stats
    # Rx RoCE PFC Stats
    roce_counters['rx-stats']['rx-pfc-stats']['pause-duration'] = \
        roce_stats['rx-roce-pfc-pause-duration']
    roce_counters['rx-stats']['rx-pfc-stats']['pause-packets'] = \
        roce_stats['rx-roce-pfc-pause-packets']

    # Rx RoCE stats
    roce_counters['rx-stats']['rx-roce-stats']['buffer-max-usage'] = \
        roce_stats['rx-roce-buffer-max-usage-bytes']
    roce_counters['rx-stats']['rx-roce-stats']['buffer-usage'] = \
        roce_stats['rx-roce-buffer-usage-bytes']
    roce_counters['rx-stats']['rx-roce-stats']['no-buffer-discard'] = \
        roce_stats['rx-roce-no-buffer-discard']
    roce_counters['rx-stats']['rx-roce-stats']['roce-packets'] = \
        roce_stats['rx-roce-pg-packets']
    roce_counters['rx-stats']['rx-roce-stats']['roce-bytes'] = \
        roce_stats['rx-roce-pg-bytes']
    roce_counters['rx-stats']['rx-roce-stats']['pg-max-usage'] = \
        roce_stats['rx-roce-pg-max-usage-bytes']
    roce_counters['rx-stats']['rx-roce-stats']['pg-usage'] = \
        roce_stats['rx-roce-pg-usage-bytes']

    # Rx CNP stats
    roce_counters['rx-stats']['rx-non-roce-stats']['pg-usage'] = \
        roce_stats['rx-cnp-pg-usage-bytes']
    roce_counters['rx-stats']['rx-non-roce-stats']['buffer-max-usage'] = \
        roce_stats['rx-cnp-buffer-max-usage-bytes']
    roce_counters['rx-stats']['rx-non-roce-stats']['buffer-usage'] = \
        roce_stats['rx-cnp-buffer-usage-bytes']
    roce_counters['rx-stats']['rx-non-roce-stats']['no-buffer-discard'] = \
        roce_stats['rx-cnp-no-buffer-discard']
    roce_counters['rx-stats']['rx-non-roce-stats']['non-roce-bytes'] = \
        roce_stats['rx-cnp-pg-bytes']
    roce_counters['rx-stats']['rx-non-roce-stats']['pg-max-usage'] = \
        roce_stats['rx-cnp-pg-max-usage-bytes']
    roce_counters['rx-stats']['rx-non-roce-stats']['non-roce-packets'] = \
        roce_stats['rx-cnp-pg-packets']

    # Tx RoCE PFC Stats
    roce_counters['tx-stats']['tx-pfc-stats']['pause-duration'] = \
        roce_stats['tx-roce-pfc-pause-duration']
    roce_counters['tx-stats']['tx-pfc-stats']['pause-packets'] = \
        roce_stats['tx-roce-pfc-pause-packets']

    # Tx RoCE stats
    roce_counters['tx-stats']['tx-roce-stats']['buffer-max-usage'] = \
        roce_stats['tx-roce-buffer-max-usage-bytes']
    roce_counters['tx-stats']['tx-roce-stats']['buffer-usage'] = \
        roce_stats['tx-roce-buffer-usage-bytes']
    roce_counters['tx-stats']['tx-roce-stats']['unicast-no-buffer-discard'] = \
        roce_stats['tx-roce-unicast-no-buffer-discard']
    roce_counters['tx-stats']['tx-roce-stats']['roce-packets'] = \
        roce_stats['tx-roce-tc-packets']
    roce_counters['tx-stats']['tx-roce-stats']['roce-bytes'] = \
        roce_stats['tx-roce-tc-bytes']
    roce_counters['tx-stats']['tx-roce-stats']['tc-max-usage'] = \
        roce_stats['tx-roce-tc-max-usage-bytes']
    roce_counters['tx-stats']['tx-roce-stats']['tc-usage'] = \
        roce_stats['tx-roce-tc-usage-bytes']

    # Tx CNP stats
    roce_counters['tx-stats']['tx-cnp-stats']['tc-usage'] = \
        roce_stats['tx-cnp-tc-usage-bytes']
    roce_counters['tx-stats']['tx-cnp-stats']['buffer-max-usage'] = \
        roce_stats['tx-cnp-buffer-max-usage-bytes']
    roce_counters['tx-stats']['tx-cnp-stats']['buffer-usage'] = \
        roce_stats['tx-cnp-buffer-usage-bytes']
    roce_counters['tx-stats']['tx-cnp-stats']['unicast-no-buffer-discard'] = \
        roce_stats['tx-cnp-unicast-no-buffer-discard']
    roce_counters['tx-stats']['tx-cnp-stats']['cnp-bytes'] = \
        roce_stats['tx-cnp-tc-bytes']
    roce_counters['tx-stats']['tx-cnp-stats']['tc-max-usage'] = \
        roce_stats['tx-cnp-tc-max-usage-bytes']
    roce_counters['tx-stats']['tx-cnp-stats']['cnp-packets'] = \
        roce_stats['tx-cnp-tc-packets']

    # Tx ECN stats
    roce_counters['tx-stats']['tx-ecn-stats']['ecn-marked-packets'] = \
        roce_stats['tx-ecn-marked-packets']

    return roce_counters


def intrf_roce_status_tc_map_get(ctx, port):
    roce_intf_status = intrf_roce_status_get(ctx, port)
    if 'tc-map' in roce_intf_status.keys():
        return roce_intf_status['tc-map']
    else:
        return {}


def intrf_roce_status_prio_map_get(ctx, port):
    roce_intf_status = intrf_roce_status_get(ctx, port)
    if 'prio-map' in roce_intf_status.keys():
        return roce_intf_status['prio-map']
    else:
        return {}


def intrf_roce_status_get(ctx, port):
    roce_status = ctx.qos_v1.getIntfRoceStatus(port)

    roce_intf_status = {}
    if 'exception' in roce_status:
        roce_intf_status['mode'] = None
        return roce_intf_status

    roce_intf_status['mode'] = roce_status['roce_mode'].lower()
    roce_pools = roce_interface_pools_get(ctx, port)
    roce_intf_status['pool-map'] = roce_pools

    dscp_map = roce_status['roce_dscp']
    pcp_map = roce_status['roce_pcp']
    roce_intf_status['prio-map'] = {}
    roce_intf_status['prio-map']['roce'] = {}
    roce_intf_status['prio-map']['roce']['dscp'] = str(dscp_map['dscp'])
    roce_intf_status['prio-map']['roce']['switch-prio'] = dscp_map['sp']
    roce_intf_status['prio-map']['roce']['pcp'] = pcp_map['pcp']

    dscp_map = roce_status['cnp_dscp']
    pcp_map = roce_status['cnp_pcp']
    roce_intf_status['prio-map']['cnp'] = {}
    roce_intf_status['prio-map']['cnp']['dscp'] = str(dscp_map['dscp'])
    roce_intf_status['prio-map']['cnp']['switch-prio'] = dscp_map['sp']
    roce_intf_status['prio-map']['cnp']['pcp'] = pcp_map['pcp']

    pfc_map = roce_status['pfc_enabled']
    roce_intf_status['pfc'] = {}
    if pfc_map["rx_enabled"] == "yes" or pfc_map["tx_enabled"] == "yes":
        roce_intf_status['pfc']['pfc-priority'] = \
            str(roce_status['pfc_priority'])
        roce_intf_status['pfc']['rx-enabled'] = pfc_map["rx_enabled"]
        roce_intf_status['pfc']['tx-enabled'] = pfc_map["tx_enabled"]
    else:
        roce_intf_status['pfc']['pfc-priority'] = '-'

    tc_map = roce_status['roce_tc_map']
    roce_intf_status['tc-map'] = {}
    roce_intf_status['tc-map']['roce'] = {}
    roce_intf_status['tc-map']['roce']['switch-prio'] = tc_map['tc']
    roce_intf_status['tc-map']['roce']['traffic-class'] = tc_map['sp']
    roce_intf_status['tc-map']['roce']['scheduler-weight'] = \
        roce_status['roce_sched_map']['dwrr_mode']
    if roce_status['roce_sched_map']['dwrr_mode'] == "dwrr":
        roce_intf_status['tc-map']['roce']['scheduler-weight'] += \
            "-{}%".format(roce_status['roce_sched_map']['dwrr_weight'])
    tc_map = roce_status['cnp_tc_map']
    roce_intf_status['tc-map']['cnp'] = {}
    roce_intf_status['tc-map']['cnp']['switch-prio'] = tc_map['tc']
    roce_intf_status['tc-map']['cnp']['traffic-class'] = tc_map['sp']
    roce_intf_status['tc-map']['cnp']['scheduler-weight'] = \
        roce_status['cnp_sched_map']['dwrr_mode']
    if roce_status['cnp_sched_map']['dwrr_mode'] == "dwrr":
        roce_intf_status['tc-map']['cnp']['scheduler-weight'] += \
            "-{}%".format(roce_status['cnp_sched_map']['dwrr_weight'])

    trust = roce_status['trust']
    roce_intf_status['trust'] = {}
    trust_string = "invalid"
    if trust['dscp'] == "yes":
        if trust['pcpdei'] == "yes":
            if trust['trust_port'] == "yes":
                trust_string = "invalid"
            else:
                trust_string = "pcp,dscp"
        elif trust['trust_port'] == "yes":
            trust_string = "invalid"
        else:
            trust_string = "dscp"
    elif trust['pcpdei'] == "yes":
        if trust['trust_port'] == "yes":
            trust_string = "invalid"
        else:
            trust_string = "pcp"
    elif trust['trust_port'] == "yes":
        trust_string = "port"
    roce_intf_status['trust']['trust-mode'] = trust_string

    roce_intf_status['congestion-control'] = {}
    congestion_control = roce_status['congestion-control']
    roce_intf_status['congestion-control']['enabled-tc'] = \
        ",".join([str(i) for i in congestion_control['ecn_tcs']])
    mode = ""
    if congestion_control['ecn_enabled']:
        mode += "ecn,"
    if congestion_control['red_enabled']:
        mode += "red,"
    mode += " {}".format(congestion_control['mode'])
    roce_intf_status['congestion-control']['congestion-mode'] = mode
    roce_intf_status['congestion-control']['min-threshold'] = \
        congestion_control['min_threshold_bytes']
    roce_intf_status['congestion-control']['max-threshold'] = \
        congestion_control['max_threshold_bytes']

    return roce_intf_status


def format_bytes(_bytes):
    _bytes = float(_bytes)
    _kb = float(1024)
    _mb = float(_kb ** 2)
    _gb = float(_mb * 1024)
    if _bytes < _kb:
        return '{0} {1}'.format(_bytes, 'Bytes' if 0 == _bytes > 1 else 'Byte')
    elif _kb <= _bytes < _mb:
        return '{0:.2f} KB'.format(_bytes / _kb)
    elif _mb <= _bytes < _gb:
        return '{0:.2f} MB'.format(_bytes / _mb)
    elif _gb <= _bytes:
        return '{0:.2f} GB'.format(_bytes / _gb)


def get_mapped_sp_tc_pool(pool_id, port, port_buffers, sp_pg_map):
    sp_list = []
    tc_list = []
    # Get the mapped pg to the pool
    pg_list = []
    for item in port_buffers:
        if item['port'] != port:
            continue
        for port_buffer in item['counter_list']:
            if port_buffer['type'] != 'INGRESS_PORT_PRIORITY_GROUP':
                continue
            res = port_buffer['reserved']
            shared = port_buffer['shared_max']
            if res == 0 and shared in ["ALPHA_0", 0]:
                continue
            if port_buffer['pool_id'] == int(pool_id):
                pg_list.append(port_buffer['pg_id'])
    for pg_id in pg_list:
        for item in sp_pg_map:
            if item['pg'] == int(pg_id) and item['sp'] < UNICAST_EGRESS_QUEUE:
                sp_list.append(item['sp'])
    # Get the mapped tc to the pool
    for item in port_buffers:
        if item['port'] != port:
            continue
        for port_buffer in item['counter_list']:
            if port_buffer['type'] != 'EGRESS_PORT_TRAFFIC_CLASS':
                continue
            res = port_buffer['reserved']
            shared = port_buffer['shared_max']
            if res == 0 and (shared == "ALPHA_0" or shared == 0):
                continue
            if port_buffer['pool_id'] == int(pool_id):
                tc_list.append(port_buffer['tclass'])
    return (sp_list, tc_list)


def roce_system_pools_get(ctx):
    roce_pools = ctx.qos_v1.getRoceSysPools()
    pool_collection = {}
    if 'exception' in roce_pools:
        return pool_collection
    ctr = 0
    for (pool_id, pool_info) in roce_pools["pools"].items():
        idx = str(ctr)
        pool_collection[idx] = {}
        pool_collection[idx]["pool-id"] = int(pool_id)
        if 'infinite' in pool_info.keys() and pool_info['infinite'] == 1:
            pool_collection[idx]["size"] = "inf"
        elif 'bytes' in pool_info.keys():
            pool_collection[idx]["size"] = format_bytes(pool_info['bytes'])
        if 'current-usage-bytes' in pool_info.keys():
            pool_collection[idx]["current-usage"] = \
                pool_info['current-usage-bytes']
        if 'max-usage-bytes' in pool_info.keys():
            pool_collection[idx]["max-usage"] = \
                pool_info['max-usage-bytes']
        if 'name' in pool_info.keys():
            pool_collection[idx]["name"] = pool_info['name']
        if 'mode' in pool_info.keys():
            pool_collection[idx]["mode"] = pool_info['mode']
        ctr = ctr + 1
    return pool_collection


def verify_roce_pfc_config(roce_static_conf, roce_file_conf, exception_dict):
    if 'pfc' in roce_file_conf:
        if 'pfc-priority' in roce_file_conf['pfc']:
            if roce_file_conf['pfc']['pfc-priority'] != \
                    roce_static_conf['pfc']['pfc-priority']:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'RoCE PFC Priority Mismatch.'\
                    'Expected pfc-priority: {}.'.format(
                    roce_static_conf['pfc']['pfc-priority'])
        if 'tx-enabled' in roce_file_conf['pfc']:
            if 'tx-enabled' in roce_static_conf['pfc']:
                if roce_static_conf['pfc']['tx-enabled'] != \
                        roce_file_conf['pfc']['tx-enabled']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Invalid RoCE PFC tx-enabled flag.'\
                        'Expected: {}.'.format(
                        roce_static_conf['pfc']['tx-enabled'])
        else:
            if 'tx-enabled' in roce_static_conf['pfc']:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'RoCE PFC tx-enabled expected to be configured.'
        if 'rx-enabled' in roce_file_conf['pfc']:
            if 'rx-enabled' in roce_static_conf['pfc']:
                if roce_static_conf['pfc']['rx-enabled'] != \
                        roce_file_conf['pfc']['rx-enabled']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Invalid RoCE PFC rx-enabled flag.'\
                        'Expected: {}.'.format(
                        roce_static_conf['pfc']['rx-enabled'])
        else:
            if 'rx-enabled' in roce_static_conf['pfc']:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'RoCE PFC rx-enabled expected to be configured. '


def verify_roce_congestion_config(
        roce_static_conf, roce_file_conf, exception_dict):
    if 'congestion-control' in roce_file_conf:
        roce_static_congestion = roce_static_conf['congestion-control']
        if 'enabled-tc' in roce_file_conf['congestion-control']:
            if 'enabled-tc' in roce_static_congestion:
                if roce_file_conf['congestion-control']['enabled-tc'] != \
                        roce_static_congestion['enabled-tc']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Congestion Config TC Mismatch.'\
                        'Expected enabled-tc: {}. '.format(
                        roce_static_congestion['enabled-tc'])

        if 'congestion-mode' in roce_file_conf['congestion-control']:
            if 'congestion-mode' in roce_static_congestion:
                if roce_file_conf['congestion-control']['congestion-mode'] != \
                        roce_static_congestion['congestion-mode']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Congestion Config mode Mismatch.'\
                        'Expected congestion-mode: {}.'.format(
                        roce_static_congestion['congestion-mode'])
        else:
            if 'congestion-mode' in roce_static_congestion:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'Congestion Config congestion-mode '\
                    'expected to be configured.'

        if 'min-threshold' in roce_file_conf['congestion-control']:
            if 'min-threshold' in roce_static_congestion:
                if roce_file_conf['congestion-control']['min-threshold'] != \
                        roce_static_congestion['min-threshold']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Congestion Config min-threshold Mismatch.'\
                        'Expected min-threshold: {}.'.format(
                        roce_static_congestion['min-threshold'])
        else:
            if 'min-threshold' in roce_static_congestion:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'Congestion Config min-threshold '\
                    'expected to be configured.'

        if 'max-threshold' in roce_file_conf['congestion-control']:
            if 'max-threshold' in roce_static_congestion:
                if roce_file_conf['congestion-control']['max-threshold'] != \
                        roce_static_congestion['max-threshold']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'Congestion Config max-threshold Mismatch.'\
                        'Expected max-threshold: {}.'.format(
                        roce_static_congestion['max-threshold'])
        else:
            if 'max-threshold' in roce_static_congestion:
                ctr = str(len(exception_dict) + 1)
                exception_dict[ctr] = {}
                exception_dict[ctr]['description'] = \
                    'Congestion Config max-threshold '\
                    'expected to be configured. '


def verify_tc_map_config(
        roce_static_conf, roce_file_conf, exception_dict):
    if 'tc-map' in roce_file_conf:
        if 'tc-map' in roce_static_conf:
            for (sp, tc_map) in roce_static_conf['tc-map'].items():
                if sp in roce_file_conf['tc-map']:
                    if 'traffic-class' in roce_file_conf['tc-map'][sp]:
                        if roce_file_conf['tc-map'][sp]['traffic-class'] != \
                                tc_map['traffic-class']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'Traffic-class mapping config'\
                                ' invalid for switch-prio {}.'\
                                'Expected traffic-class: {}. '.format(
                                sp, tc_map['traffic-class'])

                    if 'scheduler-weight' in roce_file_conf['tc-map'][sp]:
                        if roce_file_conf['tc-map'][sp]['scheduler-weight'] \
                                != tc_map['scheduler-weight']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'Scheduler config mismatch for tc {}.'\
                                'Expected scheduler-weight: {}.'.format(
                                tc_map['traffic-class'],
                                tc_map['scheduler-weight'])


def verify_pool_map_config(roce_static_conf, roce_file_conf, exception_dict):
    if 'pool-map' in roce_file_conf:
        if 'pool-map' in roce_static_conf:
            for (pool_idx, pool_map) in roce_static_conf['pool-map'].items():
                if pool_idx not in roce_file_conf['pool-map']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    exception_dict[ctr]['description'] = \
                        'pool_idx {} not configured'.format(pool_idx)
                else:
                    roce_pool_info = roce_file_conf['pool-map'][pool_idx]
                    if 'size' in roce_pool_info:
                        if roce_pool_info['size'] != pool_map['size']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'size mismatch for pool-map index {}.'\
                                'Expected size: {}.'.format(
                                pool_idx, pool_map['size'])

                    if 'mode' in roce_pool_info:
                        if roce_pool_info['mode'] != pool_map['mode']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'mode mismatch for pool-map index {}.'\
                                'Expected mode: {}. '.format(
                                pool_idx, pool_map['mode'])

                    if 'switch-priorities' in roce_pool_info:
                        if roce_pool_info['switch-priorities'] != \
                                pool_map['switch-priorities']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'switch-priorities mapping mismatch '\
                                'for pool-map index {}.'\
                                'Expected switch-priorities: {}.'.format(
                                pool_idx, pool_map['switch-priorities'])

                    if 'traffic-class' in roce_pool_info:
                        if roce_pool_info['traffic-class'] != \
                                pool_map['traffic-class']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'traffic-class mapping mismatch for '\
                                'pool-map index {}.'\
                                'Expected traffic-class: {}.'.format(
                                pool_idx, pool_map['traffic-class'])


def verify_prio_map_config(roce_static_conf, roce_file_conf, exception_dict):
    if 'prio-map' in roce_file_conf:
        if 'prio-map' in roce_static_conf:
            for (sp, prio_map) in roce_static_conf['prio-map'].items():
                if sp in roce_file_conf['prio-map']:
                    prio_map_file_conf = roce_file_conf['prio-map'][sp]
                    if 'pcp' in prio_map_file_conf:
                        if prio_map_file_conf['pcp'] != prio_map['pcp']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'PCP mapping config invalid for '\
                                'switch-prio {}.Expected PCP:'\
                                ' {}.'.format(sp, prio_map['pcp'])

                    if 'dscp' in prio_map_file_conf:
                        if prio_map_file_conf['dscp'] != prio_map['dscp']:
                            ctr = str(len(exception_dict) + 1)
                            exception_dict[ctr] = {}
                            exception_dict[ctr]['description'] = \
                                'DSCP mapping config invalid for '\
                                'switch-prio {}.Expected DSCP: '\
                                '{}. '.format(sp, prio_map['dscp'])


def verify_trust_config(roce_static_conf, roce_file_conf, exception_dict):
    if 'trust' in roce_file_conf:
        if 'trust-mode' in roce_file_conf['trust']:
            if 'trust-mode' in roce_static_conf['trust']:
                if roce_file_conf['trust']['trust-mode'] != \
                        roce_static_conf['trust']['trust-mode']:
                    ctr = str(len(exception_dict) + 1)
                    exception_dict[ctr] = {}
                    trust_str = roce_file_conf['trust']['trust-mode']
                    exception_dict[ctr]['description'] = \
                        'Port-Trust Config Mismatch.'\
                        'Expected Trust: {}. Got {} Trust'.format(
                        roce_static_conf['trust']['trust-mode'],
                        trust_str)


def verify_roce_qos_config(roce_static_conf, roce_file_conf):
    exception_dict = {}
    verify_roce_pfc_config(roce_static_conf, roce_file_conf, exception_dict)
    verify_roce_congestion_config(
        roce_static_conf, roce_file_conf, exception_dict)
    verify_trust_config(roce_static_conf, roce_file_conf, exception_dict)
    verify_prio_map_config(roce_static_conf, roce_file_conf, exception_dict)
    verify_tc_map_config(roce_static_conf, roce_file_conf, exception_dict)
    verify_pool_map_config(roce_static_conf, roce_file_conf, exception_dict)

    return exception_dict


def get_roce_conf_static_config(roce_mode):
    roce_conf = {}
    roce_conf['pfc'] = {}
    roce_conf['congestion-control'] = {}
    roce_conf['prio-map'] = {}
    roce_conf['tc-map'] = {}
    roce_conf['trust'] = {}
    roce_conf['pool-map'] = {}

    if 'mode' in roce_mode and roce_mode['mode'] == 'lossy':
        roce_conf["pfc"]['pfc-priority'] = '-'
    else:
        roce_conf["pfc"]['rx-enabled'] = 'enabled'
        roce_conf["pfc"]['tx-enabled'] = 'enabled'
        roce_conf["pfc"]['pfc-priority'] = '3'

    roce_conf['congestion-control']['enabled-tc'] = '0,3'
    roce_conf['congestion-control']['congestion-mode'] = "ECN"
    roce_conf['congestion-control']['min-threshold'] = 150000
    roce_conf['congestion-control']['max-threshold'] = 1500000

    roce_conf['trust']['trust-mode'] = "pcp,dscp"

    roce_conf['pool-map']["0"] = {}
    roce_conf['pool-map']["0"]["size"] = "50.0%"
    roce_conf['pool-map']["0"]["mode"] = "Dynamic"
    roce_conf['pool-map']["0"]["name"] = "lossy-default-ingress"
    roce_conf['pool-map']["0"]["switch-priorities"] = "0,1,2,4,5,6,7"
    roce_conf['pool-map']["0"]["traffic-class"] = "-"

    roce_conf['pool-map']["1"] = {}
    roce_conf['pool-map']["1"]["size"] = "50.0%"
    roce_conf['pool-map']["1"]["mode"] = "Dynamic"
    roce_conf['pool-map']["1"]["name"] = "roce-reserved-ingress"
    roce_conf['pool-map']["1"]["switch-priorities"] = "3"
    roce_conf['pool-map']["1"]["traffic-class"] = "-"

    roce_conf['pool-map']["2"] = {}
    roce_conf['pool-map']["2"]["size"] = "50.0%"
    roce_conf['pool-map']["2"]["mode"] = "Dynamic"
    roce_conf['pool-map']["2"]["name"] = "lossy-default-egress"
    roce_conf['pool-map']["2"]["switch-priorities"] = "-"
    roce_conf['pool-map']["2"]["traffic-class"] = "0,6"

    roce_conf['pool-map']["3"] = {}
    if 'mode' in roce_mode and roce_mode['mode'] == 'lossy':
        roce_conf['pool-map']["3"]["size"] = "50.0%"
    else:
        roce_conf['pool-map']["3"]["size"] = "inf"
    roce_conf['pool-map']["3"]["mode"] = "Dynamic"
    roce_conf['pool-map']["3"]["name"] = "roce-reserved-egress"
    roce_conf['pool-map']["3"]["switch-priorities"] = "-"
    roce_conf['pool-map']["3"]["traffic-class"] = "3"

    roce_conf['prio-map']["0"] = {}
    roce_conf['prio-map']["0"]['switch-prio'] = 0
    roce_conf['prio-map']["0"]['pcp'] = 0
    roce_conf['prio-map']["0"]['dscp'] = '0,1,2,3,4,5,6,7'

    roce_conf['prio-map']["1"] = {}
    roce_conf['prio-map']["1"]['switch-prio'] = 1
    roce_conf['prio-map']["1"]['pcp'] = 1
    roce_conf['prio-map']["1"]['dscp'] = '8,9,10,11,12,13,14,15'

    roce_conf['prio-map']["2"] = {}
    roce_conf['prio-map']["2"]['switch-prio'] = 2
    roce_conf['prio-map']["2"]['pcp'] = 2
    roce_conf['prio-map']["2"]['dscp'] = '16,17,18,19,20,21,22,23'

    roce_conf['prio-map']["3"] = {}
    roce_conf['prio-map']["3"]['switch-prio'] = 3
    roce_conf['prio-map']["3"]['pcp'] = 3
    roce_conf['prio-map']["3"]['dscp'] = '24,25,26,27,28,29,30,31'

    roce_conf['prio-map']["4"] = {}
    roce_conf['prio-map']["4"]['switch-prio'] = 4
    roce_conf['prio-map']["4"]['pcp'] = 4
    roce_conf['prio-map']["4"]['dscp'] = '32,33,34,35,36,37,38,39'

    roce_conf['prio-map']["5"] = {}
    roce_conf['prio-map']["5"]['switch-prio'] = 5
    roce_conf['prio-map']["5"]['pcp'] = 5
    roce_conf['prio-map']["5"]['dscp'] = '40,41,42,43,44,45,46,47'

    roce_conf['prio-map']["6"] = {}
    roce_conf['prio-map']["6"]['switch-prio'] = 6
    roce_conf['prio-map']["6"]['pcp'] = 6
    roce_conf['prio-map']["6"]['dscp'] = '48,49,50,51,52,53,54,55'

    roce_conf['prio-map']["7"] = {}
    roce_conf['prio-map']["7"]['switch-prio'] = 7
    roce_conf['prio-map']["7"]['pcp'] = 7
    roce_conf['prio-map']["7"]['dscp'] = '56,57,58,59,60,61,62,63'

    roce_conf['tc-map']["0"] = {}
    roce_conf['tc-map']["0"]['switch-prio'] = 0
    roce_conf['tc-map']["0"]['traffic-class'] = 0
    roce_conf['tc-map']["0"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["1"] = {}
    roce_conf['tc-map']["1"]['switch-prio'] = 1
    roce_conf['tc-map']["1"]['traffic-class'] = 0
    roce_conf['tc-map']["1"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["2"] = {}
    roce_conf['tc-map']["2"]['switch-prio'] = 2
    roce_conf['tc-map']["2"]['traffic-class'] = 0
    roce_conf['tc-map']["2"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["3"] = {}
    roce_conf['tc-map']["3"]['switch-prio'] = 3
    roce_conf['tc-map']["3"]['traffic-class'] = 3
    roce_conf['tc-map']["3"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["4"] = {}
    roce_conf['tc-map']["4"]['switch-prio'] = 4
    roce_conf['tc-map']["4"]['traffic-class'] = 0
    roce_conf['tc-map']["4"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["5"] = {}
    roce_conf['tc-map']["5"]['switch-prio'] = 5
    roce_conf['tc-map']["5"]['traffic-class'] = 0
    roce_conf['tc-map']["5"]['scheduler-weight'] = 'DWRR-50%'

    roce_conf['tc-map']["6"] = {}
    roce_conf['tc-map']["6"]['switch-prio'] = 6
    roce_conf['tc-map']["6"]['traffic-class'] = 6
    roce_conf['tc-map']["6"]['scheduler-weight'] = 'strict-priority'

    roce_conf['tc-map']["7"] = {}
    roce_conf['tc-map']["7"]['switch-prio'] = 7
    roce_conf['tc-map']["7"]['traffic-class'] = 0
    roce_conf['tc-map']["7"]['scheduler-weight'] = 'DWRR-50%'

    return roce_conf


def roce_mode_qos_config_file_get(qos_conf):
    mode = 0
    roce_mode = {}
    roce_mode['enable'] = "off"

    for line in qos_conf.splitlines():
        line = line.strip()
        if line.startswith('traffic.roce_mode'):
            mode = line.split('=')[1].strip()
    if mode == "1":
        roce_mode['mode'] = "lossy"
        roce_mode['enable'] = "on"
    elif mode == "3":
        roce_mode['mode'] = "lossless"
        roce_mode['enable'] = "on"
    else:
        roce_mode['enable'] = "off"

    return roce_mode


def ecn_config_qos_features_file_get(qos_features):
    ecn_conf = {}
    for line in qos_features.splitlines():
        line = line.strip()
        if line.startswith("default_ecn_conf.egress_queue_list"):
            tc_list = line.split('=')[1].strip()
            for ch in ['[', ']']:
                tc_list = tc_list.replace(ch, '')
            ecn_conf['enabled-tc'] = tc_list
        if line.startswith("default_ecn_conf.ecn_enable"):
            mode = line.split('=')[1]
            if re.search('true', mode, re.I):
                if 'congestion-mode' in ecn_conf.keys():
                    ecn_conf['congestion-mode'] += ',ECN'
                else:
                    ecn_conf['congestion-mode'] = 'ECN'
        if line.startswith("default_ecn_conf.red_enable"):
            mode = line.split('=')[1]
            if re.search('true', mode, re.I):
                if 'congestion-mode' in ecn_conf.keys():
                    ecn_conf['congestion-mode'] += ',RED'
                else:
                    ecn_conf['congestion-mode'] = 'RED'
        if line.startswith("default_ecn_conf.min_threshold_bytes"):
            val = line.split('=')[1]
            ecn_conf['min-threshold'] = int(val)
        if line.startswith("default_ecn_conf.max_threshold_bytes"):
            val = line.split('=')[1]
            ecn_conf['max-threshold'] = int(val)
    if not ecn_conf:
        ecn_conf['enabled-tc'] = '-'
    return ecn_conf


def prio_map_config_qos_features_file_get(qos_features):
    prio_map = {}
    for sp in ["0", "1", "2", "3", "4", "5", "6", "7"]:
        prio_map[sp] = {}
        prio_map[sp]['switch-prio'] = int(sp)
        pcp = int(sp)
        for line in qos_features.splitlines():
            line = line.strip()
            pcp_map_text = "traffic.cos_{}."\
                "priority_source.8021p".format(sp)
            if line.startswith(pcp_map_text):
                pcp = line.split('=')[1].strip()
                for ch in ['[', ']']:
                    pcp = pcp.replace(ch, '')
                pcp = int(pcp)
                break
        prio_map[sp]['pcp'] = pcp

        dscp = '-'
        for line in qos_features.splitlines():
            line = line.strip()
            dscp_map_text = "traffic.cos_{}"\
                ".priority_source.dscp".format(sp)
            if line.startswith(dscp_map_text):
                dscp = line.split('=')[1].strip()
                for ch in ['[', ']']:
                    dscp = dscp.replace(ch, '')
                dscp_list = dscp.split(',')
                dscp_list = [int(s) for s in dscp_list]
                dscp_list.sort()
                dscp_list = [str(s) for s in dscp_list]
                dscp = ",".join(dscp_list)
                break
        prio_map[sp]['dscp'] = dscp

    return prio_map


def roce_pfc_config_qos_features_file_get(qos_features):
    roce_pfc = {}
    pfc_priority = '-'
    tx_enabled = 'enabled'
    rx_enabled = 'enabled'
    for line in qos_features.splitlines():
        line = line.strip()
        if line.startswith("pfc.ROCE_PFC.cos_list"):
            val = line.split('=')[1].strip()
            for ch in ['[', ']']:
                val = val.replace(ch, '')
            pfc_priority = val
        if line.startswith("pfc.ROCE_PFC.tx_enable"):
            val = line.split('=')[1].strip()
            if re.search('false', val, re.I):
                tx_enabled = 'disabled'
        if line.startswith("pfc.ROCE_PFC.rx_enable"):
            val = line.split('=')[1].strip()
            if re.search('false', val, re.I):
                rx_enabled = 'disabled'

    roce_pfc['pfc-priority'] = pfc_priority
    if pfc_priority == '-':
        return roce_pfc

    roce_pfc['rx-enabled'] = rx_enabled
    roce_pfc['tx-enabled'] = tx_enabled

    return roce_pfc


def trust_config_qos_features_file_get(qos_features):
    trust = {}
    trust['trust-mode'] = "invalid"
    trust_port = 0
    trust_pcpdei = 0
    trust_dscp = 0
    for line in qos_features.splitlines():
        line = line.strip()
        if line.startswith("traffic.packet_priority_source_set"):
            val = line.split('=')[1]
            if re.search('port', val):
                trust_port = 1
            if re.search('802.1p', val):
                trust_pcpdei = 1
            if re.search('dscp', val):
                trust_dscp = 1
            break
    if trust_dscp:
        if trust_pcpdei:
            if trust_port:
                trust['trust-mode'] = "invalid"
            else:
                trust['trust-mode'] = "pcp,dscp"
        elif trust_port:
            trust['trust-mode'] = "invalid"
        else:
            trust['trust-mode'] = "dscp"
    elif trust_pcpdei:
        if trust_port:
            trust['trust-mode'] = "invalid"
        else:
            trust['trust-mode'] = "pcp"
    elif trust_port:
        trust['trust-mode'] = "port"

    return trust


def get_sp_tc_list(qos_infra, sp_list):
    tc_list = []
    for sp in sp_list:
        tc = "0"
        for line in qos_infra.splitlines():
            line = line.strip()
            if line.startswith('cos_egr_queue.cos_{}.uc'.format(sp)):
                tc = line.split('=')[1].strip()
                break
        if tc not in tc_list:
            tc_list.append(tc)
    return tc_list


def get_egress_queue_service_pool(qos_infra, tc):
    tc_service_pool = 0
    for line in qos_infra.splitlines():
        line = line.strip()
        tc_sp_text = 'egress_buffer.egr_queue_{}'\
            '.uc.service_pool'.format(tc)
        if line.startswith(tc_sp_text):
            tc_service_pool = int(line.split('=')[1].strip())
            break
    return tc_service_pool


def get_pg_service_pool(qos_infra, pg):
    pg_service_pool = 0
    for line in qos_infra.splitlines():
        line = line.strip()
        pg_sp_text = 'priority_group.{}'\
            '.service_pool'.format(pg)
        if line.startswith(pg_sp_text):
            pg_service_pool = int(line.split('=')[1].strip())
            break
    return pg_service_pool


def get_pg_sp_list(qos_infra, pg):
    pg_sp_list = []
    for line in qos_infra.splitlines():
        line = line.strip()
        pg_sp_text = 'priority_group.{}'\
            '.cos_list'.format(pg)
        if line.startswith(pg_sp_text):
            pg_sp_list = line.split('=')[1].strip()
            for ch in ['[', ']']:
                pg_sp_list = pg_sp_list.replace(ch, '')
            if pg_sp_list:
                pg_sp_list = pg_sp_list.split(',')
            else:
                pg_sp_list = []
            break
    return pg_sp_list


def get_fc_service_pool(qos_infra, direction):
    fc_service_pool = -1
    for line in qos_infra.splitlines():
        line = line.strip()
        fc_sp_text = 'flow_control.{}'\
            '_service_pool'.format(direction)
        if line.startswith(fc_sp_text):
            fc_service_pool = int(line.split('=')[1].strip())
            break
    return fc_service_pool


def get_pool_mode(qos_infra, direction, service_pool):
    pool_mode = "Dynamic"
    for line in qos_infra.splitlines():
        line = line.strip()
        sp_mode_text = '{}_service_pool.{}.'\
            'mode'.format(direction, service_pool)
        if line.startswith(sp_mode_text):
            mode = int(line.split('=')[1].strip())
            if mode == 0:
                pool_mode = 'Static'
            else:
                pool_mode = 'Dynamic'
            break
    return pool_mode


def get_pool_size(qos_infra, direction, service_pool):
    size = "100.0"
    inf_flag = 'false'
    for line in qos_infra.splitlines():
        line = line.strip()
        sp_size_text = '{}_service_pool.{}.'\
            'percent'.format(direction, service_pool)
        if line.startswith(sp_size_text):
            size = line.split('=')[1].strip()
            size = size.split('#')[0].strip()
        sp_inf_text = '{}_service_pool.{}.'\
            'infinite_flag'.format(direction, service_pool)
        if line.startswith(sp_inf_text):
            inf_flag = line.split('=')[1].strip()
    if re.search('true', inf_flag, re.I):
        mem_size = 'inf'
    else:
        mem_size = "{}%".format(size)
    return mem_size


def get_pfc_sp_list(qos_features):
    roce_pfc = roce_pfc_config_qos_features_file_get(qos_features)
    fc_sp_list = roce_pfc['pfc-priority']
    if fc_sp_list != "-":
        fc_sp_list = fc_sp_list.split(',')
    else:
        fc_sp_list = []
    return fc_sp_list


def get_bulk_pg(qos_infra):
    bulk_pg = ''
    for line in qos_infra.splitlines():
        line = line.strip()
        if line.startswith('traffic.priority_group_list'):
            pg_list = line.split('=')[1].strip()
            for ch in ['[', ']']:
                pg_list = pg_list.replace(ch, '')
            pg_list = pg_list.split(',')
            if 'bulk' in pg_list:
                bulk_pg = 'bulk'
            break
    return bulk_pg


def get_non_bulk_pg(qos_infra):
    non_bulk_pg = ''
    for line in qos_infra.splitlines():
        line = line.strip()
        if line.startswith('traffic.priority_group_list'):
            pg_list = line.split('=')[1].strip()
            for ch in ['[', ']']:
                pg_list = pg_list.replace(ch, '')
            pg_list = pg_list.split(',')
            non_bulk_list = list(set(pg_list) - set(['bulk']))
            if non_bulk_list:
                non_bulk_pg = non_bulk_list[0]
            break
    return non_bulk_pg.strip()


def pool_map_config_qos_infra_file_get(qos_infra, qos_features):
    pool_map = {}

    # Get the lossy-default pool
    bulk_pg = get_bulk_pg(qos_infra)
    if bulk_pg:
        pool_map["0"] = {}
        pool_map["0"]["name"] = "lossy-default-ingress"
        service_pool = \
            get_pg_service_pool(qos_infra, bulk_pg)
        pool_map["0"]["mode"] = \
            get_pool_mode(qos_infra, "ingress", service_pool)
        pool_map["0"]["size"] = \
            get_pool_size(qos_infra, "ingress", service_pool)
        sp_list = get_pg_sp_list(qos_infra, bulk_pg)
        fc_sp_list = get_pfc_sp_list(qos_features)
        sp_list = list(set(sp_list) - set(fc_sp_list))
        sp_list.sort()

        if sp_list:
            pool_map["0"]["switch-priorities"] = \
                ",".join(sp_list)
        else:
            pool_map["0"]["switch-priorities"] = "-"
        pool_map["0"]["traffic-class"] = "-"

        pool_map["2"] = {}
        pool_map["2"]["name"] = "lossy-default-egress"
        tc_list = get_sp_tc_list(qos_infra, sp_list)
        fc_tc_list = get_sp_tc_list(qos_infra, fc_sp_list)
        tc_list = list(set(tc_list) - set(fc_tc_list))
        tc_list.sort()
        if tc_list:
            pool_map["2"]["traffic-class"] = \
                ",".join(tc_list)
            service_pool = \
                get_egress_queue_service_pool(qos_infra, tc_list[0])
            pool_map["2"]["mode"] = \
                get_pool_mode(qos_infra, "egress", service_pool)
            pool_map["2"]["size"] = \
                get_pool_size(qos_infra, "egress", service_pool)
        else:
            pool_map["2"]["traffic-class"] = "-"
            pool_map["2"]["mode"] = "-"
            pool_map["2"]["size"] = "-"
        pool_map["2"]["switch-priorities"] = "-"

    # Get the roce-reserved-ingress pool to which fc is mapped
    fc_service_pool = get_fc_service_pool(qos_infra, "ingress")
    if fc_service_pool != -1:
        pool_map["1"] = {}
        pool_map["1"]["name"] = "roce-reserved-ingress"
        pool_map["1"]["mode"] = \
            get_pool_mode(qos_infra, "ingress", fc_service_pool)
        pool_map["1"]["size"] = \
            get_pool_size(qos_infra, "ingress", fc_service_pool)
        fc_sp_list = get_pfc_sp_list(qos_features)
        if fc_sp_list:
            pool_map["1"]["switch-priorities"] = \
                ",".join(fc_sp_list)
        else:
            pool_map["1"]["switch-priorities"] = "-"
        pool_map["1"]["traffic-class"] = "-"
    else:
        non_bulk_pg = get_non_bulk_pg(qos_infra)
        if non_bulk_pg:
            pool_map["1"] = {}
            pool_map["1"]["name"] = "roce-reserved-ingress"
            service_pool = \
                get_pg_service_pool(qos_infra, non_bulk_pg)
            pool_map["1"]["mode"] = \
                get_pool_mode(qos_infra, "ingress", service_pool)
            pool_map["1"]["size"] = \
                get_pool_size(qos_infra, "ingress", service_pool)
            sp_list = get_pg_sp_list(qos_infra, non_bulk_pg)
            fc_sp_list = get_pfc_sp_list(qos_features)
            sp_list = list(set(sp_list) - set(fc_sp_list))
            sp_list.sort()
            if sp_list:
                pool_map["1"]["switch-priorities"] = \
                    ",".join(sp_list)
            else:
                pool_map["1"]["switch-priorities"] = "-"
            pool_map["1"]["traffic-class"] = "-"

    # Get the roce-reserved-egress pool to which fc is mapped
    fc_service_pool = get_fc_service_pool(qos_infra, "egress")
    if fc_service_pool != -1:
        pool_map["3"] = {}
        pool_map["3"]["name"] = "roce-reserved-egress"
        pool_map["3"]["mode"] = \
            get_pool_mode(qos_infra, "egress", fc_service_pool)
        pool_map["3"]["size"] = \
            get_pool_size(qos_infra, "egress", fc_service_pool)
        pool_map["3"]["switch-priorities"] = "-"
        fc_sp_list = get_pfc_sp_list(qos_features)
        fc_tc_list = get_sp_tc_list(qos_infra, fc_sp_list)
        if fc_tc_list:
            pool_map["3"]["traffic-class"] = \
                ",".join(fc_tc_list)
        else:
            pool_map["3"]["traffic-class"] = "-"
    else:
        non_bulk_pg = get_non_bulk_pg(qos_infra)
        if non_bulk_pg:
            pool_map["3"] = {}
            pool_map["3"]["name"] = "roce-reserved-egress"
            service_pool = \
                get_pg_service_pool(qos_infra, non_bulk_pg)
            pool_map["3"]["mode"] = \
                get_pool_mode(qos_infra, "egress", service_pool)
            pool_map["3"]["size"] = \
                get_pool_size(qos_infra, "egress", service_pool)
            sp_list = get_pg_sp_list(qos_infra, non_bulk_pg)
            fc_sp_list = get_pfc_sp_list(qos_features)
            sp_list = list(set(sp_list) - set(fc_sp_list))
            sp_list.sort()
            tc_list = get_sp_tc_list(qos_infra, sp_list)
            if tc_list:
                pool_map["3"]["traffic-class"] = \
                    ",".join(tc_list)
            else:
                pool_map["3"]["traffic-class"] = "-"
            pool_map["3"]["switch-priorities"] = "-"

    return pool_map


def tc_map_config_qos_features_file_get(qos_features, qos_infra):
    tc_map = {}
    for sp in ["0", "1", "2", "3", "4", "5", "6", "7"]:
        tc_map[sp] = {}
        tc_map[sp]['switch-prio'] = int(sp)
        tc = 0
        for line in qos_infra.splitlines():
            line = line.strip()
            tc_map_text = "cos_egr_queue.cos_{}.uc".format(sp)
            if line.startswith(tc_map_text):
                tc = line.split('=')[1].strip()
                break
        tc_map[sp]['traffic-class'] = int(tc)
        sched = -1
        for line in qos_features.splitlines():
            line = line.strip()
            sched_text = "default_egress_sched.egr_queue_{}."\
                "bw_percent".format(tc)
            if line.startswith(sched_text):
                sched = int(line.split('=')[1])
        if sched == 0:
            tc_map[sp]['scheduler-weight'] = 'strict-priority'
        elif sched == -1:
            tc_map[sp]['scheduler-weight'] = 'DWRR-0%'
        else:
            tc_map[sp]['scheduler-weight'] = 'DWRR-{}%'.format(sched)
    return tc_map


def roce_system_config_get(ctx):
    qos_conf = ctx.qos_v1.getQosConfigFile()
    roce_mode = roce_mode_qos_config_file_get(qos_conf)

    roce_conf = {}
    if 'enable' in roce_mode and roce_mode['enable'] == "off":
        roce_conf['mode'] = None
        return roce_conf

    qos_features = ctx.qos_v1.getQosFeaturesFile()
    qos_infra = ctx.qos_v1.getQosInfraFile()

    # Use this roce_conf_static to compare the data from the native layer
    # Report exception list in case of any discrepancy
    roce_conf_static = get_roce_conf_static_config(roce_mode)

    if 'mode' in roce_mode and roce_mode['mode'] == 'lossy':
        roce_conf['mode'] = 'lossy'
    else:
        roce_conf['mode'] = 'lossless'

    roce_conf['congestion-control'] = \
        ecn_config_qos_features_file_get(qos_features)
    roce_conf['tc-map'] = \
        tc_map_config_qos_features_file_get(qos_features, qos_infra)
    roce_conf['prio-map'] = \
        prio_map_config_qos_features_file_get(qos_features)
    roce_conf['trust'] = \
        trust_config_qos_features_file_get(qos_features)
    roce_conf["pfc"] = \
        roce_pfc_config_qos_features_file_get(qos_features)
    roce_conf["pool-map"] = \
        pool_map_config_qos_infra_file_get(qos_infra, qos_features)

    exception = verify_roce_qos_config(roce_conf_static, roce_conf)
    roce_conf['exception-list'] = exception

    return roce_conf


def roce_interface_pools_get(ctx, port):
    pool_collection = roce_system_pools_get(ctx)
    port_buffers = ctx.qos_v1.getPortBuffers(port)
    sp_pg_map = ctx.qos_v1.getSpPgMap(port)
    for idx in pool_collection.keys():
        pool_id = pool_collection[idx]["pool-id"]
        sp_list, tc_list = \
            get_mapped_sp_tc_pool(pool_id, port, port_buffers, sp_pg_map)
        if sp_list:
            pool_collection[idx]["switch-priorities"] = \
                ",".join([str(i) for i in sp_list])
        else:
            pool_collection[idx]["switch-priorities"] = '-'
        if tc_list:
            pool_collection[idx]["traffic-class"] = \
                ",".join([str(i) for i in tc_list])
        else:
            pool_collection[idx]["traffic-class"] = '-'
    return pool_collection
