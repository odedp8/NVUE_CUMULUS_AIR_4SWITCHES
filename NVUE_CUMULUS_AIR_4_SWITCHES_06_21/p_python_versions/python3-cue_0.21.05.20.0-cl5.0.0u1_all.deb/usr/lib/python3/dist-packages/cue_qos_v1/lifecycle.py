# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/ #
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from cue import issues
import logging
from . import templates


logger = logging.getLogger(__name__)


class RoceUnsupported(issues.BadInputIssue):
    """
    ROCE isn't supported on this platform, therefore, it cannot be configured.
    """
    def __init__(self):
        super().__init__("roce_unsupported")

    def _render_message(self):
        return "ROCE is unsupported on this platform."


def is_supported(evt):
    """
    Return True if roce is supported.
    """
    # This check is probably too simple.  Ideally, we would call into a
    # "capabilities" library.  Or maybe we check if /etc/mlx/datapath exists?
    hw = evt.platform_v1.getHardware()
    if (hw.get("vendor") == "cumulus" and hw.get("model") == "vx"):
        return False
    else:
        return True


def process_qos_trust_config(evt, qos):
    if is_supported(evt):
        qos_infra_conf = "/etc/mlx/datapath/qos/qos_infra.conf"
        qos_features_conf = "/etc/cumulus/datapath/qos/qos_features.conf"
        evt.render(templates, "roce-qos-features.conf", config=qos)
        evt.stage_file("roce-qos-features.conf", qos_features_conf)
        evt.render(templates, "roce-qos-infra.conf", config=qos)
        evt.stage_file("roce-qos-infra.conf", qos_infra_conf)
        evt.render(templates, "roce-qos.conf", config=qos)
        evt.stage_file("roce-qos.conf", "/etc/cumulus/switchd.d/qos.conf")
        evt.schedule_reload_or_restart('switchd')


def process_qos_config(evt, qos):
    process_qos_trust_config(evt, qos)


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("qos_v1", handle_verify_config)
    ctx.events.ready_apply.register("qos_v1", handle_ready_apply)
    ctx.events.check_health.register("qos_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """
    # If roce is enabled, make sure we're on a platform that supports it.  This
    # check is probably too simple.  Ideally, we would call into a
    # "capabilities" library.  Or maybe we check if /etc/mlx/datapath exists?
    roce = evt.config_v1.getRoce()
    if roce["enable"] == "on" and not is_supported(evt):
        evt.report_issue(RoceUnsupported())


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    qos = evt.config_v1.getRoce()
    process_qos_config(evt, qos)


def handle_check_health(evt):
    """
    Handle a check_health event.
    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
