# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import json
import logging

logger = logging.getLogger(__name__)


def vtysh_exec_raw(ctx, cmd):
    logger.info("Exec vtysh: '%s'", cmd)
    return ctx.sh.sudo.vtysh("-c", cmd).__str__()


def vtysh_exec(ctx, cmd):
    v_output = vtysh_exec_raw(ctx, cmd)
    try:
        vtysh_result = json.loads(v_output)
    except json.JSONDecodeError:
        logger.warning("Unable to parse vtysh output:")
        logger.warning(v_output)
        return {}
    return vtysh_result


def running_config_get(ctx):
    """
    show run
    """
    try:
        return vtysh_exec_raw(ctx, "show run")
    except ctx.sh.ErrorReturnCode_1:
        return ''


def ip_route_get(ctx):
    """
    show ip route json
    """
    return vtysh_exec(ctx, "show ip route json")


def ip_route_table_get(ctx):
    """
    show ip route table all json
    """
    return vtysh_exec(ctx, "show ip route table all json")


def vrf_vni_get(ctx):
    """
    show vrf vni json
    """
    return vtysh_exec(ctx, "show vrf vni json")


def ip_route_table_id_get(ctx, table_id=""):
    """
    show ip route table <id> json
    """
    return vtysh_exec(ctx, "show ip route table {} json".format(table_id))


def evpn_get(ctx):
    """
    show evpn json
    """
    return vtysh_exec(ctx, "show evpn json")


def evpn_l2nh_get(ctx):
    """
    show evpn l2-nh json
    """
    return vtysh_exec(ctx, "show evpn l2-nh json")


def evpn_es_by_esi_get(ctx, esi_string=""):
    """
    show evpn es {esi-string} json
    """
    return vtysh_exec(ctx, "show evpn es {} json".format(esi_string))


def evpn_esevi_get(ctx):
    """
    show evpn es-evi json
    """
    return vtysh_exec(ctx, "show evpn es-evi json")


def evpn_esevi_by_vni_get(ctx, vni=""):
    """
    show evpn es-evi {vni} json
    """
    return vtysh_exec(ctx, "show evpn es-evi {} json".format(vni))


def evpn_accessvlan_get(ctx, vid=""):
    """
    show evpn access-vlan {vid} json
    """
    return vtysh_exec(ctx, "show evpn access-vlan {} json".format(vid))


def evpn_vni_get(ctx):
    """
    show evpn vni json
    """
    return vtysh_exec(ctx, "show evpn vni json")


def evpn_vni_by_vni_get(ctx, vni=""):
    """
    show evpn vni {vni} json
    """
    return vtysh_exec(ctx, "show evpn vni {} json".format(vni))


def evpn_rmac_vni_all_get(ctx):
    """
    show evpn rmac vni all json
    """
    return vtysh_exec(ctx, "show evpn rmac vni all json")


def evpn_rmac_vni_get(ctx, vni=""):
    """
    show evpn rmac vni {vni} json
    """
    return vtysh_exec(ctx, "show evpn rmac vni {} json".format(vni))


def evpn_rmac_by_vni_by_mac_get(ctx, vni="", mac=""):
    """
    show evpn rmac vni {vni} mac {mac} json
    """
    return vtysh_exec(ctx, "show evpn rmac vni {} mac {} json".format(
        vni, mac))


def evpn_next_hops_vni_all_get(ctx):
    """
    show evpn next-hops vni all json
    """
    return vtysh_exec(ctx, "show evpn next-hops vni all json")


def evpn_nexthops_by_vni_get(ctx, vni=""):
    """
    show evpn next-hops vni {vni} json
    """
    return vtysh_exec(ctx, "show evpn next-hops vni {} json".format(vni))


def evpn_nexthops_by_vni_by_ipv4_get(ctx, vni="", ipv4=""):
    """
    show evpn next-hops vni {vni} ip {ipv4} json
    """
    return vtysh_exec(ctx, "show evpn next-hops vni {} ip {} json".format(
        vni, ipv4))


def evpn_nexthops_by_vni_by_ipv6_get(ctx, vni="", ipv6=""):
    """
    show evpn next-hops vni {vni} ip {ipv6} json
    """
    return vtysh_exec(ctx, "show evpn next-hops vni {} ip {} json".format(
        vni, ipv6))


def evpn_mac_vni_all_get(ctx):
    """
    show evpn mac vni all json
    """
    return vtysh_exec(ctx, "show evpn mac vni all json")


def evpn_mac_by_vni_get(ctx, vni=""):
    """
    show evpn mac vni {vni} json
    """
    return vtysh_exec(ctx, "show evpn mac vni {} json".format(vni))


def evpn_mac_by_vni_by_mac_get(ctx, vni="", mac=""):
    """
    show evpn mac vni {vni} mac {mac} json
    """
    return vtysh_exec(ctx, "show evpn mac vni {} mac {} json".format(vni, mac))


def evpn_mac_by_vni_by_vtep_get(ctx, vni="", ipv4=""):
    """
    show evpn mac vni {vni} vtep {ipv4} json
    """
    return vtysh_exec(ctx, "show evpn mac vni {} vtep {} json".format(
        vni, ipv4))


def evpn_all_vni_by_vtep_get(ctx, ipv4=""):
    """
    show evpn vni all vtep {ipv4} json
    """
    return vtysh_exec(ctx, "show evpn vni all vtep {} json".format(ipv4))


def evpn_mac_vni_all_duplicate_get(ctx):
    """
    show evpn mac vni all duplicate json
    """
    return vtysh_exec(ctx, "show evpn mac vni all duplicate json")


def evpn_arpcache_vni_all_get(ctx):
    """
    show evpn arp-cache vni all json
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni all json")


def evpn_arpcache_by_vni_get(ctx, vni=""):
    """
    show evpn arp-cache vni {vni} json
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni {} json".format(vni))


def evpn_arpcache_duplicate_by_vni_get(ctx, vni=""):
    """
    show evpn arp-cache vni {vni} duplicate
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni {} duplicate".format(vni))


def evpn_arpcache_by_vni_by_vtep_get(ctx, vni="", ipv4=""):
    """
    show evpn arp-cache vni {vni} vtep {ipv4}
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni {} vtep {}".format(
        vni, ipv4))


def evpn_arpcache_by_vni_by_ipv4_get(ctx, vni="", ipv4=""):
    """
    show evpn arp-cache vni {vni} ip {ipv4}
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni {} ip {}".format(
        vni, ipv4))


def evpn_arpcache_by_vni_by_ipv6_get(ctx, vni="", ipv6=""):
    """
    show evpn arp-cache vni {vni} ip {ipv6}
    """
    return vtysh_exec(ctx, "show evpn arp-cache vni {} ip {}".format(
        vni, ipv6))


def bgp_vrf_all_get(ctx):
    """
    show bgp vrf all
    """
    return vtysh_exec(ctx, "show bgp vrf all json")


def bgp_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME>
    """
    return vtysh_exec(ctx, "show bgp vrf {} json".format(vrf))


def bgp_by_vrf_v4_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} json".format(vrf, ipv4))


def bgp_bestpath_by_vrf_v4_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D> bestpath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} bestpath json".
                      format(vrf, ipv4))


def bgp_multipath_by_vrf_v4_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D> multipath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} multipath json".
                      format(vrf, ipv4))


def bgp_by_vrf_v4prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D/M>
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} json".
                      format(vrf, ipv4prefix))


def bgp_bestpath_by_vrf_v4prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D/M> bestpath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} bestpath json".
                      format(vrf, ipv4prefix))


def bgp_multipath_by_vrf_v4prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <A.B.C.D/M> multipath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} multipath json".
                      format(vrf, ipv4prefix))


def bgp_by_vrf_v6_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X>
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} json".
                      format(vrf, ipv6))


def bgp_bestpath_by_vrf_v6_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X> bestpath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} bestpath json".
                      format(vrf, ipv6))


def bgp_multipath_by_vrf_v6_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X> multipath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} multipath json".
                      format(vrf, ipv6))


def bgp_by_vrf_v6prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X/M>
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} json".
                      format(vrf, ipv4prefix))


def bgp_bestpath_by_vrf_v6prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X/M> bestpath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} bestpath json".
                      format(vrf, ipv4prefix))


def bgp_multipath_by_vrf_v6prefix_get(ctx, vrf='', ipv4prefix=''):
    """
    show bgp vrf <VRFNAME> <X:X::X:X/M> multipath
    """
    return vtysh_exec(ctx, "show bgp vrf {} {} multipath json".
                      format(vrf, ipv4prefix))


def bgp_summary_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> summary
    """
    return vtysh_exec(ctx, "show bgp vrf {} summary json".
                      format(vrf))


def bgp_routeleak_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> route-leak
    """
    return vtysh_exec(ctx, "show bgp vrf {} route-leak json".
                      format(vrf))


def bgp_l2vpn_evpn_get(ctx):
    """
    show bgp l2vpn evpn
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn json")


def bgp_l2vpn_evpn_by_rd_get(ctx, evpnrd=''):
    """
    show bgp l2vpn evpn rd <ASN:NN_OR_IP-ADDRESS:NN>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn rd {} json".
                      format(evpnrd))


def bgp_l2vpn_evpn_routes_by_rd_v4neigh_get(ctx, evpnrd='', ipv4=''):
    """
    show bgp l2vpn evpn rd <ASN:NN_OR_IP-ADDRESS:NN> neighbors <A.B.C.D> routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn rd {} neighbors {} routes"
                      "json".format(evpnrd, ipv4))


def bgp_l2vpn_evpn_routes_by_rd_v6_get(ctx, evpnrd='', ipv6=''):
    """
    show bgp l2vpn evpn rd <ASN:NN_OR_IP-ADDRESS:NN> neighbors
    <X:X::X:X> routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn rd {} neighbors {} routes"
                      "json".format(evpnrd, ipv6))


def bgp_l2vpn_evpn_advertisedroutes_by_rd_v4neigh_get(ctx, evpnrd='',
                                                      ipv4=''):
    """
    show bgp l2vpn evpn rd <ASN:NN_OR_IP-ADDRESS:NN> neighbors <A.B.C.D>
    advertised-routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn rd {} neighbors {} "
                      "advertised-routes json".format(evpnrd, ipv4))


def bgp_l2vpn_evpn_advertisedroutes_by_rd_v6_get(ctx, evpnrd='', ipv6=''):
    """
    show bgp l2vpn evpn rd <ASN:NN_OR_IP-ADDRESS:NN> neighbors <X:X::X:X>
    advertised-routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn rd {} neighbors {} "
                      "advertised-routes json".format(evpnrd, ipv6))


def bgp_l2vpn_evpn_routes_by_v4neigh_get(ctx, ipv4=''):
    """
    show bgp l2vpn evpn neighbors <A.B.C.D> routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn neighbors {} routes json".
                      format(ipv4))


def bgp_l2vpn_evpn_routes_by_v6neigh_get(ctx, ipv6=''):
    """
    show bgp l2vpn evpn neighbors <X:X::X:X> routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn neighbors {} routes json".
                      format(ipv6))


def bgp_l2vpn_evpn_advertisedroutes_v4neigh_get(ctx, ipv4=''):
    """
    show bgp l2vpn evpn neighbors <A.B.C.D> advertised-routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn neighbors {} "
                      "advertised-routes json".format(ipv4))


def bgp_l2vpn_evpn_advertisedroutes_v6neigh_get(ctx, ipv6=''):
    """
    show bgp l2vpn evpn neighbors <X:X::X:X> advertised-routes
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn neighbors {} "
                      "advertised-routes json".format(ipv6))


def bgp_l2vpn_evpn_all_overlay_get(ctx):
    """
    show bgp l2vpn evpn all overlay
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn all overlay json")


def bgp_l2vpn_evpn_by_community_get(ctx, community=''):
    """
    show bgp l2vpn evpn community <AA:NN>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn community {}".
                      format(community))


def bgp_l2vpn_evpn_by_largecommunitynumbers_get(ctx, largecommunitynumbers=''):
    """
    show bgp l2vpn evpn large-community <AA:BB:CC>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn large-community {}".
                      format(largecommunitynumbers))


def bgp_l2vpn_evpn_by_vni_get(ctx, vni=''):
    """
    show bgp l2vpn evpn vni <VNI>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn vni {}".
                      format(vni))


def bgp_l2vpn_evpn_by_esevi_get(ctx, vni=''):
    """
    show bgp l2vpn evpn es-evi <VNI>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn es-evi {}".
                      format(vni))


def bgp_l2vpn_evpn_by_es_get(ctx, esistr=''):
    """
    show bgp l2vpn evpn es <ESISTR>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn es {}".
                      format(esistr))


def bgp_l2vpn_evpn_by_esvrf_get(ctx, esistr=''):
    """
    show bgp l2vpn evpn es-vrf <ESISTR>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn es-vrf {}".
                      format(esistr))


def bgp_l2vpn_evpn_nexthops_get(ctx):
    """
    show bgp l2vpn evpn next-hops
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn next-hops json")


def bgp_l2vpn_evpn_summary_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> l2vpn evpn summary
    """
    return vtysh_exec(ctx, "show bgp vrf {} l2vpn evpn summary json".
                      format(vrf))


def bgp_l2vpn_evpn_route_get(ctx):
    """
    show bgp l2vpn evpn route
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route json")


def bgp_l2vpn_evpn_route_by_type_get(ctx, evpnroutetype=''):
    """
    show bgp l2vpn evpn route type <ead|1|macip|2|multicast|3|es|4|prefix|5>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route type {}".
                      format(evpnroutetype))


def bgp_l2vpn_evpn_route_by_rd_get(ctx, evpnrd=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {}".
                      format(evpnrd))


def bgp_l2vpn_evpn_route_by_rd_type_get(ctx, evpnrd='', evpnroutetype=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> type
    <ead|macip|multicast|es|prefix>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} type {}".
                      format(evpnrd, evpnroutetype))


def bgp_l2vpn_evpn_route_by_rd_mac_get(ctx, evpnrd='', mac=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> mac <WORD>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} mac {}".
                      format(evpnrd, mac))


def bgp_l2vpn_evpn_route_by_rd_mac_v4_get(ctx, evpnrd='', mac='',
                                          ipv4=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> mac <WORD> ip
    <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} mac {} ip {}".
                      format(evpnrd, mac, ipv4))


def bgp_l2vpn_evpn_route_by_rd_mac_v6_get(ctx, evpnrd='', mac='',
                                          ipv6=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> mac <WORD> ip
    <X:X::X:X>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} mac {} ip {}".
                      format(evpnrd, mac, ipv6))


def bgp_l2vpn_evpn_route_by_rd_v4prefix_get(ctx, evpnrd='', ipv4prefix=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> ip <A.B.C.D/M>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} ip {}".
                      format(evpnrd, ipv4prefix))


def bgp_l2vpn_evpn_route_by_rd_v6prefix_get(ctx, evpnrd='', ipv4prefix=''):
    """
    show bgp l2vpn evpn route rd <ASN:NN_OR_IP-ADDRESS:NN> ip <X:X::X:X/M>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route rd {} ip {}".
                      format(evpnrd, ipv4prefix))


def bgp_l2vpn_evpn_route_by_esi_get(ctx, esistr=''):
    """
    show bgp l2vpn evpn route esi <ESISTR>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route esi {}".
                      format(esistr))


def bgp_l2vpn_evpn_route_vni_all_get(ctx):
    """
    show bgp l2vpn evpn route vni all
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni all json")


def bgp_l2vpn_evpn_route_by_vni_get(ctx, vni=''):
    """
    show bgp l2vpn evpn route vni <VNI>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {}".
                      format(vni))


def bgp_l2vpn_evpn_route_by_vni_type_get(ctx, vni='', evpnroutetype=''):
    """
    show bgp l2vpn evpn route vni <VNI> type <ead|macip|multicast|es|prefix>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} type {}".
                      format(vni, evpnroutetype))


def bgp_l2vpn_evpn_route_by_vni_vtep_get(ctx, vni='', ipv4=''):
    """
    show bgp l2vpn evpn route vni <VNI> vtep <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} vtep {}".
                      format(vni, ipv4))


def bgp_l2vpn_evpn_route_by_vni_mac_get(ctx, vni='', mac=''):
    """
    show bgp l2vpn evpn route vni <VNI> mac <WORD>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} mac {}".
                      format(vni, mac))


def bgp_l2vpn_evpn_route_by_vni_mac_v4_get(ctx, vni='', mac='', ipv4=''):
    """
    show bgp l2vpn evpn route vni <VNI> mac <WORD> ip <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} mac {} ip {}".
                      format(vni, mac, ipv4))


def bgp_l2vpn_evpn_route_by_vni_mac_v6_get(ctx, vni='', mac='', ipv6=''):
    """
    show bgp l2vpn evpn route vni <VNI> mac <WORD> ip <X:X::X:X>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} mac {} ip {}".
                      format(vni, mac, ipv6))


def bgp_l2vpn_evpn_route_by_vni_multicast_get(ctx, vni='', ipv4=''):
    """
    show bgp l2vpn evpn route vni <VNI> multicast <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn route vni {} multicast {}".
                      format(vni, ipv4))


def bgp_l2vpn_evpn_vrfimportrt_get(ctx):
    """
    show bgp l2vpn evpn vrf-import-rt
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn vrf-import-rt json")


def bgp_l2vpn_evpn_importrt_get(ctx):
    """
    show bgp l2vpn evpn import-rt
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn import-rt json")


def bgp_l2vpn_vni_by_vrf_get(ctx, vrf=''):
    """
    show bgp l2vpn vrf <VRFNAME> vni
    """
    return vtysh_exec(ctx, "show bgp l2vpn vrf {} vni json".
                      format(vrf))


def bgp_largecommunitylist_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> large-community-list
    """
    return vtysh_exec(ctx, "show bgp vrf {} large-community-list json".
                      format(vrf))


def bgp_by_vrf_largecommunitynumber_get(ctx, vrf='',
                                        largecommunitynumber=''):
    """
    show bgp vrf <VRFNAME> large-community-list <1-500>
    """
    return vtysh_exec(ctx, "show bgp vrf {} large-community-list {}".
                      format(vrf, largecommunitynumber))


def bgp_by_vrf_largecommunityname_get(ctx, vrf='', largecommunitynname=''):
    """
    show bgp vrf <VRFNAME> large-community-list <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} large-community-list {}".
                      format(vrf, largecommunitynname))


def bgp_largecommunity_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> large-community
    """
    return vtysh_exec(ctx, "show bgp vrf {} large-community json".
                      format(vrf))


def bgp_by_vrf_largecommunitynumbers_get(ctx, vrf='',
                                         largecommunitynumbers=''):
    """
    show bgp vrf <VRFNAME> large-community <AA:BB:CC>
    """
    return vtysh_exec(ctx, "show bgp vrf {} large-community {}".
                      format(vrf, largecommunitynumbers))


def bgp_statistics_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> statistics-all
    """
    return vtysh_exec(ctx, "show bgp vrf {} statistics-all json".
                      format(vrf))


def bgp_l2vpn_evpn_statistics_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> l2vpn evpn statistics
    """
    return vtysh_exec(ctx, "show bgp vrf {} l2vpn evpn statistics json".
                      format(vrf))


def bgp_neighbors_by_vrf_get(ctx, vrf=''):
    """
    show bgp vrf <VRFNAME> neighbors
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors json".
                      format(vrf))


def bgp_prefixcounts_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> prefix-counts
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} prefix-counts json".
                      format(vrf, ipv4))


def bgp_prefixcounts_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> prefix-counts
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} prefix-counts json".
                      format(vrf, ipv6))


def bgp_prefixcounts_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> prefix-counts
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} prefix-counts json".
                      format(vrf, mac))


def bgp_l2vpn_evpn_by_v4_get(ctx, ipv4=''):
    """
    show bgp l2vpn evpn <A.B.C.D>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn {}".
                      format(ipv4))


def bgp_l2vpn_evpn_by_v4prefix_get(ctx, ipv4prefix=''):
    """
    show bgp l2vpn evpn <A.B.C.D/M>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn {}".
                      format(ipv4prefix))


def bgp_l2vpn_evpn_by_v6_get(ctx, ipv6=''):
    """
    show bgp l2vpn evpn <X:X::X:X>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn {}".
                      format(ipv6))


def bgp_l2vpn_evpn_by_v6prefix_get(ctx, ipv4prefix=''):
    """
    show bgp l2vpn evpn <X:X::X:X/M>
    """
    return vtysh_exec(ctx, "show bgp l2vpn evpn {}".
                      format(ipv4prefix))


def bgp_bestpathroutes_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> bestpath-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} bestpath-routes json".
                      format(vrf, ipv4))


def bgp_bestpathroutes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> bestpath-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} bestpath-routes json".
                      format(vrf, ipv6))


def bgp_bestpathroutes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> bestpath-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} bestpath-routes json".
                      format(vrf, mac))


def bgp_advertisedroutes_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> advertised-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "json".format(vrf, ipv4))


def bgp_advertisedroutes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> advertised-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "json".format(vrf, ipv6))


def bgp_advertisedroutes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> advertised-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "json".format(vrf, mac))


def bgp_advertisedroutes_by_vrf_v4neigh_map_get(ctx, vrf='', ipv4='',
                                                routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> advertised-routes route-map
    <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "route-map {}".format(vrf, ipv4, routemap))


def bgp_advertisedroutes_by_vrf_v6neigh_map_get(ctx, vrf='', ipv6='',
                                                routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> advertised-routes route-map
    <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "route-map {}".format(vrf, ipv6, routemap))


def bgp_advertisedroutes_by_vrf_macneigh_map_get(ctx, vrf='', mac='',
                                                 routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> advertised-routes route-map <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} advertised-routes "
                      "route-map {}".format(vrf, mac, routemap))


def bgp_receivedroutes_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> received-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes json".
                      format(vrf, ipv4))


def bgp_receivedroutes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> received-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes json".
                      format(vrf, ipv6))


def bgp_receivedroutes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> received-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes json".
                      format(vrf, mac))


def bgp_receivedroutes_by_vrf_v4neigh_map_get(ctx, vrf='', ipv4='',
                                              routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> received-routes route-map <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes "
                      "route-map {}".  format(vrf, ipv4, routemap))


def bgp_receivedroutes_by_vrf_v6neigh_map_get(ctx, vrf='', ipv6='',
                                              routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> received-routes route-map
    <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes "
                      "route-map {}".format(vrf, ipv6, routemap))


def bgp_receivedroutes_by_vrf_macneigh_map_get(ctx, vrf='', mac='',
                                               routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> received-routes route-map <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} received-routes "
                      "route-map {}".format(vrf, mac, routemap))


def bgp_filteredroutes_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> filtered-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes json".
                      format(vrf, ipv4))


def bgp_filteredroutes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> filtered-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes json".
                      format(vrf, ipv6))


def bgp_filteredroutes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> filtered-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes json".
                      format(vrf, mac))


def bgp_filteredroutes_by_vrf_v4_map_get(ctx, vrf='', ipv4='',
                                         routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> filtered-routes route-map <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes "
                      "route-map {}".format(vrf, ipv4, routemap))


def bgp_filteredroutes_by_vrf_v6neigh_map_get(ctx, vrf='', ipv6='',
                                              routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> filtered-routes route-map
    <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes "
                      "route-map {}".format(vrf, ipv6, routemap))


def bgp_filteredroutes_by_vrf_macneigh_map_get(ctx, vrf='', mac='',
                                               routemap=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> filtered-routes route-map <WORD>
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} filtered-routes "
                      "route-map {}".format(vrf, mac, routemap))


def bgp_prefixfilter_by_v4neigh_get(ctx, ipv4=''):
    """
    show bgp ipv4 neighbors <A.B.C.D> received prefix-filter
    """
    return vtysh_exec(ctx, "show bgp ipv4 neighbors {} received prefix-filter "
                      "json".format(ipv4))


def bgp_prefixfilter_by_v6neigh_get(ctx, ipv6=''):
    """
    show bgp ipv6 neighbors <X:X::X:X> received prefix-filter
    """
    return vtysh_exec(ctx, "show bgp ipv6 neighbors {} received prefix-filter "
                      "json".format(ipv6))


def bgp_prefixfilter_by_macneigh_get(ctx, mac=''):
    """
    show bgp neighbors <WORD> received prefix-filter
    """
    return vtysh_exec(ctx, "show bgp neighbors {} received prefix-filter json".
                      format(mac))


def bgp_flapstats_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> flap-statistics
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} flap-statistics json".
                      format(vrf, ipv4))


def bgp_dampenedroutes_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> dampened-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} dampened-routes json".
                      format(vrf, ipv4))


def bgp_routes_by_vrf_v4neigh_get(ctx, vrf='', ipv4=''):
    """
    show bgp vrf <VRFNAME> neighbors <A.B.C.D> routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} routes json".
                      format(vrf, ipv4))


def bgp_flapstats_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> flap-statistics
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} flap-statistics json".
                      format(vrf, ipv6))


def bgp_dampenedroutes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> dampened-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} dampened-routes json".
                      format(vrf, ipv6))


def bgp_routes_by_vrf_v6neigh_get(ctx, vrf='', ipv6=''):
    """
    show bgp vrf <VRFNAME> neighbors <X:X::X:X> routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} routes json".
                      format(vrf, ipv6))


def bgp_flapstats_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> flap-statistics
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} flap-statistics json".
                      format(vrf, mac))


def bgp_dampenedroutes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> dampened-routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} dampened-routes json".
                      format(vrf, mac))


def bgp_routes_by_vrf_macneigh_get(ctx, vrf='', mac=''):
    """
    show bgp vrf <VRFNAME> neighbors <WORD> routes
    """
    return vtysh_exec(ctx, "show bgp vrf {} neighbors {} routes json".
                      format(vrf, mac))
