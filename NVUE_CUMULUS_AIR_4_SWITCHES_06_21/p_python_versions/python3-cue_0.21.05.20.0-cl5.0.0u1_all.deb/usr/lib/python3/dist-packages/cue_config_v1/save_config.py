# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from cue.utils import yaml_dump
from cue.issues import InternalError
from cue import config
from contextlib import contextmanager
from pathlib import Path
from shutil import rmtree
from tempfile import mkdtemp
import logging

logger = logging.getLogger(__name__)


SAVE_TRANSITIONS = {
    "save": ["saving"],
    "saving": ["save_error", "saved"]
}


###############################
# lifecycle event handlers
###############################

def handle_revision_state(evt):
    if evt.new_state == "save":
        # Kick off the job by transitioning to the next state.
        evt.ctx.jobs.add(
            f"save: {evt.rev_id}",
            lambda: evt.progress("saving"),
        )
    elif evt.new_state == "saving":
        try:
            config_text = get_config_text(evt.ctx.config_v1, evt.rev_id)
            replace_startup(
                evt.ctx.fileops,
                config.PUBLIC_CONFIG_ROOT,
                config_text,
            )
        except Exception:
            # Shoul
            logger.exception("Unexpected error while saving.")
            evt.progress("save_error", issues=[InternalError()])
        else:
            evt.progress("saved")


def handle_init_revision_transitions(evt):
    evt.add_entry_state("save")
    evt.update_transitions(SAVE_TRANSITIONS)


def handle_cleanup_revisions(evt):
    revisions = evt.versions_v1.getRevisions()
    for rev_id, rev_data in revisions.items():
        # EARLY CONTINUE
        if rev_data["state"] not in SAVE_TRANSITIONS:
            # It's in a terminal/unknown state, so we won't touch it.
            continue
        # Put it in a terminal state, so we can still use it.
        evt.versions_v1.updateRevision(rev_id, state="save_interrupted")


############################
# Implementation utilities
############################

@contextmanager
def get_tmp_path(*args, **kwargs):
    """
    Context manager to create and delete a temporary directory. The
    args/keyword args are passed into the call to `tempfile.mkdtemp`. The
    `tmp_path` and its contents are removed upon exiting the context.

    Returns:
        A `pathlib.Path` referencing the temporary directory.
    """
    tmp_path = Path(mkdtemp(*args, **kwargs))
    try:
        yield tmp_path
    finally:
        rmtree(tmp_path)


_CONFIG_FILE_NAME = "startup.yaml"
"""The file name to save the config file as."""


def replace_startup(fileops, config_dir, config_text):
    """
    Replace the contents of the public config directory with `config_text`.

    This operation is somewhat atomic. If any exceptions happen while messing
    with the files, restore the original files. (If cued suddenly stops,
    however, atomicity is not guaranteed.)

    Args:
        fileops: The fileops API handle.
        config_dir: Path to the public config directory.
        config_text: The string contents with which to overwrite the startup
            contents.

    Side-effects:
        Removes any existing files in the public config directory, and writes a
        new startup.yaml.
    """
    config_dir = Path(config_dir)

    # This is where we'll ultimately put our new config file.
    target_path = config_dir / _CONFIG_FILE_NAME

    with get_tmp_path() as tmp_path:
        # Start it as a temporary file. Copying this to target_path will be the
        # last step in the process.
        new_config = tmp_path / _CONFIG_FILE_NAME
        new_config.write_text(config_text)

        # Put the existing config files in here. If anything goes wrong, we
        # will restore the directory to its original state.
        backup_dir = tmp_path / "backup"
        backup_dir.mkdir()
        try:
            # Move all the existing config files into our backup_dir.
            for existing_file in config_dir.iterdir():
                # EARLY CONTINUE
                if existing_file.is_dir():
                    # We won't touch directories. Just files.
                    continue
                fileops.move_file(
                    existing_file,
                    backup_dir / existing_file.name,
                    sudo=True
                )
            # Now that the directory is cleared out, put the new config in.
            fileops.copy_file(new_config, target_path, sudo=True)
        except Exception:
            # Something went wrong. Put everything back where you found it.
            for backup_path in backup_dir.iterdir():
                restore_path = config_dir / backup_path.name
                fileops.move_file(backup_path, restore_path)
            # Let the caller handle the exception.
            raise


def get_config_text(config_v1, rev_id):
    """
    Return the current contents of `rev_id` as a string in config file format.

    Args:
        config_v1: The API handle for config_v1.
        rev_id: The revision to get config for.

    Returns:
        YAML string config file contents.
    """
    return yaml_dump(
        [{"set": config_v1.getRoot(rev_id, filled=False)}]
    )
