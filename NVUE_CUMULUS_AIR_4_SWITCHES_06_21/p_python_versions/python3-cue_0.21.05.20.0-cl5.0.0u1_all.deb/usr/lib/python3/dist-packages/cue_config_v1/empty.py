# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import MethodNotAllowed
from . import schema
import logging


logger = logging.getLogger(__name__)


def empty_get(ctx):
    """
    Return the magic `empty` config.
    """
    return schema.empty_config()


def empty_put(ctx, body):
    raise MethodNotAllowed("'empty' revision is read only.")
