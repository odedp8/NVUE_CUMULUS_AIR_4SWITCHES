# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import json
import logging
from cue.exceptions import NotFound


logger = logging.getLogger(__name__)


################################
# ifquery
################################

def ifqueries_get(ctx):
    """
    Return the output of "ifquery -r -a".
    """
    # Get the list from ifquery.  It doesn't seem to work, unless we sudo.
    iface_txt = ctx.sh.sudo.ifquery("-r", "-a", "-o", "json")

    # Load the JSON output.  This will give us a list.
    logger.info('Running ifrquery -r -a -o json')
    try:
        iface_list = json.loads(iface_txt.strip())
    except json.JSONDecodeError:
        logger.warning("Unable to parse ifquery output")
        iface_list = []

    # Re-organize the list into an IfQueries, which is a mapping
    # from name to interface config
    objs = {}
    for iface in iface_list:
        # Pull the name up
        name = iface.pop("name")

        # Add it to our response
        objs[name] = iface

    return objs


def ifquery_get(ctx, ifquery_id, entries=None):
    """
    Return the output of "ifquery -r <ifquery_id>".
    """
    query_arg = "-r"
    if entries == "config":
        query_arg = "-x"

    # Get the iface from ifquery.  It doesn't seem to work, unless we sudo.
    iface_txt = ctx.sh.sudo.ifquery(query_arg, "-o", "json", ifquery_id)

    # Load the JSON output.  This will give us a list.
    try:
        iface_list = json.loads(iface_txt.strip())
    except json.JSONDecodeError:
        logger.warning("Unable to parse ifquery output")
        iface_list = []

    if len(iface_list) == 0:
        raise NotFound
    else:
        iface = iface_list[0]

        # Pull the name out
        iface.pop("name")

        # Return it as is.
        return iface
