# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

import copy
from . import templates
from hashlib import sha256
import re
import logging
from pydash import py_

logger = logging.getLogger(__name__)


# class Utils:
#     @staticmethod
#     def get_boolean_from_string(s):
#         return {
#             True: True,
#             "on": True,
#             "yes": True,
#             "1": True,
#             "true": True,
#             "True": True,
#             False: False,
#             "off": False,
#             "no": False,
#             "0": False,
#             "false": False,
#             "False": False
#         }.get(s, False)


class NoPeerlinkConfigured(Exception):
    pass


class Attribute:
    """
    Base class for attributes of a Stanza.

    Encapsulates how to retrieve an ifupdown2 attribute's value from the CUE
    config tree and then translate it into a format ifupdown2 recognizes.
    """

    def __init__(self, name, sequence):
        """ Create an Attribute object

        Arguments:
            name     - The name of the ifupdown2 attribute that this
                       Attribute is mapped to.
            sequence - A list of strings that will be used as a path into
                       the CUE config tree to retreive the value that will
                       eventually be translated into a format accepted by
                       ifupdown2 for the given attribute

        Example:
            The ifupdown2 attribute 'bond-slaves' is represented in the CUE OM
            under an interface's 'bond.slaves', so "bond-slaves" would be the
            Attribute's 'name', and ["bond", "slaves"] its 'sequence'.
        """
        self._name = name
        self._sequence = sequence
        self._value = None

    def __get(self):
        """ Generate an ifupdown2 attribute string

        Create an attribute string using '_name' and '_value'.  This string
        will be written to ENI in a stanza during 'handle_ready_apply'.

        Returns:
            A string

        Example:
            "bond-mode 802.3ad"
        """
        if self._value is None:
            return []
        else:
            if isinstance(self._value, list):
                return [
                    "{} {}".format(self._name, value) for value in self._value
                ]
            else:
                return ["{} {}".format(self._name, self._value)]

    def _translate(self, _):
        """ Translate '_value' into the format required by ifupdown2

        This is implemented by children of the Attribute class if any
        translation from CUE's value to ifupdown2's value is needed.

        Example:
            CUE's bond modes are called "lacp" and "static", while ifupdown2's
            bond modes are called "802.3ad" and "balance-xor".  Before we
            render a "bond-mode" string that will be written to ENI, a
            translation is performed:
                lacp   -> 802.3ad
                static -> balance-xor
        """
        pass

    def reduce(self, data, stanza, ifname, kind):
        """ Get the attribute's value and return an ENI attribute string.

        Each 'Attribute' has a corresponding ifupdown2 attribute.  The 'reduce
        function is given the name of the ifupdown2 attribute and a path
        for extracting the value of that attribute from the CUE config.
        'reduce' extracts the value and then performs any translation required
        from the CUE value to the ifupdown2 value via '_translate'.

        Arguments:
            data   - A dict of CUE config
            stanza - 'Stanza' object.

                     The 'Stanza' object is what calls 'reduce' and passes
                     itself as an argument via 'self'.
            ifname - Interface name of the interface for a which a stanza is
                     being created.
            brname - Name of the bridge to which the interface belongs
            kind   - Type of interface

        Returns:
            A string that is recognized by ifupdown2.  Ex. "bond-mode 802.3ad".
        """

        # Get the corresponding value of the ifupdown2 attribute from the CUE
        # config
        if self._sequence is None:
            self._value = None
        elif callable(self._sequence):
            self._value = self._sequence(data)
        else:
            self._value = py_.get(data, '.'.join(self._sequence))

        if self._value is not None:
            self._translate(stanza)

        return self.__get()


class AttributeNotImplemented(Attribute):
    """
    Placeholder for non implemented attributes
    """

    def __init__(self, name):
        """
        Instantiate an Attribute with a None reduce-sequence
        """
        super().__init__(name, None)


class __AttributeBoolean(Attribute):
    """
    Base class for boolean attributes -
    Translate attribute boolean value into a string defined by a child class.
    """

    def __init__(self, name, sequence, true_str, false_str):
        super().__init__(name, sequence)
        self.__true = true_str
        self.__false = false_str

    def _translate(self, _):
        self._value = self.__true if self._value else self.__false


# class AttributeOnOffBoolean(__AttributeBoolean):
#    """
#    Boolean Attribute on/off
#    """
#
#    def __init__(self, name, sequence):
#        super().__init__(name, sequence, "on", "off")


class AttributeIPv6Disable(Attribute):
    def _translate(self, stanza):
        # If we get a value of "off", disable ipv6.  We need to do this as a
        # post-up sysctl call, currently.
        if self._value == "off":
            self._value = \
                f"sysctl -w net.ipv6.conf.{stanza.ifname}.disable_ipv6=1"
        # Otherwise, do nothing.
        else:
            self._value = None


class AttributeYesNoBoolean(__AttributeBoolean):
    """
    Boolean Attribute yes/no
    """

    def __init__(self, name, sequence):
        super().__init__(name, sequence, "yes", "no")


class AttributeYesNoBooleanIgnoreDefault(AttributeYesNoBoolean):
    """
    Boolean Attribute yes/no
    """

    def __init__(self, name, sequence, default):
        super().__init__(name, sequence)
        self.default = default

    def _translate(self, stanza):
        super()._translate(stanza)
        if self._value == self.default:
            self._value = None


class AttributeYesNoState(AttributeYesNoBooleanIgnoreDefault):
    """
    Convert "state" object into a yes/no.
    """

    def __init__(self, name, sequence, default):
        super().__init__(name, sequence, default)

    def _translate(self, stanza):
        self._value = ("up" in self._value)
        super()._translate(stanza)


class __AttributeOnOff(Attribute):
    """
    Base class for offon attributes -
    Translate attribute off/on value into a string defined by a child class.
    """

    def __init__(self, name, sequence, true_str, false_str):
        super().__init__(name, sequence)
        self.__true = true_str
        self.__false = false_str

    def _translate(self, _):
        self._value = self.__true if self._value == "on" else self.__false


# class AttributeIntegerOnOff(__AttributeOnOff):
#    """
#    offon attribute translated to 1/0
#    """
#
#    def __init__(self, name, sequence):
#        super().__init__(name, sequence, "1", "0")
#
#
# class AttributeIntegerOnOffIgnoreDefault(AttributeIntegerOnOff):
#    """
#    offon attribute translated to 1/0 that ignores default
#    """
#
#    def __init__(self, name, sequence, default):
#        super().__init__(name, sequence)
#        self.default = default
#
#    def _translate(self, *args, **kwargs):
#        super()._translate(*args, **kwargs)
#        if self._value == self.default:
#            self._value = None


class AttributeYesNoOnOff(__AttributeOnOff):
    """
    offon attribute translated to yes/no
    """

    def __init__(self, name, sequence):
        super().__init__(name, sequence, "yes", "no")


class AttributeYesNoOnOffIgnoreDefault(AttributeYesNoOnOff):
    """
    offon attribute translated to yes/no that ignores default
    """

    def __init__(self, name, sequence, default):
        super().__init__(name, sequence)
        self.default = default

    def _translate(self, *args, **kwargs):
        super()._translate(*args, **kwargs)
        if self._value == self.default:
            self._value = None


class AttributeListToString(Attribute):
    """
    Translate attribute value (list) into a string
    """

    def _translate(self, _):
        if self._value:
            self._value = " ".join(map(str, self._value))


class AttributeKeysToString(AttributeListToString):
    """
    Translate attribute's keys (dict) into a string
    """

    def _translate(self, stanza):
        self._value = list(self._value.keys())
        super()._translate(stanza)


class AttributeBondMode(Attribute):
    """
    bond-mode attribute -
    Translate "lacp" to "802.3ad" and "static" to "balance-xor"
    """

    __user_value_to_bond_mode = {
        "lacp": "802.3ad",
        "static": "balance-xor"
    }

    def _translate(self, stanza):
        self._value = self.__user_value_to_bond_mode.get(self._value)


class AttributeAddresses(Attribute):
    """
    Collection of addresses attribute -
    Ignore "dhcp" and "dhcp6"
    """

    def _translate(self, _):
        if "dhcp" in self._value or "dhcp6" in self._value:
            self._value = None
        else:
            # _value is a list of IP addresses.  Write each on its own line.
            self._value = list(self._value.keys())


class AttributeGateway(Attribute):
    def _translate(self, _):
        # _value is a list of IP addresses.  Write each on its own line.
        self._value = list(self._value.keys())


class AttributeFec(Attribute):
    def _translate(self, _):
        # If the user requested "auto", let ifupdown2 decide the best value
        if self._value == "auto":
            self._value = None

        # If the user requested driver-auto, use ifupdown2's `auto`
        elif self._value == 'driver-auto':
            self._value = 'auto'


class AttributeLinkSpeed(Attribute):
    """
    link-speed attribute -
    Translate object model link speed into ifupdown2 link-speed valid values
    """

    def _translate(self, _):
        # If the user requested "auto", let ifupdown2 decide the best value
        if self._value == "auto":
            self._value = None
        else:
            self._value = self._value.replace("M", "")
            self._value = self._value.replace("G", "000")


class AttributeLinkDown(Attribute):
    """
    link-down attribute -
    Translate object model link state into ifupdown2 link-down values
    """
    def _translate(self, _):
        if 'up' in self._value:
            self._value = None
        else:
            self._value = 'yes'


class AttributeBridgeVids(Attribute):
    """
    bridge-vids -
    Extract bridge vids from the bridge port object
    """

    def __init__(self):
        super().__init__("bridge-vids",
                         ["bridge", "domain", "br_default", "vlan"])

    def _translate(self, stanza):
        if "all" in self._value or not self._value:
            self._value = []
        else:
            self._value = " ".join(self._value.keys())

    def reduce(self, data, stanza, ifname, kind):
        if stanza \
                and stanza.bridge_name \
                and stanza.bridge_name != self._sequence[2]:
            self._sequence[2] = stanza.bridge_name
        return super().reduce(data, stanza, ifname, kind)


class AttributeBridgePVid(Attribute):
    """
    bridge-pvid -
    Extract bridge pvid from the bridge port object
    """

    def __init__(self):
        super().__init__("bridge-pvid",
                         ["bridge", "domain", "br_default", "untagged"])

    def _translate(self, stanza):
        # If the user requested "auto", we want to inherit from the global
        # bridge.  Also, if it's "none", then we'll disable tagging.  Either
        # way, we don't want to emit a bridge-pvid line.
        if self._value in ["auto", "none"]:
            self._value = None

    def reduce(self, data, stanza, ifname, kind):
        if stanza \
                and stanza.bridge_name \
                and stanza.bridge_name != self._sequence[2]:
            self._sequence[2] = stanza.bridge_name
        return super().reduce(data, stanza, ifname, kind)


class AttributeBridgeAllowUntagged(Attribute):
    """
    bridge-allow-untagged -
    If untagged is none, disable tagging.
    """

    def __init__(self):
        super().__init__("bridge-allow-untagged",
                         ["bridge", "domain", "br_default", "untagged"])

    def _translate(self, stanza):
        # If the user requested "none", then we need to disable untagged
        # packets.
        if self._value == "none":
            self._value = "no"
        # Otherwise, we shouldn't emit anything.  The default is "yes", which
        # is what we want.
        else:
            self._value = None

    def reduce(self, data, stanza, ifname, kind):
        if kind != "bridge" \
                and stanza \
                and stanza.bridge_name \
                and stanza.bridge_name != self._sequence[2]:
            self._sequence[2] = stanza.bridge_name
        return super().reduce(data, stanza, ifname, kind)


class AttributeBridgeAccess(Attribute):
    """
    bridge-access -
    Extract bridge access from the bridge port object
    """

    def __init__(self):
        super().__init__("bridge-access",
                         ["bridge", "domain", "br_default", "access"])

    def _translate(self, stanza):
        # If the user requested "auto", we want to inherit from the global
        # bridge.
        if self._value == "auto":
            self._value = None

    def reduce(self, data, stanza, ifname, kind):
        if kind != "bridge" \
                and stanza \
                and stanza.bridge_name \
                and stanza.bridge_name != self._sequence[2]:
            self._sequence[2] = stanza.bridge_name
        return super().reduce(data, stanza, ifname, kind)


class AttributeBridgeVlanAware(Attribute):
    """
    bridge-vlan-aware -
    Extract bridge type from the bridge
    """

    def __init__(self):
        super().__init__("bridge-vlan-aware",
                         ["bridge", "domain", "br_default", "type"])

    def _translate(self, stanza):
        if self._value == "vlan-aware":
            self._value = "yes"
        else:
            self._value = None

    def reduce(self, data, stanza, ifname, kind):
        if kind == "bridge" and ifname != self._sequence[2]:
            self._sequence[2] = ifname
        return super().reduce(data, stanza, ifname, kind)


class AttributeBridgeStp(AttributeYesNoState):
    """
    bridge-stp -
    Extract bridge vids from the bridge port object
    """

    def __init__(self):
        super().__init__("bridge-stp",
                         ["bridge", "domain", "br_default", "stp", "state"],
                         "yes")

    def reduce(self, data, stanza, ifname, kind):
        if kind == "bridge" and ifname != self._sequence[2]:
            self._sequence[2] = ifname
        return super().reduce(data, stanza, ifname, kind)


class AttributeStpIgnoreDefault(AttributeYesNoOnOffIgnoreDefault):
    """
    offon attribute translated to yes/no that ignores default
    """

    def reduce(self, data, stanza, ifname, kind):
        if kind != "bridge" \
                and stanza \
                and stanza.bridge_name \
                and stanza.bridge_name != self._sequence[2]:
            self._sequence[2] = stanza.bridge_name
        return super().reduce(data, stanza, ifname, kind)


class AttributeIgnoreDefault(Attribute):
    """
    Ignore if attribute value matches default value
    """

    def __init__(self, name, sequence, default):
        super().__init__(name, sequence)
        self.default = default

    def _translate(self, _):
        if self._value == self.default:
            self._value = None


class AttributeIgnoreNone(Attribute):
    """
    Ignore if attribute value if it's "none"
    """

    def _translate(self, _):
        if self._value == "none":
            self._value = None


class AttributeMac(Attribute):
    @staticmethod
    def _mac_int_to_str(mac_int):
        return ":".join(
            ("{:04x}".format(mac_int))[i:i + 2] for i in range(0, 4, 2)
        )


class AttributeAddressVirtual(AttributeMac):
    def _translate(self, stanza):
        om = stanza.object_model
        state = self._value.get("state")
        id_ = py_.get(om, "system.global.anycast-id")
        mac = py_.get(om, "system.global.anycast-mac")

        if "up" in state:
            # One of these must exist or config_v1 verify config wouldn't pass
            override_id = self._value.get("mac-id")
            override_mac = self._value.get("mac-address")
            if override_id != "none":
                mac = f"00:00:5e:00:01:{override_id:02x}"
            elif override_mac != "auto":
                mac = override_mac
            elif id_ != "none":
                # Use the anycast-mac
                mac = "44:38:39:ff:{}".format(
                    self._mac_int_to_str(id_)
                )

            ip_list = " ".join(self._value.get("address").keys())
            self._value = "{} {}".format(mac, ip_list)
        else:
            self._value = None


class AttributeBridgeHwAddress(AttributeMac):
    def __init__(self):
        super().__init__('hwaddress', ['system-mac'])


class AttributeVlanRawDevice(Attribute):
    def __init__(self):
        super().__init__('vlan-raw-device', ['base-interface'])


class AttributeL3vniSviAddressVirtual(AttributeMac):
    def __init__(self):
        super().__init__('address-virtual', ['global_anycast'])

    def _translate(self, stanza):
        om = stanza.object_model

        # If an mlag backup is set, mlag must be enabled
        mlag_enabled = py_.get(om, 'mlag.backup')

        if mlag_enabled:
            id_ = self._value.get("anycast-id")
            mac = self._value.get("anycast-mac")
            if id_ != "none":
                mac = "44:38:39:ff:{}".format(
                    self._mac_int_to_str(id_)
                )
            self._value = mac
        else:
            self._value = None


class AttributeClagdBackIp(Attribute):
    # clagd-backup-ip 10.0.11.9 vrf mgmt
    def _translate(self, _):
        # For now, there will always be just one backup.
        ip, backup = list(self._value.items())[0]
        vrf = backup["vrf"]
        if vrf == "default":
            self._value = "{}".format(ip)
        else:
            self._value = "{} vrf {}".format(ip, vrf)


class AttributeClagdSysMac(AttributeMac):
    def __init__(self):
        super().__init__("clagd-sys-mac", ['mlag'])

    def _translate(self, stanza):
        """
        Checks if the user specified an MLAG MAC to override the globals, and
        if not uses the global anycast-id or anycast-mac.
        """
        self._value = self._value.get('mac-address')
        if self._value == "auto":
            om = stanza.object_model
            id_ = py_.get(om, 'system.global.anycast-id')
            mac = py_.get(om, 'system.global.anycast-mac')
            if id_ != "none":
                self._value = "44:38:39:ff:{}".format(
                    self._mac_int_to_str(id_)
                )
            else:
                self._value = mac


class AttributeClagdArgs(Attribute):
    def _translate(self, _):
        clagd_args = ""
        init_delay = self._value.get("init-delay")
        debug = self._value.get('debug')
        extra_args = self._value.get('clagd_extra_args')
        if init_delay:
            clagd_args += '--initDelay {} '.format(init_delay)
        if debug == 'on':
            clagd_args += '--debug 0x4 '
        if extra_args:
            clagd_args += extra_args

        self._value = clagd_args.strip() if clagd_args else None


class AttributeClagId(Attribute):
    def __init__(self):
        super().__init__("clag-id", ["bond", "mlag", "id"])

    def _translate(self, stanza):
        ifname = stanza.ifname

        if self._value == 'auto':
            m = re.match(r'^\S+\D+(\d+$)', ifname)
            if m and int(m.group(1)) >= 1 and int(m.group(1)) <= 65535:
                self._value = int(m.group(1))
            else:
                clag_id = int(sha256(ifname.encode()).hexdigest(), 16)

                # Mod by max clag-id value
                self._value = clag_id % 65535 + 1


class AttributeVxlanUnicast(Attribute):
    """
    vxlan-remoteip: if value is not a multicast address
    """
    def _translate(self, _):
        self._value = list(self._value.keys())
        if len(self._value) == 1:
            if self._value[0] == 'evpn':
                self._value = None


class AttributeVxlanLocalAddress(Attribute):
    """
    vxlan-local-tunnelip: if value is not a multicast address and not auto.
    """
    def _translate(self, _):
        try:
            ip_addrs = list(self._value.keys())
            # Find an address we can use.
            for ip_addr in ip_addrs:
                if ip_addr.startswith("127."):
                    continue
                if ip_addr == "::1/128":
                    continue
                self._value, _, _ = ip_addr.partition("/")
                break
        except AttributeError:
            return


class Stanza:
    """
    The Stanza class aligns with the ENI format (header followed by
    attributes). It contains several "${Addon}Attributes"
    data-structures (one per ifupdown2's addon). Each of those data-structures
    is filled with "Attribute" object tasked to extract (using the reduce
    function) the appropriate value for a specific ifupdown2 attribute. This
    design allow anybody to quickly add support for new attributes or easily
    make updates if the object model changes.


    Simplified structure of a 'Stanza':

                                         +------+
                          +--------------+Stanza+-----------------+
                          |              +---+--+                 |
                          |                  |                    |
                +---------+--------+ +-------+------+     +-------+------+
    Addons:     | AddressAttributes| |BondAttributes| ... |ClagAttributes|
                +------+-----------+ +-----+--------+     +------+-------+
                       +                   |                     +
                      ...                  |                    ...
                                           |
                                 +---------+-------+
    Attributes:                  |AttributeBondMode|...
                                 +-----------------+

    """

    AddressAttributes = (
        AttributeAddresses("address", ["ip", "address"]),

        AttributeGateway("gateway", ["ip", "gateway"]),
        AttributeIgnoreDefault("mtu", ["link", "mtu"], default=9216),

        # TODO CUE-3179
        # Attribute("alias", ["alias"]),

        AttributeIgnoreDefault("ip-forward", ["ip", "ipv4", "forward"], "on"),
        AttributeIgnoreDefault("ip6-forward", ["ip", "ipv6", "forward"], "on"),
        AttributeIPv6Disable("post-up", ["ip", "ipv6", "enable"]),

        AttributeIgnoreNone(
            "clagd-vxlan-anycast-ip",
            ["vxlan", "vxlan", "mlag", "shared-address"]
        ),

        AttributeNotImplemented("netmask"),
        AttributeNotImplemented("broadcast"),
        AttributeNotImplemented("preferred-lifetime"),
        AttributeNotImplemented("pointopoint"),
        AttributeNotImplemented("hwaddress"),
        AttributeNotImplemented("address-purge"),
        AttributeNotImplemented("ip6-forward"),
        AttributeNotImplemented("mpls-enable"),
        AttributeNotImplemented("ipv6-addrgen"),
    )

    AddressVirtualAttributes = (
        AttributeAddressVirtual("address-virtual", ["ip", "vrr"]),
        AttributeNotImplemented("address-virtual-ipv6-addrgen"),
        AttributeNotImplemented("vrrp")
    )

    BondAttributes = (
        AttributeKeysToString("bond-slaves", ["bond", "member"]),

        AttributeBondMode("bond-mode", ["bond", "mode"]),

        AttributeIgnoreDefault("bond-updelay",
                               ["bond", "up-delay"], default=0),
        AttributeIgnoreDefault("bond-downdelay",
                               ["bond", "down-delay"], default=0),

        AttributeYesNoOnOff(
            "bond-lacp-bypass-allow",
            ["bond", "lacp-bypass"]
        ),
        AttributeIgnoreDefault("bond-lacp-rate",
                               ["bond", "lacp-rate"], default="fast"),
        AttributeClagId(),

        AttributeNotImplemented("bond-use-carrier"),
        AttributeNotImplemented("bond-num-grat-arp"),
        AttributeNotImplemented("bond-num-unsol-na"),
        AttributeNotImplemented("bond-xmit-hash-policy"),
        AttributeNotImplemented("bond-miimon"),
        AttributeNotImplemented("bond-min-links"),
        AttributeNotImplemented("bond-ad-sys-priority"),
        AttributeNotImplemented("bond-ad-actor-sys-prio"),
        AttributeNotImplemented("bond-ad-sys-mac-addr"),
        AttributeNotImplemented("bond-ad-actor-system"),
    )

    EvpnAttributes = (
        AttributeIgnoreDefault(
            "es-sys-mac",
            ['evpn', 'multihoming', 'segment', 'mac-address'], 'auto'),
    )

    BridgeAttributes = (
        AttributeListToString("bridge-ports", ["bridge", "bridge-ports"]),
        AttributeBridgeHwAddress(),

        AttributeBridgeVlanAware(),

        # bridge-vids:
        # since we can find the information on both the brport and the bridge
        # we need to split this into two classes. Each object will set the
        # sequence to reduce in the object model to find the data.
        AttributeBridgeVids(),

        # bridge-pvid:
        AttributeBridgePVid(),  # bridge
        AttributeBridgeAllowUntagged(),  # brport

        Attribute("bridge-vlan-protocol", ["vlan-protocol"]),

        # Commented until we add support for IGMP
        # Attribute("bridge-igmp-version",
        #     ["ip-multicast", "igmp", "version"]),

        # bridge-access:
        AttributeBridgeAccess(),

        AttributeBridgeStp(),

        AttributeYesNoOnOffIgnoreDefault(
            "bridge-mcsnoop", [
                "bridge", "domain", "br_default", "multicast", "snooping",
                "enable"
            ], "yes"),
        AttributeYesNoOnOffIgnoreDefault(
            "bridge-mcquerier", [
                "bridge", "domain", "br_default", "multicast", "snooping",
                "querier", "enable"
            ], "no"),

        # Commented until we add support for stats capture.
        # AttributeYesNoBoolean(
        #     "bridge-vlan-stats",
        #     ["capture-vlan-statistics"]
        # ),

        # Commented until we add support for IGMP
        # AttributeYesNoOnOffIgnoreDefault(
        #     "bridge-portmcfl",
        #     ["bridge", "igmp-fast-leave"], "no"
        # ),

        AttributeIgnoreDefault("bridge-arp-nd-suppress",
                               ["arp-nd-suppress"], "on"),

        # bridge-learning
        AttributeIgnoreDefault(
            "bridge-learning",
            ["bridge", "learning"], "on"
        ),

        # bridge-learning for vxlan port
        AttributeIgnoreDefault("bridge-learning", ["mac-learning"], "on"),

        # Commented until we add support for stats capture.
        # AttributeOnOffBoolean(
        #     "bridge-mcstats",
        #     ["capture-multicast-statistics"]
        # ),

        # Commented until we add support for IGMP
        # AttributeIntegerOnOffIgnoreDefault(
        #     "bridge-portmcrouter",
        #     ["bridge", "igmp-router-port"], "0"
        # ),

        AttributeNotImplemented("bridge-bridgeprio"),
        AttributeNotImplemented("bridge-ageing"),
        AttributeNotImplemented("bridge-fd"),
        AttributeNotImplemented("bridge-gcint"),
        AttributeNotImplemented("bridge-hello"),
        AttributeNotImplemented("bridge-maxage"),
        AttributeNotImplemented("bridge-pathcosts"),
        AttributeNotImplemented("bridge-portprios"),
        AttributeNotImplemented("bridge-mclmc"),
        AttributeNotImplemented("bridge-mcrouter"),
        AttributeNotImplemented("bridge-mcsqc"),
        AttributeNotImplemented("bridge-mcqifaddr"),
        AttributeNotImplemented("bridge-hashel"),
        AttributeNotImplemented("bridge-hashmax"),
        AttributeNotImplemented("bridge-mclmi"),
        AttributeNotImplemented("bridge-mcmi"),
        AttributeNotImplemented("bridge-mcqpi"),
        AttributeNotImplemented("bridge-mcqi"),
        AttributeNotImplemented("bridge-mcqri"),
        AttributeNotImplemented("bridge-mcsqi"),
        AttributeNotImplemented("bridge-mcqv4src"),
        AttributeNotImplemented("bridge-waitport"),
        AttributeNotImplemented("bridge-maxwait"),
        AttributeNotImplemented("bridge-port-vids"),
        AttributeNotImplemented("bridge-port-pvids"),
        AttributeNotImplemented("bridge-mld-version"),
        AttributeNotImplemented("bridge-l2protocol-tunnel"),
        AttributeNotImplemented("bridge-ports-condone-regex"),
    )

    BridgeVlanAttributes = (
        Attribute("bridge-igmp-querier-src", ["igmp-querier-src"]),
    )

    DHCPAttributes = (
    )

    EthtoolAttributes = (
        AttributeFec("link-fec", ["link", "fec"]),

        AttributeLinkSpeed("link-speed", ["link", "speed"]),

        AttributeIgnoreDefault(
            "link-duplex",
            ["link", "duplex"],
            default="full"
        ),
        AttributeIgnoreDefault(
            "link-autoneg",
            ["link", "auto-negotiate"],
            default="on"
        ),
    )

    LinkAttributes = (
        AttributeLinkDown("link-down", ["link", "state"]),
        AttributeNotImplemented("link-type"),
    )

    MstpctlAttributes = (
        AttributeStpIgnoreDefault(
            "mstpctl-portbpdufilter",
            ["bridge", "domain", "br_default", "stp", "bpdu-filter"], "no"
        ),
        AttributeStpIgnoreDefault(
            "mstpctl-bpduguard",
            ["bridge", "domain", "br_default", "stp", "bpdu-guard"], "no"
        ),
        AttributeStpIgnoreDefault(
            "mstpctl-portadminedge",
            ["bridge", "domain", "br_default", "stp", "admin-edge"], "no"
        ),
        AttributeStpIgnoreDefault(
            "mstpctl-portautoedge",
            ["bridge", "domain", "br_default", "stp", "auto-edge"], "yes"
        ),
        AttributeStpIgnoreDefault(
            "mstpctl-portnetwork",
            ["bridge", "domain", "br_default", "stp", "network"], "no"
        ),
        AttributeStpIgnoreDefault(
            "mstpctl-portrestrrole",
            ["bridge", "domain", "br_default", "stp", "restrrole"], "no"
        ),

        AttributeNotImplemented("mstpctl-ports"),
        AttributeNotImplemented("mstpctl-stp"),
        AttributeNotImplemented("mstpctl-treeprio"),
        AttributeNotImplemented("mstpctl-ageing"),
        AttributeNotImplemented("mstpctl-maxage"),
        AttributeNotImplemented("mstpctl-fdelay"),
        AttributeNotImplemented("mstpctl-maxhops"),
        AttributeNotImplemented("mstpctl-txholdcount"),
        AttributeNotImplemented("mstpctl-forcevers"),
        AttributeNotImplemented("mstpctl-portpathcost"),
        AttributeNotImplemented("mstpctl-portp2p"),
        AttributeNotImplemented("mstpctl-portrestrtcn"),
        AttributeNotImplemented("mstpctl-treeportprio"),
        AttributeNotImplemented("mstpctl-hello"),
        AttributeNotImplemented("mstpctl-treeportcost"),
    )

    UserCmdsAttributes = (
        Attribute("pre-up", ["hooks", "pre-up"]),
        Attribute("up", ["hooks", "up"]),
        Attribute("post-up", ["hooks", "post-up"]),
        Attribute("pre-down", ["hooks", "pre-down"]),
        Attribute("down", ["hooks", "down"]),
        Attribute("post-down", ["hooks", "post-down"]),
    )

    VrfAttributes = (
        AttributeIgnoreDefault("vrf", ["ip", "vrf"], "default"),
        Attribute("vrf-table", ["table"])
    )

    # Only for loopback
    VxlanLoopbackAttributes = (
        AttributeVxlanLocalAddress("vxlan-local-tunnelip",
                                   ["vxlan", "vxlan", "source", "address"]),
    )

    @property
    def addons(self):
        """
        This is an attempt to separate addons according to the type of Stanza
        we're creating.  I.e. now a Vxlan Stanza can add a VxlanAttributes
        addon to the tuple of addons, and only Vxlan Stanzas will try to render
        those attributes, instead of the previous model where all Stanzas tried
        to render all attributes.
        """
        cls = type(self)
        # return type(self).addons
        return (
            cls.AddressAttributes,
            cls.AddressVirtualAttributes,
            cls.EvpnAttributes,
            cls.BondAttributes,
            cls.BridgeAttributes,
            cls.DHCPAttributes,
            cls.LinkAttributes,
            cls.MstpctlAttributes,
            cls.UserCmdsAttributes,
            cls.VrfAttributes,
            cls.VxlanLoopbackAttributes
        )

    def __init__(self, object_model, ifname, kind, data, snippets):
        """Constructs a stanza object.

        Arguments:
            object_model - The full CUE config.
            ifname       - The interface name.
            kind         - The type of interface.
            data         - A dict of CUE config.

                           Whereas 'object_model' was the root
                           of the CUE config, this is CUE config under a
                           particular object.
                           I.e. if the object in question was the interface
                           swp1, then 'data' would be the CUE config under that
                           interface, which is the config found at
                           'interface.swp1' if accessing from the root.

            snippets     - These are strings rendered directly into the stanza.

                           Snippets can be found at 'platform.config.snippets'
                           within the CUE OM.
        """
        self.object_model = object_model
        self.ifname = ifname
        self.kind = kind
        self.data = data
        self.base_interface = ""

        if not hasattr(self, 'bridge_name'):
            # here we should only get one bridge object but we are getting a
            # dict of what could have multiple bridges (which doesn't make
            # sense?) we are extracting the bridge data from the first bridge
            # in that data structure.
            bridge_domain_list = list(
                data.get("bridge", {}).get("domain", {}).keys()
            )

            if bridge_domain_list:
                self.bridge_name = bridge_domain_list[0]
            else:
                self.bridge_name = None

        try:
            self.base_interface = data["base-interface"]
        except KeyError:
            pass

        self.attributes = []
        self.snippet = snippets.get(ifname, '')

        addons = self.addons
        if kind == 'swp':
            addons = (*addons, self.EthtoolAttributes)

        for addon in addons:
            for attribute in addon:
                self.attributes.extend(
                    attribute.reduce(
                        data,
                        self,
                        ifname,
                        kind
                    )
                )

        self.auto = "auto {}".format(self.ifname)
        self.iface = []

        dhcp = "dhcp" in self.data.get("ip", {}).get("address", {})
        dhcp6 = "dhcp6" in self.data.get("ip", {}).get("address", {})

        if dhcp or dhcp6:
            #
            # inet dhcp
            #
            if dhcp:
                self.iface.append("iface {} inet dhcp".format(self.ifname))

            #
            # inet6 dhcp6
            #
            if dhcp6:
                self.iface.append("iface {} inet6 dhcp6".format(self.ifname))

        elif kind == "loopback":
            self.iface.append("iface {} inet loopback".format(self.ifname))

        elif not dhcp and not dhcp6:
            self.iface = ["iface {}".format(self.ifname)]

    def get_header(self):
        return "\n".join([self.auto, "\n".join(self.iface)])

    def get_attributes(self):
        return self.attributes


class Vxlan(Stanza):

    @staticmethod
    def __reduce_svd_data_bridge_vlan_vni_map(vxlan_data):
        svd_vlan_vni_map = []

        for data in vxlan_data.get("single-vxlan-device-data", []):
            svd_data = data["single-vxlan-device"]
            svd_vlan_vni_map.append(
                "{}={}".format(svd_data["vlan_id"], svd_data["vxlan_id"])
            )

        return " ".join(svd_vlan_vni_map) if svd_vlan_vni_map else None

    @staticmethod
    def __reduce_svd_data_mcastgrp_map(vxlan_data):
        svd_mcastgrp_map = []

        for data in vxlan_data.get("single-vxlan-device-data", []):

            vni = data.get("single-vxlan-device", {}).get("vxlan_id")

            mcastgrp = data.get("flooding", {}).get("multicast-group")

            if not mcastgrp:
                continue

            svd_mcastgrp_map.append("{}={}".format(vni, mcastgrp))

            del data["flooding"]["multicast-group"]

        return " ".join(svd_mcastgrp_map) if svd_mcastgrp_map else None

    VxlanAttributes = (
        # This attribute is handled in the Vxlan(Stanza) class
        AttributeNotImplemented("vxlan-id"),

        # vxlan-mcastgrp & vxlan-remote-ip
        AttributeVxlanUnicast("vxlan-remoteip",
                              ["flooding", "head-end-replication"]),

        Attribute("vxlan-mcastgrp", ["flooding", "multicast-group"]),


        Attribute(
            "vxlan-mcastgrp-map",
            __reduce_svd_data_mcastgrp_map.__func__
        ),

        AttributeIgnoreDefault("vxlan-port", ["port"], 4789),

        # single vxlan device
        Attribute(
            "bridge-vlan-vni-map",
            __reduce_svd_data_bridge_vlan_vni_map.__func__
        ),

        AttributeNotImplemented("vxlan-svcnodeip"),
        AttributeNotImplemented("vxlan-learning"),
        AttributeNotImplemented("vxlan-ageing"),
        AttributeNotImplemented("vxlan-purge-remotes"),
        AttributeNotImplemented("vxlan-physdev"),
        AttributeNotImplemented("vxlan-ttl"),
    )

    @property
    def addons(self):
        """
        Overrides Stanza's addons property and adds VxlanAttributes.
        """
        return (*super().addons, type(self).VxlanAttributes)

    def __init__(self, vxlan_id, *args, **kwargs):
        super(Vxlan, self).__init__(*args, **kwargs)

        if vxlan_id:
            self.attributes.append("vxlan-id {}".format(vxlan_id))


class SingleVxlanDevice(Vxlan):
    def __init__(self, object_model, vxlan_data, br_name,
                 svd_name_hash, snippets):
        if not vxlan_data:
            raise Exception("SingleVxlanDevice: vxlan_data is empty")

        self.bridge_name = br_name
        hash_key = hashkey(br_name, 100)
        if hash_key in svd_name_hash.keys():
            for x in range(len(br_name) - 1):
                hash_key = hashkey(br_name[x:], 100)
                if hash_key not in svd_name_hash.keys():
                    break

        svd_name_hash[hash_key] = br_name
        ifname = "vxlan" + str(hash_key)

        super(SingleVxlanDevice, self).__init__(
            None,
            object_model,
            ifname,
            "vxlan",
            {
                "single-vxlan-device-data": vxlan_data
            },
            snippets
        )

        # Special handling for vxlan attributes -
        # since all the vxlan data are in separate objects and not in unique
        # svd object, we have to do some funky stuff to make it work with the
        # existing code. Fetch data from the vxlan objects:
        # - access ports
        # - mac-learning
        # - mtu
        # remove:
        # - access ports
        # - mac-learning
        # - multicast-group is already removed by the reduce func
        mtu = None
        vxlan_vids = {}
        mac_learning = None
        for data in vxlan_data:
            svd = data["single-vxlan-device"]
            vxlan_vids[str(svd.get("vlan_id"))] = {}

            try:
                del data["bridge"]["domain"][br_name]["access"]
            except Exception:
                pass

            if not mac_learning:
                mac_learning = data.get("mac-learning")

            try:
                del data["mac-learning"]
            except Exception:
                pass

            if not mtu:
                mtu = data.get("link", {}).get("mtu")

            try:
                del data["link"]["mtu"]
            except Exception:
                pass

        dummy_vxlan_obj = {
            "bridge": {
                "domain": {
                    # self.bridge_name: {
                    br_name: {
                        "vlan": vxlan_vids
                    }
                }
            },
        }

        if mac_learning:
            dummy_vxlan_obj["mac-learning"] = mac_learning

        if mtu:
            dummy_vxlan_obj["link"] = {"mtu": mtu}

        # add dummy object containing all the vids
        vxlan_data.insert(0, dummy_vxlan_obj)

        for data in vxlan_data:
            for addon in self.addons:
                for attribute in addon:
                    self.attributes.extend(
                        attribute.reduce(
                            data,
                            self,
                            ifname,
                            "vxlan"
                        )
                    )


class Svi(Stanza):
    SviAttributes = (
        # Handled in the Svi class:
        #   AttributeNotImplemented("vlan-id"),
        AttributeVlanRawDevice(),
        AttributeL3vniSviAddressVirtual(),
        AttributeNotImplemented("vlan-protocol"),
    )

    @property
    def addons(self):
        """
        Overrides Stanza's addons property and adds SviAttributes.
        """
        return (*super().addons, type(self).SviAttributes)

    def __init__(self, vlan_id, *args, **kwargs):
        super(Svi, self).__init__(*args, **kwargs)
        self.attributes.append("vlan-id {}".format(vlan_id))


class BridgeVlan(Stanza):
    @property
    def addons(self):
        """
        Overrides Stanza's addons property.
        """
        return (type(self).BridgeVlanAttributes,)

    def __init__(self, object_model, ifname, kind, data, snippets):
        super().__init__(object_model, ifname, kind, data, snippets)
        self.iface = [f"vlan {ifname}"]


class PeerlinkVlan(Stanza):
    ClagAttributes = (
        Attribute("clagd-peer-ip", ["mlag", "peer-ip"]),
        AttributeIgnoreDefault("clagd-priority", ["mlag", "priority"], 32768),

        AttributeClagdBackIp("clagd-backup-ip", ["mlag", "backup"]),
        AttributeClagdSysMac(),
        AttributeClagdArgs("clagd-args", ["mlag"]),
        AttributeNotImplemented("clagd-enable"),
    )

    @property
    def addons(self):
        """
        Overrides Stanza's addons property and adds ClagAttributes.
        """
        return (*super().addons, type(self).ClagAttributes)

    def __init__(self, object_model, data, snippets):
        super(PeerlinkVlan, self).__init__(object_model, 'peerlink.4094',
                                           "vlan", data, snippets)


IFUPDOWN2_CONF_PATH = "/etc/network/ifupdown2/ifupdown2.conf"


def merge_vxlan_data(br_name, vlan_id, vtep_data, vxlan_data):
    merged_vxlan_data = dict(vtep_data)
    merged_vxlan_data.update(vxlan_data)
    merged_vxlan_data["bridge"] = {
        "domain": {
            br_name: {
                "access": int(vlan_id)
            }
        }
    }

    if vxlan_data["mac-learning"] == "auto":
        merged_vxlan_data["mac-learning"] = vtep_data["mac-learning"]

    if vxlan_data["flooding"]["enable"] == "auto":
        merged_vxlan_data["flooding"] = vtep_data["flooding"]

    if merged_vxlan_data["flooding"]["enable"] == "off":
        merged_vxlan_data.pop("flooding")

    if vtep_data["mtu"]:
        merged_vxlan_data["link"] = {
            "mtu": vtep_data["mtu"]
        }

    return merged_vxlan_data


def hashkey(value, size):
    key = 0
    for c in value:
        key += (ord(c))
    return key % size  # noqa: S001


def get_max_hash_size(min_val, max_val):
    return (max_val - min_val) + 1


def get_evpn_global_es_sys_mac(data, evpn_data):
    """
    This API inherits global es mac-address to es enabled
    bond interface.
    Es enabled bond implies:
    Mutihoming.segment.enable is 'on', implies one of the required
    field either local-id or es identifier is configured on the bond.
    """
    if py_.get(evpn_data, 'multihoming.enable') == 'on':
        if py_.get(data, 'evpn.multihoming.segment.enable') == 'on' \
                and py_.get(data, 'evpn.multihoming.segment.mac-address') \
                == 'auto':
            global_mac = py_.get(evpn_data,
                                 '.multihoming.segment.mac-address')
            data['evpn']['multihoming']['segment']['mac-address'] = global_mac
    elif 'evpn' in data and 'multihoming' in data['evpn']:
        del data['evpn']['multihoming']


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("ifupdown2_v1", handle_verify_config)
    ctx.events.ready_apply.register("ifupdown2_v1", handle_ready_apply)
    ctx.events.check_health.register("ifupdown2_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.
    """
    # ports = evt.config_v1.getSwps()
    #
    # TODO Ask env_v1 unit for a list of physical ports.
    # Verify each configured port actually exists on this hardware.
    #
    # TODO Verify peerlink is configured when we have mlags


def _get_hardware_sys_mac(evt):  # pragma: no cover
    return py_.get(evt.platform_v1.getHardware(), 'system-mac')


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Generates a list of 'Stanza' objects and then renders them to ENI.

    Broken down into the following sections based on the type of ENI stanza
    being created and if it requires special handling:
        1. Vrfs
        2. Interfaces
        3. Vxlan
        4. Vrf-vni
        5. Peerlinks
        6. Bridges
    """
    caps = evt.platform_v1.getIfupdown2Capabilities()
    single_vxlan_device_enabled = caps['single-vxlan-device'] == 'on'
    single_vxlan_data = []
    svd_name_hash = {}

    # Get a copy of the object model
    object_model = evt.config_v1.getRoot()
    om_interfaces = evt.config_v1.getInterfaces()
    snippets = evt.config_v1.getSnippets().get('ifupdown2_eni', {})
    bridge_data = evt.config_v1.getBridge()
    mlag_data = evt.config_v1.getMlag()
    evpn_data = evt.config_v1.getEvpn()
    global_data = evt.config_v1.getGlobal()
    sys_mac = py_.get(global_data, 'system-mac')

    # Global configured system-mac is auto we use the system-mac read from
    # /run/system_mac, if it exists.
    if sys_mac == 'auto':
        sys_mac = _get_hardware_sys_mac(evt)

    # Prepare 'clagd_extra_args' for AttributeClagdArgs.
    # This gets appended to the value of ifupdown2's "clagd-args"
    # attribute.
    mlag_data["clagd_extra_args"] = snippets.get('clagd_extra_args', '')

    # List of all the stanza extracted from the object model
    stanzas = []

    ###########################################
    # special handling for loopback interfaces
    # Today in the OM the interface: loopback has a list of dictionary
    # since we only supports one loopback we can simple get the first element
    # and hardcode it's ifname as "lo". By design the "Stanza" object doesn't
    # have access nor visibility on the entire object model. Since we are
    # interested in some attribute in the top level "mlag" object (like
    # "anycast-address"), we add this object under loopback: mlag: mlag (to
    # avoid collision with any future attributes).
    # loopback: [
    #    {
    #        mlag: {
    #            mlag: {
    #               shared-address: ipv4
    #            }
    #        }
    #    }
    # ]
    vtep_data = evt.config_v1.getNveVxlan()

    loopback_data = om_interfaces.get("lo", {})
    loopback_data.update({"mlag": {"mlag": evt.config_v1.getMlag()}})
    if vtep_data["enable"] == "on":
        vtep_copy = copy.deepcopy(vtep_data)
        if "auto" in vtep_data["source"]["address"]:
            # If auto, then use the loopback's address.  We know
            # we have at least one useful one because of verification
            vtep_copy["source"]["address"] = loopback_data["ip"]["address"]
        loopback_data.update({"vxlan": {"vxlan": vtep_copy}})
        # once the vtep data is merged with the loopback data object, it is
        # important to remove the "address" object from the vtep data. The vtep
        # data object is also merged with each vxlan data object later on
        del vtep_data["source"]["address"]

    stanzas.append(
        Stanza(
            object_model,
            "lo",
            "loopback",
            loopback_data,
            snippets
        )
    )

    ##########################################################################
    # Vrf #####################################################################
    vrf_data = evt.config_v1.getVrfs().items()
    vrf_vni = {}

    for ifname, data in vrf_data:
        # For now, skip past the default VRF since we don't need to explicitly
        # mention it in eni for it to exist.  However, someday, we may want to
        # configure it.  I'm not sure how that would be rendered in eni.
        if ifname == "default":
            continue

        # Treat "loopback.ip" like a normal "ip" so that we can pick up the
        # normal ip handling code.
        data["ip"] = data["loopback"]["ip"]

        stanzas.append(Stanza(object_model, ifname, "vrf", data, snippets))

        if evpn_data["enable"] == "on" and data["evpn"]["enable"] == "on":
            vnis = list(data['evpn'].get("vni", {}).keys())
            if vnis:
                vrf_vni[ifname] = vnis[0]

    ###########################################################################
    # Interface
    for ifname, data in om_interfaces.items():
        link_kind = data["type"]
        if link_kind in ["eth", "swp", "bond", "sub", "peerlink"]:
            breakout = py_.get(data, 'link.breakout')
            if breakout and breakout not in ['1x', 'loopback']:
                continue

            if ifname == 'peerlink':
                br_name = list(bridge_data.get("domain", {}).keys())[0]
                data["bridge"] = {"domain": {br_name: {}}}

            # For multihomed es bond derive es-system-mac
            # from global evpn data tree.
            if link_kind == "bond":
                get_evpn_global_es_sys_mac(data, evpn_data)

            # Peerlink and peerlink.4094 special handling
            if ifname == 'peerlink.4094':
                data = py_.merge({}, data, {
                    'mlag': mlag_data,
                    'global': global_data
                })
                stanzas.append(PeerlinkVlan(object_model, data, snippets))
            else:
                stanzas.append(
                    Stanza(object_model, ifname, link_kind, data, snippets)
                )

        elif link_kind == "svi":
            vlan_id = data["vlan"]
            if data["base-interface"] == 'none':
                data["base-interface"] = \
                    list(bridge_data.get("domain", {}).keys())[0]

            data["system-mac"] = sys_mac
            stanzas.append(
                Svi(vlan_id, object_model, ifname, link_kind, data, snippets)
            )

    ###########################################################################
    # Create BridgeVlans.  The only thing in these stanzas currently is the
    # querier source-ip, so we can drive their create from that.
    for br_name, br_data in bridge_data.get("domain", {}).items():
        vlan_data = br_data.get("vlan")
        for vlan_id, vlan in vlan_data.items():
            querier_src = py_.get(vlan, "multicast.snooping.querier.source-ip")
            if querier_src != "0.0.0.0":
                data = {
                    "igmp-querier-src": querier_src
                }
                stanzas.append(
                    BridgeVlan(object_model, f"{br_name}.{vlan_id}", "vlan",
                               data, snippets)
                )

    ###########################################################################
    # Vxlan handling ##########################################################

    if bridge_data and vtep_data["enable"] == "on":

        for br_name, br_data in bridge_data.get("domain", {}).items():
            vlan_data = br_data.get("vlan")

            for vlan_id, vlan in vlan_data.items():
                vni_data = vlan.get("vni")

                if vni_data:
                    for vxlan_id, vxlan_data in vni_data.items():
                        # Merge the VTEP data with each vxlan data
                        merged_vxlan_data = merge_vxlan_data(
                            br_name,
                            vlan_id,
                            vtep_data,
                            vxlan_data
                        )

                        if single_vxlan_device_enabled:
                            merged_vxlan_data["single-vxlan-device"] = {
                                "vlan_id": vlan_id,
                                "vxlan_id": vxlan_id,
                            }
                            single_vxlan_data.append(merged_vxlan_data)
                        else:
                            stanzas.append(
                                Vxlan(
                                    vxlan_id,
                                    object_model,
                                    "vni{}".format(vxlan_id),
                                    "vxlan",
                                    merged_vxlan_data,
                                    snippets
                                )
                            )
            # Processing single vxlan device
            if single_vxlan_device_enabled and single_vxlan_data != []:
                stanzas.append(
                    SingleVxlanDevice(
                        object_model,
                        single_vxlan_data,
                        br_name,
                        svd_name_hash,
                        snippets
                    )
                )
                single_vxlan_data = []

    ###########################################################################
    # Vrf-vni mapping #########################################################
    if vrf_vni:
        vni_hash = {}
        br_name = "br_l3vni"
        bridge_data["domain"][br_name] = {"type": "vlan-aware"}

        vlan_base = 1
        hash_size = get_max_hash_size(1, 4096)

        global_anycast = {
            'anycast-id': py_.get(global_data, 'anycast-id'),
            'anycast-mac': py_.get(global_data, 'anycast-mac')
        }
        for ifname, vni in vrf_vni.items():
            hash_key = 0
            vni_id = str(vni)
            vni_data = dict(vtep_data)
            if len(vni_hash) >= hash_size:
                logger.exception("cannot assign a VLAN id for L3 VNI")
                break

            hash_key = vlan_base + hashkey(ifname, hash_size)
            if hash_key in vni_hash.keys():
                for x in range(len(ifname) - 1):
                    hash_key = vlan_base + hashkey(ifname[x:], hash_size)
                    if hash_key not in vni_hash.keys():
                        break

            vni_hash[hash_key] = vni_id
            vlan_id = hash_key

            vni_data["bridge"] = \
                {"domain": {br_name: {"access": int(vlan_id)}}}
            vni_data["global"] = global_data
            vni_data["link"] = {"mtu": vni_data["mtu"]}
            if vni_data["flooding"]["enable"] == "off":
                vni_data.pop("flooding")

            if single_vxlan_device_enabled:
                vni_data["single-vxlan-device"] = {
                    "vlan_id": vlan_id,
                    "vxlan_id": vni_id,
                }
                single_vxlan_data.append(vni_data)
            else:
                stanzas.append(
                    Vxlan(
                        vni_id, object_model, "vni{}".format(vni_id),
                        "vxlan", vni_data, snippets
                    )
                )

            vlan_data = {"base-interface": br_name,
                         "ip": {"vrf": ifname},
                         "global_anycast": global_anycast}

            stanzas.append(
                Svi(vlan_id, object_model, "vlan{}_l3".format(vlan_id), "svi",
                    vlan_data, snippets)
            )

        #######################################
        # Processing single vxlan device
        if single_vxlan_device_enabled:
            stanzas.append(
                SingleVxlanDevice(
                    object_model,
                    single_vxlan_data,
                    br_name,
                    svd_name_hash,
                    snippets
                )
            )

    #######################################
    # Processing bridges

    # br_default is an immutable and always exists. ifupdown2 should not render
    # it into eni if it is not referenced by any user configured interface
    if not [s.ifname for s in stanzas if s.bridge_name == "br_default"
            or s.base_interface == "br_default"]:
        # It should always exist since it is a mutable
        del bridge_data["domain"]["br_default"]

    for br_name, br_data in bridge_data.get("domain").items():
        # bridge require special handling
        # since the bridge object doesn't have a member field we flag each
        # stanza as brport if they have a "bridge" field in their data-object.
        # Then we go through the list of all the stanza to generate the
        # "bridge-ports" list. This list is then saved in the bridge-data
        # object under the key "bridge-ports"
        bridge_ports = [s.ifname for s in stanzas if s.bridge_name == br_name]

        data = {
            "bridge": {
              "domain": {
                br_name: br_data,
               },
              "bridge-ports": bridge_ports
             }
        }

        if br_name in ['br_default', 'br_l3vni']:
            data['system-mac'] = sys_mac

        stanzas.append(
            Stanza(
                object_model,
                br_name,
                "bridge",
                data,
                snippets
            )
        )

    #######################################
    # Grab any snippet stanzas to be appended to eni
    snippet_stanzas = snippets.get('eni_stanzas', '')

    #######################################
    # Generate /etc/network/interfaces
    evt.render(
        templates, "eni",
        stanzas=stanzas,
        snippet_stanzas=snippet_stanzas
    )

    evt.render(templates, "run_ifreload.sh")

    # Make sure we can update our config files.
    if evt.stage_file('eni', '/etc/network/interfaces'):
        evt.schedule_run_script("run_ifreload.sh")


def handle_check_health(evt):
    """
    Handle an check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
