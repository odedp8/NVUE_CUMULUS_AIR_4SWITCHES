# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.

import logging

logger = logging.getLogger(__name__)


def portmap_get(ctx):
    """
    Return operational portmap dictionary
    """
    pconf = ctx.fileops.load_file("/etc/cumulus/ports.conf")
    portmap = {}
    if pconf:
        for line in pconf.split('\n'):
            if line.startswith('#'):
                continue
            line = line.strip()
            split_list = line.split('=', 1)
            if len(split_list) != 2:
                continue
            port = split_list[0]
            speed = split_list[1]
            portmap[port] = speed
    return portmap


def default_portmap_get(ctx):
    """
    Return platform specific portmap dictionary.
    """
    portmap = {}
    # platform string format is always "mfg,platform"
    platform_string = ctx.platform_v1.getPlatformString()
    if not platform_string:
        logger.debug("No platform string")
        return {}

    mfg = platform_string['manufacturer']
    platform = platform_string['model']

    # read platform specific default ports.conf file to create portmap
    fn = ("/usr/share/cumulus-platform/{0}/{1}/etc/cumulus/ports.conf"
          .format(mfg, platform))
    pconf = ctx.fileops.load_file(fn)
    if pconf:
        for line in pconf.split('\n'):
            if line.startswith('#'):
                continue
            line = line.strip()
            split_list = line.split('=', 1)
            if len(split_list) != 2:
                continue
            port = split_list[0]
            speed = split_list[1]
            portmap[port] = speed

    return portmap
