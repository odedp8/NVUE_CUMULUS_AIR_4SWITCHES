# Copyright (C) 2018, 2019, 2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from . import templates
from . import native
from cue.utils.format_checker import patterns
import re
import logging
import time
from pydash import py_

logger = logging.getLogger(__name__)
swp_pattern = patterns['swp']


def _get_ifaces(evt):
    """
    Wrapping the API call so we can mock this function in
    test_lifecycle.py
    """
    return evt.config_v1.getInterfaces()


# def _parse_validation_error(port_modes, error):
#     """
#     Return a meaningful error string if the error is of the form:
#     "[Line 6]:'6=4x4x40G'"
#
#     This error tells us where in the ports.conf file an invalid port
#     mode is configured.
#
#     If the error string isn't in this format, return None.
#     """
#     pattern = r"\[Line (?P<line>\d+)\]\:'(?P<port>\S+)=(?P<mode>\S+)'"
#     m = re.match(pattern, error)
#     if m:
#     port = m.group('port')
#     mode = m.group('mode')
#     ifname = 'swp' + port if 'p' not in port else 'sw' + port
#     return 'Configured mode {} not valid for {}.  Valid modes: {}'.format(
#         mode, ifname, port_modes[port])
#     return None


def _validate_ports(evt, port_modes, temp_ports_conf):
    cmd = "/usr/cumulus/bin/validate-ports -f {0}".format(temp_ports_conf)
    try:
        evt.sh.bash('-c', cmd)
    except evt.sh.ErrorReturnCode_1 as e:
        errors = str(e.stdout).replace("\\n", "\n")
        for line in errors.splitlines():
            # TODO CUE-3192: Improve error reporting
            evt.report_issue(line)
    except Exception:
        evt.report_issue("Internal Error: Unable to validate ports")


def _get_default_ports_conf_fn(evt):
    platform_string = evt.platform_v1.getPlatformString()
    if not platform_string:
        logger.debug("No platform string")
        return ""

    mfg = platform_string['manufacturer']
    platform = platform_string['model']

    # read platform specific default ports.conf file to create portmap
    fn = ("/usr/share/cumulus-platform/{0}/{1}/etc/cumulus/ports.conf"
          .format(mfg, platform))
    return fn


speed_map = {
    "100M": 100,
    "1G": 1000,
    "10G": 10000,
    "25G": 25000,
    "40G": 40000,
    "50G": 50000,
    "100G": 100000,
    "200G": 200000}

breakout_map = {
    "1x": "",
    "2x": "2x",
    "4x": "4x",
    "/4": "/4",
    "/2": "/2",
    "disabled": "disabled",
    "loopback": "loopback"}


class PortConf:

    def __init__(self, evt):

        self.allowed_speeds = {}
        self.evt = evt
        self.port_modes = {}
        self.default_ports_conf_fn = _get_default_ports_conf_fn(self.evt)
        self.default_portmap = native.default_portmap_get(self.evt)

        self.port_modes = self.evt.platform_v1.getPortModes()
        if not self.port_modes:
            return

        for port in self.port_modes:
            speed_list = []
            for mode in self.port_modes[port]:
                for key in breakout_map:
                    mode = mode.replace(key, '')
                speed = speed_map.get(mode, None)
                if (speed):
                    speed_list.append(speed)
            self.allowed_speeds[port] = sorted(list(set(speed_list)))

    def get_default_ports_conf_fn(self):
        return self.default_ports_conf_fn

    def get_port_modes(self):
        return self.port_modes

    def get_port_bandwidth(self, port, iface_speed):
        # If port is not in portmap, or cant be mapped then use
        # interface speed for port_bandwidth
        if port not in self.default_portmap.keys():
            return iface_speed  # pragma: no cover TODO CUE-3046
        mapped_speed = speed_map.get(iface_speed, None)
        if not mapped_speed:
            return iface_speed

        # Otherwise, use the iface speed to select the best
        # possible bandwidth from list of allowed speeds for the port
        if str(port) in self.allowed_speeds:
            for allowed_speed in self.allowed_speeds[str(port)]:
                if mapped_speed <= allowed_speed:
                    mapped_speed = allowed_speed
                    break

        else:
            return iface_speed

        bandwidth = str(allowed_speed)

        if len(bandwidth) <= 3:
            return bandwidth + 'M'
        else:
            return bandwidth[:-3] + "G"

    def get_platform_operational_portmap(self):
        return native.portmap_get(self.evt)

    def get_platform_default_portmap(self):
        return self.default_portmap


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("ports_v1", handle_verify_config)
    ctx.events.ready_apply.register("ports_v1", handle_ready_apply)
    ctx.events.check_health.register("ports_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """
    poer_handler = PortConf(evt)
    # Always start with a platform specific default portmap
    # portmap dictionary keys represent the port labels in ports.conf
    # portmap dictionary values represent the ports mode in ports.conf
    portmap = poer_handler.get_platform_default_portmap()
    if portmap is None:
        # logger.warning("Internal Error: Cannot create platform portmap")
        # evt.report_issue("Internal Error: Cannot create platform portmap")
        return  # pragma: no cover TODO CUE-3046

    # Populate configured iface_speeds and iface_breakouts from
    # the Object Model
    iface_speeds = {}
    iface_breakouts = {}
    ifaces = _get_ifaces(evt)
    for iface_name, iface in sorted(ifaces.items()):
        m = re.match(swp_pattern, iface_name)
        if m:
            # Use the port as the key for speeds and breakouts to make
            # it easier to index via portmap keys later
            iface_name = m.group('suffix').strip('p')
        try:
            if iface["link"]["speed"] != "auto":
                iface_speeds[iface_name] = iface["link"]["speed"]
        except Exception:
            pass
        try:
            iface_breakouts[iface_name] = iface["link"]["breakout"]
        except Exception:
            pass

    # Override the default port settings with configured speeds and/or
    # breakouts
    for port in portmap.keys():
        iface_breakout = iface_breakouts.get(port)
        iface_speed = iface_speeds.get(port, portmap.get(port))
        if iface_breakout and iface_breakout != '1x':
            portmap[port] = iface_breakout
        elif iface_speed:
            portmap[port] = poer_handler.get_port_bandwidth(port, iface_speed)

    # Dont allow breakout config for ports that are not configurable
    for iface in sorted(ifaces.keys()):
        m = re.match(swp_pattern, iface)
        if m:
            # Use the port as the key for speeds and breakouts to make
            # it easier to index via portmap keys later
            iface = m.group('suffix').strip('p')
        if iface not in portmap and iface_breakouts.get(iface, "1x") != "1x":
            msg = "Breakout config is not valid for port {0}".format(iface)
            logger.warning(msg)
            evt.report_issue(msg)

    # Create a temporary ports.conf file from portmap so it can be validated
    ts = time.strftime("%Y%m%d-%H%M%S")
    temp_ports_conf = "/tmp/ports.conf_{0}".format(ts)
    data = ""
    for port, mode in portmap.items():
        data += "{0}={1}\n".format(port, mode)
    try:
        with evt.fileops.open_file(temp_ports_conf, 'w') as ports_conf:
            ports_conf.write(("# See {}\n# for additional details about this "
                             "file.").format(
                                 poer_handler.get_default_ports_conf_fn()))
            ports_conf.write(data)
    except Exception:  # pragma: no cover TODO CUE-3046
        msg = "Internal Error: Unable to create {0}".format(temp_ports_conf)  # pragma: no cover TODO CUE-3046 # noqa
        logger.error(msg)  # pragma: no cover TODO CUE-3046
        evt.report_issue(msg)  # pragma: no cover TODO CUE-3046
        return  # pragma: no cover TODO CUE-3046

    # Use existing validate-ports script to perform final validation of
    # potential ports.conf file.
    _validate_ports(evt, poer_handler.get_port_modes(), temp_ports_conf)

    # remove the temp time unconditionally
    try:
        evt.fileops.remove_file("{0}".format(temp_ports_conf))
    except Exception:  # pragma: no cover TODO CUE-3046
        pass  # pragma: no cover TODO CUE-3046


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    poer_handler = PortConf(evt)

    default_portmap = poer_handler.get_platform_default_portmap()
    if not default_portmap:
        logger.info("Platform default portmap is empty")# pragma: no cover # noqa TODO: CUE-3046
        return  # pragma: no cover TODO: CUE-3046

    portmap = default_portmap.copy()

    # Populate configured iface_speeds and iface_breakouts from
    # the Object Model
    iface_speeds = {}
    iface_breakouts = {}
    ifaces = _get_ifaces(evt)
    for iface_name, iface in sorted(ifaces.items()):
        m = re.match(swp_pattern, iface_name)
        if m:
            # Use the port as the key for speeds and breakouts to make
            # it easier to index via portmap keys later
            # Suffix contains 'p' so strip it to just get port number
            iface_name = m.group('suffix').strip('p')
        if py_.get(iface, 'type') != "swp":
            continue
        if py_.get(iface, 'link.speed') != 'auto':
            iface_speeds[iface_name] = iface["link"]["speed"]
        if py_.get(iface, 'link.breakout'):
            iface_breakouts[iface_name] = iface["link"]["breakout"]

    # Override the default port settings with configured speeds and/or
    # breakouts
    for port in portmap.keys():
        iface_speed = iface_speeds.get(port, portmap[port])
        iface_breakout = iface_breakouts.get(port)

        # If a breakout mode is configured we want to render it in
        # ports.conf, otherwise we'll render the speed.
        if iface_breakout and iface_breakout != '1x':
            portmap[port] = iface_breakout
        elif iface_speed:
            portmap[port] = poer_handler.get_port_bandwidth(port, iface_speed)

    # Generate the final config file
    header = ("# See {}\n# for additional details about this "
              "file.").format(poer_handler.get_default_ports_conf_fn())
    evt.render(templates, "ports.conf",
               header=header,
               ports_dictionary=portmap)

    staged = evt.stage_file("ports.conf", "/etc/cumulus/ports.conf")

    # No need to reload config file if there are no configurable ports
    if not portmap:
        return  # pragma: no cover TODO CUE-3046

    operational_portmap = poer_handler.get_platform_operational_portmap()
    asic_vendor = py_.get(evt.platform_v1.getHardware(), 'asic-vendor')
    if staged and operational_portmap != portmap:
        if asic_vendor == 'Broadcom':
            evt.schedule_restart('switchd')
        else:
            evt.schedule_reload('switchd')


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
