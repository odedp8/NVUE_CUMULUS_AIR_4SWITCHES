# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from shlex import split
from cue_versions_v1.revman import UnknownRevisionError
from cue.exceptions import NotFound, BadRequest


AVAILABLE_SUBCOMMANDS = {"show", "log"}


def git_raw_get(ctx, revision_id, cmd):
    cmd_tokens = split(cmd)
    if not (cmd_tokens and cmd_tokens[0] in AVAILABLE_SUBCOMMANDS):
        raise BadRequest(f"{cmd!r} not available.")
    try:
        with ctx.versions_v1._repo.get_revman(revision_id) as revman:
            output = ctx.sh.contrib.git(
                *cmd_tokens,
                _cwd=revman.root
            )
    except UnknownRevisionError:
        raise NotFound()
    return str(output)
