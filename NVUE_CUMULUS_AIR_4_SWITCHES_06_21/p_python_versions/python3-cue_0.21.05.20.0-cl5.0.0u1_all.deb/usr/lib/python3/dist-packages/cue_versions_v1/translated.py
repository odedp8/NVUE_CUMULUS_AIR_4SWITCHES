# Copyright (C) 2021 NVIDIA Corporation. ALL RIGHTS RESERVED.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


def _should_include_in_history(commit):
    is_merge = len(commit['parent-hashes']) > 1
    has_meta = 'parsed-body' in commit
    return has_meta and is_merge


def _translate_commit_for_history(commit):
    return {
        'message': commit['subject'],
        'date': commit['date'],
        'ref': next((
            refname
            for refname in commit['ref-names']
            if refname.endswith("/done")
        ), commit['hash']),
        'apply-meta': commit['parsed-body'],
    }


def history_get(ctx, revision_id):
    commits = ctx.versions_v1.getGitLog(revision_id)
    return [
        _translate_commit_for_history(commit)
        for commit in commits
        if _should_include_in_history(commit)
    ]
