# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("rsyslog_v1", handle_verify_config)
    ctx.events.ready_apply.register("rsyslog_v1", handle_ready_apply)
    ctx.events.check_health.register("rsyslog_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """


def get_current_config(evt, path, file_name):
    conf_files = []
    for f in evt.fileops.list_files(path):
        # we are interested in dhcp server config file only
        if not f.name.startswith(file_name):
            continue
        # extracting the VRF name from the config file
        conf_files.append(f.name)
    return conf_files


def handle_stale_config(evt, conf):
    """
    Check the existing rsyslog config files in /etc/rsyslog.d associated
    with particular vrf, delete them if they are not required any more.
    """
    old = get_current_config(evt, "/etc/rsyslog.d", "11-remotesyslog-")
    new = []
    for vrf in conf:
        conf_file = '11-remotesyslog-' + vrf
        conf_file = conf_file + '.conf'
        new.append(conf_file)
    diff = set(old) - set(new)
    if len(diff) > 0:
        evt.render(templates, "cleanup.sh", stale_configs=diff)
        evt.schedule_run_script("cleanup.sh")


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """

    # Get the syslog config info.  DEFAULT values are expected if user has not
    # configured it
    syslogs = evt.config_v1.getSyslogs()
    handle_stale_config(evt, syslogs)
    start = False
    for vrf in syslogs:
        path = "/etc/rsyslog.d/"
        config_file = "11-remotesyslog-"
        config_file += vrf
        config_file += ".conf"
        path += config_file
        evt.render(templates, config_file, "11-remotesyslog.conf",
                   data=syslogs[vrf]["server"], vrf=vrf)
        evt.stage_file(config_file, path)
        start = True
    if start:
        evt.schedule_reload_or_restart("rsyslog")


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
