# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


def server_get(ctx, vrf_id, server_id):
    """
    Get a syslog server.
    """
    try:
        # The native layer already built the servers as a collection, so
        # there's nothing to translate here.
        servers = ctx.rsyslog_v1.getRemoteSyslogConf()[vrf_id]
        return servers["server"][server_id]
    except KeyError:
        return {}


def servers_get(ctx, vrf_id):
    """
    Get the collection of syslog servers.
    """
    # The native layer already built the servers as a collection, so there's
    # nothing to translate here.
    try:
        servers = ctx.rsyslog_v1.getRemoteSyslogConf()[vrf_id]
        return servers["server"]
    except KeyError:
        return {}
