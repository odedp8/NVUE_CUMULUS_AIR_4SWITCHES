# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("snmp_server_v1", handle_verify_config)
    ctx.events.ready_apply.register("snmp_server_v1", handle_ready_apply)
    ctx.events.check_health.register("snmp_server_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """


def handle_check_health(evt):
    """
    Handle an check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
