# Copyright 2021 NVIDIA Corporation

import sh
import sys
import json
import logging
import logging.handlers
from time import sleep


# Setup syslog logging
syslog_h = logging.handlers.SysLogHandler(address="/dev/log")
formatter = logging.Formatter("cue-startup: %(levelname)7s:  %(message)s")
syslog_h.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(syslog_h)


APPLY_ERR_MSG = ("An exception occurred while trying to poll the startup"
                 " revision.  See /var/log/cued.log for more information.")


def sh_curl(*args, **kwargs):
    # HACK: Wrap this in a function, so unit tests can run on platforms that
    #       don't have curl available at '/usr/bin/curl'.
    return sh.Command("/usr/bin/curl")(*args, **kwargs)


def cued_is_listening(max_tries, wait_time):
    """
    Wait for cued to listen on '/run/cue/cue.sock'
    """
    logger.info("Verifying cued is listening on '/run/cue/cue.sock'")
    socket_open = False
    tries = 0
    while not socket_open and tries < max_tries:
        sleep(wait_time)  # Allow time for cued to open socket
        tries += 1
        try:
            sh_curl('--unix-socket',
                    '/run/cue/cue.sock',
                    'http://invalid/')
            socket_open = True
            logger.info("CUED is listening")
        except sh.ErrorReturnCode_7:
            # Cannot connect to server
            pass
        except sh.ErrorReturnCode as err:
            logger.error(('Unexpected error.\n'
                          'Command: %s\n'
                          'stdout: %s\n'
                          'stderr: %s\n'),
                         err.full_cmd,
                         err.stdout,
                         err.stderr)

    err_msg = ("CUED is not listening after waiting {} seconds.".format(
        wait_time * tries))

    if not socket_open:
        logger.error(err_msg)
        return False, err_msg
    return True, None


def run_apply_startup():
    """
    Send a patch request to cued to run a startup apply
    """
    # Create a PATCH request to the cue server to apply the startup config.
    header = "Content-Type: application/json"
    request = "PATCH"

    # state-controls are used to tell CUE that this will be a skinny apply,
    # meaning it should render and install configuration files without
    # reloading services.  At boot time these services such as ifupdown2,
    # and frr will be brought up after CUE and will use the configuration
    # files we've rendered and installed.
    # check-health is skipped as well because the services it would normally
    # query won't be running yet.
    data = {"state": "apply",
            "auto-prompt": {"ays": "ays_yes"},
            "state-controls": {"reload": "skip",
                               "check-health": "skip"}}
    sock = '/run/cue/cue.sock'
    url = 'http://invalid/cue_v1/revision/startup'

    args = ('--header', header,
            '--request', request,
            '--data', json.dumps(data),
            '--unix-socket', sock,
            url)
    logger.info("Sending PATCH request to cued.\nArgs: %s", args)

    try:
        out = sh_curl(*args)

        if out.exit_code != 0:
            err = (f"PATCH request resulted in non-zero exit code.\n"
                   f"Output: {str(out)}")
            logger.error(err)
            return False, err
        else:
            logger.info(f"Request output: %s", out)
            return True, None
    except sh.ErrorReturnCode as err:
        msg = (f"PATCH request resulted in unexpected error.\n"
               f"Command: {err.full_cmd}\n"
               f"stdout: {err.stdout}\n"
               f"stderr: {err.stderr}")
        logger.error(msg)

        return False, msg


def main():
    ret, err = cued_is_listening(30, 1)
    if not ret:
        sys.exit(err)

    ret, err = run_apply_startup()
    if not ret:
        sys.exit(err)

    # This will trigger the cl script to poll the startup revision
    try:
        sh.cl('config', 'apply', 'startup')
    except sh.ErrorReturnCode as err:
        logger.error(err.stdout)
        logger.error(APPLY_ERR_MSG)
        sys.exit(APPLY_ERR_MSG)

    logger.info("Exiting")
    sys.exit()


if __name__ == '__main__':  # pragma: no cover
    main()
