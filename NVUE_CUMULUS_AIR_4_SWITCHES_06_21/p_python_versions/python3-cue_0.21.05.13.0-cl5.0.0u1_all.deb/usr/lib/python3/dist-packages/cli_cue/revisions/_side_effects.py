# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from cli_cue.network import (
    send_request,
    CueRequest,
    encode_path,
    CueRequestError,
)
from cli_cue.revisions._exceptions import NoPendingRevisionError


######################
# API handling
######################

def fetch_revisions():
    return send_request(CueRequest(
        path=encode_path("cue_v1", "revision"),
        method="GET",
    ))


def fetch_revision(revision_id):
    return send_request(CueRequest(
        path=encode_path("cue_v1", "revision", revision_id),
        method="GET",
    ))


def update_revision(revision_id, patch_body):
    return send_request(CueRequest(
        path=encode_path("cue_v1", "revision", revision_id),
        method="PATCH",
        payload=patch_body,
    ))


def create_revision():
    # Request a new revision be made
    rev_req = CueRequest(
        path="/cue_v1/revision",
        method="POST",
    )
    return send_request(rev_req)


def is_revision_patchable(revision_id):
    """
    Check if a revision is accepting PATCH requests.

    Side-effects:
        Makes an empty PATCH request using the specified revision.
    """
    try:
        send_request(CueRequest(
            method="PATCH",
            path="/cue_v1/",
            query_params={"rev": revision_id},
            payload={},
        ))
    except CueRequestError as err:
        # EARLY RETURN
        if err.status == 409:
            # It's not patchable right now
            return False
        else:
            # Something else went wrong. We don't know what, nor do we care!
            # Let the caller worry about it!
            raise
    # If we made it this far, we're probably good to go.
    return True


#######################
# revision tracking
#######################

def _get_cue_revision_id_file():
    """
    Get the pathlib Path for the current cue revision id file. The user can
    configure it with CUE_REVISION_ID_FILE environment variable. If that
    variable is not present, it defaults to $XDG_DATA_HOME/cue/rev_id

    Returns a pathlib Path of the revision id file.
    """
    from pathlib import Path
    import os
    rev_id_file = os.environ.get("CUE_REVISION_ID_FILE", None)
    if rev_id_file is None:
        # Get XDG_DATA_HOME (default to $HOME/.local/share)
        xdg_data_home = (
            os.environ["XDG_DATA_HOME"]
            if "XDG_DATA_HOME" in os.environ
            else f"{os.environ['HOME']}/.local/share"
        )
        # $XDG_DATA_HOME/cue/rev_id
        rev_id_file = xdg_data_home + "/cue/rev_id"
    return Path(rev_id_file)


def get_active_pending_revision() -> str:
    """
    Get the active pending revision from the cue revision id file.

    Returns value stored in cue revision id file if present. Otherwise,
    raise a NoPendingRevisionError.
    """
    cue_rev_id_file = _get_cue_revision_id_file()
    try:
        rev_id = cue_rev_id_file.read_text()
    except FileNotFoundError:
        raise NoPendingRevisionError() from None
    return rev_id


def detach_pending():
    """
    Detach the current user's active pending revision.
    """
    # The true purpose of this function is to make unit testing easier.
    try:
        _get_cue_revision_id_file().unlink()
    except FileNotFoundError:
        # We're going from "applied" -> "applied". Not a problem.
        pass


def attach_pending(revision_id):
    rev_id_file = _get_cue_revision_id_file()
    # Ensure rev_id_file parent dir exists
    rev_id_file.parent.mkdir(parents=True, exist_ok=True)
    rev_id_file.write_text(revision_id)
