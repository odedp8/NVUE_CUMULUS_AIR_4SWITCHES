# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates
from pydash import py_
from cue import utils
import ipaddress


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("linuxptp_v1", handle_verify_config)
    ctx.events.ready_apply.register("linuxptp_v1", handle_ready_apply)
    ctx.events.check_health.register("linuxptp_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.report_issue to report any found issues.

    Args:
        evt: A VerifyConfigEvent instance.
    """


def format_acceptable_masters_clocks(ptps):
    """
    The config file expects clock-ids in a different format.
    """
    for ptp in ptps.values():
        new_masters = {}
        for clock_id, acc in ptp["acceptable-master"].items():
            parts = clock_id.split(":")
            new_clock_id = "{}{}{}.{}{}.{}{}{}".format(*parts)
            new_masters[new_clock_id] = acc
        ptp["acceptable-master"] = new_masters


def find_svi_interface(all_ifaces, domain_name, vid):
    svi_name = None

    # For now, if we're dealing with br_default, just generate the svi's name.
    # Long term, we shouldn't be assuming a naming convention, but for that to
    # work, we need base-interface and vlan to be populated.
    if domain_name == "br_default":
        svi_name = "vlan" + str(vid)
    else:
        # If not br-default, look for a matching svi.
        for iface_name, iface in all_ifaces.items():
            if iface["type"] != "svi":
                continue
            if (domain_name == iface.get("base-interface")
                    and str(vid) == str(iface.get("vlan"))):
                svi_name = iface_name
                break

    if svi_name:
        try:
            iface = all_ifaces[svi_name]

            # Found a match.  Get it's first IP address.
            ip_prefix = next(iter(iface["ip"]["address"]))
            ip_addr = str(ipaddress.ip_interface(ip_prefix).ip)

            # Got an IP address, too.  Return it.
            return svi_name, ip_addr
        except (KeyError, IndexError, ValueError):
            pass

    return None


def find_active_vlan(domains, domain_name, vlans):
    # Find one that's active.
    for vid, vlan in vlans.items():
        try:
            vlan = domains[domain_name]["vlan"][vid]
            candidate = vlan["service"]["ptp"]
            if candidate["enable"] == "on":
                return vid, candidate
        except KeyError:
            pass

    return None


def inherit_interface_config(ifaces, all_ifaces, vrfs, domains):
    """
    Squash the "auto" values in interface configs.

    Replace "auto" by inheriting from VRF, VLAN, or bond as appropriate.
    """
    for iface in ifaces.values():
        if_ptp = iface["service"]["ptp"]

        # If we cannot inherit, then assume our parent is disabled.
        parent = {"enable": "off"}

        # If the iface is in a VRF, inherit from the VRF.
        vrf = iface["ip"]["vrf"]
        if vrf in vrfs:
            parent = vrfs[vrf]["service"]["ptp"]

        # If the iface is in a VLAN with PTP, inherit from the VLAN.
        if parent["enable"] == "off" and "bridge" in iface:
            for domain_name, domain in iface["bridge"]["domain"].items():
                # If the interface is in all VLANs, loop over the domain's
                # vlans.  Otherwise, loop over the interface's vlans.
                if "all" in domain["vlan"]:
                    vlans = domains[domain_name]["vlan"]
                else:
                    vlans = domain["vlan"]

                # Look for an active VLAN in this bridge
                active_vlan = find_active_vlan(domains, domain_name, vlans)
                if active_vlan is None:
                    continue
                vid, parent = active_vlan

                # While we know where we found a match, fill in the SVI props
                svi_tup = find_svi_interface(all_ifaces, domain_name, vid)
                if svi_tup:
                    svi_name, ip_addr = svi_tup
                    if_ptp["_vlan-interface"] = svi_name
                    if_ptp["_source-ip"] = ip_addr

        # If our parent is disabled, then we're disabled.
        if parent["enable"] == "off":
            if_ptp["enable"] = "off"
        else:
            # Inherit the autos
            utils.auto_inherit(if_ptp, parent)
            utils.auto_inherit(if_ptp["timers"], parent["timers"])


def find_active_interfaces(ifaces):
    """
    Filter ifaces for ones with PTP enabled.
    """
    enabled_ifaces = {}
    for iface_name, iface in ifaces.items():
        if_ptp = py_.get(iface, "service.ptp", {"enable": "off"})

        # If explicitly on (or inherited on), add it to the list of
        # interface instances
        if if_ptp["enable"] == "on":
            enabled_ifaces[iface_name] = iface

    return enabled_ifaces


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.

    Use evt.config_v1 to access the pending configuration's state.
    Use evt.render to render a template with the given variables.
    Use evt.stage_file to prepare a rendered file to be copied over to its
        ultimate destination.

    Args:
        evt: A ReadyApplyEvent instance.
    """
    ptps = evt.config_v1.getPtps()

    # For now, assume a single instance, named "1".
    if "1" in ptps and ptps["1"]["enable"] == "on":
        format_acceptable_masters_clocks(ptps)

        # Find the enabled PTP interfaces
        all_ifaces = evt.config_v1.getInterfaces()
        ifaces = find_active_interfaces(all_ifaces)

        # Inherit values
        vrfs = evt.config_v1.getVrfs()
        domains = evt.config_v1.getBridgeDomains()
        inherit_interface_config(ifaces, all_ifaces, vrfs, domains)

        # Some of our interfaces might be disabled now.  Filter again.
        ifaces = find_active_interfaces(ifaces)

        # Pull out just the PTP service
        if_ptps = {
            iface_name: iface["service"]["ptp"]
            for iface_name, iface in ifaces.items()
        }

        # Check if running in HW or SW
        hw = evt.platform_v1.getHardware()
        if (hw.get("vendor") == "cumulus" and hw.get("model") == "vx"):
            sim = True
        else:
            sim = False

        evt.render(
            templates, "ptp4l.conf",
            py_=py_,
            running=True,
            simulation=sim,
            ptp_conf=ptps["1"],
            if_ptps=if_ptps
        )
        evt.stage_file("ptp4l.conf", "/etc/ptp4l.conf")
        evt.schedule_reload_or_restart("ptp4l")
    else:
        # Render a config for a stopped service
        evt.render(templates, "ptp4l.conf", running=False)
        evt.stage_file("ptp4l.conf", "/etc/ptp4l.conf")
        # Make sure the service is stopped.
        evt.schedule_stop("ptp4l")


def handle_check_health(evt):
    """
    Handle a check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
