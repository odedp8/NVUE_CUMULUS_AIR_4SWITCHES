# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue import utils


def platform_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPlatform(rev)

    return ctx.env_v1.getPlatform()


def platform_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getPlatform, ctx.config_v1.setPlatform,
        rev, patch=body)


def platform_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPlatform, ctx.config_v1.setPlatform, rev)


def software_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.env_v1.getSoftware()


def installed_packages_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.env_v1.getInstalledPackages()


def installed_package_get(ctx, rev, installed_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.env_v1.getInstalledPackage(installed_id)


def hostname_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getHostname(rev)

    return ctx.env_v1.getHostname()


def hostname_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getHostname, ctx.config_v1.setHostname,
        rev, patch=body)


def hostname_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getHostname, ctx.config_v1.setHostname, rev)


###############################
# Platform config
###############################

def platform_config_get(ctx, rev):
    if rev == 'operational':
        # Platform config does not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getPlatformConfig(rev)


def platform_config_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getPlatformConfig, ctx.config_v1.setPlatformConfig,
        rev, patch=body)


def platform_config_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPlatformConfig, ctx.config_v1.setPlatformConfig, rev)


###############################
# Config apply
###############################

def config_apply_get(ctx, rev):
    if rev == 'operational':
        # Platform config does not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getPlatformConfigApply(rev)


def config_apply_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply,
        rev, patch=body)


def config_apply_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply, rev)


###############################
# Apply ignores
###############################

def apply_ignores_get(ctx, rev):
    return config_apply_get(ctx, rev)["ignore"]


def apply_ignores_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply,
        rev, "ignore", patch=body)


def apply_ignores_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply, rev, "ignore")


###############################
# Apply ignore
###############################

def apply_ignore_get(ctx, rev, ignore_id):
    ignores = apply_ignores_get(ctx, rev)
    try:
        return ignores[ignore_id]
    except KeyError:
        raise NotFound


def apply_ignore_patch(ctx, rev, ignore_id, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)
    return ops.patch_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply,
        rev, "ignore", patch=body)


def apply_ignore_delete(ctx, rev, ignore_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getPlatformConfigApply,
        ctx.config_v1.setPlatformConfigApply, rev, "ignore")


###############################
# Snippets
###############################

def snippets_get(ctx, rev):
    if rev == 'operational':
        # Snippets do not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getSnippets(rev)


###############################
# Capabilities
###############################

def capabilities_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return utils.fast_merge(
        ctx.platform_v1.getIfupdown2Capabilities()
    )
