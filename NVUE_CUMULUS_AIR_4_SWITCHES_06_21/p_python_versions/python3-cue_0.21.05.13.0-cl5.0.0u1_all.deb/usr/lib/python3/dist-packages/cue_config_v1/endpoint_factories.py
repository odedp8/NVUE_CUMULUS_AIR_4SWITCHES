# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Endpoint factories.
#
# The config DB is a simple document store.  It allows data, represented in the
# form of a tree, to be retrieved and set.  These operations, no matter where
# you are in the tree, are the same.
#
# For convenience, we expose paths into the tree so that data can be accessed
# relative to that path instead of always from the root.
#
# This module provides factories that create functions (endpoints) that can be
# used as controllers for these paths.


from pydash import py_
from cue import exceptions, utils
from . import full
import logging


logger = logging.getLogger(__name__)


def _collect_defaults(defaults_schema, rooted):
    """
    Given a `defaults_schema` and `rooted`, return the set of defaults for the
    `instance`.
    """
    try:
        # Collect the defaults.  The result will be rooted.
        collector = utils.DefaultsCollector(defaults_schema)
        return collector.collect(rooted)
    except utils.DefaultsError:
        # This should never happen, but if it does, return as gracefully as we
        # can.  The collector will log a more detailed description of the error
        # to debug.
        logger.warning("Unable to collect defaults")
        return {}


def _fill_defaults(conf, instance, obj_type, id_=None, root=None):
    """
    Fill `instance` with its defaults, returning a new object.

    Providing a `root` instance will enable filling the defaults from the root
    (which is sometimes necessary for conditional defaults.)
    """
    # We need to collect defaults from the root, so we'll put our instance
    # in an object relative to the root.  obj_type and id_ have to be
    # handled differently because obj_type might use dot notation and id_
    # cannot.
    if id_:
        rooted = {id_: instance}
    else:
        rooted = instance

    if obj_type == ".":
        # Special case for the root endpoint.
        pass
    else:
        rooted = py_.set_({}, obj_type, rooted)

    rooted_defaults = None

    if "_rooted_defaults" in conf:
        # We have cached the full set of defaults.  Use them.
        rooted_defaults = conf["_rooted_defaults"]
    else:
        # We don't have cached defaults.  We'll need to collect them.
        # Depending on the request, we'll try to cache the result for future
        # calls, but we won't do any more work now than we have to.

        if root is not None:
            # This is a rooted request.  We have to build the defaults for the
            # entire tree, but only need part of it.
            rooted_defaults = _collect_defaults(conf["_defaults"], root)
            # We can cache the results.
            conf["_rooted_defaults"] = rooted_defaults
        elif obj_type == "." and id_ is None:
            # This is a request to fill in the entire config tree.
            rooted_defaults = _collect_defaults(conf["_defaults"], rooted)
            # We can cache the results.
            conf["_rooted_defaults"] = rooted_defaults
        else:
            # This is a request to fill in part of the config tree.
            rooted_defaults = _collect_defaults(conf["_defaults"], rooted)
            # We cannot cache these, since they are partial results.

    # Pull up the defaults for this instance and return it.
    defaults = py_.get(rooted_defaults, obj_type, {})
    if id_:
        defaults = py_.get(defaults, [id_], {})

    return utils.fast_merge(defaults, instance)


def _get(conf, obj_type, id_=None, filled=True, from_root=False):
    """
    Utility to build objects configured for a given type. It deals with
    immutables, defaults, etc.

    Args:
        conf: The config conf dict containing "opinions", "immutables", and
            "_defaults".
        obj_type: The dot-delimited path string to the requested object.
        id_: optional - The identifier for an item inside a collection.
        filled: optional - Should the result include defaults/immutables?
            Defaults to True.
        from_root: optional - Should the defaults be collected from the root of
            the OM tree? (This is necessary when the defaults of the object
            depend on data outside of that object.) Defaults to False.

    Returns:
        The requested object.

    Raises:
        NotFound if an `id_` was requested, and that `id_` isn't present.
    """
    # sentinel for when a collection item is missing.
    _item_missing = object()

    root_opinions = conf["opinions"]
    root_immutables = conf["immutables"]

    # Is this a request for a single item in a collection?
    if id_ is not None:
        # Include the id_ in the pydash path for simplicity.
        obj_type = ".".join([
            obj_type,
            # Escape the id string to ensure pydash treats it as a single item.
            id_.replace(".", r"\."),
        ])
        # For collection item requests, we need to throw an error if the object
        # isn't found. Set the fallback for missing objects to something
        # different. We'll raise a NotFound error when we see this.
        fallback_obj = _item_missing
    else:
        # For everything else, missing objects are fine. We'll fill up an empty
        # dict with defaults.
        fallback_obj = {}

    if filled:
        # Merge in the immutables, so we pick up nested immutables.
        root = utils.fast_merge(root_immutables, root_opinions)

        obj = py_.get(root, obj_type, fallback_obj)
        if obj is _item_missing:
            raise exceptions.NotFound()

        # And fill in with the defaults.  This will return a copy.
        if from_root:
            return _fill_defaults(conf, obj, obj_type, root=root)
        else:
            return _fill_defaults(conf, obj, obj_type)
    else:
        obj = py_.get(root_opinions, obj_type, fallback_obj)
        if obj is _item_missing:
            # Before we raise an error: Is the item in the immutables?
            immutable = py_.get(root_immutables, obj_type, _item_missing)
            if immutable is _item_missing:
                raise exceptions.NotFound()
            else:
                # The item is present, but the user only asked for opinions.
                # Give them an empty object instead of whatever is in
                # immutables.
                obj = {}
        # If we're not filling, then we're only interested in opinions.
        # Make a defensive copy.
        return utils.fast_clone(obj)


def _objs_get(conf, obj_type, filled=True):
    """
    Utility to build the list of objects configured for a given type.  It deals
    with immutables, defaults, etc.
    """
    return _get(conf, obj_type, filled=filled)


def _obj_get(conf, obj_type, id_, filled=True):
    """
    Utility to build the instance configured for a given type.  It deals with
    immutables, defaults, etc.  Returns NotFound if it's an unknown instance.
    """
    return _get(conf, obj_type, id_, filled)


def _singleton_get(conf, obj_type, filled=True):
    """
    Utility to build the given singleton.  It deals with immutables, defaults,
    etc.  Note that singletons are always immutable and always exist.
    """
    return _get(conf, obj_type, filled=filled)


def endpoint_get(path_def, from_root=False):
    """
    Generate an endpoint to get the config specified by `path_def`.

    Args:
        path_def: A dot-delimited path to the requested object. If the final
            item is wrapped in curly braces (e.g. `foo.bar.{id}`), then it is
            treated as the identifier token for an item in a collection.
        from_root: optional - Should the defaults be collected from the root of
            the OM tree? (This is necessary when the defaults of the object
            depend on data outside of that object.) Defaults to False.
    """
    identifier = None
    # Get the sequence of `segments` and maybe the `identifier`.
    if path_def == ".":
        # This case is different, mostly because it doesn't str.split nicely.
        segments = ()
    else:
        segments = tuple(path_def.split("."))
        # identifier can only be the the final item in the path_def.
        if segments[-1].startswith("{"):
            *segments, raw_identifier = segments
            identifier = raw_identifier.strip("{}")

    obj_type = ".".join(segments) or "."

    def get(ctx, revision_id, *path, attrs=None, filled=True):
        logger.dump("Get", revision_id, obj_type, path, attrs, filled)
        id_ = None
        if identifier is not None:
            # For collection item requests, the first path arg is the `id_`.
            # Pop it off so we use it as such.
            id_, *path = path

        conf = full.full_get(ctx, revision_id)

        # Build the requested base object.
        obj = _get(conf, obj_type, id_, filled=filled, from_root=from_root)

        # If requested, limit the returned attrs to the given list.  An empty
        # field list is an efficient way to get a list of configured instance
        # ids.
        # NOTE: this is only applicable for collections.
        if attrs is not None:
            obj = py_.map_values(obj, lambda obj: py_.pick(obj, *attrs))

        # Convert any extra path tokens into a list. pydash likes it that way.
        path = list(path)
        # If we got extra path, pull out the part of the config we care about.
        if len(path) > 0:
            obj = py_.get(obj, path, {})

        # Return the result
        return obj

    # Return the closure
    return get


def endpoint_objs_get(obj_type, **kwargs):
    """
    Generate an endpoint to get the configuration for all instances of a given
    object type.
    """
    return endpoint_get(obj_type, **kwargs)


def _persist_config(ctx, revision_id, conf):
    """
    After putting a config change, persist it.
    """
    # Invalidate the cached defaults.  Also, make sure we don't save them.
    if "_rooted_defaults" in conf:
        del conf["_rooted_defaults"]

    # Save the new config
    full.full_put(ctx, revision_id, conf)


def endpoint_objs_put(obj_type):
    """
    Generate an endpoint to put the configuration of all instances of a given
    object type.
    """
    def objs_put(ctx, revision_id, body):
        logger.dump("Put objs", revision_id, obj_type)

        conf = full.full_get(ctx, revision_id)

        # If the body is empty, then clear the config node completely.
        if len(body) == 0:
            py_.unset(conf["opinions"], obj_type)
            conf["opinions"].pop(obj_type, None)
        else:
            # Set the new value.  Make a defensive copy.
            py_.set_(conf["opinions"], obj_type, utils.fast_clone(body))

        # Save the new config
        _persist_config(ctx, revision_id, conf)

        return _objs_get(conf, obj_type, False)

    # Return the closure
    return objs_put


def endpoint_obj_get(obj_type, **kwargs):
    """
    Generate an endpoint to get an instance's configuration, full or in part.
    """
    return endpoint_get(obj_type + ".{id_}", **kwargs)


def endpoint_obj_put(obj_type):
    """
    Generate an endpoint to put the configuration of an instance.
    """
    def obj_put(ctx, revision_id, id_, *path, body):
        logger.dump("Put obj", revision_id, obj_type, id_, path)

        conf = full.full_get(ctx, revision_id)

        # Make a defensive copy
        body = utils.fast_clone(body)

        # Convert any extra path tokens into a list. pydash likes it that way.
        path = list(path)

        # Get the list of instances of this obj_type, starting it if necessary.
        objs = py_.get(conf["opinions"], obj_type, {})
        py_.set_(conf["opinions"], obj_type, objs)

        # Set the new value, letting pydash deal with the path
        if len(path) > 0:
            # Get the instance in question.  If it's not configured, start it.
            obj = objs.get(id_, {})
            py_.set_(obj, path, body)
        else:
            # We'll replace whatever we have
            obj = body

        # Put it back into the confg.
        objs[id_] = obj

        # Save the new config
        _persist_config(ctx, revision_id, conf)

        # Return the relative result
        return py_.get(_obj_get(conf, obj_type, id_, False), path)

    # Return the closure
    return obj_put


def endpoint_singleton_get(obj_type, **kwargs):
    """
    Generate an endpoint to get a singleton's configuration, full or in part.
    """
    return endpoint_get(obj_type, **kwargs)


def endpoint_singleton_put(obj_type):
    """
    Generate an endpoint to put the configuration of a singleton.
    """
    def singleton_put(ctx, revision_id, *path, body):
        logger.dump("Put single", revision_id, obj_type, path)

        conf = full.full_get(ctx, revision_id)

        # Make a defensive copy
        body = utils.fast_clone(body)

        # Convert any extra path tokens into a list. pydash likes it that way.
        path = list(path)

        # Set the new value, letting pydash deal with the path
        if len(path) > 0:
            # Get the instance in question.  If it's not configured, start it.
            obj = py_.get(conf["opinions"], obj_type, {})
            py_.set_(obj, path, body)
        else:
            # We'll replace whatever we have
            obj = body

        if obj_type == ".":
            # Special case for the root endpoint.  We can't set something in
            # conf["opinions"] because we're actually replacing it.
            conf["opinions"] = obj
        elif len(obj) == 0:
            # If the body is empty, then clear the config node completely.
            obj = py_.unset(conf["opinions"], obj_type)
        else:
            # Otherwise, put it back into the config.
            py_.set_(conf["opinions"], obj_type, obj)

        # Save the new config
        _persist_config(ctx, revision_id, conf)

        # Return the relative result
        return py_.get(_singleton_get(conf, obj_type, False), path)

    # Return the closure
    return singleton_put
