# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue import utils
from importlib import resources
import functools
from . import manip


@functools.lru_cache()
def _load_defaults_schema():
    """
    Return the root of the schema we'll user for generating defaults.
    """
    # Load the spec file and pull out the defaults schema.
    spec_obj = utils.loaders.load_openapi_json(__package__)
    defaults_schema = spec_obj["components"]["schemas"]["defaults-root"]

    # Squirrel away the schema version.  That's how we'll know if our defaults
    # have changed.
    defaults_schema["x-version"] = spec_obj["info"]["version"]

    return defaults_schema


@functools.lru_cache()
def _load_immutables(typ="safe"):
    """
    Read in the set of immutables, as shipped with this version.
    """
    with resources.path(__package__, "immutables.yaml") as src:
        return utils.yaml_load(src, typ=typ)


@functools.lru_cache()
def load_initial(typ="safe"):
    """
    Read in the initial config.  This is the startup.yaml we'll use when
    startup.yaml doesn't exist.
    """
    with resources.path(__package__, "initial.yaml") as src:
        return utils.yaml_load(src, typ=typ)


def empty_config():
    """
    Return an empty configuration.  Each child of this object follows the
    config schema (except the _defaults child).  When the children are merged
    together, you get the whole config.

    In an empty config, we have an empty "opinions" which will hold the user's
    configuration.

    We'll also have an "immutables" which holds things that will always exist,
    even the user doesn't have an opinion.  For example, the mgmt vrf is an
    immutable.  It will always exist, but the user can have an opinion about
    its settings.

    The _defaults child is different.  Defaults are part of the config, but
    they aren't structured the same since they come out of the schema itself.
    """
    return {
        "opinions": {},
        "immutables": _load_immutables(),
        "_defaults": _load_defaults_schema(),
    }


def _create_config_validators():
    """
    Wrap each config schema with a CueValidator.
    """
    # Load the spec file
    spec_obj = utils.loaders.load_openapi_json(__package__)

    # Pull out the schemas
    schemas = spec_obj["components"]["schemas"]

    # Build the validators we need.
    validators = {}
    for schema_name in ["patch-root", "root"]:
        schema = schemas[schema_name]
        validators[schema_name] = utils.CueValidator(schema)

    return validators


def prepare_schema(ctx):
    """
    Load for schema validations.
    """
    # Keep the schemas around for validation calls
    ctx.config_v1._config_validators = _create_config_validators()


def validate_cue_file(ctx, cue_file):
    """
    Verify the given cue file, in Python object format, is valid.  We will use
    jsonschema to verify each operation matches the "patch-root" schema in
    openapi.yaml.

    Raises a ParseError if the cue file is invalid.
    """
    # Do some sanity checking before diving in with jsonschema.  This points
    # out some of the obvious flaws in a friendly way before we go crazy with
    # schema-speak.

    # It's not an array.  That's a bad start.
    if not isinstance(cue_file, list):
        utils.raise_parse_error(
            utils.find_location(cue_file, []), "top level must be an array")

    # Loop through each delta op
    for op_num, delta_op in enumerate(cue_file):
        # Verify the block has one operation.
        if len(delta_op) != 1:
            utils.raise_parse_error(utils.find_location(cue_file, [op_num]),
                                    "each block must have a single operation")

        # Pull out the operation name
        op_name = list(delta_op.keys())[0]

        # Verify the block has a known operation.
        if op_name not in {"set", "unset"}:
            utils.raise_parse_error(
                utils.find_location(cue_file, [op_num]), "unknown operation")

        # Validate against the patch-root schema.
        validator = ctx.config_v1._config_validators["patch-root"]
        validator.conforms(delta_op[op_name], path_prefix=[op_num, op_name])


def validate_full_config(ctx, full_config):
    """
    Verify the given full config, in Python object format, is schema valid.
    This means merging the config trees in full_config (opinions and
    immutables) into a single tree and calling `validate_full_tree()`.

    Raises a ParseError if the config is not schema invalid.
    """
    validate_full_tree(ctx, manip.squash_full_config(full_config))


def validate_full_tree(ctx, full_tree):
    """
    Verify the given full config tree, in Python object format, is schema
    valid.  This means verifying `full_tree` matches the fully constrained
    root schema.

    Raises a ParseError if the config is not schema invalid.
    """
    config_root_validator = ctx.config_v1._config_validators["root"]
    config_root_validator.conforms(full_tree)
