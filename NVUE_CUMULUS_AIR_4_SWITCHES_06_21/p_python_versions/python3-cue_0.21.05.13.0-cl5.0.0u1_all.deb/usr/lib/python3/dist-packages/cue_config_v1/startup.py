# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Retrieve and store the startup config.  The format for the startup config is
# different from configs in the repo.  Where repo configs have the complete
# config in a single YAML file, the startup config is broken out into a series
# of deltas that may be edited by end users.


from cue import exceptions, utils, issues
from . import schema, manip
import logging


logger = logging.getLogger(__name__)


def prepare_startup(ctx):
    """
    Prepare the startup config cache.
    """
    ctx.config_v1._startup_files = None


def startup_get(ctx):
    """
    Return the startup config.  If the files haven't changed since the last
    load, then return what we loaded last time.
    """
    files = ctx.versions_v1.getFiles("startup")

    if ctx.config_v1._startup_files == files:
        # The startup files have not changed.  Return the cached version.
        return ctx.config_v1._startup_conf

    # Start with an empty config.
    conf = schema.empty_config()

    # Loop through all the files in the startup directory and build the
    # opinions.
    found_startup = False
    for fname in files.keys():
        # Look for extensions we understand.
        if fname.endswith(".yaml") or fname.endswith(".yml"):
            logger.dump("Adding", fname)
            found_startup = True

            # Verifier for yaml_load_safe()
            def _verify_startup(delta_ops):
                caught_ex = None

                # TODO CUE-2522: Expand before verifying because our schemas
                # can't yet handle glob formats.  The downside is a parse error
                # might get reported multiple times; once for each expansion.
                try:
                    expanded_ops = manip.expand_deltas(delta_ops)
                except Exception as ex:
                    # HACK: If expansion raises an error, it's probably because
                    #       something's off with the YAML's structure. Eat the
                    #       error and let the validation give us a better idea
                    #       of what went wrong.
                    # TODO: Get rid of this hack when CUE-2522 is resolved.
                    expanded_ops = delta_ops
                    caught_ex = ex

                schema.validate_cue_file(ctx, expanded_ops)

                # If we caught an exception during expansion and we're still
                # here, raise it now.  This is likely a bug in the morphers and
                # we need to see it to fix it.
                if caught_ex:
                    raise caught_ex

                # Since we didn't expand in place, replace the original
                # ops with the expanded versions.
                delta_ops.clear()
                delta_ops.extend(expanded_ops)

            # Load the cue file
            yaml_str = ctx.versions_v1.getRawFile("startup", fname)

            try:
                # And parse it
                expanded_ops = utils.yaml_load_safe(
                    yaml_str, filename=fname, verifier=_verify_startup)
            except utils.ParseError as ex:
                # We can't load the cue file.  Raise an HTTP exception.
                raise exceptions.from_issue(issues.CueFileParseError(
                    ex.location, ex.reason)) from None

            # Merge it in.
            manip.merge_deltas(conf["opinions"], expanded_ops)

    if not found_startup:
        logger.dump("Using initial")

        # There's no useable startup configuration.  Run with our intitial
        # config.
        initial = schema.load_initial()
        manip.merge_deltas(conf["opinions"], initial)

    conf["opinions"] = utils.filter_none(conf["opinions"])

    # Cache it.
    ctx.config_v1._startup_files = files
    ctx.config_v1._startup_conf = conf

    return conf


def startup_put(ctx):
    # XXX Work work work
    raise NotImplementedError()  # pragma: no cover
