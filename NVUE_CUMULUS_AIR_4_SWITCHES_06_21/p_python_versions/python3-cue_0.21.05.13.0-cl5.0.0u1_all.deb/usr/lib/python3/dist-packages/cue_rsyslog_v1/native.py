# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


def rsyslogconf_vrf_get(ctx, conf_file):
    """
    Returns lists of remote syslog hosts reading from
    vrf specific file - "1-remotesyslog-VRF-xyz.conf" in /etc/rsyslog.d/
    """

    output = ctx.fileops.load_file(conf_file)
    rsyslog = {}
    hflag = pflag = prflag = False
    for line in output.splitlines():
        for word in line.split():
            if (word.find('Target') != -1):
                host = word[8:-1]
                hflag = True
            elif (word.find('Port') != -1):
                port = word[6:-1]
                pflag = True
            elif (word.find('Protocol') != -1):
                proto = word[10:-2]
                prflag = True
        if (hflag and pflag and prflag):
            rsyslog[host] = {'port': int(port), 'protocol': proto}
            hflag = pflag = prflag = False
    conf = {}
    conf.update({"server": rsyslog})
    return conf


def rsyslogconf_get(ctx):
    config_data = {}
    for config_file in ctx.fileops.list_files("/etc/rsyslog.d"):
        # we are interested in rsyslog config file only
        if not config_file.name.startswith('11-remotesyslog-'):
            continue
        # extracting the VRF name from the config file
        vrf = config_file.name[16:-5]
        vrf_data = rsyslogconf_vrf_get(ctx, config_file)
        config_data.update({vrf: vrf_data})
    return config_data
