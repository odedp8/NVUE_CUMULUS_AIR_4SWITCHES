# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.

# Even though we could reuse the same netlink socket for each
# GET, I'm creating it in each function call because its easier to
# test.  We have to mock the netlink_socket so that the tests can
# run all platforms and I can't do that if its global.

import logging
import json
import re


logger = logging.getLogger("cue_netlink_v1")


def _get(ctx, cmd, obj='', options='', if_id='', if_type='', show_type=''):
    """
    Call the native cmd provided using the sh module

    cmd must be one of: ip | bridge | clagctl

    :return: a list
    """
    args = options.split()
    if obj:
        args.append(obj)

    if cmd in ['bridge']:
        if show_type in ['tunnelshow']:
            args.append('tunnelshow')
        else:
            args.append('show')
    if if_id:
        if cmd in ['ip', 'clagctl']:
            args.append('show')

        # "bridge -j vlan show foo" will return all interfaces.
        # "bridge -j vlan show dev foo" will return just the one we want.
        if cmd in ['bridge']:
            if obj in ['fdb']:
                if if_type:
                    args.append(if_type)
                else:
                    args.append('br')
            else:
                args.append('dev')

        args.append(if_id)

    logger.info("Running '%s %s'", cmd, str.join(' ', args))
    response = []
    try:
        if cmd == 'ip':
            # Fixing invalid json in ip output by replacing string
            output = str(ctx.sh.ip(*args)).replace(
                'group_fwd_maskhi 0x0 group_fwd_maskhi_str 0x0',
                ', "group_fwd_maskhi": "0x0", "group_fwd_maskhi_str": "0x0"')

        elif cmd == 'bridge':
            output = str(ctx.sh.bridge(*args))

        elif cmd == 'clagctl':
            output = str(ctx.sh.clagctl(*args))

        elif cmd == 'ethtool':
            output = str(ctx.sh.ethtool(*args))

        elif cmd == 'mstpctl':
            output = str(ctx.sh.mstpctl(*args))

        response = json.loads(output) if '-j' in options else output

    except Exception as e:
        if 'Unable to communicate with clagd' in str(e):
            return {'errorMsg':
                    'Unable to communicate with clagd. Is it running?'}
        elif cmd == 'mstpctl' and 'Not a valid interface' in str(e):
            return {'errorMsg': 'Not a valid interface'}

    return response


def ethtool_info_get(ctx, interface_id):
    """
    Get ethtool information for the device (port) provided
    """
    response = {}
    output = _get(ctx, 'ethtool', if_id=interface_id)
    if not output:
        return response

    # Parse the output
    lines = output.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i]
        split = line.split(':')
        if len(split) > 1:
            key, val = split
            val = val.strip()
            if 'Supported ports' in key:
                response['supported-ports'] = _parse_ports_list(val)
            elif 'Supported link modes' in key:
                new_i, link_modes = _parse_link_modes(val, i, lines)
                i = new_i
                response['supported-link-modes'] = link_modes
            elif 'Supported pause frame use' in key:
                response['supported-pause-frame-use'] = val
            elif 'Supports auto-negotiation' in key:
                response['supports-auto-negotiation'] = val
            elif 'Supported FEC modes' in key:
                response['supported-fec-modes'] = _parse_fec_modes(val)
            elif 'Advertised link modes' in key:
                new_i, link_modes = _parse_link_modes(val, i, lines)
                i = new_i
                response['advertised-link-modes'] = link_modes
            elif 'Advertised pause frame use' in key:
                response['advertised-pause-frame-use'] = val
            elif 'Advertised auto-negotiation' in key:
                response['advertised-auto-negotiation'] = val
            elif 'Advertised FEC modes' in key:
                response['advertised-fec-modes'] = _parse_fec_modes(val)
            elif 'Speed' in key:
                response['speed'] = val
            elif 'Duplex' in key:
                response['duplex'] = val
            elif 'Port' in key:
                response['port'] = val
            elif 'PHYAD' in key:
                response['phyad'] = val
            elif 'Transceiver' in key:
                response['transceiver'] = val
            elif 'Auto-negotiation' in key:
                response['auto-negotiation'] = val
            elif 'Link detected' in key:
                response['link-detected'] = val
        i += 1

    return response


def ethtool_stats_get(ctx, interface_id):
    response = {}
    output = _get(ctx, 'ethtool', if_id=interface_id, options='-S')
    if not output:
        return {}

    output = output.split('\n')
    for line in output:
        split = line.split(':')
        if len(split) > 1 and ('rx_queue' in split[0] or 'tx_queue' in
                               split[0]):
            key, val = split
            response[key.strip()] = int(val.strip())
    return response


def ethtool_fec_get(ctx, interface_id):
    """ Example output from 'sudo ethtool --show-fec swp1'

        FEC parameters for swp1:
        Configured FEC encodings: Off
        Active FEC encoding: None
    """
    response = {}
    output = _get(ctx, 'ethtool', if_id=interface_id, options='--show-fec')
    if not output:
        return {}

    output = output.split('\n')
    for line in output:
        split = line.split(':')
        if len(split) == 2:
            if 'Configured FEC encodings' in split[0]:
                response['configured-encodings'] = split[1].strip()
            elif 'Active FEC encoding' in split[0]:
                response['active-encodings'] = split[1].strip()
    return response


def ip_get(ctx, obj, options='', if_id=''):
    """
    Call iproute2 ip command with options provided

    obj should be one of:
       link | address | addrlabel | route | rule | neigh | ntable |
       tunnel | tuntap | maddress | mroute | mrule | monitor | xfrm |
       netns | l2tp | fou | macsec | tcp_metrics | token | netconf | ila |
       vrf | sr | nexthop

    :return: If found, list of the one requested object.  If not found, empty
    list.
    """
    return _get(ctx, 'ip', obj, options, if_id)


def bridge_get(ctx, obj, options='', if_id='', if_type='', show_type=''):
    """
    Call iproute2 bridge command with options provided

    obj should be one of:
       link | fdb | mdb | vlan | monitor

    if_id - interface id
    if_type - One of:
        br | brport | vlan | state
    show_type - Only alternative show type supported currently is 'tunnelshow'

    :return: list of requested objects or db entries
             in json form
    """
    return _get(ctx, 'bridge', obj, options, if_id, if_type, show_type)


def clagctl_get(ctx, obj='', options=''):
    """
    Call clagctl command with options provided

    :return: dict of clag interfaces and status information
             in json form
    """
    return _get(ctx, 'clagctl', obj=obj, options=options)


def mstpctl_get(ctx, obj='', options='', if_id=''):
    """
    Call mstpctl command with options provided

    :return: dict of mstpctl information
    """
    return _get(ctx, 'mstpctl', obj=obj, options=options, if_id=if_id)


def ip_addrs_get(ctx):
    """
    Get a list of links with address information

    :return: list of ifinfomsg dictionaries for
             each link with addr_info attached
    """
    return ip_get(ctx, 'address', '-j -s -s -d')


def ip_addr_get(ctx, if_id):
    """
    Get a single link with address information

    :return: ifinfomsg dictionary for link
             with addr_info attached
    """
    return ip_get(ctx, 'address', '-j -s -s -d', if_id)


def ip_bridges_get(ctx):
    """
    Get a list of bridge links

    :return: list of ifinfomsg dictionaries for each bridge link with
             linkinfo attached
    """
    return ip_get(ctx, 'link', '-j -d -f bridge')


def ip_bridge_get(ctx, if_id):
    """
    Get a specific bridge links

    :return: ifinfomsg dictionaries for the link with
             linkinfo attached
    """
    return ip_get(ctx, 'link', '-j -d -f bridge', if_id)


#  def ip_neighbors_get(ctx):
#      """
#      Get a list of ip neighbors
#
#      :return: list of dictionaries for each neighbor
#      """
#      return ip_get(ctx, 'neighbor')


def ipv4_neighbors_get(ctx):
    """
    Get a list of ipv4 neighbors

    :return: list of dictionaries for each neighbor
    """
    return ip_get(ctx, 'neighbor', options='-j -f inet')


def ipv6_neighbors_get(ctx):
    """
    Get a list of ipv6 neighbors

    :return: list of dictionaries for each neighbor
    """
    return ip_get(ctx, 'neighbor', options='-j -f inet6')


def bridge_fdb_get(ctx, if_name, if_type=''):
    """
    Get a list of bridge fdb entries

    if_name - interface name
    if_type - One of:
        br | brport | vlan | state

    :return: list of fdb entry dictionaries
    """
    return bridge_get(ctx, 'fdb', '-d -j -s', if_name, if_type)


def ifs_bridge_vlans_get(ctx):
    """
    Get a list of bridge vlan entries

    :return: list of interfaces and their vlans
    """
    return bridge_get(ctx, 'vlan', '-j')


def if_bridge_vlans_get(ctx, if_id):
    """
    Get vlan entries for a particular port.

    The response from bridge get is a list of
    dicts containing ports and their vlans.  Since
    we are only interested in a single port, we can
    just return the list of vlans.

    :return: list of interfaces and their vlans
    """
    res = bridge_get(ctx, 'vlan', '-j', if_id)
    if res:
        res = res[0]['vlans']
    ip_res = ip_get(ctx, 'link', '-j -f bridge', if_id)
    res.append(ip_res[0])

    return res


def if_bridge_vlans_tunnels_get(ctx):
    """
    Get vlan tunnelshow entries for all ports.

    :return: list of vlans and vni mappings
    """
    return bridge_get(ctx, 'vlan', '-j', show_type='tunnelshow')


def if_bridge_vlan_tunnels_get(ctx, if_id):
    """
    Get vlan tunnelshow entries for a particular port.

    The response from bridge get is a list of
    dicts containing vlan and vni mappings.  Since
    we are only interested in a single port, we can
    just return the list of vlan and vni mappings.

    :return: list of vlans and vni mappings
    """
    res = bridge_get(ctx, 'vlan', '-j', if_id, show_type='tunnelshow')
    if res:
        res = res[0]['tunnels']

    return res


def mlag_info_get(ctx):
    """
    Get MLAG information using clagctl

    :return: dict of MLAG interfaces and status info
    """
    return clagctl_get(ctx, options='-j')


def mstpctl_bridge_get(ctx, if_id):
    """
    Get mstpctl bridge port details

    :return: dict of mstpctl bridge ports
    """

    output = mstpctl_get(ctx, obj='br_default', options='showportdetail',
                         if_id=if_id)
    if "errorMsg" in output:
        return output
    else:
        return _parse_showportdetail(output)


############################################################
# Ethtool parsing
############################################################
def _parse_ports_list(list_str):
    res = []
    m = re.match(r'\[(.*)\]', list_str)
    if m:
        if m.group(1) == ' ':
            return res
        res = [s for s in m.group(1).strip().split(' ')]
    return res


def _parse_link_modes(val, i, lines):
    """
    Parse the link modes starting at the line containing the key
    "Supported link modes" or "Advertised link modes"

    Example output from ethtool:
        Supported link modes:   1000baseT/Full
                                10000baseT/Full
                                10000baseCR/Full
                                10000baseSR/Full
                                10000baseLR/Full
                                10000baseLRM/Full
                                10000baseER/Full
    """
    link_modes = [val]
    i += 1
    while i < len(lines):
        m = re.match(r'\d+base.*', lines[i].strip())
        if not m:
            break
        link_modes.append(lines[i].strip())
        i += 1

    return (i - 1, link_modes)


def _parse_fec_modes(val):
    if 'Not reported' in val:
        return [val]
    modes = val.split(' ')
    return modes


############################################################
# mstpctl parsing
############################################################
def _parse_showportdetail(show_output):
    res = {}
    pattern = (r'^\s+(\S.{0,18})\s*(\S.{0,23})'
               r'(\s*(\S.{0,20})\s*(\S.{0,16}))?')

    if not show_output:
        return {}
    for line in show_output.split('\n'):
        m = re.match(pattern, line)
        if m:
            g = m.groups()
            res[g[0].strip()] = g[1].strip()
            if g[3] is not None:
                res[g[3].strip()] = g[4].strip()
    return res
