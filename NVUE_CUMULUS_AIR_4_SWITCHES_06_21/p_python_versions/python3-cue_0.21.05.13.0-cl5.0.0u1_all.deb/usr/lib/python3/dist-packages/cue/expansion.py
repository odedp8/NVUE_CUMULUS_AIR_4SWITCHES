# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from dataclasses import dataclass, field

# Utilities to expand parameters.
# TODO CUE-2152 CUE-2164


class ExpansionError(Exception):
    """
    Top level exception for all expansion-related errors.
    """
    pass


def expand_number_range(range_token):
    """
    Given a string number range token (e.g., "8-10"), return the expanded list
    of numbers specified by the range.

    Args:
        range_token: A string range token, specifying a range of numbers.

    Returns:
        The expanded list of tokens specified by the input range_token.

    Raises:
        ExpansionError when the given range cannot be expanded
    """
    expanded = []
    for subrange in range_token.split(","):
        # Quick and dirty globbing for number ranges
        if "-" in subrange:
            begin_str, _, end_str = subrange.partition("-")
            try:
                begin = int(begin_str)
                end = int(end_str)
            except ValueError:
                raise ExpansionError(
                    f"Could not expand number range {repr(subrange)}"
                )

            has_leading_zero = (
                (begin_str.startswith("0") and begin_str != "0")
                or (end_str.startswith("0") and end_str != "0")
            )

            if has_leading_zero:
                raise ExpansionError(
                    "Can't expand numbers containing leading '0':"
                    + f" {repr(subrange)}"
                )

            if begin >= end:
                raise ExpansionError(
                    "Lower bound of range needs to come first:"
                    + f" {repr(range_token)}"
                )

            # Use range to list the subrange, then cast them to strings.
            expanded.extend(map(str, range(begin, end + 1)))
        else:
            # Not a range.  Just add it to the list
            try:
                int(subrange)
            except ValueError:
                raise ExpansionError(
                    f"Expected range of numbers: {repr(range_token)}",
                )
            has_leading_zero = subrange.startswith("0") and subrange != "0"
            if has_leading_zero:
                raise ExpansionError(
                    "Can't expand numbers containing leading '0':"
                    + f" {repr(range_token)}"
                )

            expanded.append(subrange)

    return expanded


def _simplify_sequential(numbers):
    if len(numbers) == 1:
        return str(numbers[0])
    else:
        start = numbers[0]
        end = numbers[-1]
        return f"{start}-{end}"


def simplify_numbers(numbers):
    """
    Return a single number range token representing the given numbers.
    """
    range_tokens = []
    sequential_nums = []
    for number in sorted(set(map(int, numbers))):
        try:
            next_in_sequence = sequential_nums[-1] + 1
        except IndexError:
            # The sequence is empty, so we'll put `number` in there no matter
            # what.
            next_in_sequence = number

        if number != next_in_sequence:
            # Not in sequence with the previous numbers. Cut it off and start a
            # new sequence.
            range_tokens.append(_simplify_sequential(sequential_nums))
            sequential_nums = []

        sequential_nums.append(number)

    # Get the last group in there.
    if sequential_nums:
        range_tokens.append(_simplify_sequential(sequential_nums))
    return ",".join(range_tokens)


########################
# Name range expansion
########################
def split_base_name_from_number_range(name_token):
    """
    Split a name token into its base name and number range.
    """
    # Find the index of the first character of the number range token.
    found_idx = len(name_token)
    # Count the dashes to ensure we only include one.
    seen_dashes = 0
    for idx, char in reversed(list(enumerate(name_token))):
        if char == "-":
            seen_dashes = seen_dashes + 1

        # EARLY BREAK
        if not (char.isdigit() or char == "-") or seen_dashes > 1:
            break
        found_idx = idx

    base_name = name_token[:found_idx]
    num_range_token = name_token[found_idx:]

    if num_range_token.startswith("-"):
        # "vni-1000,1010" is fine.
        base_name = base_name + "-"
        num_range_token = num_range_token[1:]
    elif base_name.endswith("-") and "-" in num_range_token:
        # "spine-1-2" doesn't expand to "spine-1,spine-2".
        base_name = name_token
        # TODO: consider making "spine-1-2,3" expand to "spine-1-2,spine-1-3".
        #       That's a weird enough case that it might be better to throw an
        #       error whenever a user puts modifiers after it.
        num_range_token = ""
    return (base_name, num_range_token)


@dataclass
class NameGroup:
    """
    A portion of an expandable range that share's a single base name. For
    example, given an expandable name "swp1-9,11-12,15,eth0", the name groups
    would be "swp1-9,11-12,15" and "eth0". Each NameGroup is split into one
    `name_token` (the first comma-separated value, e.g. "swp1-9") and a list of
    `modifier_tokens` (the number range tokens that follow the `name_token`,
    e.g. "11-12" and "15").

    Attributes:
        name_token: The string token of an expandable group that contains the
            base name to prepend to all the modifying number ranges. The
            `name_token` may also contain a number range at the end, which will
            be expanded and treated as a modifier.
        modifier_tokens: A list of string number modifiers that modify the base
            name. These should already be expanded by the time they get into
            this data structure, since expanding a number range is the easiest
            way to check if a number range can be expanded.
    """

    name_token: str = ""
    modifier_tokens: list = field(default_factory=list)


def expand_name_range(range_token):
    """
    Given a string name range token (e.g., "swp8-10"), return the expanded list
    of names specified by the range.

    Args:
        range_token: A string range token, specifying a range of names.

    Returns:
        The expanded list of tokens specified by the input range_token.
    """
    if range_token.startswith("="):
        # The user doesn't want us to expand anything. Drop the leading "=" and
        # return the input as is.
        return [range_token[1:]]

    # Empty strings, or strings that would be empty if we removed all the
    # whitespace and commas aren't allowed.
    if range_token.strip(" ,") == "":
        raise ExpansionError(
            "Cannot use an empty string where range expansion is supported:"
            + f" {repr(range_token)}"
        )

    # Don't attempt expansion when whitespace is involved
    if " " in range_token:
        return [range_token]

    subranges = range_token.split(",")

    # Group name tokens with all the modifying number ranges that follow it.
    name_groups = [NameGroup()]
    current_group = name_groups[0]
    for sub in subranges:
        # First, validate that each subrange looks okay.
        if sub == "":
            raise ExpansionError(
                f"Cannot have an empty subrange: {repr(range_token)}"
            )
        elif sub.strip("-") == "":
            raise ExpansionError(
                f"Cannot have a lonesome '-': {repr(range_token)}"
            )
        # Now, categorize/store it based off of whether it's a name token or a
        # number range token.
        try:
            current_group.modifier_tokens.extend(
                # NOTE: Store it in its expanded form so we don't have to do it
                #       again later
                expand_number_range(sub)
            )
        except ExpansionError:
            # If it can't be expanded as a number, it's a name token. Create a
            # new token for the subrange and set that as  the current group.
            name_groups.append(
                NameGroup(name_token=sub)
            )
            current_group = name_groups[-1]

    # Expand and collect all name groups.
    expanded_names = []
    for group in name_groups:
        name_token = group.name_token
        modifier_tokens = group.modifier_tokens

        base_name, num_range_token = split_base_name_from_number_range(
            name_token
        )

        if num_range_token != "":
            # Only try to parse it if we've got it. An empty num_range_token is
            # valid here, even though it won't parse as a number range.
            try:
                expanded_suffix = expand_number_range(num_range_token)
            except ExpansionError:
                should_pass = (
                    # "foo03" is okay
                    num_range_token.startswith("0")
                    # "foo03,4" is NOT okay. (It's ambiguous.)
                    and modifier_tokens == []
                    # "foo03-4" is still not okay
                    and "-" not in num_range_token
                )
                if should_pass:
                    # This is okay. Just use the num_range_token and move on.
                    expanded_suffix = [num_range_token]
                else:
                    raise ExpansionError(
                        "Could not expand number range"
                        + f" {repr(num_range_token)} in {repr(range_token)}"
                    )
        elif name_token == "":
            # HACK: This happens when the first token of the full range isn't a
            #       number range, e.g., "swp1-3".
            #       "But that's almost every case!" I hear you say.
            #       Yes. Yes it is. But this is the simplest way I could think
            #       of to handle that divergence.
            expanded_suffix = []
        elif modifier_tokens != []:
            # e.g., "lo,1" (I have no idea what to do with that!)
            raise ExpansionError(
                "Ambiguous expansion. Can't have number ranges following a"
                + " name token that doesn't end with a number range:"
                + f" {repr(range_token)}"
            )
        else:
            # e.g., "lo"
            # We need to put an empty string in here, otherwise we'll be adding
            # the base_name 0 times.
            expanded_suffix = [""]

        # Add modifiers from expanding the base name's suffix. Since it's
        # coming first, it should come before the other modifiers.
        modifier_tokens = [
            *expanded_suffix,
            *modifier_tokens,
        ]

        expanded_names.extend((
            f"{base_name}{mod}"
            for mod in modifier_tokens
        ))

    # Dedupe the results while perserving order.
    return list(dict.fromkeys(expanded_names))


def simplify_names(names):
    """
    Return a sequence of name range tokens, unexpanded to as few tokens as
    possible.
    """
    nums_by_base_name = {}
    no_expands = []
    for name in sorted(names):
        # EARLY CONTINUE
        if len(expand_name_range(name)) > 1:
            # Can't safely be simplified. Prefix it and don't mess with it.
            no_expands.append(f"={name}")
            continue
        base, num = split_base_name_from_number_range(name)
        if num.startswith("0") and len(num) > 1:
            base = name
            num = ""
        numbers = nums_by_base_name.setdefault(base, [])
        if num != "":
            numbers.append(num)

    name_ranges = []
    for base, numbers in nums_by_base_name.items():
        simplified_nums = simplify_numbers(numbers)
        name_ranges.append(f"{base}{simplified_nums}")

    simplified_tokens = tuple()
    name_range = ",".join(name_ranges)
    if name_range:
        simplified_tokens = (*simplified_tokens, name_range)

    simplified_tokens = (*simplified_tokens, *no_expands)
    return simplified_tokens
