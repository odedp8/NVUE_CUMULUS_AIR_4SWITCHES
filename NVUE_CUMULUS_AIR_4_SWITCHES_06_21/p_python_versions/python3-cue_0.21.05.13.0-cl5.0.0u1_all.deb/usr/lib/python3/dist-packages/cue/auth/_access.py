# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
import logging
from flask import request
from cue import utils
from cue.exceptions import Forbidden
from ruamel.yaml import YAML
from importlib import resources
from jsonschema import validate, ValidationError
from pathlib import Path
from dataclasses import dataclass


logger = logging.getLogger(__package__)


AUTH_CONFIG_PATH = Path("/etc/cue-auth.yaml")


WILDCARD_TOKEN = "*"


ALLOW_ACTION = "allow"
DENY_ACTION = "deny"


class AuthConfigDuplicateReasonError(Exception):
    """
    Every rule in cue-auth.yaml must have a unique reason.
    """
    pass


def check_authorization():
    """
    Check whether or not the requesting user has access to the requested
    resource.

    Raises:
        cue.exceptions.Forbidden if the user doesn't have access.
    """
    return get_auth_config().check_authorization()


# Only load schema once. Cache it here.
_schema = None


def get_auth_schema():
    """
    Get the JSON Schema for validating cue-auth.yaml.
    """
    global _schema
    # EARLY RETURN
    if _schema is not None:
        return _schema

    # NOTE: Can't use cue.utils.yaml_load here, because there's recursion in
    #       the schema's $refs
    with resources.path(__package__, "cue-auth.schema.yaml") as src:
        _schema = YAML(typ="rt").load(src)
        return _schema


def validate_auth_config(parsed_config):
    """
    Validate the loaded cue-auth.yaml.

    Raises:
        utils.ParseError if invalid.
    """
    try:
        validate(instance=parsed_config, schema=get_auth_schema())
    except ValidationError as err:
        location = utils.find_location(parsed_config, err.absolute_path)
        utils.raise_parse_error(
            location,
            # NOTE: flake8 wants us to use str(err) instead of err.message, but
            #       for ValidationError, str and message are different. We want
            #       message.
            err.message,  # noqa: B306
        )

    rules = parsed_config.get("rules", [])
    seen_reasons = set()
    for idx, rule in enumerate(rules):
        reason = rule["reason"]
        if reason in seen_reasons:
            location = utils.find_location(
                parsed_config, ('rules', idx, 'reason')
            )
            utils.raise_parse_error(
                location,
                f"Each rule's reason must be unique: {reason!r}"
            )
        seen_reasons.add(reason)


# Only load cue-auth.yaml once. Cache it here.
_auth_config = None


def get_auth_config() -> "AuthConfig":
    """
    Load cue-auth.yaml, validate it, and return it as an AuthConfig object.
    """
    global _auth_config
    if _auth_config is not None:
        return _auth_config

    found_auth = {}
    try:
        loaded = utils.yaml_load(AUTH_CONFIG_PATH)
        validate_auth_config(loaded)
    except FileNotFoundError:
        logger.warning(
            '%s does not exist. Non-root users will be forbidden.',
            AUTH_CONFIG_PATH,
        )
    except utils.ParseError as err:
        # This can come from yaml_load or validation. Either way, we want to
        # crash cued with no survivors.
        msg = str(err)
        logger.error(msg)
        raise SystemExit(1)
    else:
        found_auth = loaded
        logger.info(
            "Loaded %s",
            AUTH_CONFIG_PATH
        )

    _auth_config = AuthConfig(**found_auth)
    return _auth_config


@dataclass
class AuthConfig:
    """
    A wrapped cue-auth.yaml with handy utilities.

    Use check_authorization to see if the current flask request context has
    access to the resource it's requesting.
    """

    rules: tuple = ()

    def __post_init__(self):
        self.rules = tuple(
            AuthorizationRule(**{
                # Convert the attrs from kebabs to snakes
                attr.replace('-', '_'): value
                for attr, value in rule.items()
            })
            for rule in self.rules
        )

    def check_authorization(self):
        """
        Allow/deny the current flask request based off the rules.

        Raises:
            cue.exceptions.Forbidden if request is denied.
        """
        # EARLY RETURN
        if request.is_root:
            # root is always cool
            return
        action = None
        for rule in self.rules:
            action = rule(
                req_path=request.path,
                req_method=request.method,
                conn_username=request.username,
                conn_user_groups=request.user_groups,
            )
            # EARLY BREAK
            if action:
                break

        # EARLY RETURN
        if action == ALLOW_ACTION:
            # Everything past this point will result in a 403 forbidden
            # response.
            return

        logger_dump_args = [
            "Denying",
            repr(request.username),
            f'"{request.method} {request.path}"',
        ]
        if action == DENY_ACTION:
            logger.dump(
                *logger_dump_args,
                'because:',
                rule.reason
            )
        else:
            logger.dump(
                *logger_dump_args,
                '(no rule matched)',
            )

        # NOTE: don't tell the client WHY they're forbidden. (It'll show up
        #       in the response, and we don't necessarily want anyone to be
        #       able to probe our endpoints to learn about the rules.)
        raise Forbidden()


@dataclass
class AuthorizationRule:
    """
    Callable wrapper around an auth rule.

    Returns this rule's action if the request is a match. Otherwise None.
    """
    reason: str
    action: str
    match_request: 'RequestMatcher'
    match_user: 'UserMatcher'

    def __post_init__(self):
        self.match_request = RequestMatcher(**self.match_request)
        self.match_user = UserMatcher(**self.match_user)

    def __call__(self, req_path, req_method, conn_username, conn_user_groups):
        if (
            self.match_user(conn_username, conn_user_groups)
            and self.match_request(req_path, req_method)
        ):
            return self.action
        else:
            return None


def _ensure_collection(maybe_string, cls=frozenset):
    if isinstance(maybe_string, str):
        return cls([maybe_string])
    else:
        return cls(maybe_string)


@dataclass
class RequestMatcher:
    """
    Callable wrapper around "match-request" data.

    Returns True when given data is a match, otherwise False.

        >>> matcher = RequestMatcher('*', 'GET')
        >>> matcher('/foo/bar', 'GET')
        True
        >>> matcher('/foo/bar', 'PATCH')
        False

    """
    path: frozenset
    method: frozenset

    class _Wildcard:
        def __contains__(self, *_):
            return True

    def __post_init__(self):
        for attr, value in vars(self).items():
            if value == WILDCARD_TOKEN:
                setattr(self, attr, self._Wildcard())
            else:
                setattr(self, attr, _ensure_collection(value))

    def __call__(self, req_path, req_method):
        return (
            req_path in self.path
            and req_method in self.method
        )


@dataclass
class UserMatcher:
    """
    Callable wrapper around "match-user" data.

    Returns True when given data is a match, otherwise False.

        >>> matcher = UserMatcher(name='bob')
        >>> matcher('bob', [])
        True
        >>> matcher('alice', [])
        False

    """
    name: frozenset = ()
    group: frozenset = ()

    def __post_init__(self):
        for attr, value in vars(self).items():
            setattr(self, attr, _ensure_collection(value))

    def __call__(self, conn_username, conn_user_groups):
        return (
            conn_username in self.name
            or any(
                group in self.group
                for group in conn_user_groups
            )
        )
