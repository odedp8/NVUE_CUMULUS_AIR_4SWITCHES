# Copyright (C) 2018-2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.service import service_patch


###############################
# PTPs
###############################

def ptps_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getPtps(rev)
    ds = {}
    ptp_conf = ctx.linuxptp_v1.getPtpInstanceConfig('1')
    ds['1'] = ptp_conf
    return ds


def ptps_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"ptp": body})
    return service.get("ptp", {})


def ptps_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPtps,
                             ctx.config_v1.setPtps, rev)


###############################
# PTP instance
###############################

def ptp_get(ctx, rev, instance_id):
    if rev != "operational":
        ptp = ctx.config_v1.getPtp(rev, instance_id)
        return ptp

    ptp = ctx.linuxptp_v1.getPtpInstance(instance_id)
    return ptp


def ptp_patch(ctx, rev, instance_id, body=None):
    service = ptps_patch(ctx, rev, {instance_id: body})
    return service.get(instance_id, {})


def ptp_delete(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPtp,
                             ctx.config_v1.setPtp, rev, instance_id)

###############################
# PTP acceptable masters
###############################


def ptp_acc_masters_get(ctx, rev, instance_id):
    if rev != "operational":
        ptp = ctx.config_v1.getPtp(rev, instance_id)
        return ptp["acceptable-master"]

    return ctx.linuxptp_v1.getAccMasters(instance_id)


def ptp_acc_masters_patch(ctx, rev, instance_id, body=None):
    ptp = ptp_patch(ctx, rev, instance_id, {"acceptable-master": body})
    return ptp.get("acceptable-master", {})


def ptp_acc_masters_delete(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPtp,
                             ctx.config_v1.setPtp, rev, instance_id,
                             "acceptable-master")


def ptp_acc_master_get(ctx, rev, instance_id, clock_id):
    masters = ptp_acc_masters_get(ctx, rev, instance_id)
    try:
        return masters[clock_id]
    except KeyError:
        raise NotFound


def ptp_acc_master_patch(ctx, rev, instance_id, clock_id, body=None):
    masters = ptp_acc_masters_patch(ctx, rev, instance_id,
                                    {clock_id: body})
    return masters.get(clock_id, {})


def ptp_acc_master_delete(ctx, rev, instance_id, clock_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPtp,
                             ctx.config_v1.setPtp, rev, instance_id,
                             "acceptable-master", clock_id)


###############################
# PTP monitor
###############################

def ptp_monitor_get(ctx, rev, instance_id):
    if rev != "operational":
        ptp = ctx.config_v1.getPtp(rev, instance_id)
        return ptp["monitor"]

    mon = ctx.linuxptp_v1.getMonitorConfig(instance_id)
    return mon


def ptp_monitor_patch(ctx, rev, instance_id, body=None):
    ptp = ptp_patch(ctx, rev, instance_id, {"monitor": body})
    return ptp.get("monitor", {})


def ptp_monitor_delete(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getPtp,
                             ctx.config_v1.setPtp, rev, instance_id,
                             "monitor")


###############################
# PTP violations
###############################

def ptp_violations_get(ctx, rev, instance_id):
    raise NotFound


###############################
# PTP forced master violations
###############################

def ptp_violations_fms_get(ctx, rev, instance_id):
    raise NotFound


###############################
# PTP forced master violation
###############################

def ptp_violations_fm_get(ctx, rev, instance_id, clock_id):
    raise NotFound


###############################
# PTP acceptable master violations
###############################

def ptp_violations_ams_get(ctx, rev, instance_id):
    raise NotFound


###############################
# PTP acceptable master violation
###############################

def ptp_violations_am_get(ctx, rev, instance_id, clock_id):
    raise NotFound


###############################
# PTP current status
###############################

def ptp_current_get(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.linuxptp_v1.getPtpCurrentDS(instance_id)


###############################
# PTP clock quality status
###############################

def ptp_clock_quality_get(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.linuxptp_v1.getPtpClockQuality(instance_id)


###############################
# PTP parent status
###############################

def ptp_parent_get(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.linuxptp_v1.getPtpParentDS(instance_id)


###############################
# PTP parent clock status
###############################

def ptp_parent_gm_clock_get(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    parent = ctx.linuxptp_v1.getPtpParentDS(instance_id)
    return parent["grandmaster-clock-quality"]


###############################
# PTP time status
###############################

def ptp_time_get(ctx, rev, instance_id):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.linuxptp_v1.getPtpTimeProperties(instance_id)
