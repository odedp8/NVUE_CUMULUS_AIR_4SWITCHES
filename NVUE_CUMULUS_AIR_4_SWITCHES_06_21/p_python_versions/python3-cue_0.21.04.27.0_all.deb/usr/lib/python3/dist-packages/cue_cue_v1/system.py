# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue import utils
from cue_cue_v1.root import root_patch


###############################
# System
###############################

def system_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getSystem(rev)

    # Todo
    return {}


def system_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"system": body})
    return root.get("system", {})


def system_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getSystem,
                             ctx.config_v1.setSystem, rev)


###############################
# Global
###############################

def global_get(ctx, rev):
    system_mac = None

    if rev == 'operational':
        system_mac = ctx.platform_v1.getHardware().get('system-mac')

        # Can only get global applied config, not operational
        rev = 'applied'

    global_config = ctx.config_v1.getGlobal(rev)
    # If 'system-mac' is set to 'auto' we'll try to get it from eeprom
    if system_mac and global_config['system-mac'] == 'auto':
        global_config['system-mac'] = system_mac

    return global_config


def global_patch(ctx, rev, body=None):
    system = system_patch(ctx, rev, {"global": body})
    return system.get("global", {})


def global_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getGlobal, ctx.config_v1.setGlobal,
                             rev)


###############################
# Reserved
###############################

def reserved_get(ctx, rev):
    if rev == 'operational':
        # Can only get reserved applied config, not operational
        rev = 'applied'

    return ctx.config_v1.getReserved(rev)


def reserved_patch(ctx, rev, body=None):
    global_ = global_patch(ctx, rev, {"reserved": body})
    return global_.get("reserved", {})


def reserved_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getReserved,
                             ctx.config_v1.setReserved, rev)


###############################
# Routing-table
###############################

def routing_table_get(ctx, rev):
    return reserved_get(ctx, rev)["routing-table"]


def routing_table_patch(ctx, rev, body=None):
    reserved = reserved_patch(ctx, rev, {"routing-table": body})
    return reserved.get("routing-table", {})


def routing_table_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getReserved,
                             ctx.config_v1.setReserved, rev, "routing-table")


###############################
# PBR
###############################

def pbr_get(ctx, rev):
    return routing_table_get(ctx, rev)["pbr"]


def pbr_patch(ctx, rev, body=None):
    rt = routing_table_patch(ctx, rev, {"pbr": body})
    return rt.get("pbr", {})


def pbr_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getReserved,
                             ctx.config_v1.setReserved, rev, "routing-table",
                             "pbr")


###############################
# Reboot reason
###############################

def reboot_get(ctx, rev):
    return {
        "reason": ctx.cue_v1.getRebootReason(rev),
        "history": ctx.cue_v1.getRebootHistory(rev),
    }


def reboot_reason_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return utils.fast_merge(
        {
            # Default any non-existent keys to 'unknown'
            key: 'unknown'
            for key in ['gentime', 'reason', 'user']
        },
        ctx.platform_v1.getRebootReason()
    )


def reboot_history_get(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_get_oper_only(rev)
    return ctx.platform_v1.getRebootHistory()
