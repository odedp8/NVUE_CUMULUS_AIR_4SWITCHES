# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from pydash import py_
from cue_cue_v1.morphers import root_patch_expand, root_patch_prepare


##############
# Endpoints
##############
def root_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getRoot(rev)

    # TODO
    return {}


def root_patch(ctx, rev, body=None):
    ops = ctx.cue_v1._ops
    body = ops.pre_patch(rev, body)

    # Expand the patch (deglob, derive, etc.)
    expanded = body
    root_patch_expand(expanded)

    # Build the prepare patch.  We use the expanded patch to seed the prepare
    # morpher so we don't need to worry about globs, or other things that might
    # be derived, while worrying about prepare.  But that also means that if
    # something isn't touched by the prepare morpher and just passes through,
    # we'll end up merging it into the config twice.  But that's OK; the result
    # is the same and the user doesn't see it.
    prepare = py_.clone_deep(expanded)
    root_patch_prepare(prepare)

    return ops.patch_config(
        ctx.config_v1.getRoot, ctx.config_v1.setRoot,
        rev, patch=expanded, prepare=prepare)


def root_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getRoot, ctx.config_v1.setRoot, rev)
