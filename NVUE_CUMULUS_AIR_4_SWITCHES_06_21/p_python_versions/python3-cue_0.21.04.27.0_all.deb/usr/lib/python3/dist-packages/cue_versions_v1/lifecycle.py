# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from dataclasses import dataclass, field
from functools import partial
from cue.events import AbstractEvent
from cue.states import validate_transition
from . import repo, startup, empty


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    repo.prepare_repo(ctx)
    startup.prepare_startup(ctx)
    empty.prepare_empty(ctx)
    ctx.events.main_prepared.register("versions_v1", handle_main_prepared)
    ctx.events.init_revision_transitions.register(
        "versions_v1", handle_init_revision_transitions
    )


@dataclass
class InitRevisionTransitionsEvent(AbstractEvent):
    """
    Event context for initializing the revision FSM transitions. Upon exiting
    this event context, a `validate_transition` callable will be added to
    `target` as an attribute (ie, `target.validate_transition`).
    """

    target: object
    entry_states: set = field(default_factory=set)
    transitions: dict = field(default_factory=dict)

    def add_entry_state(self, entry_state):
        """
        Add `entry_state` as an allowed transition from a terminal state.
        """
        self.entry_states.add(entry_state)

    def update_transitions(self, transitions):
        """
        Update the revision transitions with `transitions`.
        """
        self.transitions.update(transitions)

    def __exit__(self, *args):
        # Bake the validation function with args and attach it to target.
        self.target.validate_transition = partial(
            validate_transition, self.entry_states, self.transitions
        )


@dataclass
class CleanupRevisionsEvent(AbstractEvent):
    """
    Event context for cleaning up "stuck" revision FSMs. Inside this context,
    invalid transitions are allowed.
    """
    versions_v1: object

    def __enter__(self):
        # HACK: Assume that we're running before the validator has actually
        #       been initialized. Don't bother checking if we're clobbering
        #       anything.
        self.versions_v1.validate_transition = lambda *_: None

    def __exit__(self, *args):
        delattr(self.versions_v1, "validate_transition")


def handle_main_prepared(evt):
    ctx = evt.ctx
    # Before initializing the revision state machine, clean up the revisions.
    # ORDER MATTERS: The cleanup_revisions event has to go first, since it's
    #       going to set a 'noop' transition validator on versions_v1 while
    #       handling the event. We don't want to overwrite the real validator
    #       with our noop one, nor do we want to use the real validator. (The
    #       whole point of cleanup_revisions is to circumvent the transitions
    #       to unstick revisions that are in non-terminal states.)
    ctx.events.cleanup_revisions(
        CleanupRevisionsEvent(ctx.versions_v1)
    )
    # Now that we've cleaned up the revisions, we can initialize the revision
    # state transitions and start enforcing them.
    ctx.events.init_revision_transitions(
        InitRevisionTransitionsEvent(ctx.versions_v1)
    )


def handle_init_revision_transitions(evt):
    # Sometimes, it makes sense to clear a terminal state and reset it to
    # "pending".
    evt.add_entry_state("pending")
