# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from pathlib import Path
import logging
from . import revman
from cue import config


logger = logging.getLogger(__name__)


class RevManager(revman.RevManager):
    """
    Fetch the startup "revision" inside a "with" block.
    """

    def start_write(self, commit_msg):
        """
        Prepare to write.  This is a no-op.  We're always ready to write.  The
        commit_msg is ignored.
        """
        pass

    def start_branch(self, branch_name):
        """
        Raise an exception; you can't branch startup.
        """
        raise RuntimeError("Cannot branch startup")

    def merge_branch(self, branch_name, commit_msg):
        """
        Raise an exception; you can't branch startup.
        """
        raise RuntimeError("Cannot branch startup")

    def create_tag(self, tag_name, target=None):
        """
        Raise an exception; you can't tag startup.
        """
        raise RuntimeError("Cannot tag startup")

    def run_file(self, filename, shell):
        """
        Raise an exception; you can't run files in startup.
        """
        raise RuntimeError("Cannot run files in startup")

    def __enter__(self):
        """
        Start using the startup revision.
        """
        # There's nothing to prepare.  We assume the directory always exists.
        return self

    def __exit__(self, t, v, b):
        """
        Start using the startup revision.
        """
        pass


class StartupImpl:
    """
    Implementation class for startup.  It holds the ctx and config path
    determined at init to provide a simplified interface.
    """
    def __init__(self, ctx, root):
        self.ctx = ctx
        self.root = root

    def get_revman(self):
        """
        Given a revisionId, return a RevManager for it.  The RevManager is a
        with-able object under which the revision can be accessed.
        """
        return RevManager(self.ctx, self.root)


def prepare_startup(ctx, config_dir=config.PUBLIC_CONFIG_ROOT):
    """
    Make sure the config directory has been created and create the get_revman()
    accessor.
    """
    config_path = Path(config_dir)
    if not config_path.exists():
        raise FileNotFoundError(
            "Missing configuration directory at " + str(config_path))

    # Create the _startup implementation.
    ctx.versions_v1._startup = StartupImpl(ctx, config_path)
