# Copyright (C) 2018-2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from pathlib import Path
import logging
from cue import config, utils
from . import revman
import threading
import contextlib


logger = logging.getLogger(__name__)

repo_lock = threading.RLock()
"""
Lock around the git repo, allowing only one thread at a time to use it.
"""

repo_rev = []
"""
Stack of revisions that have been checked out.  Since we only allow one thread
and that one thread must checkout the same revision, this is really just a
count of nested revmans.  For now, at least.
"""


meta_lock = threading.RLock()
"""
Lock around the metadata worktree, allowing only one thread at a time to use
it.  git seems to tolerate concurrent actions as long as they happen in
different worktrees, so there's no need to combine this with the repo_lock.
"""


class RevManager(revman.RevManager):
    """
    Fetch revisions from a git repository inside a "with" block.
    """

    def __init__(self, ctx, root, rev_id):
        """
        Create a new revision manager for the given rev_id.
        """
        super().__init__(ctx, root)
        self.rev_id = rev_id
        self.writable = False
        self.commit_msg = None
        self.new_files = set()

    def start_write(self, commit_msg):
        """
        Start a new commit on this branch.  After this call, files can be
        updated.  When the RevManager context exits, the commit will be made
        using the given commit_msg.
        """
        self.commit_msg = commit_msg
        self.writable = True

    def start_branch(self, branch_name):
        """
        Start a new branch relative to this branch and move to the new branch.
        """
        try:
            logger.dump('Branching', branch_name, self.root)
            logger.info('Creating pending revision: %s', branch_name)
            self.ctx.sh.contrib.git.checkout("-b", branch_name, _cwd=self.root)
        except self.ctx.sh.ErrorReturnCode_128:
            # This means it didn't like our branch name for some reason.
            # That's as detailed as we can get without parsing the output.
            raise revman.BadBranchNameError()

    def merge_branch(self, branch_name, commit_msg):
        """
        Merge a branch into this branch.  A merge commit will always be
        created; no fast-forwarding.
        """
        try:
            logger.dump('Merging', branch_name, self.root)

            # git merge doesn't allow the commit message to come from stdin,
            # but commit does.  So, we'll do it in two steps.  This avoids
            # long, possibly sensitive, commit messages on the command line or
            # having to use a temporary file.
            self.ctx.sh.contrib.git.merge(
                "--no-ff", "--no-commit", branch_name, _cwd=self.root)

            # Always create a commit, even if it's empty.  This ensures our
            # commit_msg is recorded.
            self.ctx.sh.contrib.git.commit(
                "--allow-empty", "-F", "-", _cwd=self.root, _in=commit_msg)
        except self.ctx.sh.ErrorReturnCode_1:
            # This means it didn't like our branch name for some reason.
            # That's as detailed as we can get without parsing the output.
            raise revman.BadBranchNameError()

    def create_tag(self, tag_name, target=None):
        """
        Create a git tag. If `target` is specified, it will be passed to git as
        the target object of the tag.

        Always clobbers existing tags with same name.
        """
        try:
            tag_args = [tag_name]
            if target is not None:
                tag_args.append(target)

            logger.dump('Tagging', *tag_args, self.root)
            self.ctx.sh.contrib.git.tag("--force", *tag_args, _cwd=self.root)
        except self.ctx.sh.ErrorReturnCode_128:
            # This means it didn't like our tag name for some reason.
            # That's as detailed as we can get without parsing the output.
            raise revman.BadBranchNameError()

    @contextlib.contextmanager
    def _commit(self, filename=None):
        """
        Return a context manager that wraps writable calls.  On enter, it
        verifies this revman is writeable.  On exit, it schedules the file for
        commit.
        """
        self._check_writable()
        exists = filename and self.file_exists(filename)

        # Do the write
        yield

        # If it didn't exist before, add it to the list of new files.
        if filename and not exists:
            self.new_files.add(filename)

    def _check_writable(self):
        """
        If we're writable, pass through.  Otherwise, raise an exception.
        """
        if not self.writable:
            raise PermissionError("Start a commit before writing")

    def save_file(self, filename, *args, **kwargs):
        """
        Save a file as usual, but only if we started a commit or branch first.
        Also, add it to the commit.

        Raises a PermissionError, if a commit hasn't been started.
        """
        with self._commit(filename):
            super().save_file(filename, *args, **kwargs)

    def zero_file(self, filename, *args, **kwargs):
        """
        Zero a file as usual, but only if we started a commit or branch first.
        Also, add it to the commit.

        Raises a PermissionError, if a commit hasn't been started.
        """
        with self._commit(filename):
            super().zero_file(filename, *args, **kwargs)

    def remove_file(self, filename, *args, **kwargs):
        """
        Remove a file as usual, but only if we started a commit or branch
        first.  Also, add it to the commit.

        Raises a PermissionError, if a commit hasn't been started.
        """
        with self._commit():
            super().remove_file(filename, *args, **kwargs)

    def append_file(self, filename, *args, **kwargs):
        """
        Append a file as usual, but only if we started a commit or branch
        first.  Also, add it to the commit.

        Raises a PermissionError, if a commit hasn't been started.
        """
        with self._commit(filename):
            super().append_file(filename, *args, **kwargs)

    def copy_file_in(self, abs_src, filename):
        """
        Copy a file in as usual, but only if we started a commit or branch
        first.  Also, add it to the commit.

        Raises a PermissionError, if a commit hasn't been started.
        """
        with self._commit(filename):
            super().copy_file_in(abs_src, filename)

    def _checkout(self, rev_id):
        """
        Checkout a revision.
        """
        # Just do it, but in a separate method that can be stubbed.
        try:
            logger.dump('Checking out', rev_id, self.root)
            self.ctx.sh.contrib.git.checkout(rev_id, _cwd=self.root)
        except self.ctx.sh.ErrorReturnCode_1:
            # This just means the branch is unknown
            raise revman.UnknownRevisionError()
        except self.ctx.sh.ErrorReturnCode:
            # We have no idea what went wrong...
            raise RuntimeError()

    def __enter__(self):
        """
        Start accessing the repo.
        """
        global repo_lock, repo_rev

        # Only one thread at a time in the repo.  We want it to stay on the
        # branch we checked out.
        repo_lock.acquire()

        logger.dump("Entering", self.rev_id)

        # If we raise an exception here, __exit__() won't be called, so we need
        # to cleanup before leaving.
        try:
            # Our lock is re-entrant.  Check to see if we're already under a
            # revman.
            if len(repo_rev) > 0:
                if repo_rev[0] != self.rev_id:
                    # The thread is asking for a different revision now.  We
                    # simply can't support that.
                    raise RuntimeError(
                        "Attempt to access revision {} while already "
                        "using {}".format(self.rev_id, repo_rev[0]))
                else:
                    # The thread wants the same revision again.  Add to the
                    # repo_rev stack so we keep track of how far nested we are.
                    # Avoid checking it out again.
                    repo_rev.append(self.rev_id)
                    return self

            else:
                # Check out the branch
                self._checkout(self.rev_id)

                # Remember which branch we're on so we ready if the thread
                # opens a nested revman.
                repo_rev.append(self.rev_id)

                return self
        except Exception:
            # Release the lock here, since we won't be calling __exit__()
            repo_lock.release()
            raise

    def __exit__(self, t, v, b):
        """
        Finish accessing the repo.
        """
        try:
            # If we're writable, then it's time to commit.
            if self.writable:
                # Add new files to the commit
                if self.new_files:
                    self.ctx.sh.contrib.git.add(
                        *self.new_files, _cwd=self.root
                    )

                # Always commit, even if nothing has changed.  We want the
                # commit message at least.  Also, pass the long, possibly
                # sensitive, commit message via stdin instead of on the command
                # line.
                self.ctx.sh.contrib.git.commit(
                    "-a", "--allow-empty", "-F", "-",
                    _cwd=self.root, _in=self.commit_msg
                )
        finally:
            global repo_lock, repo_rev

            # Pop the repo_rev stack; we're coming up a level.  If the stack is
            # now empty, then this thread is completely done with the repo.
            repo_rev.pop()

            logger.dump("Exiting", self.rev_id)

            # Release the lock.
            repo_lock.release()


class RepoImpl:
    """
    Implementation class for repo.  It holds the ctx and repo root determined
    at init to provide a simplified interface.
    """
    def __init__(self, ctx, config_root, meta_root):
        self.ctx = ctx
        self.config_root = config_root
        self.meta_root = meta_root

    def get_revman(self, rev_id):
        """
        Given a revisionId, return a RevManager for it.  The RevManager is a
        with-able object under which the revision can be accessed.
        """
        return RevManager(self.ctx, self.config_root, rev_id)

    def get_revision(self, rev_id):
        """
        Return the metadata for the given revision.  If the revision is
        unknown, returns None.
        """
        with meta_lock:
            # If it's an "interesting" revision, return it's meta.
            rev_meta_path = self.meta_root / rev_id
            if(rev_meta_path.is_file()):
                return utils.yaml_load_safe(Path(rev_meta_path))

            # Does git know about it?
            try:
                self.ctx.sh.contrib.git("cat-file", "-e", rev_id,
                                        _cwd=self.meta_root)
                # Git knows about it, but we don't have any meta data.
                return {}
            except self.ctx.sh.ErrorReturnCode:
                # Git doesn't know about it.
                return None

    def get_revisions(self):
        """
        Return the current set of "interesting" revisions in the repo.  These
        are the revisions for which we have metadata, which means they've been
        poked at directly by a user recently.
        """
        with meta_lock:
            revs = {}
            for file_path in self.ctx.fileops.walk(self.meta_root):
                rev_id = str(file_path.relative_to(self.meta_root))
                revs[rev_id] = utils.yaml_load_safe(file_path)
            return revs

    def write_revision_metadata(self, rev_id, metadata):
        """
        Write a blob of metadata about the given rev_id.
        """
        with meta_lock:
            with self.ctx.fileops.cd(self.meta_root):
                # Write it
                logger.dump("Updating meta for", rev_id)
                self.ctx.fileops.save_file(rev_id, utils.yaml_dump(metadata))

                # Commit it
                git = self.ctx.sh.contrib.git
                git.add(rev_id)
                git.commit("--allow-empty", "-m", "Updating " + rev_id)


def _migrate_ensure_empty_revision(ctx, meta):
    """
    Hack to ensure that the empty revision is present, even if /var/lib/cue was
    created before 'empty' was added to CUE.

    This is easier than forcing everyone to rebuild their systems.

    (It will be safe to remove this step after summer 2021.)
    """
    empty_meta = meta / "empty"
    if empty_meta.exists():
        # Nothing to do
        return

    git = ctx.sh.contrib.git
    ctx.fileops.save_file(meta / "empty", utils.yaml_dump({}))
    git.add("empty", _cwd=meta)
    git.commit("-m", "Created 'empty' revision", _cwd=meta)


def prepare_repo(ctx, base_dir=config.WORKING_DIRECTORY):
    """
    Make sure the repository has been created and create the get_revman()
    accessor.
    """
    git = ctx.sh.contrib.git
    base_path = Path(base_dir)

    # Init the repo, if it doesn't exist
    repo = base_path / "config"
    if not repo.exists():
        # Create the base directory if it doesn't exist
        base_path.mkdir(exist_ok=True)

        # Init the repo
        logger.dump('Creating repo at', repo)
        git.init("config", _cwd=base_path)

        # Under the repo, build out our structure.
        with ctx.fileops.cd(repo):
            # Configure the repo
            git.config("user.email", "cue@cumulus.localhost")
            git.config("user.name", "CUE")

            # Create the applied branch
            git.checkout("-b", "applied")

            # Need to create something so we can create branches
            open("cue.yaml", "w").close()
            git.add("cue.yaml")
            git.commit("-m", "Config repository created")
    else:
        # The repo exists.  But make sure it's in a ready state.

        # Force a checkout.  This will clobber any local modifications that
        # might have been left around after a crash.
        git.checkout("--force", "applied", _cwd=repo)

    # Init the meta worktree, if it doesn't exist
    meta = base_path / "meta"
    if not meta.exists():
        # Make sure we're on the applied branch
        git.checkout("applied", _cwd=repo)

        # Init the repo
        logger.dump('Creating meta worktree at', meta)
        git.worktree("add", "-b", "cue/revision_meta", meta, _cwd=repo)

        # Add meta data for the startup "branch".  Since it's not a real
        # branch, _get_revision() won't know what to do with it unless it finds
        # it under meta/.
        ctx.fileops.save_file(meta / "startup", utils.yaml_dump({}))
        ctx.fileops.save_file(meta / "empty", utils.yaml_dump({}))

        # Clear out the cue.yaml.  We have to create it on master or master
        # wouldn't exist.
        git.rm("cue.yaml", _cwd=meta)
        git.commit("-m", "Revision meta created", _cwd=meta)
    else:
        # The worktree exists.  But make sure it's in a ready state.

        # Force a checkout.  This will clobber any local modifications that
        # might have been left around after a crash.
        git.checkout("--force", "cue/revision_meta", _cwd=meta)
        _migrate_ensure_empty_revision(ctx, meta)

    # Create the _repo implementation.
    ctx.versions_v1._repo = RepoImpl(ctx, repo, meta)
