# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
Expose the current request to units via ctx.
"""
from flask import request as _request


def get_username():
    return _request.username
