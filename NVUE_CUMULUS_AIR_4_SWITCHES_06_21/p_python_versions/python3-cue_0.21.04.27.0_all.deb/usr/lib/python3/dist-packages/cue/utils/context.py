# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
The intent of this module is to help units find each other while keeping them
decoupled.  An instance of CueContext will be passed into endpoint handlers.
From the context, handlers will be able to find the handlers they depend on.
They'll also be able to find other runtime requirements they need.
"""


import functools
import inspect


class BoundEndpoint:
    """
    A wrapper for endpoint functions, binding them to ctx.

    This is similar in effect to `functools.partial(function, ctx)`, with some
    advantages:

        - easier to mock/patch; and
        - wraps function metadata (e.g., docstring) better.

    The patch/mock use case is important for unit testing. A BoundEndpoint is
    called both by connexion when handling HTTP requests and when calling an
    operation on an api client (e.g., `ctx.config_v1.getInterfaces()`).
    Patching `BoundEndpoint().function` directly allows us to patch
    already-created API clients and have those changes propogate to the HTTP
    API clients.

    Wrapping the metadata better is helpful for dev tools that provide
    function/object introspection. Not important for functionality, but can be
    helpful for developer productivity.
    """

    def __init__(self, function, ctx):
        self._ctx = ctx
        self.function = function
        functools.update_wrapper(self, function)
        # Update the signature to reflect the binding.
        # HACK: Instead of munging the signature, use the signature of a
        #       partial. It's easier and captures our intent well.
        self.__signature__ = inspect.signature(
            functools.partial(function, ctx)
        )

    def __call__(self, *args, **kwargs):
        return self.function(self._ctx, *args, **kwargs)


class CueApiClient(object):
    """
    Simple class to collect API operations and provide callables to
    access the endpoints within that API.
    """

    def __init__(self, ctx):
        """
        Create a new CueApiClient that lives within the given context.
        """
        self.ctx = ctx

    def new_endpoint(self, endpoint, operation_id) -> BoundEndpoint:
        """
        Given an endpoint and its operationId, add it this client object.
        We'll wrap it with a BoundEndpoint so it is always passed the context
        as it's first argument.  Returns the BoundEndpoint instance.
        """
        bound_endpoint = BoundEndpoint(endpoint, self.ctx)
        setattr(self, operation_id, bound_endpoint)
        return bound_endpoint


class CueContext(object):
    """
    Collection of things an endpoint handler may need.
    """
    pass


# Create the single instance
context = CueContext()
