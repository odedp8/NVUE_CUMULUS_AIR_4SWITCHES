# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from dataclasses import dataclass
from functools import wraps

from pydash import py_

from cue.expansion import (
    expand_number_range,
    ExpansionError,
    expand_name_range,
)
from cue.exceptions import MethodNotAllowed


__pdoc__ = {}
# FIXME: CUE-2520 - this will only work with newer versions of pdoc.
__pdoc__["Morpher.__call__"] = True


@dataclass(frozen=True)
class _WildcardToken:
    """Used as a path rule segment to match any property."""
    token: str

    @property
    def identifier(self):
        # This is just the token, sans curly braces.
        return self.token[1:-1]

    @property
    def should_capture(self):
        return self.identifier not in ["", "_"]


def _find_all_path_rule_matches(data, rule_segments, _match_kwargs=None):
    """
    Find all matches for the morpher path rule defined by
    `rule_segments`, and yield the target data of each match as well as the
    property names matched by identified wildcard tokens.

    Args:
        data: The object to find rule matches in.
        rule_segments: The sequence of rule segments comprising the rule we're
            finding matches for. Each segment is either a string property name,
            or a _WildcardToken. String property names will match with the
            exact property names at that level. A _WildcardToken will match all
            property names at that level. If a _WildcardToken has an
            identifier, the string value of each matched property will be
            included in the yielded `match_kwargs`, using the wildcard
            identifier as its key.

    Yields:
        2-tuple `(target, match_kwargs)` where `target` is the target value of
        the path rule match, and `match_kwargs` is a dict of the captured
        wildcard matches.
    """
    if _match_kwargs is None:
        _match_kwargs = {}

    # EARLY RETURN
    if len(rule_segments) == 0:
        # Found the target. Yield the data and any matched properties captured
        # along the way.
        yield (data, _match_kwargs)
        return
    elif not isinstance(data, dict):
        # Not something we can iterate through. Return without yielding
        # anything.
        return

    current_segment, *next_segments = rule_segments

    # Add all props that are matched by the current segment.
    current_matches = []
    # The key to map each match value to, if we're capturing matches for this
    # segment.
    current_capture_id = None
    if hasattr(current_segment, "identifier"):
        # It's a wildcard segment. All the keys are matches.
        current_matches.extend(data.keys())
        if current_segment.should_capture:
            current_capture_id = current_segment.identifier
    elif current_segment in data:
        # It's a plain string prop, so it's the only match.
        current_matches.append(current_segment)

    for matched_prop in current_matches:
        next_data = data[matched_prop]

        next_match_kwargs = _match_kwargs.copy()
        if current_capture_id is not None:
            # Add the captured match to the match
            next_match_kwargs[current_capture_id] = matched_prop

        yield from _find_all_path_rule_matches(
            next_data, next_segments, next_match_kwargs
        )


class Morpher:
    """
    Create a reusable mechanism to apply mutations to a JSON-like data
    structure. Use the `add_step` decorator to register new morph step
    functions on a Morpher instance. Each Morpher instance is callable. Apply
    the morpher by calling it on the JSON-like structure you'd like to morph.

    Each morph step will be called on the input structure, ordered by depth
    (with deepest steps running last.)
    """

    def __init__(self):
        self.morph_steps = []

    def _insert_step(self, morph_step):
        """Insert each morph step, sorted by length of the path rule."""
        # HACK: just insert the element and sort the list. Python's timsort
        #       algorithm is quite fast when elements are already mostly
        #       sorted.
        self.morph_steps.append(morph_step)
        self.morph_steps.sort(
            key=lambda step: len(step.path_rule_segments)
        )

    def add_step(self, path_rule, **sides):
        """
        A decorator that is used to register a morph step function for a given
        path_rule.

        Args:
            path_rule: A "."-delimited string, defining the property path to
                call the morph step function on. Wildcard properties can be
                specified by using `{_}` as a path segment. To pass the value
                of a matched property into the morph step function as a
                keyword arg, replace `_` with a valid python variable name,
                e.g. `{capture_me}`.
                If `path_rule` is `None`, then the rule will apply to the root
                of the object.
            sides: Optional.  kwargs collection of "."-delimited strings, each
                representing a side object relative to root.  (Wildcards are
                not supported).  When path_rule is matched, these side objects
                will also be passed into the morph step function so that they
                can be modified in place.  If they don't yet exist in root,
                they'll be added.
        """
        if path_rule is None:
            # None means that we're morphing the root.
            path_rule_segments = ()
        else:
            path_rule_segments = tuple(
                (
                    token
                    if not (token.startswith("{") and token.endswith("}"))
                    else _WildcardToken(token)
                )
                for token in path_rule.split(".")
            )

        def decorator(func):

            @wraps(func)
            def wrapped_morph_step_function(root):
                for target, matched_kwargs in _find_all_path_rule_matches(
                    root, path_rule_segments
                ):
                    # Skip null targets
                    if target is not None:
                        # Get the side objects
                        side_kwargs = {
                            side_name: py_.get(root, side, {})
                            for side_name, side in sides.items()
                        }

                        # Call the step function
                        func(target, **side_kwargs, **matched_kwargs)

                        # Put the side objects back in
                        for side_name, side in sides.items():
                            # Skip any empty objects.  This is a simple way to
                            # avoid adding things that weren't there before.
                            # Of course, it assumes a morph step would never
                            # want to add an empty object.  This isn't perfect
                            # but it's straight-forward.
                            if side_kwargs[side_name]:
                                py_.set_(root, side, side_kwargs[side_name])

                return None

            # Attach the rule segments to the wrapper, to enable sorting and
            # aid in debugging.
            wrapped_morph_step_function.path_rule_segments = path_rule_segments
            wrapped_morph_step_function.raw_path_rule = path_rule

            self._insert_step(wrapped_morph_step_function)
            return wrapped_morph_step_function
        return decorator

    def __call__(self, root):
        """
        Mutates root by calling all the registered morph step functions on the
        locations specified by their respective path rules.

        Args:
            root: The JSON-like data structure to morph. This value will be
                mutated in place.

        Returns:
            None. The Morpher knows only how to mutate. It knows naught
            of duplication.

        Side effects:
            Mutates `root` in place.
        """
        for morph_step in self.morph_steps:
            morph_step(root)


############################
# Morphing utilities
############################

def make_state_preparer(state_propname="state"):
    """
    Prepare a state object, identified by `state_propname`, for patching.  That
    means clearing any current values so that after the patch, we're left with
    just the one in the patch.

    Must be added to the state object's parent.
    """
    def func(parent_object):
        state = parent_object.get(state_propname, None)
        if state:
            parent_object[state_propname] = None
        # Always return None, since we're mutating the input.
        return None
    return func


def make_id_expander(expansion_func):
    """
    Create a function that uses `expansion_func` to expand the id keys in a
    collection.
    """

    def func(collection):
        iter_collection = {**collection}
        for id_range, value in iter_collection.items():
            try:
                ids = expansion_func(id_range)
            except ExpansionError:
                raise MethodNotAllowed

            del collection[id_range]

            # Expand the ids, making sure we copy the value each time
            expanded = {id_: py_.clone_deep(value) for id_ in ids}

            # Merge expanded values into collection.
            py_.merge(collection, expanded)

    return func


expand_number_ids = make_id_expander(expand_number_range)
expand_name_ids = make_id_expander(expand_name_range)


def expand_feature_on(feature):
    """
    Enable the feature.  This is useful for features that default to "off".
    When they're configured, this will automatically enable them.
    """
    if "enable" not in feature:
        feature["enable"] = "on"


def expand_side_feature_on(target, side_feature):
    """
    Enable a side-feature, which is a feature located outside the target path
    we morph against.  If target is itself a feature, the side-feature will
    only be enabled if target is enabled.

    This is useful when the feature to be enabled is in a different part of the
    OM that triggers it to be enabled.  For example, the evpn feature requires
    vxlan to be enabled.  So, enabling evpn, the target, should trigger vxlan,
    the side-feature, to be enabled also.

    This morpher does NOT modify target.
    """
    # target is disabled, don't enable side_feature
    if "enable" in target and target["enable"] == "off":
        return

    if "enable" not in side_feature:
        side_feature["enable"] = "on"
