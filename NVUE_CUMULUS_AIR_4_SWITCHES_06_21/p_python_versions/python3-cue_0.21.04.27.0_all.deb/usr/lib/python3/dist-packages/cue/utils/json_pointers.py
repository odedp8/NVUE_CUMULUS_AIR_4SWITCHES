# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from dataclasses import dataclass


__all__ = [
    "convert_path_to_json_pointer", "dereference_json_pointer",
    "dereference_relative_json_pointer", "JsonPointerError",
    "JsonPointerSyntaxError", "JsonPointerLookupError"
]


class JsonPointerError(Exception):
    """Base class for errors relating to JSON Pointer handling"""
    pass


class JsonPointerSyntaxError(JsonPointerError):
    """Invalid syntax for a JSON Pointer (or Relative JSON Pointer)"""
    pass


class JsonPointerLookupError(JsonPointerError):
    """Unable to lookup JSON Pointer (or Relative JSON Pointer)"""
    def __init__(self, pointer, found, found_path):
        super().__init__()
        self.pointer = pointer
        self.found = found
        self.found_path = found_path

    @property
    def description(self):
        return f"Unable to lookup '{self.pointer}'"

    def __str__(self):
        return self.description


def convert_path_to_json_pointer(path):
    return "/".join(["", *[
        str(token).replace("~", "~0").replace("/", "~1")
        for token in path
    ]])


def dereference_json_pointer(pointer, document):
    # If the pointer is an empty string, the RFC says to return the document.
    if pointer == "":
        return document

    # Otherwise, the pointer has to start with a slash.
    if pointer[0] != '/':
        raise JsonPointerSyntaxError(
            f"Missing leading slash in pointer {repr(pointer)}"
        )

    reference_tokens = pointer.split("/")[1:]

    found = document
    found_path = ""
    for raw_token in reference_tokens:
        token = raw_token.replace("~1", "/").replace("~0", "~")
        try:
            found = found[token]
        except TypeError:
            # Probably complaining that we tried to use a string as a list
            # index.
            try:
                found = found[int(token)]
            except Exception:
                # Nope.  It can't be used as an index either
                raise JsonPointerLookupError(
                    pointer, found, found_path) from None
        except LookupError:
            raise JsonPointerLookupError(pointer, found, found_path) from None

        # Keep track of how for we've gotten.
        found_path += "/" + raw_token

    return found


@dataclass
class RelativeJsonPointer:
    """
    Parsed data for a Relative JSON Pointer.
    """

    back_count: int = None
    index_operation: str = None  # "+" or "-"
    index_delta: int = None
    json_pointer: str = None
    key_token: str = None  # "#"


def take_non_negative_integer(string):
    stop_idx = next((
        idx
        for idx, char in enumerate(string)
        if not char.isdigit()
    ), len(string))
    result = string[:stop_idx]
    remaining = string[stop_idx:]
    return result, remaining


def take_char(chars, string):
    result = ""
    remaining = string
    if string != "" and string[0] in chars:
        result = string[0]
        remaining = string[1:]
    return result, remaining


def parse_relative_json_pointer(pointer):
    parsed = RelativeJsonPointer()
    back_count, remaining = take_non_negative_integer(pointer)
    if back_count == "":
        raise JsonPointerSyntaxError(
            f"Missing the leading number in pointer {repr(pointer)}"
        )
    parsed.back_count = int(back_count)
    index_operation, remaining = take_char(["+", "-"], remaining)
    index_delta = ""
    if index_operation:
        index_delta, remaining = take_non_negative_integer(remaining)
        if index_delta == "":
            raise JsonPointerSyntaxError("".join([
                "Missing index manipulation number after",
                f" {repr(index_operation)}",
            ]))
        parsed.index_operation = index_operation
        parsed.index_delta = int(index_delta)
    key_token, remaining = take_char("#", remaining)
    if key_token and remaining:
        raise JsonPointerSyntaxError("".join([
            "Cannot have any characters after the key token:",
            f" {repr(key_token)}",
        ]))
    parsed.key_token = key_token or None
    parsed.json_pointer = remaining
    return parsed


def dereference_relative_json_pointer(current_location, pointer, document):
    current_reference_tokens = current_location.split("/")[1:]

    parsed = parse_relative_json_pointer(pointer)
    try:
        for _ in range(parsed.back_count):
            current_reference_tokens.pop()
    except IndexError:
        # Popped from an empty list, which means we tried to beyond the top of
        # the document.
        raise JsonPointerLookupError(pointer, document, "/")

    if parsed.index_operation:
        current_index = int(current_reference_tokens.pop())
        if parsed.index_operation == "+":
            current_index += parsed.index_delta
        else:
            current_index -= parsed.index_delta
        current_reference_tokens.append(str(current_index))

    if parsed.key_token:
        cur_key = current_reference_tokens.pop()
        cur_key = cur_key.replace("~1", "/").replace("~0", "~")
        parent = dereference_json_pointer(
            "/".join(["", *current_reference_tokens]),
            document,
        )
        try:
            parent[cur_key]
        except TypeError:
            # It's an index.
            cur_key = int(cur_key)
        except KeyError:
            # It's not present in the object
            pass
        return cur_key
    else:
        new_pointer = "/".join([
            "",
            *current_reference_tokens,
        ]) + parsed.json_pointer
        return dereference_json_pointer(new_pointer, document)
