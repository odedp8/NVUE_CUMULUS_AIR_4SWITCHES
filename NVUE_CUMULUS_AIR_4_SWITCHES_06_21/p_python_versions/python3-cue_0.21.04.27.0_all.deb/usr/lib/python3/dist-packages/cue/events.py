# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""
CUE's event system. This is exposed to units as `ctx.events`.

Available events
----------------
Units can register functions to be called whenever the following events are
fired.

- `verify_config`
- `ready_apply`
- `check_health`
- `revision_state`
    *(this one isn't needed for foundational unit development)*

The events are exposed on `ctx.events`:

.. include:: ./docs/events.md
"""


# Event broadcaster
# - Units can register handlers for events.
# - Events are identified by name


import logging
import contextlib
from queue import SimpleQueue
from threading import get_ident


logger = logging.getLogger(__name__)


#############################
# Event Framework
#############################

class _EventHandler(object):
    """
    Wrap the actual handler with a name we can use when logging.
    """

    def __init__(self, name, fn):
        """
        Create a new handler, given a function and a informational name.
        """
        self.name = name
        self.fn = fn


class _PerThreadEventData:
    """Container for thread-specific event queue data."""

    def __init__(self):
        self.event_queue = SimpleQueue()
        """The pending events. Each item is a 2-tuple `(broadcaster, evt)`."""

        self.is_handling = False
        """Is there an event currently being handled?"""


class EventBroadcaster(object):
    """
    Simple event broadcaster.
    """

    _per_thread_data = {get_ident(): _PerThreadEventData()}
    """Containers for thread-specific event queue data."""

    @classmethod
    def get_current_thread_data(cls):
        """
        Get the data specific to the current thread.
        """
        thread_id = get_ident()
        if thread_id not in cls._per_thread_data:
            cls._per_thread_data[thread_id] = _PerThreadEventData()
        return cls._per_thread_data[thread_id]

    def __init__(self, name):
        """
        Create a new broadcaster with the given name.  The name will be used
        when logging.
        """
        self.handlers = []
        self.name = name

    def register(self, name, fn):
        """
        Register a new handler by name.  The name will be used when logging and
        to identify the handler when calling deregister().  In the future, it
        may also be used for dependency management.  It should be unique.
        """
        logger.dump("Registering", name, "to", self.name)

        # Run the newest handler first.  Some day, we'll need to handle
        # dependencies and the easiest way to do that will be to scan the list
        # and insert after all the dependencies have been found.  If the new
        # handler doesn't have dependencies, it will be inserted at the
        # beginning of the list.  Simulate that future behavior now.
        self.handlers.insert(0, _EventHandler(name, fn))

        return self

    def deregister(self, name):
        """
        Deregister a handler by name.
        """
        logger.dump("Deregistering", name, "from", self.name)

        # Just rebuild the list, preserving order, but filtering any handler
        # that matches the deregistered name.
        self.handlers = [cb for cb in self.handlers if cb.name != name]

        return self

    def __call__(self, evt):
        """
        Call each handler, passing the given event.  Each handler is called
        synchronously.

        Any events broadcast while handling another event will be queued up and
        executed after the current event is handled.
        """
        queue_data = type(self).get_current_thread_data()
        # EARLY RETURN
        if queue_data.is_handling:
            # Another event is being handled right now. Put it in the queue and
            # go away.
            queue_data.event_queue.put((self, evt))
            logger.dump("Queued", self.name)
            return

        logger.dump("Firing", self.name)
        # Tell everyone else to wait their turn.
        queue_data.is_handling = True
        try:
            with evt:
                for handler in self.handlers:
                    logger.dump("Firing", self.name, handler=handler.name)
                    with evt.calling_handler(handler.name):
                        handler.fn(evt)
        finally:
            queue_data.is_handling = False
            # Make sure we don't stop processing until the queue is empty.
            if not queue_data.event_queue.empty():
                broadcaster, next_evt = queue_data.event_queue.get_nowait()
                broadcaster(next_evt)


class AbstractEvent(contextlib.AbstractContextManager):
    """
    Base class for event objects.  Event objects provide a context for the
    event.  They describe the event and provide utilities.
    """

    def calling_handler(self, handler_name):
        """
        Notification that the EventBroadcaster is about to call a
        handler of this event.  The handler is identified by handler_name.

        This method must return a context manager.  Subclasses should override,
        call super and add to the ExitStack returned here.
        """
        return contextlib.ExitStack()

    def __enter__(self):
        """
        Prepare the event context. This will be called once per broadcast,
        immediately before calling any of the event handlers.
        """
        pass

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Finish handling the event context. This will be called once per
        broadcast, immediately after calling the event handlers, even if an
        exception was raised by the handlers.

        If an exception was raised, the info in `exc_type`, `exc_value`, and
        `traceback` will describe the exception. Otherwise, each of those
        arguments will be `None`. Do not re-raise the exception inside the
        `__exit__` method. That's handled by the caller as part of the context
        manager protocol.

        To suppress the exception, return `True`. Otherwise, the exception will
        be raised normally.
        """
        pass


#############################
# Events
#############################


verify_config = EventBroadcaster("verify_config")
"""
Given a config, verify the unit can apply it.  The unit should check for issues
related to implementation details and limitations.  For example, if it can only
support 128 VRFs and there are 130 in the config, this is the place to raise
the issue.

On the other hand, units can assume the config complies to the schema and is
correct and consistent, so they don't have to check the easy stuff.  For
example, the unit can assume the VRF name isn't empty and doesn't contain weird
characters.

The `verify_config` event may be triggered often and will sometimes be followed
by a `ready_apply` event.

The handler will be called as:

    handler(evt)

`evt.config_v1` provides access to the configuration to verify.

`evt.report_issue(msg)` to report an issue, `msg`, that will prevent the unit
from applying the config.
"""


ready_apply = EventBroadcaster("ready_apply")
"""
Prepare to apply a config.  The FUnit will generate any files it will need,
stage them to be installed, and schedule actions.  It should also report
warnings to the user as appropriate.

The `ready_apply` event will only be triggered after a successful
`verify_config` event.  After all units have staged and scheduled their
changes, CUE will apply them during the "reloading" state.

The handler will be called as:

    handler(evt)

`evt.config_v1` provides access to the configuration to ready.  Each
`operationId` in `cue_config_v1/openapi.yaml` is a method on this object.

`evt.render(template_pkg, name, **kwargs)` can be used to render a template.
The template is loaded from the `template_pkg` package.  All `kwargs` are
passed into the template.  The result is saved into the event's scratch area
using `name` as a reference.

`evt.save(name, contents)` can be used to save a file to the scratch area given
its contents.  `contents` can be a single object or an iterable of objects.  If
an iterable, each object will be written in turn.  All objects are stringified
before writing.  The result is saved into the event's scratch area, using
`name` as a reference.

`evt.report_warning(msg)` will report an issue, `msg`, that should concern the
user.  The UI may ask the user "are you sure?" before continuing.

`evt.stage_file(name, dst, chown="root.", chmod="0644")` will stage a file to
be installed.  `name` identifies the file in the scratch area.  `dst` is an
absolute path.  The `dst` is checked to verify we will be able to install the
file and warnings reported as appropriate.  When installed, permissions will be
set using `chown` and `chmod`.

`evt.schedule_run_script(name, user="root")` will schedule a script in the
scratch area to be run as the given user.

`evt.schedule_reload_or_restart(systemd_unit)` will schedule the given systemd
unitto be reloaded or restarted if necessary.  If the systemd unit is not
already running, it will be started.  If it does not support reload, it will be
restarted instead.

`evt.schedule_reload(systemd_unit)` will schedule the given systemd unit
to be reloaded.  If the systemd unit is not already running, it will not be
started.  It is assumed the systemd unit supports reload.

`evt.schedule_restart(systemd_unit)` will schedule the given systemd unit
to be restarted.  If the systemd unit is not already running, it will be
started.

`evt.schedule_stop(systemd_unit)` will schedule the given systemd unit to be
stopped.  If the systemd unit is already stopped, this is a no-op.
"""


check_health = EventBroadcaster("check_health")
"""
Check the health of the unit and it's underlying component.  If the component
is in a state where it cannot perform its function, the unit should report
errors and warnings appropriately.

The handler will be called as:

    handler(evt)

`evt.report_warning(msg)` will report a warning.  Warnings are issues that
*should* clear on their own, but are currently preventing the FUnit's component
from functioning.

`evt.report_error(msg)` will report an error.  Errors are issues that *will
not* clear on their own and prevent the FUnit's component from functioning.

`evt.check_is_active(systemd_unit)` will check a service.  If it is active,
return True.  If it's `failed`, report an error and return False.  Otherwise,
report a warning and return `False`.
"""


revision_state = EventBroadcaster("revision_state")
"""
A revision's state has changed.  The handler will be called as:

    handler(evt)

`evt.ctx` is the global context.  `evt.rev_id` is the revision that changed.
`evt.old_state` and `evt.new_state` describe the state transition.

`evt.progress()` can be used to change the revision to yet another state,
indicating progress or completion of a task.  It is called as:

    evt.progress(new_state, progress, errors)

`evt.progress()` may be called multiple times to indicate progress through the
task and update the state.  The optional `progress` parameter is a user-facing
informational string.  It can be updated without changing the state.  The
optional parameter `errors` is an array of error strings encountered.

`evt.revman(rev_id)` return a revision manager context for the given revision.
"""


main_prepared = EventBroadcaster("main_prepared")
"""
The cued process has finished its "prepare" step. All the units are loaded and
prepared.

`evt.ctx` is the global context.
"""


init_revision_transitions = EventBroadcaster("init_revision_transitions")
"""
Initialize the revision finite-state machine's transitions. The transitions are
defined as a dict, where each key is a state and each value is the
collection of allowed transitions from that state.

`evt.add_entry_state(state)` adds an allowed entry state. Only entry states are
allowed transitions from a terminal state (or any state without transitions
defined for it.)

`evt.update_transitions(transitions)` updates the revision transitions dict
with the contents of `transitions`.

After this event, invalid transitions will be forbidden.
"""


cleanup_revisions = EventBroadcaster("cleanup_revisions")
"""
Clean up any "stuck" revisions. After an unexpected exit of cued, there may be
revisions that were in the middle of a finite-state machine. This event allows
units to "unstick" revisions. This could mean a variety of things, but most
likely it means resetting the revision to a terminal state. (A revision can
only start new FSM jobs while in a terminal state.)

Transition validation is disabled while inside this event context. Any
transitions are allowed.

`evt.versions_v1` exposes the `versions_v1` API to event handlers.
"""
