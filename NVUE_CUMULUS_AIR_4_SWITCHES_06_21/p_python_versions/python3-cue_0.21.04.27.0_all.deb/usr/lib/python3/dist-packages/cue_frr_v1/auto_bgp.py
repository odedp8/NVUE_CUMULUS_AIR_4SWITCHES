# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
import logging
from pydash import py_


logger = logging.getLogger(__name__)


######################
# Auto BGP utilities
######################
# These are the official bounds, as per RFC 6996
FIRST_PRIVATE_ASN = 4200000000
LAST_PRIVATE_ASN = 4294967294
# Add one, since the range is inclusive.
RANGE_PRIVATE_ASNS = LAST_PRIVATE_ASN - FIRST_PRIVATE_ASN + 1

SPINE_ASN = FIRST_PRIVATE_ASN

FIRST_LEAF_ASN = SPINE_ASN + 1
LAST_LEAF_ASN = LAST_PRIVATE_ASN
# Add one, since the range is inclusive.
RANGE_LEAF_ASNS = LAST_LEAF_ASN - FIRST_LEAF_ASN + 1


def mac_address_to_integer(mac_string):
    """
    Convert a MAC address into its integer form.

    Args:
        mac_string: The string MAC address in hexadecimal form.

    Returns:
        The integer form of the MAC address.
    """
    if isinstance(mac_string, int):
        # Do nothing if it's already an int
        return mac_string
    return int(
        mac_string.replace(":", "").replace("-", "").replace(".", ""),
        16
    )


def generate_auto_leaf_asn_from_mac_address(mac_string):
    """
    Generate a leaf ASN by converting the MAC address into an integer, and
    coercing that integer into the private ASN range.

    Args:
        mac_string: The string MAC address in hexadecimal form.

    Returns:
        An integer private ASN.
    """
    mac_int = mac_address_to_integer(mac_string)
    return FIRST_LEAF_ASN + mac_int.__mod__(RANGE_LEAF_ASNS)


def generate_auto_spine_asn():
    """
    It's always the same, but it's better to have these both in the same place.

    Returns:
        An integer private ASN.
    """
    return SPINE_ASN


def generate_auto_leaf_asn(evt):
    """
    Generate a leaf ASN in the private range, generated from the device's base
    MAC address.

    Returns:
        An integer private ASN, or None if a valid MAC address couldn't be
        found.
    """
    asn = None

    mac_address = retrieve_base_mac_address(evt)
    if mac_address is not None:
        asn = generate_auto_leaf_asn_from_mac_address(mac_address)

    return asn


def generate_auto_bgp_asn(evt, asn_config):
    """
    Generate an ASN for 'leaf' or 'spine' values.

    Returns:
        An integer private ASN for 'leaf' or 'spine' inputs or None.
    """
    asn = None

    if asn_config == 'leaf':
        asn = generate_auto_leaf_asn(evt)
    elif asn_config == 'spine':
        asn = generate_auto_spine_asn()

    return asn


def retrieve_base_mac_address(evt):
    """
    Generate an asn from a hash of the mac address modulo (private asn range).

    Returns:
        A MAC address if one could be found, otherwise None.
    """
    # Get the eeprom data
    eeprom_data = py_.get(evt.platform_v1.getEeprom(), 'eeprom')
    return py_.get(eeprom_data, "tlv.Base MAC Address.value")
