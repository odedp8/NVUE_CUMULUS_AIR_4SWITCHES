# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from functools import partial, reduce
from cli_cue.minimock import sentinel
from cli_cue.exceptions import UserError
from cli_cue.schema_utils import convert_to_flat_paths, deep_get


######################
# Utilities
######################

def mutate_deep(path, value, obj):
    """
    Side-effects:
        Mutates `obj` in place.
    """
    if len(path) == 0:
        raise ValueError("'path' must contain at least one token.")
    elif not all(str(token) == token for token in path):
        raise TypeError(f"Each token must be printable: {repr(path)}")

    *path_to_target, final_token = path
    for token in path_to_target:
        obj = obj.setdefault(token, {})
    obj[final_token] = value


def update_tuple(index, value, sequence):
    return (
        *sequence[:index],
        value,
        *sequence[index + 1:]
    )


def sequence_starts_with(prefix, sequence):
    return prefix == sequence[:len(prefix)]


######################
# create_patch
######################

_NO_DIFFERENCE = sentinel.NO_DIFFERENCE


def create_patch(base, target, *, _empty=None):
    if _empty is None:
        _empty = {}

    base_is_scalar = (
        isinstance(base, str)
        or not hasattr(base, "__getitem__")
    )
    target_is_scalar = (
        isinstance(target, str)
        or not hasattr(target, "__getitem__")
    )

    # EARLY RETURN
    if base_is_scalar and target_is_scalar:
        # Both items are scalar. We can just do a simple equality check.
        if base != target:
            return target
        else:
            return _empty
    elif base_is_scalar or target_is_scalar:
        # Just one of them is a scalar, so we KNOW they're different
        return target

    for obj in [base, target]:
        if not hasattr(obj, "items"):
            raise TypeError(
                f"Only Mapping-like collections are allowed: {repr(obj)}"
            )

    base_keys = frozenset(base.keys())
    target_keys = frozenset(target.keys())

    patch = {}
    for removed_key in base_keys - target_keys:
        patch[removed_key] = None

    for added_key in target_keys - base_keys:
        patch[added_key] = target[added_key]

    for shared_key in base_keys.intersection(target_keys):
        base_val = base[shared_key]
        target_val = target[shared_key]
        sub_patch = create_patch(base_val, target_val, _empty=_NO_DIFFERENCE)
        if sub_patch is not _NO_DIFFERENCE:
            patch[shared_key] = sub_patch

    if patch == {}:
        return _empty
    else:
        return patch


######################
# simplify_patch
######################

_EMPTY_DICT = sentinel.EMPTY_DICT
_TEMPLATE_PLACEHOLDER = sentinel.TEMPLATE_PLACEHOLDER


def _simplify_patch_names_at_path(patch, name_path):
    # NOTE: Importing from `cue` loads the vast majority of the package's
    #       contents. We don't want to do that in performance-sensitive
    #       situations.
    from cue.expansion import simplify_names  # TODO: CUE-3414

    # EARLY RETURN
    if deep_get(patch, name_path, None) is None:
        # We can't simplify it any more than this!
        return patch

    def _should_simplify(path):
        return (
            sequence_starts_with(name_path, path)
            # This means we're setting the object containing the identifiers,
            # so we won't be able to simplify it.
            and path != name_path
        )

    commands_to_simplify = []
    simplified_patch = {}
    for path, value in convert_to_flat_paths(patch):
        if _should_simplify(path):
            command = (
                *path,
                # Can't use an empty dict in a key. Use a sentinel placeholder.
                value if value != {} else _EMPTY_DICT
            )
            commands_to_simplify.append(command)
        else:
            mutate_deep(path, value, simplified_patch)

    _replace_name_token = partial(update_tuple, len(name_path))

    template_commands = {}
    for command in commands_to_simplify:
        template = _replace_name_token(_TEMPLATE_PLACEHOLDER, command)
        names = template_commands.setdefault(template, [])
        names.append(command[len(name_path)])

    for template, names in template_commands.items():
        *tmpl_path, value = template
        if value is _EMPTY_DICT:
            # Return it to normal
            value = {}
        # Sometimes we can't simplify list of names to a single token
        for name_range in simplify_names(names):
            simplified_path = _replace_name_token(name_range, tmpl_path)
            mutate_deep(simplified_path, value, simplified_patch)
    return simplified_patch


def simplify_patch(patch, name_paths):
    """
    Create a simplified representation of `patch`.

    This is a hack until we can simplify patches on the server side. It doesn't
    handle nested identifier paths or number ids, and it probably never will.

    Args:
        patch: The patch to simplify. (Given `patch` is not mutated.)
        name_paths: A list of paths. The tokens after that path will be
            simplified as names.

    Returns:
        A copy of `patch`, with simplified ranges used where possible.
    """
    # EARLY RETURN
    if not patch:
        # Empty patch means no changes are being made. We're good to go!
        return patch
    return reduce(_simplify_patch_names_at_path, name_paths, patch)


#############################
# convert_patch_to_cue_yaml
#############################

def convert_patch_to_cue_yaml(patch):
    operations = []
    oper_unset = {}
    oper_set = {}
    # Split out the unset patch from the set patch
    for path, value in convert_to_flat_paths(patch):
        if value is None:
            mutate_deep(path, value, oper_unset)
        else:
            mutate_deep(path, value, oper_set)

    if oper_unset:
        operations.append({"unset": oper_unset})
    if oper_set:
        operations.append({"set": oper_set})
    return operations


#############################
# convert_cue_yaml_to_patch
#############################

class CueFileException(UserError):
    pass


class InvalidOperationException(CueFileException):
    pass


_VALID_OPERATION_KEYS = ["set", "unset"]


def _apply_operation(patch, operation):
    oper_keys = list(operation.keys())
    # Should have one and only one key
    if len(oper_keys) != 1:
        raise InvalidOperationException(
            "Operations can only have one top-level key."
            + f" Found: {repr(oper_keys)}"
        )

    mode = oper_keys[0]
    if mode not in _VALID_OPERATION_KEYS:
        raise InvalidOperationException(
            "Each operation's top-level key must be one of"
            + f" {repr(_VALID_OPERATION_KEYS)}."
            + f" Found: {repr(mode)}"
        )

    for path, value in convert_to_flat_paths(operation[mode]):
        if mode == "set" and value is None:
            raise InvalidOperationException(
                "'set' operation values must not be 'null'."
            )
        elif mode == "unset" and value is not None:
            raise InvalidOperationException(
                "'unset' operation values must be 'null'."
            )

        if value == {}:
            # Make sure we're not clobbering an existing dict with an empty one
            existing = deep_get(patch, path, None)
            # EARLY CONTINUE
            if hasattr(existing, "keys"):
                # There's already a dict. No need to do anything.
                continue
        mutate_deep(path, value, patch)


def convert_cue_yaml_to_patch(cue_yaml):
    if not isinstance(cue_yaml, list):
        raise CueFileException(
            "CUE file must contain a list of operation objects."
        )
    patch = {}
    for operation in cue_yaml:
        _apply_operation(patch, operation)
    return patch
