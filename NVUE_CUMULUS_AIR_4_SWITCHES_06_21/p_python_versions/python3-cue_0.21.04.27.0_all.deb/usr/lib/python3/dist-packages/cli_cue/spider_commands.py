# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

import sys
from cli_cue.schema_utils import deep_get
from cli_cue.minimock import SimplePatch
from cli_cue.cl import parse_argv
from cli_cue import network
from io import StringIO
from cli_cue.locoparse import LocoParser, _AccumulateWildcardSubParsersAction
from dataclasses import dataclass, field


@dataclass
class BaseNode:
    """
    A node in the CUE CLI command tree.
    """

    tokens: tuple = ()
    parser: object = None
    usage: str = None
    description: str = None
    helptext: str = None
    children: list = field(default_factory=list)
    is_suppressed: bool = False

    def __iter__(self):
        yield self
        for child in self.children:
            yield from child

    def to_jsonish(self):
        return {
            "tokens": self.tokens,
            "usage": self.usage,
            "description": self.description,
            "helptext": self.helptext,
            "is_suppressed": self.is_suppressed,
            "children": [
                child.to_jsonish()
                for child in self.children
            ]
        }

    @classmethod
    def from_jsonish(cls, jsonish):
        node = cls()
        node.tokens = tuple(jsonish["tokens"])
        node.usage = jsonish["usage"]
        node.description = jsonish["description"]
        node.helptext = jsonish["helptext"]
        node.is_suppressed = jsonish["is_suppressed"]
        node.children = [
            cls.from_jsonish(child_jsonish)
            for child_jsonish in jsonish["children"]
        ]
        return node


WILDCARD_NAME = "-"
"""
The string token used to fill in any wildcard values.
"""


def collect_parser_and_helptext(tokens):
    """
    Returns:
        A 2-tuple `(parser, helptext)` where `parser` is the `LocoParser` for
        the command, and `helptext` is the string helptext that was printed to
        stdout.
    """
    orig_exit_method = LocoParser.exit

    fake_argv = ["cl", *tokens, "--help"]
    fake_stdout = StringIO()
    found_parser = None

    def fake_exit(self, *args, **kwargs):
        nonlocal found_parser
        found_parser = self
        return orig_exit_method(self, *args, **kwargs)

    with SimplePatch(sys, argv=fake_argv, stdout=fake_stdout):
        with SimplePatch(LocoParser, exit=fake_exit):
            try:
                parse_argv()
            except SystemExit:
                pass
    return found_parser, fake_stdout.getvalue()


def get_subcommand_names(
    parser, *, include_suppressed=False
):
    try:
        subparsers = parser.get_subparsers()
    except AttributeError:
        subparsers = None

    # EARLY RETURN
    if subparsers is None:
        # No children to handle!
        return []

    # EARLY RETURN
    if isinstance(subparsers, _AccumulateWildcardSubParsersAction):
        # Wildcard subparsers are silly. Handle them as a special case and
        # return early.
        return [WILDCARD_NAME]

    names = []
    for token in subparsers.choices.keys():
        # HACK on HACK: Leverage the LocoParser hack that keeps suppressed
        #       subcommands out of completions: The name of a suppressed
        #       subcommand will always return False for str.startswith. If
        #       the token says it doesn't start with an empty string, then
        #       we know it's LYING (and therefore suppressed.)
        suppress_child = not token.startswith("")
        # EARLY CONTINUE
        if suppress_child and not include_suppressed:
            # Skip over the suppressed value
            continue
        names.append(token)

    return names


@dataclass
class SpiderNode(BaseNode):

    on_collect: callable = None
    """
    Called as `on_collect(self)` after collecting the parser data but before
    crawling the parser's subcommands.
    """

    class StopCrawling(Exception):
        """
        Raise within an `on_collect` callback to stop crawling past the current
        node.
        """
        pass

    def __post_init__(self):
        """
        Grab the helptext for a command, capture the relevant subparser, and
        then create nodes for each subcommand of the subparser.

        This is a crazy megahack, but it gets us as close to the "production"
        code path as possible.
        """
        found_parser, helptext = collect_parser_and_helptext(self.tokens)
        self.parser = found_parser
        self.usage = found_parser.just_usage()
        self.description = self.parser.description or ""
        self.helptext = helptext

        # (maybe) EARLY RETURN
        if self.on_collect is not None:
            try:
                self.on_collect(self)
            except type(self).StopCrawling:
                # The callback has indicated that it doesn't want this stuff.
                return

        for name in get_subcommand_names(self.parser):
            child = type(self)(
                (*self.tokens, name),
                on_collect=self.on_collect
            )
            self.children.append(child)


@dataclass
class LocalOpenapiProvider:
    openapi_spec: dict
    map_token_tuple_to_path_def: dict = field(init=False)

    def __post_init__(self):
        self.map_token_tuple_to_path_def = {
            self.oai_path_to_path_tuple(path): (path, path_obj)
            for path, path_obj in self.openapi_spec["paths"].items()
        }

    @staticmethod
    def oai_path_to_path_tuple(oai_path):
        return tuple((
            (
                token
                if not token.startswith("{")
                else
                WILDCARD_NAME
            )
            for token in oai_path.strip("/").split("/")
            if token != ""
        ))

    def _get_path_def(self, tokens):
        """
        Return a 2-tuple `(path_name, path_item)` where `path_name` is the
        OpenAPI path name, and `path_item` is the OpenAPI path item object.

        Raises a 404 CueRequestError if the path isn't found. (Since this
        function is pretending to be making network requests, the 404 error
        lets the client handle missing endpoints normally.)
        """
        try:
            return self.map_token_tuple_to_path_def[tuple(tokens)]
        except KeyError:
            raise network.CueRequestError(
                method="GET",
                url="/fakerequest",
                status=404,
                reason="not found",
                body={},
            )

    def fetch_openapi_schemas(self, api, positional, subpaths):
        """
        A stand in for `fetch_openapi_schemas` that doesn't use the CUE server.
        Instead, this function uses the OpenAPI spec directly via
        `cue_cue_v1.get_openapi`.
        """
        if api != "cue_v1":
            raise Exception(f"Only works with 'cue_v1': {repr(api)}")
        positional = tuple(positional)
        _, path_item = self._get_path_def(positional)

        result = {}
        for path in subpaths:
            found = deep_get(path_item, path, None)
            if found is not None:
                result[path] = found
        return result

    def fetch_templatelinks(self, api, positional):
        """
        A stand in for `fetch_templatelinks` that doesn't use the CUE server.
        Instead, this function uses the OpenAPI spec directly via
        `cue_cue_v1.get_openapi`.

        The templatelinks logic is somewhat involved. This function is as close
        to a straight copy/paste of the server logic as possible, but
        discrepancies are possible.
        """
        if api != "cue_v1":
            raise Exception(f"Only works with 'cue_v1': {repr(api)}")
        positional = tuple(positional)

        links = []
        template_filled = {}
        template_suggested = {}

        url_prefix = "/" + api

        self_path, self_data = self._get_path_def(positional)

        self_href = url_prefix + self_path

        self_link = {
            "rel": "self",
            "href": self_href,
            "targetHints": {
                "allow": list(map(
                    # Use uppercase, since that's the norm for the "Allow" HTTP
                    # header.
                    lambda method: method.upper(),
                    self_data.keys()
                ))
            }
        }
        links.append(self_link)

        for tmpl_token in self_href.split("/"):
            if tmpl_token.startswith("{"):
                filled_token = tmpl_token[1:-1]
                template_filled[filled_token] = WILDCARD_NAME

        # Any path that starts with the path and one trailing slash is a
        # subpath. (The trailing slash is necessary to prevent /foo-name from
        # being considered a subpath of /foo.)
        child_path_prefix = self_path.rstrip("/") + "/"

        # Only look at paths that have one more level than current path.
        self_slashes = self_path.rstrip("/").count("/")
        child_paths = {
            path: obj
            for path, obj in self.openapi_spec["paths"].items()
            if (
                path.startswith(child_path_prefix)
                and path.rstrip("/").count("/") == self_slashes + 1
            )
        }

        wildcard_token = None
        wildcard_path = None
        # Add child links for explicit children
        for child_path, path_obj in child_paths.items():
            token = child_path[len(self_path):].lstrip("/")
            if "{" in token:
                wildcard_token = token[1:-1]
                wildcard_path = child_path
            links.append({
                "rel": "up",
                "anchor": url_prefix + child_path,
                "contextHints": {
                    "allow": list(map(
                        lambda method: method.upper(),
                        path_obj.keys()
                    )),
                },
            })

        # Fill out possible values for wildcard by recursively calling the
        # current endpoint and grabbing the keys.
        if wildcard_path is not None:
            data = {WILDCARD_NAME: None}
            template_suggested[wildcard_token] = list(data.keys())

        template_container = {}
        if template_suggested:
            template_container["suggested"] = template_suggested
        if template_filled:
            template_container["filled"] = template_filled

        result = {
            "base": "http://localhost:8765",
            "links": links,
        }
        if template_container:
            result["template"] = template_container

        return result


def spider_go(tokens=(), on_collect=None):
    from cue_cue_v1 import get_openapi
    oai_provider = LocalOpenapiProvider(get_openapi())

    patch_network = SimplePatch(
        network,
        _fetch_openapi_schemas=oai_provider.fetch_openapi_schemas,
        _fetch_templatelinks=oai_provider.fetch_templatelinks,
        init_connection=lambda _: None,
    )
    with patch_network:
        root = SpiderNode(tokens, on_collect=on_collect)
    return root


def stream_commands(positional, stream):

    def _should_print(node):
        if len(positional) == 0:
            # The user wants everything. Give them everything (except for
            # suppressed nodes.)
            return True

        all_match = all(
            node_tkn == "-" or node_tkn == pos_tkn
            for node_tkn, pos_tkn in zip(node.tokens[1:], positional)
        )
        if not all_match:
            # We're not printing this or any children of this node. Stop before
            # we go any farther.
            raise node.StopCrawling()
        return len(node.tokens) >= 1 + len(positional)

    def on_collect(node):
        # EARLY RETURN
        if not _should_print(node):
            # Nothing to do!
            return
        usage = node.parser.just_usage()
        # Drop the options bit, since it's just noise for list-commands
        usage = usage.replace(" [options]", "")
        # Strip all optional subcommands from the usage string. (Each
        # subcommand will get its own entry in the output.)
        while True:
            try:
                start_substring = " ["
                end_substring = "...]"
                end_idx = usage.rindex(end_substring) + len(end_substring)
                start_idx = usage.rindex(start_substring)
                usage = usage[:start_idx] + usage[end_idx:]
            except ValueError:
                break
        # EARLY RETURN
        if usage.endswith("..."):
            # This is a command that requires followup. Don't list it as if
            # it were self-sufficient.
            return
        stream.write(usage)
        stream.write("\n")

    return spider_go(on_collect=on_collect)
