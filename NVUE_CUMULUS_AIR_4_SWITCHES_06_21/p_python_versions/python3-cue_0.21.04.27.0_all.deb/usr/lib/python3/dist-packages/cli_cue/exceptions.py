# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


class UserError(Exception):
    """
    Base for exceptions that we're going to calmly tell users about (without
    dumping a traceback.)
    """
