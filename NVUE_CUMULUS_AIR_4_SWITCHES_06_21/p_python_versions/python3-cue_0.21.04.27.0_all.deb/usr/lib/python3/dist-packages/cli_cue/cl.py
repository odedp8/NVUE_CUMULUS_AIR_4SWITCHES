#!/usr/bin/env python3.7
# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:.
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


import sys
import argparse
import json
from errno import EPIPE
from dataclasses import dataclass, replace, field, InitVar
from functools import wraps, partial, lru_cache

from cli_cue.network import (
    CueRequest,
    CueRequestError,
    send_request,
    needs_connection,
    encode_path,
    fetch_openapi_schemas,
    fetch_templatelinks,
    convert_json_pointer_to_path,
)
from cli_cue.exceptions import UserError
from cli_cue.minimock import sentinel
from cli_cue.schema_utils import (
    group_schema_paths_by_instance_path,
    find_schema_keyword,
    get_schema_types,
    coerce_value_from_schema,
    PATH_KEY,
    PATH_WILDCARD,
    deep_get,
    map_deep,
    make_tree,
    are_paths_matching,
)
from cli_cue.locoparse import parse_from_json, wants_completion
from cli_cue.revisions import (
    NoPendingRevisionError,
    get_tracked_revision,
    fetch_revisions,
    fetch_revision,
    update_revision,
    attach_pending,
    get_active_pending_revision,
    detach_pending,
    make_pending_revision,
    is_revision_patchable,
    resolve_revision,
    REVISION_ID_ACTIVE_PENDING,
    REVISION_ID_TRACKED,
    REVISION_ID_APPLIED,
    REVISION_ID_RUNNING,
)


# Default values for options
DEFAULT_HOSTNAME = None  # None means use the UNIX domain socket
DEFAULT_OUTPUT = "auto"
DEFAULT_API = "cue_v1"
DEFAULT_COLOR = "auto"


SUPPORTED_OUTPUTS = [
    "json", "yaml", "auto", "constable", "end-table"
]
SUPPORTED_COLORS = ["never", "always", "auto"]


HTTP_METHODS = [
    "GET",
    "HEAD",
    "POST",
    "PUT",
    "DELETE",
    "CONNECT",
    "OPTIONS",
    "TRACE",
    "PATCH",
]
HTTP_METHODS_WITH_BODIES = [
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
]


######################
# revision states
######################

STATE_PENDING = "pending"

# apply config
STATE_APPLY = "apply"
STATE_VERIFYING = "verifying"
STATE_INVALID = "invalid"
STATE_VERIFIED = "verified"
STATE_VERIFY_ERROR = "verify_error"
STATE_READYING = "readying"
STATE_READY = "ready"
STATE_READY_ERROR = "ready_error"
STATE_AYS = "ays"
STATE_AYS_FAIL = "ays_fail"
STATE_AYS_NO = "ays_no"
STATE_AYS_YES = "ays_yes"
STATE_RELOADING = "reloading"
STATE_RELOADED = "reloaded"
STATE_CHECKING = "checking"
STATE_CHECKED = "checked"
STATE_APPLY_ERROR = "apply_error"
STATE_IGNORE_FAIL = "ignore_fail"
STATE_IGNORE_FAIL_NO = "ignore_fail_no"
STATE_IGNORE_FAIL_YES = "ignore_fail_yes"
STATE_APPLY_FAIL = "apply_fail"
STATE_CONFIRM = "confirm"
STATE_CONFIRM_NO = "confirm_no"
STATE_CONFIRM_YES = "confirm_yes"
STATE_CONFIRM_FAIL = "confirm_fail"
STATE_APPLIED = "applied"
STATE_APPLY_INTERRUPTED = "apply_interrupted"

# save_config
STATE_SAVE = "save"
STATE_SAVING = "saving"
STATE_SAVED = "saved"
STATE_SAVE_ERROR = "save_error"
STATE_SAVE_INTERRUPTED = "save_interrupted"


ALL_STATES = [
    STATE_PENDING,
    # apply config
    STATE_APPLY,
    STATE_VERIFYING,
    STATE_INVALID,
    STATE_VERIFIED,
    STATE_VERIFY_ERROR,
    STATE_READYING,
    STATE_READY,
    STATE_READY_ERROR,
    STATE_AYS,
    STATE_AYS_FAIL,
    STATE_AYS_NO,
    STATE_AYS_YES,
    STATE_RELOADING,
    STATE_RELOADED,
    STATE_CHECKING,
    STATE_CHECKED,
    STATE_APPLY_ERROR,
    STATE_IGNORE_FAIL,
    STATE_IGNORE_FAIL_NO,
    STATE_IGNORE_FAIL_YES,
    STATE_APPLY_FAIL,
    STATE_CONFIRM,
    STATE_CONFIRM_NO,
    STATE_CONFIRM_YES,
    STATE_CONFIRM_FAIL,
    STATE_APPLIED,
    STATE_APPLY_INTERRUPTED,
    # save config
    STATE_SAVE,
    STATE_SAVING,
    STATE_SAVED,
    STATE_SAVE_ERROR,
    STATE_SAVE_INTERRUPTED,
]
FAILURE_STATES = [
    # apply failures
    STATE_INVALID,
    STATE_VERIFY_ERROR,
    STATE_READY_ERROR,
    STATE_AYS_FAIL,
    STATE_APPLY_ERROR,
    STATE_APPLY_FAIL,
    STATE_CONFIRM_FAIL,
    STATE_APPLY_INTERRUPTED,
    # save failures
    STATE_SAVE_ERROR,
    STATE_SAVE_INTERRUPTED,
]
PROMPT_USER_STATES = {
    STATE_AYS: {
        True: STATE_AYS_YES,
        False: STATE_AYS_NO,
    },
    STATE_IGNORE_FAIL: {
        True: STATE_IGNORE_FAIL_YES,
        False: STATE_IGNORE_FAIL_NO,
    },
}
EARLY_EXIT_STATES = [
    STATE_CONFIRM,
]
IN_PROGRESS_STATES = [
    # apply config
    STATE_APPLY,
    STATE_VERIFYING,
    STATE_VERIFIED,
    STATE_READYING,
    STATE_READY,
    STATE_RELOADING,
    STATE_RELOADED,
    STATE_CHECKING,
    STATE_CHECKED,
    STATE_AYS_NO,
    STATE_AYS_YES,
    STATE_IGNORE_FAIL_NO,
    STATE_IGNORE_FAIL_YES,
    STATE_CONFIRM_NO,
    STATE_CONFIRM_YES,
    # save config
    STATE_SAVE,
    STATE_SAVING,
]
SUCCESS_STATES = [
    STATE_APPLIED,
    STATE_SAVED,
]


# URLs to ignore in object model
OBJECT_MODEL_IGNORE = [
    "/cue_v1/revision",
]


# ANSI escape sequences
# http://ascii-table.com/ansi-escape-sequences.php
ANSI_CLEAR_SCREEN_DOWN = u"\u001b[J"
# HACK: moves cursor left 1000 columns. (We've got bigger problems if 1000
#       columns isn't enough)
ANSI_CURSOR_LEFT = u"\u001b[1000D"


# Assume user wants to be prompted
PROMPT_ASSUME_DEFAULT = sentinel.PROMPT_ASSUME_DEFAULT
# Assume 'yes' for everything
PROMPT_ASSUME_YES = sentinel.PROMPT_ASSUME_YES
# Assume 'no' for everything
PROMPT_ASSUME_NO = sentinel.PROMPT_ASSUME_NO


#################################
# Detailed command descriptions
#################################

HELPTEXT_CL_EDIT = """\
Edit the CUE configuration tree as a YAML file.

Open the contents of a CUE revision in a text editor. The saved
contents will REPLACE the revision's existing contents after you
close the text editor.

An empty file will abort the edit without making any changes.

If the edited configuration is invalid, the revision's original
contents will be restored.

The text editor will be chosen from the following (in order).

- the VISUAL environment variable
- the EDITOR environment variable
- "nano"

By default, "cl edit" will edit the current pending revision.
To edit a specific revision, use the <revision> argument.
"""


HELPTEXT_CL_TREE = """\
View the CUE object model as a tree.

WARNING: This is a development feature! It may be
         changed/removed without any notice!

"cl tree" queries cued for a command's "cl show" schema and its
"cl set" schema. From the schemas, it determines the tree of valid
instance locations, and which locations are "read only".

"Read only" nodes (ie, valid for "cl show", but not valid for "cl set")
are prefixed with "+--ro".
"Read/write" nodes are prefixed with "+--rw".

Collections are marked by "* [found-type]" after the node name, where
"found-type" is the type/format expected as the key for the collection.

If the "--show-proposed" flag is set, "cl tree" will fetch the
"proposed" schema (which doesn't show up in the CLI) in addition
to the "set" and "show" schemas.
Any node in the "proposed" schema is prefixed with "?---p".

The format is roughly modeled off of RFC 8340 "YANG Tree Diagrams".
Since CUE is using OpenAPI (not YANG) as its modeling language, a
compliant diagram would be impossible/nonsensical.
"""


APPLY_CONFIRM_EXPLANATION = """\
To keep this configuration, use

    cl config apply [<revision>] --confirm-yes

To roll this configuration back immediately, use

    cl config apply [<revision>] --confirm-no

To see how much time is left until automatic roll back, use

    cl config apply [<revision>] --confirm-status

"""


###############
# Data classes
###############

@dataclass(frozen=True)
class CueCommand:
    """
    Data structure to contain/organize user input in a standard format.

    Attributes:
        mode: The mode of the command
        config_mode: The string config_mode of the command
        positional: Positional arguments that come after the mode arg
        mappings: Dot prefix mappings for set commands

        hostname: The hostname of the server we're using
        output: Output format to use
        api: The pertinent unit's API name (default cue_v1)

        revision: The pertinent revision id
    """
    mode: str  # All commands
    config_mode: str  # Just for config commands
    positional: list  # set/show commands
    mappings: dict  # set commands

    revision_filter: str  # Only for config revision

    hostname: str
    output: str
    api: str
    color: str

    revision: str
    original_revision: str

    include_proposed: bool = False
    prompt_assume: object = PROMPT_ASSUME_DEFAULT
    # NOTE: By this point 'cue_file' is a PATCH payload object.
    cue_file: dict = None
    diff_revision_base: str = None
    diff_revision_target: str = None

    apply_confirm: int = None
    apply_state: str = None
    apply_state: str = None
    confirm_status: bool = False

    @classmethod
    def from_options(cls, options):
        """
        Create a CueCommand from options parsed from argparse.
        """
        mode = options.mode
        config_mode = getattr(options, "config_mode", None)
        positional = list(getattr(options, "positional", []))
        revision_filter = getattr(options, "revision_filter", None)
        include_proposed = getattr(options, "include_proposed", False)
        dot_tokens = getattr(options, "dot_tokens", None)
        prompt_assume = getattr(
            options, "prompt_assume", PROMPT_ASSUME_DEFAULT
        )
        cue_file = getattr(options, "cue_file", None)
        diff_revision_base = getattr(options, "diff_revision_base", None)
        diff_revision_target = getattr(options, "diff_revision_target", None)
        apply_confirm = getattr(options, "apply_confirm", None)
        apply_state = getattr(options, "apply_state", None)
        confirm_status = getattr(options, "confirm_status", False)

        mappings = cls._munge_dot_tokens(dot_tokens)

        if getattr(options, "payload_value", None) is not None:
            positional.append(options.payload_value)

        # HACK: Need to look at revision and --rev, since users can configure
        #       the revision in either place, and docopt doesn't let us write
        #       both options to the same dest.
        try:
            opt_revision = options.revision or options.rev
        except AttributeError:
            opt_revision = options.rev

        if mode in ["show"]:
            # Original revision is allowed to be "None" for show
            original_revision = opt_revision
            revision = original_revision or REVISION_ID_RUNNING
        else:
            original_revision = opt_revision or REVISION_ID_TRACKED
            revision = original_revision

        revision = resolve_revision(revision)
        diff_revision_base = resolve_revision(diff_revision_base)
        diff_revision_target = resolve_revision(diff_revision_target)

        return cls(
            mode=mode,
            config_mode=config_mode,
            positional=positional,
            mappings=mappings,
            revision_filter=revision_filter,
            original_revision=original_revision,
            revision=revision,
            hostname=options.hostname,
            output=options.output,
            api=options.api,
            color=options.color,
            include_proposed=include_proposed,
            prompt_assume=prompt_assume,
            cue_file=cue_file,
            diff_revision_base=diff_revision_base,
            diff_revision_target=diff_revision_target,
            apply_confirm=apply_confirm,
            apply_state=apply_state,
            confirm_status=confirm_status,
        )

    @staticmethod
    def _munge_dot_tokens(dot_tokens):
        if dot_tokens is None:
            return None
        if len(dot_tokens) % 2 == 1:
            dot_tokens = (*dot_tokens, None)
        return dict(zip(dot_tokens[0::2], dot_tokens[1::2]))

    def set_auto_output(self, value):
        """
        Set the "auto" value for output, if not already set.
        """
        if self.output == "auto":
            object.__setattr__(self, 'output', value)


####################
# Network utilities
####################

class RiskyConfigContext:
    """
    A context manager for risky config operations. This is a hack for
    pseudo-atomic operations. This context grabs the contents of the specified
    revision and sets that revision back to its original state if any errors
    occur inside the context.

    Most commands only contain one "mutating" request. This context manager
    isn't necessary for those. It should only be necessary for commands that
    consist of multiple "mutating" requests.

    Attributes:
        revision: The id of the revision to operate on.
        original_config: optional - saves a GET request if you already have the
            original config handy.
    """

    class _RiskyConfigContextHandle:
        """
        The handle return upon entering the context. For example:

        ```with RiskyConfigContext(some_rev) as handle: ...```
        """
        def __init__(self, parent):
            self.original_config = parent.original_config
            self.revision = parent.revision

        def clear_config(self):
            """Clear out all the 'opinions' contained in a revision."""
            send_request(CueRequest(
                method="DELETE",
                path="/cue_v1/",
                query_params={"rev": self.revision},
            ))

    def __init__(self, revision, original_config=None):
        self.revision = revision
        self.config_path = encode_path("config_v1", "rev", revision)
        self.original_config = original_config

    def __enter__(self):
        if self.original_config is None:
            # Grab the original config
            self.original_config = send_request(CueRequest(
                method="GET",
                path=self.config_path,
                query_params={"filled": False},
            ))
        return self._RiskyConfigContextHandle(self)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            return

        # Tell the user that something went wrong and restore it.
        sys.stderr.write("Failed to update the configuration.\n")
        sys.stderr.write(
            "  Attempting to restore prior state of"
            + f" {repr(self.revision)}...\n"
        )
        sys.stderr.flush()
        send_request(CueRequest(
            method="PUT",
            path=self.config_path,
            payload=self.original_config,
        ))
        sys.stderr.write(
            f"  Restored {repr(self.revision)}!\n"
        )


class OaiOperation:
    """
    The parts of an OpenAPI operation that we care about.

    Attributes:
        schema: The schema for the response or request body (whichever is
            applicable)
        parameters: The list of parameter objects that apply to the operation.

    Side-effects:
        Makes a network request for the spec info on init.
    """

    def __init__(self, api, positional, http_method):
        path_to_schema = schema_path_for_method(http_method)
        path_to_base_params = ("parameters",)
        path_to_method_params = (http_method.lower(), "parameters")

        response = fetch_openapi_schemas(api, positional, subpaths=[
            path_to_base_params,
            path_to_schema,
            path_to_method_params,
        ])

        self.schema = response.get(path_to_schema, {})
        self.parameters = [
            *response.get(path_to_base_params, []),
            *response.get(path_to_method_params, [])
        ]


###################
# Input utilities
###################
def input_editor(default=None, editor=None, **tmpfile_kwargs):
    """
    Like the built-in input(), except that it uses a visual text editor for
    ease of editing. Unlike input() it can also take a default value.

    This is a modified version of the `raw_input_editor` found here:
    https://chase-seibert.github.io/blog/2012/10/31/python-fork-exec-vim-raw-input.html

    Args:
        default: A string to write to the text file before opening it for the
            user.
        editor: Which text editor to use.
        **tmpfile_kwargs: Keyword arguments to pass through to
            `NamedTemporaryFile`

    Returns:
        The contents of the temporary file after the user closes their text
        editor.

    Side effects:
        Creates a temporary file.
        Starts a text editor process.
        Blocks this script until the text editor process exits.
    """
    from tempfile import NamedTemporaryFile
    from subprocess import run
    import os
    editor = (
        editor
        or os.environ.get("VISUAL")
        or os.environ.get("EDITOR")
        or "nano"
    )
    with NamedTemporaryFile(mode='r+', **tmpfile_kwargs) as tmp_file:
        if default:
            tmp_file.write(default)
            tmp_file.flush()
        run([editor, tmp_file.name])
        tmp_file.seek(0)
        return tmp_file.read().strip()


class NonBlocking:
    """
    Add the O_NONBLOCK flag to a file descriptor.
    Restore original flags when finished.
    """

    def __init__(self, fd):
        # `fd` can be an int file descriptor, or a file-like object that
        # implements the `.fileno()` method.
        self.fd = fd

    def __enter__(self):
        # fcntl - manipulate file descriptor (see `man fcntl` for more.)
        from fcntl import fcntl, F_GETFL, F_SETFL
        from os import O_NONBLOCK
        self.flags = fcntl(self.fd, F_GETFL)
        fcntl(self.fd, F_SETFL, self.flags | O_NONBLOCK)

    def __exit__(self, *_):
        from fcntl import fcntl, F_SETFL
        fcntl(self.fd, F_SETFL, self.flags)


async def stdin_readline():
    """
    Read a line from stdin once it's ready. Can be cancelled.

    Q: Why use this instead of `sys.stdin.readline()`?

    A: We need to be able to STOP reading stdin if certain conditions are met.
    Normal stdin doesn't let you do that.

    Q: Will this work on Windows?

    A: Nope! This requires Unix-only fcntl controls for setting stdin to
    non-blocking mode.
    This also needs `loop.add_reader()`, which doesn't work with stdin on
    Windows.
    https://docs.python.org/3/library/asyncio-platforms.html#asyncio-platform-support

    Returns:
        The result of `sys.stdin.readline()` as soon as it's available.
    """

    # Do we already have a line ready?
    # NOTE: This is important for when our buffer has several lines already. If
    #       stdin is redirected from a file/pipe, `loop.add_reader()` tends to
    #       explode. If stdin is a tty, then `loop.add_reader()` only triggers
    #       for the first read line. The "read-available" event seems to get
    #       cleared, even though we didn't read the whole buffer. So the next
    #       line (which is already buffered) won't be read until the buffer
    #       gets YET ANOTHER line. Annoying. "Easily" circumvented by trying a
    #       non-blocking read of stdin first.
    #       Catch up with the buffer.
    #       Only consume the "read-available" event when we need it.
    with NonBlocking(sys.stdin):
        # HACK: sys.stdin populates its buffer whenever a newline is received.
        #       Assume this is either a full line or nothing.
        maybe_line = sys.stdin.readline()

    # EARLY RETURN
    if maybe_line != "":
        # We're done here!
        return maybe_line

    from asyncio import Future, get_running_loop
    # The next line isn't ready yet. That's cool. We can wait.
    line_waiter = Future()

    def handle_read():
        # The secret sauce:
        # Don't try to read the line if we got cancelled or otherwise resolved.
        if not line_waiter.done():
            line = sys.stdin.readline()
            line_waiter.set_result(line)

    loop = get_running_loop()
    try:
        # Set a callback to run once stdin is ready for us.
        loop.add_reader(sys.stdin, handle_read)
        return await line_waiter
    finally:
        # We only want to read it once (or not at all if this gets cancelled.)
        loop.remove_reader(sys.stdin)


async def ainput(prompt: str) -> str:
    """
    Asynchronous version of builtin `input` function.
    Print prompt to stdout and wait for the next line from stdin.

    If stdin is not a TTY, print the prompt, check if there's a line in stdin,
    and return immediately. (If there's not already a line, we're probably not
    going to be getting one any time soon.)
    """
    sys.stdout.write(prompt)
    sys.stdout.flush()
    # EARLY RETURN
    if not sys.stdin.isatty():
        # Don't wait for input.
        # Return what's in the buffer,
        # Or return empty.
        with NonBlocking(sys.stdin):
            maybe_line = sys.stdin.readline()
        # The caller isn't expecting trailing newlines.
        maybe_line = maybe_line.rstrip()
        # No TTY means input isn't visible in the console. Make it visible!
        # Print the input along with a newline so the user can understand
        # what's happening.
        sys.stdout.write(f"{maybe_line}\n")
        sys.stdout.flush()
        return maybe_line

    user_line = await stdin_readline()
    return user_line.rstrip()


def input_yes_no(query, default=False, *, blocking=True):
    """
    Solicit and collect yes/no input from the user, and return result as a
    boolean.

    Args:
        query: The string question to ask users.
        default: The default response as a boolean.
        blocking: If True, run in a new asyncio event loop and block until
            completion. If False, run asynchronously in the current event loop,
            finishing upon receiving user input.

    Returns:
        The user's response as a boolean.

    Side-effects:
        Print to stdout and read from stdin.
    """

    async def _input_yes_no():
        yes_opt = "y"
        no_opt = "n"
        if default:
            opts_prompt = f"[{yes_opt.upper()}/{no_opt}]"
        else:
            opts_prompt = f"[{yes_opt}/{no_opt.upper()}]"
        prompt = f"{query} {opts_prompt} "
        user_input = await ainput(prompt)
        user_input = user_input.lower()

        if user_input == yes_opt:
            return True
        elif user_input == no_opt:
            return False
        else:
            return default

    if blocking:
        from asyncio import run
        return run(_input_yes_no())
    else:
        return _input_yes_no()


def yaml_load(yaml_in, *, name=None):
    from ruamel.yaml import YAML
    """
    Convenience function for loading YAML. Works with strings and file handles.
    Intercepts any YAML parsing errors and coerces them into more user-friendly
    error messages.

    Raises:
        UserError whenever a YAML parse error is hijacked.
    """
    try:
        # NOTE: 'rt' is slower, but that's not likely to be the bottleneck on
        #       the client side.
        return YAML(typ="rt").load(yaml_in)
    except Exception as err:
        # HACK: Working with the YAML exceptions is like nailing jello to a
        #       tree. There's no common parent class for "Marked" exceptions.
        #       And YAMLError and YAMLWarning are used interchangeably.
        #       Fortunately, whenever class hierarchies crumble do the ground,
        #       duck typing is there to pick up the pieces!
        needed_attrs = ["note", "context_mark", "problem_mark"]
        if not all(hasattr(err, attr) for attr in needed_attrs):
            raise
        from textwrap import indent
        # The note/warn are usually for developers. Users won't care. Delete.
        err.note = None
        if hasattr(err, "warn"):
            # Not everything has 'warn'. Fix that by making nothing have
            # 'warn'.
            err.warn = None
        # Set the name to something more useful than '<unicode string>'
        if name is not None:
            # We don't always have both marks. Be careful.
            for attr in ['context_mark', 'problem_mark']:
                mark = getattr(err, attr)
                try:
                    mark.name = name
                except AttributeError:
                    pass
        # Create a more user-centric error.
        message = "\n".join([
            "Failed to parse YAML for the following reason:",
            indent(str(err), " │  "),
        ])
        raise UserError(message) from err


def yaml_dumps(data):
    """Convenience function for dumping YAML as a string"""
    from io import StringIO
    from ruamel.yaml import YAML
    yaml = YAML()
    yaml_stream = StringIO()
    yaml.dump(data, yaml_stream)
    return yaml_stream.getvalue()


##################
# Tab completions
##################

# Bake the args we want into our cue_autocomplete callable
def cue_autocomplete(parser, **kwargs):
    # EARLY RETURN
    if not wants_completion():
        return
    from cli_cue.minimock import SimplePatch
    from contextlib import ExitStack
    import argcomplete
    import argparse
    import os

    # MEGAHACK: argcomplete eats all parser errors while it figures out which
    #       options/subparsers are active. Unfortunately, when an "invalid
    #       choice" is provided, the "active parser" is the parent of the
    #       invalid subcommand.  This means `cl config bogus <tab>` gives us
    #       the completions for `cl config <tab>`, even though it should give
    #       us nothing.
    #       To address this, we have to spy on any ArgumentErrors raised from
    #       argparse. When the "invalid choice" error is raised, we turn off
    #       the completions by making `autocomplete.filter_completions` filter
    #       out everything.
    autocomplete = argcomplete.CompletionFinder()

    class AutocompleteArgumentError(argparse.ArgumentError):
        def __init__(self, argument, message):
            if message.startswith("invalid choice: "):
                # Turn off completions, since this isn't a valid command
                # anymore.
                autocomplete.filter_completions = lambda *_: []
            return super().__init__(argument, message)

    with ExitStack() as stack:
        # NOTE: This is mostly for the unit tests, so we don't spill the patch
        #       over to subsequent tests.
        stack.enter_context(SimplePatch(
            argparse, "ArgumentError", AutocompleteArgumentError,
        ))
        # JUMBOHACK: Bash completion is weird about colons. argcomplete tries
        #       to be smart about this weirdness. That "intelligence" mucks
        #       with completions when a colon is at play.
        #       To address this, we patch the environment variables to tell
        #       argcomplete that colons aren't a wordbreak.
        stack.enter_context(SimplePatch(
            os,
            "environ",
            {
                **os.environ,
                "_ARGCOMPLETE_COMP_WORDBREAKS": os.environ.get(
                    "COMP_WORDBREAKS", ""
                ).replace(":", "")
            }
        ))
        autocomplete(
            parser,
            always_complete_options=False,
            default_completer=None,
            **kwargs,
        )


def make_files_completer(**init_kwargs):
    """
    Make a FilesCompleter that respects hidden files by default.

    Args:
        **init_kwargs: Keyword arguments will be used to init the completer.
    """
    if not wants_completion():
        # We don't care unless we're completing. Bail out before doing any real
        # work.
        return lambda *_: None

    from argcomplete.completers import FilesCompleter

    class RespectHiddenFilesCompleter(FilesCompleter):
        """
        A FilesCompleter that respects hidden files by default.
        """
        def __call__(self, prefix, **kwargs):
            from os.path import basename

            completions = super().__call__(prefix, **kwargs)

            prefix_basename = basename(prefix)
            if prefix_basename.startswith("."):
                return completions
            else:
                return [
                    comp
                    for comp in completions
                    # HACK: strip trailing '/' so the directory shows up in
                    #       basename
                    if not basename(comp.rstrip("/")).startswith(".")
                ]

    return RespectHiddenFilesCompleter(**init_kwargs)


@needs_connection(get_hostname=lambda **kw: kw["parsed_args"].hostname)
def complete_api(**_):
    links_resp = fetch_templatelinks()
    paths = [
        link["anchor"]
        for link in links_resp["links"]
        if link["rel"] == "up"
    ]
    return [path[1:] for path in paths]


def make_revision_completer(
    info_filter=lambda _: True,
    include_magic_pending=False,
    additional_completions=tuple(),
    result_filter=lambda comp, parsed_args: True,
):
    @needs_connection(get_hostname=lambda **kw: kw["parsed_args"].hostname)
    def _revision_completer(parsed_args, **_):
        revisions_resp = send_request(CueRequest(
            path="/cue_v1/revision",
            method="GET",
        ))
        # Filter down the list of completions from the server
        completions = [
            rev_id
            for rev_id, info in revisions_resp.items()
            if info_filter(info)
        ]
        # Handle the magic pending revision if needed
        if include_magic_pending:
            try:
                get_active_pending_revision()
            except NoPendingRevisionError:
                pass
            else:
                completions.append(REVISION_ID_ACTIVE_PENDING)
        return [
            comp
            for comp in [*completions, *additional_completions]
            if result_filter(comp, parsed_args)
        ]

    return _revision_completer


###################
# Parsing commands
###################

PATH_TO_OAI_REQUEST_SCHEMA = (
    "requestBody", "content", "application/json", "schema",
)
PATH_TO_OAI_RESPONSE_SCHEMA = (
    "responses", "200", "content", "application/json", "schema",
)


def schema_path_for_method(method):
    if method.upper() in HTTP_METHODS_WITH_BODIES:
        return (method.lower(), *PATH_TO_OAI_REQUEST_SCHEMA)
    else:
        return (method.lower(), *PATH_TO_OAI_RESPONSE_SCHEMA)


def fetch_closest_templatelinks(api, path_tuple, allow_retry=False):
    links_resp = None
    unmatched_path = tuple()
    while links_resp is None:
        try:
            links_resp = fetch_templatelinks(api, list(path_tuple))
        except CueRequestError as err:
            if not allow_retry or err.status != 404 or len(path_tuple) == 0:
                raise
            # Go up one level and try again
            unmatched_path = (path_tuple[-1], *unmatched_path)
            path_tuple = path_tuple[:-1]

    return (links_resp, unmatched_path)


###################################
# get_value_usage_string
###################################

def iterschema(schema):
    """
    Iterate over each subschema in a schema, yielding a 3-tuple
    `(instance_path, schema_path, subschema)` for each subschema.
    """
    paths_by_instance = group_schema_paths_by_instance_path(schema)
    for instance_path, schema_paths in paths_by_instance.items():
        for schema_path in schema_paths:
            subschema = deep_get(schema, schema_path)
            yield (instance_path, schema_path, subschema)


def get_schema_keywords(schema, target_instance_path, keywords):
    """
    Find all values for keywords at target_instance_path in schema.

    Returns:
        `{keyword: {schema_path: keyword_value}}`
    """
    collected = {kw: {} for kw in keywords}
    for instance_path, schema_path, subschema in iterschema(schema):
        if instance_path != target_instance_path:
            continue
        for sought_key in keywords:
            if sought_key in subschema:
                collected[sought_key][schema_path] = subschema[sought_key]
    return collected


def get_value_usage_string(schema, instance_path):
    keywords = {"maximum", "minimum", "enum", "maxProperties", "format"}
    relevant_vals = get_schema_keywords(schema, instance_path, keywords)
    usage_alternatives = []

    ###########################################################################
    # Look for number ranges
    mins = relevant_vals["minimum"]
    maxs = relevant_vals["maximum"]
    # Only care about the subschemas that have BOTH min and max
    min_max_schema_locs = filter(maxs.__contains__, mins.keys())
    for schema_path in min_max_schema_locs:
        usage = f"{mins[schema_path]}-{maxs[schema_path]}"
        usage_alternatives.append(usage)

    ###########################################################################
    # Look for enums
    for enum_values in relevant_vals["enum"].values():
        for val in enum_values:
            if val is not None:
                usage_alternatives.append(val)

    ###########################################################################
    # Look for state machines
    if set(relevant_vals["maxProperties"].values()) == {1}:
        instance_paths = group_schema_paths_by_instance_path(schema).keys()
        usage_alternatives.extend([
            # Get the next token after the instance path
            path[len(instance_path)]
            for path in instance_paths
            if (
                path != instance_path
                and path[:len(instance_path)] == instance_path
            )
        ])

    ###########################################################################
    # Look for formats
    for format_attribute in relevant_vals["format"].values():
        usage_alternatives.append(
            f"<{format_attribute}>"
        )

    # Dedup the usage alternatives (while preserving order.)
    usage_alternatives = list(dict.fromkeys(usage_alternatives))

    if len(usage_alternatives) == 0:
        # Ehh, still not sure what it is. Let's go with something noncommittal.
        return "<value>"
    elif len(usage_alternatives) == 1:
        return usage_alternatives[0]
    else:
        return "(" + "|".join(usage_alternatives) + ")"


@needs_connection
def create_path_subparser_def(parsed, unknown):
    api = parsed.api

    mode = parsed.mode
    http_method = {
        "tree": "GET",
        "list-commands": "GET",
        "show": "GET",
        "set": "PATCH",
        "unset": "PATCH",
    }[mode]

    wants_body = http_method in HTTP_METHODS_WITH_BODIES

    dot_tokens = None
    path_tuple = tuple(unknown)

    if wants_body and not wants_completion():
        # Drop dot syntax from path_tuple, since that won't be part of the
        # path.
        idx_first_dot = next((
            idx
            for idx, token in enumerate(path_tuple)
            if token.startswith(".")
        ), len(path_tuple))
        dot_tokens = path_tuple[idx_first_dot:]
        path_tuple = path_tuple[:idx_first_dot]
        # Make sure the dot_tokens look right
        if not all(map(lambda token: token.startswith("."), dot_tokens[0::2])):
            raise UserError(
                "Every second token after first '.'-prefixed"
                + " token should also start with '.'"
            )

    allow_retry = (
        # If we're excecuting a command, we always want to grab parent info for
        # helptext.
        not wants_completion()
        # If we're completing, we only want to allow crawling back up the chain
        # if it makes sense.
        or (wants_body and mode != "unset")
    )

    try:
        links_resp, unmatched_path = fetch_closest_templatelinks(
            api, path_tuple, allow_retry
        )
    except CueRequestError:
        # Technically barfing here on completions would be fine, but it makes
        # the unit tests easier if we don't.
        if wants_completion():
            return {}
        raise

    if unmatched_path:
        path_tuple = path_tuple[:-len(unmatched_path)]

    def _get_next_link_segments():
        all_links = links_resp["links"]
        child_links = filter(
            lambda link: (
                link["rel"] == "up"
                and "anchor" in link
                and http_method in link.get(
                    "contextHints", {}).get("allow", [])
                and link["anchor"] not in OBJECT_MODEL_IGNORE
            ),
            all_links
        )

        return tuple(map(
            lambda link: link["anchor"].strip("/").split("/")[-1],
            child_links
        ))
    next_params = _get_next_link_segments()

    def _expand_next_identifier():
        next_identifier = None
        path_completions = []
        for param in next_params:
            if not param.startswith("{"):
                path_completions.append(param)
            else:
                # Squirrel away the identifier for the next level
                next_identifier = param.strip("{}")
                path_completions.extend([
                    suggestion
                    for suggestion in (
                        links_resp["template"]["suggested"][next_identifier]
                    )
                ])
        return next_identifier, path_completions

    next_identifier, path_completions = _expand_next_identifier()

    def _fetch_oai_resp():
        uses_oai_resp = (
            (
                wants_body
                and not (mode == "unset" and len(unmatched_path) > 0)
            )
            or not wants_completion()
        )
        if not uses_oai_resp:
            return {}, []
        else:
            oper = OaiOperation(
                api, list(map(str, path_tuple)), http_method
            )
            return oper.schema, oper.parameters

    schema, parameters = _fetch_oai_resp()

    # HACK: This list will be populated while getting attribute completions.
    #       Any empty object properties will be captured here and treated as
    #       flags/states.
    empty_props = []

    def _get_attribute_completions():
        if http_method not in HTTP_METHODS_WITH_BODIES:
            return []

        by_instance_path = group_schema_paths_by_instance_path(schema)

        def _is_attribute_completion(instance_path):
            obviously_not = not (
                len(instance_path) == 1
                # We only want explicit attributes, not wildcards/keys (which
                # are handled by the path_completions.)
                and isinstance(instance_path[0], str)
                and instance_path[0] not in path_completions
            )
            if obviously_not:
                return False
            found_types = set(get_schema_types(
                schema, instance_path,
                strict_match=True,
            ))

            # NOTE: Determining a boolean with if blocks is silly/verbose, but
            #       it helps us get a reasonable coverage report.
            if found_types != {"object"}:
                # It's not an object, so we can use it as a value.
                return True

            is_empty_prop = all(
                properties == {}
                for properties in find_schema_keyword(
                    "properties", schema, instance_path
                )
            )
            if is_empty_prop:
                # HACK: Grab it so we can (maybe) use it as a flag/state. Still
                #       let it fall through to `False`. It's not a normal
                #       completion.
                empty_props.append(instance_path[0])
            return False

        return [
            instance_path[0]
            for instance_path in by_instance_path.keys()
            if _is_attribute_completion(instance_path)
        ]

    attribute_completions = _get_attribute_completions()
    completions = [*path_completions, *attribute_completions]

    self_link = next(filter(
        lambda link: link["rel"] == "self",
        links_resp["links"]
    ))

    def _find_identifier_synopsis(id_):
        try:
            schema = next(
                param['schema']
                for param in parameters
                if param.get('name') == id_
            )
            return next(
                find_schema_keyword("x-cue-synopsis", schema, tuple()),
            )
        except StopIteration:
            return None

    base_def = {}

    def _fill_out_path_nodes():
        _, *link_tokens = self_link["href"].strip("/").split("/")

        cur_node = base_def
        for cli_token, link_token in zip(path_tuple, link_tokens):
            if link_token.startswith("{"):
                identifier = link_token.strip("{}")
                metavar = f"<{identifier}>"
                next_node = {
                    "metavar": metavar,
                    "help": _find_identifier_synopsis(identifier),
                    # HACK: null out description, so the keyword helptext
                    #       doesn't get used as helptext
                    "description": None,
                    "dest": "positional",
                    "choices": [cli_token],
                }
                cur_node.update({
                    "identifier_node": next_node
                })

            else:
                next_node = {
                    "value": cli_token,
                    "help": None,
                }
                cur_node.update({
                    "nodes": {
                        "dest": "positional",
                        "title": "Attributes",
                        "choices": [next_node],
                    },
                })
            cur_node = next_node
        return cur_node

    cur_node = _fill_out_path_nodes()

    def _find_description(path, default=None):
        return next(find_schema_keyword("description", schema, path), default)

    cur_node["description"] = _find_description(tuple())

    def _can_request_current_link():
        try:
            return (
                http_method in self_link["targetHints"]["allow"]
                # HACK: This one says we can request it, but we really
                #       can't/shouldn't.
                and self_link["href"] != "/cue_v1/"
            )
        except KeyError:
            return False

    is_self_valid = (
        _can_request_current_link()
        # NOTE: tree is special, and we can request any point with it.
        or mode in ["tree", "list-commands"]
    )

    usage = "%(prog)s [options]"

    if dot_tokens and len(unmatched_path) == 0:
        # HACK: accommodate dot tokens at the cost of helptext accuracy
        cur_node.update({
            "groups": [{
                "title": None,
                "arguments": [{
                    "value": "dot_tokens",
                    "help": argparse.SUPPRESS,
                    "nargs": len(dot_tokens),
                    "action": "store",
                }],
            }],
        })
    elif next_identifier is None and len(completions) == 0:
        # Is this a state/flag?
        if empty_props and mode == "set":
            empty_props = list(dict.fromkeys(empty_props))
            usage_options = "|".join(empty_props)
            if len(empty_props) == 1:
                # No need for parens if there's only one option.
                usage = f"{usage} {usage_options}"
            else:
                usage = f"{usage} ({usage_options})"
            cur_node.update({
                "usage": usage,
                "groups": [{
                    "title": None,
                    "arguments": [{
                        "value": "payload_value",
                        "required": True,
                        # Need to suppress this, otherwise weird artifacts show
                        # up in the helptext.
                        "help": argparse.SUPPRESS,
                        "choices": empty_props,
                    }]
                }]
            })
        else:
            cur_node.update({
                "usage": usage,
            })
    elif next_identifier is None:
        if is_self_valid:
            usage = f"{usage} [<attribute> ...]"
        else:
            usage = f"{usage} <attribute> ..."

        try:
            next_unmatched = unmatched_path[0]
        except IndexError:
            next_unmatched = None

        def _create_choice(comp):
            choice = {
                "value": comp,
                "help": _find_description((comp,)),
                "usage": "%(prog)s [options]",
            }
            # EARLY RETURN
            if not wants_body or mode == "unset" or comp != next_unmatched:
                return choice

            usage_value = get_value_usage_string(
                schema, (comp,)
            )
            choice["usage"] = f"%(prog)s [options] {usage_value}"

            if wants_completion():
                # Find the possible next values
                next_comps = [
                    val
                    for found_enum in find_schema_keyword(
                        "enum", schema, (comp,)
                    )
                    for val in found_enum
                    # NOTE: because of PATCH, `null` can be in the enums.
                    if val is not None
                ] or None
            else:
                # Accept anything when actually executing commands
                next_comps = None

            choice["groups"] = [{
                "title": None,
                "arguments": [{
                    "value": "payload_value",
                    # Need to suppress this, otherwise weird artifacts show up
                    # in the helptext.
                    "help": argparse.SUPPRESS,
                    "choices": next_comps
                }]
            }]
            return choice

        cur_node.update({
            "usage": usage,
            "nodes": {
                "dest": "positional",
                "title": "Attributes",
                "required": not is_self_valid,
                "metavar": "<attribute>",
                "choices": [
                    _create_choice(comp)
                    for comp in completions
                ],
            }
        })
    else:
        # "set" commands on collections aren't useful. A specific item must be
        # specified for the command to have any meaning.
        is_self_valid = is_self_valid and mode != "set"

        next_metavar = f"<{next_identifier}>"
        if is_self_valid:
            usage = f"{usage} [{next_metavar} ...]"
        else:
            usage = f"{usage} {next_metavar} ..."
        cur_node.update({
            "usage": usage,
            "identifier_node": {
                "metavar": next_metavar,
                "dest": "positional",
                "required": not is_self_valid,
                "help": next(find_schema_keyword(
                    "x-cue-synopsis", schema, (PATH_KEY,)
                ), ""),
                "choices": completions,
            },
        })
    return base_def


class PrettyOSErrors:
    """
    A context manager that captures OSErrors and converts them into friendlier
    UserErrors.

        >>> with PrettyOSErrors(), open('bogus-file.txt'):
        ...     pass
        Traceback (most recent call last):
            ...
        UserError("'bogus-file.txt': No such file or directory")

    IMPORTANT: If you're opening the file in the same `with` statement,
            `PrettyOSErrors()` MUST come before `open(...)`. Otherwise, the
            file won't be opened inside the PrettyOSErrors context.
    """

    __slots__ = ()

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_value, traceback):
        if isinstance(exc_value, OSError):
            # Create a more friendly representation of the OSError message.
            msg = f"{repr(exc_value.filename)}: {exc_value.strerror}"
            raise UserError(msg)


@lru_cache(maxsize=None)
def load_cue_file(path):
    """
    Load and parse a CUE file into a single "patch" object.

    HACK: This function is cached. LocoParser runs multiple passes at parsing
          argv, and we don't want to do all this heavy lifting multiple times.
          It's weird, but it's simpler than fixing it on the LocoParser side.

    Args:
        path: String path to read file from.

    Returns:
        A patch object for use as a JSON payload.

    Raises:
        UserError if the CUE file couldn't be loaded into a patch.
    """
    from cli_cue.patches import convert_cue_yaml_to_patch

    with PrettyOSErrors(), open(path) as f:
        text = f.read()
    if text.strip() == "":
        raise UserError("CUE file must not be empty.")
    cue_operations = yaml_load(text, name=path)
    return convert_cue_yaml_to_patch(cue_operations)


def argtype_cue_file(path):
    """An argument type representing a CUE file."""
    return load_cue_file(path)


def argtype_duration(duration: str) -> int:
    """
    A positive integer followed by a time unit.

    Returns:
        An int representing the duration in seconds.
    """
    from datetime import timedelta
    # Strip all whitespace
    duration = duration.strip().replace(" ", "")
    duration_unit_conversions = {
        "s": "seconds",
        "m": "minutes",
        "h": "hours",
    }
    short_unit = duration.lstrip("".join(map(str, range(10))))
    num = duration[:-len(short_unit)]
    # Strip leading zeroes.
    num = num.lstrip('0')
    try:
        unit = duration_unit_conversions[short_unit]
    except KeyError:
        raise UserError("\n".join([
            f"Invalid {argtype_duration.__name__} unit: {short_unit!r}",
            f"The following units are supported:",
            *[
                f"  {short} ({full})"
                for short, full in duration_unit_conversions.items()
            ]
        ]))
    if num == "":
        raise UserError(
            f'{argtype_duration.__name__} must start with a positive integer.'
        )
    # Coerce the string num to an int
    num = int(num)

    # NOTE: timedelta.total_seconds() output gets a decimal part when
    #       serializing as JSON. Convert it to an int to make JSON Schema
    #       validation happy.
    return int(timedelta(**{unit: num}).total_seconds())


# HACK: argparse's type errors use __name__. Give it a user-friendly value.
argtype_duration.__name__ = "<duration>"


def parse_argv(argv=None):
    """
    Parse the command line arguments with argparse.

    Args:
        argv: List of strings corresponding to sys.argv

    Returns:
        An argparse parsed options object.

    Side effects:
        Calls argcomplete.autocomplete on the argparse parser. When in
        tab-complete mode, this causes the script to call the configured
        completers and end script execution immediately after handling the
        completions.
    """
    # The title for the revision section of config commands
    _revision_positional_group_title = "Revision"

    prompt_option_group = {
        "title": "Prompt Options",
        "mutually_exclusive": True,
        "arguments": [
            {
                "value": ("-y", "--assume-yes"),
                "help": "Automatic yes to all prompts",
                "dest": "prompt_assume",
                "action": "store_const",
                "const": PROMPT_ASSUME_YES,
            },
            {
                "value": "--assume-no",
                "help": "Automatic no to all prompts",
                "dest": "prompt_assume",
                "action": "store_const",
                "const": PROMPT_ASSUME_NO,
            },
        ],
    }

    config_commands_def = {
        "dest": "config_mode",
        "title": "Commands",
        "metavar": "<command>",
        "required": True,
        "choices": [
            {
                "value": "apply",
                "usage": "%(prog)s [options] [<revision>]",
                "help": "Apply the running configuration.",
                "defaults": {
                    "prompt_assume": PROMPT_ASSUME_DEFAULT,
                },
                "groups": [
                    {
                        "title": "Apply Confirm Options",
                        "mutually_exclusive": True,
                        "arguments": [
                            {
                                "value": "--confirm",
                                "help": (
                                    "Roll back apply after duration has passed"
                                    + " if no confirmation is provided"
                                    + " (default duration: %(const)s)"
                                ),
                                "metavar": argtype_duration.__name__,
                                "dest": "apply_confirm",
                                "action": "store",
                                "nargs": "?",
                                "type": argtype_duration,
                                "const": "10m",
                            },
                            {
                                "value": "--confirm-yes",
                                "help": "Confirm the apply, keeping it.",
                                "action": "store_const",
                                "dest": "apply_state",
                                "const": STATE_CONFIRM_YES,
                            },
                            {
                                "value": "--confirm-no",
                                "help": (
                                    "Roll back the unconfirmed apply now."
                                ),
                                "action": "store_const",
                                "dest": "apply_state",
                                "const": STATE_CONFIRM_NO,
                            },
                            {
                                "value": "--confirm-status",
                                "help": (
                                    "Show remaining time before rollback."
                                ),
                                'action': "store_true",
                                'dest': 'confirm_status',
                            },
                        ],

                    },
                    prompt_option_group,
                    {
                        "title": _revision_positional_group_title,
                        "arguments": [{
                            "value": "revision",
                            "help": (
                                "The revision to apply (default: pending)"
                            ),
                            "metavar": "<revision>",
                            "nargs": "?",
                            # NOTE: The default will get filled in as pending
                            #       elsewhere.
                            "default": None,
                            "completer": make_revision_completer(
                                lambda info: info["state"] == "pending",
                                include_magic_pending=True,
                                # HACK: startup isn't technically pending,
                                #       but we can still apply it
                                additional_completions=["startup"],
                            ),
                        }],
                    },
                ],
            },
            {
                "value": "save",
                "usage": "%(prog)s [options]",
                "help": "Overwrite startup with the applied revision.",
            },
            {
                "value": "replace",
                "usage": "%(prog)s [options] <cue-file>",
                "help": "Replace pending revision with the specified file",
                # TODO: add description?
                "groups": [{
                    # TODO: Suppress this and describe in Description?
                    "title": "File Options",
                    "arguments": [
                        {
                            "value": "cue_file",
                            "help": "Location of file to load",
                            "metavar": "<cue-file>",
                            "type": argtype_cue_file,
                            "completer": make_files_completer(
                                allowednames=("yaml", "yml"),
                            ),
                        },
                    ],
                }],
            },
            {
                "value": "detach",
                "usage": "%(prog)s [options]",
                "help": "Detach from the current pending revision",
            },
            {
                "value": "diff",
                "usage": (
                    "%(prog)s [options] [<revision>] [<revision>]"
                ),
                "help": "Show differences between two config revisions",
                "groups": [{
                    "title": "Diff Options",
                    "arguments": [
                        {
                            "value": "diff_revision_base",
                            "nargs": "?",
                            # HACK: Since we're displaying both as <revision>,
                            #       we only want it to show up once. Suppress
                            #       the first instance and leave all the
                            #       "display" work to the second instance.
                            "help": argparse.SUPPRESS,
                        },
                        {
                            "value": "diff_revision_target",
                            "metavar": "<revision>",
                            "help": "A revision to include in the diff.",
                            "nargs": "?",
                            "completer": make_revision_completer(
                                include_magic_pending=True,
                                # TODO: CUE-2611
                                additional_completions=["applied"],
                                result_filter=lambda comp, parsed_args: (
                                    # Don't suggest duplicate revisions.
                                    comp != parsed_args.diff_revision_base
                                )
                            )
                        },
                    ]
                }]
            },
            {
                "value": "patch",
                "usage": "%(prog)s [options] <cue-file>",
                "help": "Update the pending revision with a config YAML file",
                # TODO: add description?
                "groups": [
                    {
                        # TODO: Suppress this and describe in Description?
                        "title": "File Options",
                        "arguments": [
                            {
                                "value": "cue_file",
                                "help": "Location of file to load",
                                "metavar": "<cue-file>",
                                "type": argtype_cue_file,
                                "completer": make_files_completer(
                                    allowednames=("yaml", "yml"),
                                ),
                            },
                        ],
                    },
                ],
            },
            {
                "value": "attach",
                # NOTE: <revision> is required here.
                "usage": "%(prog)s [options] <revision>",
                "help": argparse.SUPPRESS,
                "description": "Attach to a pending revision.",
                "groups": [{
                    "title": _revision_positional_group_title,
                    "arguments": [{
                        "value": "revision",
                        "help": (
                            "The revision to attach as the active revision"
                        ),
                        "metavar": "<revision>",
                        "nargs": "?",
                        "completer": make_revision_completer(
                            lambda info: info["state"] == "pending"
                        ),
                    }],
                }],
            },
            {
                "value": "revision",
                "usage": "%(prog)s [options] [filter option]",
                "help": argparse.SUPPRESS,
                "description": "Display the state of revisions.",
                "groups": [{
                    "title": "Filter Options",
                    "mutually_exclusive": True,
                    "arguments": [
                        {
                            "value": "--pending",
                            "action": "store_const",
                            "const": "pending",
                            "dest": "revision_filter",
                            "help": "Only show pending revisions",
                        },
                        {
                            "value": "--applied",
                            "action": "store_const",
                            "const": "applied",
                            "dest": "revision_filter",
                            "help": "Only show applied revisions",
                        },
                        {
                            "value": "--current",
                            "action": "store_const",
                            "const": "current",
                            "dest": "revision_filter",
                            "help": "Only show the current revision",
                        },
                    ],
                }]
            },
            {
                "value": "tracked",
                "usage": "%(prog)s [options]",
                "help": argparse.SUPPRESS,
                "description": "Print the current tracked revision id.",
            },
            {
                "value": "history",
                "usage": "%(prog)s [options] [<revision>]",
                "help": "Show revision's 'apply' history.",
                "groups": [
                    {
                        "title": _revision_positional_group_title,
                        "arguments": [{
                            "value": "revision",
                            "help": (
                                "A revision (default: tracked)"
                            ),
                            "metavar": "<revision>",
                            "nargs": "?",
                            "default": None,
                            "completer": make_revision_completer(
                                include_magic_pending=True,
                            ),
                        }],
                    },
                ],
            },
        ],
    }

    revision_option_group = {
        "title": "Revision Options",
        "mutually_exclusive": True,
        "propagate": True,
        "arguments": [
            {
                "value": "--rev",
                "help": "The revision id to operate on",
                "metavar": "<revision>",
                "default": None,
                "action": "store",
                "completer": make_revision_completer(
                    include_magic_pending=True,
                    # HACK: since applied doesn't show up in
                    #       /cue_v1/revision
                    additional_completions=["applied", "operational"],
                ),
            },
            {
                "value": "--pending",
                "help": "Alias of '--rev=pending'",
                "dest": "rev",
                "action": "store_const",
                "const": "pending",
            },
            {
                "value": "--applied",
                "help": "Alias of '--rev=applied'",
                "dest": "rev",
                "action": "store_const",
                "const": "applied",
            },
            {
                "value": "--startup",
                "help": "Alias of '--rev=startup'",
                "dest": "rev",
                "action": "store_const",
                "const": "startup",
            },
            {
                "value": "--operational",
                "help": "Alias of '--rev=operational'",
                "dest": "rev",
                "action": "store_const",
                "const": "operational",
            },
        ],
    }

    def _make_output_option_group(output_choices=SUPPORTED_OUTPUTS):
        return {
            "title": "Output Options",
            "propagate": True,
            "arguments": [
                {
                    "value": ("--output", "-o"),
                    "help": (
                        "Supported formats: %(choices)s (default: %(default)s)"
                    ),
                    "choices": output_choices,
                    "metavar": "<format>",
                    "default": DEFAULT_OUTPUT,
                    "action": "store"
                },
                {
                    "value": "--color",
                    "help": "When to color output (default: %(default)s)",
                    "metavar": f"({'|'.join(SUPPORTED_COLORS)})",
                    "choices": SUPPORTED_COLORS,
                    "default": DEFAULT_COLOR,
                    "action": "store"
                },
            ]
        }

    parser_def = {
        "usage": "%(prog)s <command> [options] ...",
        "description": "CUE: management CLI",
        "groups": [
            {
                "title": argparse.SUPPRESS,
                "propagate": False,
                "arguments": [
                    {
                        "value": "--api",
                        "help": argparse.SUPPRESS,
                        "default": DEFAULT_API,
                        "action": "store",
                        "completer": complete_api,
                    },
                    {
                        "value": "--hostname",
                        # TODO: CUE-4008
                        "help": argparse.SUPPRESS,
                        "default": DEFAULT_HOSTNAME,
                        "action": "store",
                    },
                    *_make_output_option_group()["arguments"],
                ]
            },
            {
                **revision_option_group,
                # HACK: We want revision options here for backwards
                #       compatibility. Since they're not used in all
                #       subcommands, however, we're not going to show them in
                #       the helptext or propagate them to subcommands. The
                #       subcommands that need them will get them.
                "title": argparse.SUPPRESS,
                "propagate": False,
            },
            {
                "title": "General Options",
                "propagate": True,
                "arguments": [{
                    "value": ["-h", "--help"],
                    "help": "Show help.",
                    "action": "help",
                }],
            },
        ],
        "commands": {
            "dest": "mode",
            "title": "Commands",
            "metavar": "<command>",
            "required": True,
            "choices": [
                {
                    "value": "show",
                    "help": "Show system configuration.",
                    "defaults": {"positional": tuple()},
                    "groups": [
                        revision_option_group,
                        _make_output_option_group([
                            choice
                            for choice in SUPPORTED_OUTPUTS
                            # FIXME: Allow specifying the "pretty" outputs once
                            #        we've given them final names.
                            if choice not in {"constable", "end-table"}
                        ]),
                    ],
                    "hook": create_path_subparser_def,
                },
                {
                    "value": "tree",
                    "help": argparse.SUPPRESS,
                    "description": HELPTEXT_CL_TREE,
                    "defaults": {"positional": tuple()},
                    "groups": [{
                        "title": "Tree Options",
                        "propagate": True,
                        "arguments": [{
                            "value": ("--show-proposed", "-P"),
                            "help": "Include OM marked as 'proposed'",
                            "dest": "include_proposed",
                            "action": "store_true",
                        }],
                    }],
                    "hook": create_path_subparser_def,
                },
                {
                    "value": "list-commands",
                    "help": argparse.SUPPRESS,
                    "defaults": {"positional": tuple()},
                    "hook": create_path_subparser_def,
                },
                {
                    "value": "set",
                    "help": "Modify system configurations.",
                    "defaults": {"positional": tuple()},
                    "hook": create_path_subparser_def,
                },
                {
                    "value": "unset",
                    "help": "Unset configuration attributes.",
                    "defaults": {"positional": tuple()},
                    "hook": create_path_subparser_def,
                },
                {
                    "value": "edit",
                    "usage": "%(prog)s [options] [<revision>]",
                    "help": argparse.SUPPRESS,
                    "description": HELPTEXT_CL_EDIT,
                    "groups": [{
                        "title": _revision_positional_group_title,
                        "arguments": [{
                            "value": "revision",
                            "metavar": "<revision>",
                            "help": (
                                "The revision to edit (default: %(default)s)"
                            ),
                            "nargs": "?",
                            "default": "tracked",
                            "completer": make_revision_completer(
                                include_magic_pending=True,
                            ),
                        }],
                    }],
                },
                {
                    "value": "config",
                    "usage": "%(prog)s <command> [options] ...",
                    "help": "Manage/apply configurations.",
                    "commands": config_commands_def,
                },
                {
                    "value": "legacy",
                    "usage": "%(prog)s <legacy-command> [options] ...",
                    "help": argparse.SUPPRESS,
                    "defaults": {"positional": tuple()},
                    "nodes": {
                        "dest": "positional",
                        "title": "Legacy Commands",
                        "required": True,
                        "metavar": "<legacy-command>",
                        "choices": [
                            {
                                "value": "show",
                                "help": "Run a legacy show command.",
                                "usage": (
                                    "%(prog)s [options] <show-argument>..."
                                ),
                                "groups": [{
                                    'title': argparse.SUPPRESS,
                                    'arguments': [{
                                        "value": "positional",
                                        'metavar': '<show-argument>...',
                                        "nargs": "+",
                                    }]
                                }]
                            },
                        ],
                    },
                }
            ],
        }
    }

    return parse_from_json(
        parser_def,
        callback=cue_autocomplete,
    )


def parse_command(argv):
    """
    Parse user input and return it as a CueCommand
    """
    options = parse_argv(argv)
    cmd = CueCommand.from_options(options)
    return cmd


###############################
# poll_revision_state_machine
###############################

class RevisionPollingError(Exception):
    """
    Base class for errors that happen while polling revisions.
    """
    exit_code = 1


class FailureRevisionStateError(RevisionPollingError):
    """
    A known failure state has been reached.
    """

    def __init__(self, *args, rollback=None):
        super().__init__(*args)
        self.rollback = rollback


class UnknownRevisionStateError(RevisionPollingError):
    """
    An unknown revision state has been reached.
    """


class RevisionTimeoutError(RevisionPollingError):
    """
    Too much client-side time has elapsed without progress.
    """
    exit_code = 0


class EarlyExitException(RevisionPollingError):
    """
    Stop polling and exit the command.
    """
    exit_code = 0

    def __init__(self, *, state):
        self.state = state


async def wait_for_revision_state_change(revision, state):
    """
    Asynchronously poll the revision endpoint, and return when the server's
    state is different from the specified 'state' argument.
    """
    import asyncio

    interval = 4  # in seconds
    while True:
        await asyncio.sleep(interval)
        result = fetch_revision(revision)
        if result["state"] != state:
            break
    return


def poll_revision_state_machine(revision, *, prompt_assume):
    """
    Poll the revision's state and print progress messages when appropriate.
    Time out after 120 seconds of no progress.

    Args:
        revision: The revision id to poll
        prompt_assume: What to do when we need user input. Must be one of:
            - `PROMPT_ASSUME_DEFAULT` to prompt user for input;
            - `PROMPT_ASSUME_YES` to assume "yes" for everything; or
            - `PROMPT_ASSUME_NO` to assume "no" for everything.

    Raises:
        FailureRevisionStateError when the revision hits a known "failure"
            state.
        UnknownRevisionStateError when the revision its an unkown state.
        RevisionTimeoutError after too much time elapses without progress.

    Side effects:
        - Spams the revision API endpoint with GET requests.
        - Prints progress/result messages to stdout and stderr.
        - Prompts user for input when SFM needs human input.
            - Sends PATCH request to revision endpoint, based on that input.
    """
    import time
    from cli_cue.minimock import SimplePatch
    from cli_cue.autils import deathrace
    from asyncio import run, CancelledError

    timeout = 120  # in seconds

    min_interval = 0.1
    max_interval = 2
    cur_interval = min_interval

    cur_time = time.perf_counter()
    stop_time = cur_time + timeout

    prev_state = None
    while cur_time < stop_time:

        result = fetch_revision(revision)
        state = result["state"]

        transition = result["transition"]
        # TODO: handle result["issue"]
        progress = transition["progress"]

        # Update the interval.
        if state != prev_state:
            # Stuff's happening. Poll faster and bump the timeout!
            cur_interval = min_interval
            stop_time = cur_time + timeout
        else:
            # No changes. Poll slower.
            cur_interval = min(cur_interval * 1.5, max_interval)

        # Clear the terminal whenever the state changes
        needs_clear = (
            state != prev_state
            and prev_state not in [None, *PROMPT_USER_STATES]
        )
        if needs_clear:
            # Move cursor to the far left
            sys.stdout.write(ANSI_CURSOR_LEFT)
            # Clear to end of cursor
            sys.stdout.write(ANSI_CLEAR_SCREEN_DOWN)
            sys.stdout.flush()

        if state in IN_PROGRESS_STATES:
            # Print the progress state and continue polling
            if state != prev_state:
                sys.stdout.write(state)
                sys.stdout.flush()
        elif state in SUCCESS_STATES:  # EARLY RETURN
            sys.stdout.write(state + "\n")
            return
        elif state in FAILURE_STATES:  # EARLY RETURN
            sys.stderr.write(f"{progress or state}\n")
            rollback_target = None
            for issue in transition["issue"].values():
                sys.stderr.write("  " + issue["message"])
                sys.stderr.write("\n")
                if issue["code"] == "rollback":
                    rollback_target = issue["data"]["rollback_target"]

            if rollback_target:
                # Roll back, redirecting all stdout to stderr. If the user is
                # looking at stdout only, we don't want it to look like the
                # command succeeded.
                with SimplePatch(sys, stdout=sys.stderr):
                    # The exit code for the rollback doesn't matter. The
                    # "apply" failed, so we have to exit nonzero.
                    poll_revision_state_machine(
                        rollback_target, prompt_assume=prompt_assume
                    )
            raise FailureRevisionStateError(rollback=rollback_target)
        elif state in EARLY_EXIT_STATES:
            # Give the user some context info.
            sys.stdout.write(f"{progress or state}\n")
            for issue in transition["issue"].values():
                sys.stdout.write("  " + issue["message"])
                sys.stdout.write("\n")
            raise EarlyExitException(state=state)
        elif state in PROMPT_USER_STATES:
            # Give the user some context info.
            for issue in transition["issue"].values():
                sys.stdout.write(issue["message"])
                sys.stdout.write("\n")
            # Ask the user what they want to do.
            if prompt_assume is PROMPT_ASSUME_DEFAULT:
                # Wait for user input or server-side state change, whichever
                # comes first.
                input_task, *_ = run(deathrace(
                    input_yes_no(progress, default=False, blocking=False),
                    wait_for_revision_state_change(revision, state),
                ))
                # Don't count user time toward the timeout.
                user_time = time.perf_counter() - cur_time
                stop_time = stop_time + user_time
                try:
                    user_response = input_task.result()
                except CancelledError:
                    # EARLY CONTINUE
                    # The server state changed before the user responded. Start
                    # a new line and continue polling the FSM.
                    sys.stdout.write("\n")
                    continue
            else:
                user_response = {
                    PROMPT_ASSUME_YES: True,
                    PROMPT_ASSUME_NO: False,
                }[prompt_assume]
            next_state = PROMPT_USER_STATES[state][user_response]
            # Update the revision accordingly.
            update_revision(revision, {"state": next_state})
            # Carry on with the config apply process.
        else:  # EARLY RETURN
            sys.stderr.write(f"Unknown state: '{state}'\n")
            raise UnknownRevisionStateError()

        # Don't hammer the server overzealously
        time.sleep(cur_interval)
        # Keep track of previous state so we know when it changes
        prev_state = state
        cur_time = time.perf_counter()

    # Print a newline to stdout to make sure the timed out message doesn't end
    # up on the same line as the progress message.
    sys.stdout.write("\n")
    sys.stderr.write("Timed out\n")
    raise RevisionTimeoutError()


###################
# Schema analysis
###################
COLLECTION_VIEW_KEYWORD = "x-cue-collection-view"


def is_collection(schema, instance_path=tuple()):
    return "collection" in find_schema_keyword(
        "x-cue-marker", schema, instance_path
    )


def _get_column_title(schema, dot_path):
    instance_path = (PATH_WILDCARD, *dot_path.split("."))
    return next(
        find_schema_keyword("title", schema, instance_path),
        ".".join(instance_path[1:])
    )


def _get_summary_title(schema, dot_path):
    instance_path = (PATH_WILDCARD, *dot_path.split("."))
    if is_collection(schema, instance_path):
        # We want the title of the key
        instance_path = (*instance_path, PATH_KEY)
    return next(
        find_schema_keyword("title", schema, instance_path),
        dot_path
    )


def find_collection_view(schema, default=None):
    return next(
        find_schema_keyword(COLLECTION_VIEW_KEYWORD, schema, tuple()),
        default
    )


@dataclass
class CollectionView:
    schema: InitVar[dict]

    # These all get determined based off the schema
    id_title: str = field(init=False)
    columns: list = field(init=False)
    summary_includes: list = field(init=False)
    titles: dict = field(init=False)

    def __post_init__(self, schema):
        # Is this something we can actually view as a collection?
        if not is_collection(schema):
            # HACK: hardcoded format name
            raise UserError(
                "Can only use 'constable' format to display collections."
            )

        overrides = find_collection_view(schema, {})

        self.id_title = self._determine_id_header(schema, overrides)
        self.summary_includes = self._determine_summary_includes(
            schema, overrides
        )
        self.columns = self._determine_columns(schema, overrides)
        self.titles = self._determine_titles(schema, overrides)

    def _find_instance_paths(self, schema):
        state_machine_paths = set()
        collection_instance_paths = set()
        primitive_instance_paths = set()

        paths_by_instance = group_schema_paths_by_instance_path(schema)

        for instance_path, schema_paths in paths_by_instance.items():
            if len(instance_path) == 0:
                continue
            if instance_path[0] != PATH_WILDCARD:
                continue
            if PATH_KEY in instance_path[1:]:
                continue

            if PATH_WILDCARD in instance_path[1:]:
                # It's got an inner collection. Add the path leading up to it.
                collection_instance_paths.add(
                    instance_path[:instance_path.index(PATH_WILDCARD, 1)]
                )
            else:
                subschemas = list(
                    map(partial(deep_get, schema), schema_paths)
                )
                is_state_path = any(map(
                    lambda subschema: subschema.get("maxProperties") == 1,
                    subschemas,
                ))
                is_primitive_path = any(map(
                    lambda subschema: (
                        "type" in subschema
                        and subschema["type"] not in ["object", "array"]
                    ),
                    subschemas,
                ))
                if is_state_path:
                    state_machine_paths.add(instance_path)
                elif is_primitive_path:
                    primitive_instance_paths.add(instance_path)

        if len(state_machine_paths) == 0:
            column_instance_paths = primitive_instance_paths
            summary_instance_paths = collection_instance_paths
        else:
            # HACK: remove all paths that start with state machine path
            column_instance_paths = set()
            summary_instance_paths = set()
            for state_path in state_machine_paths:
                column_instance_paths.add(state_path)

                column_instance_paths.update((
                    primitive_path
                    for primitive_path in primitive_instance_paths
                    if primitive_path[:len(state_path)] != state_path
                ))
                summary_instance_paths.update((
                    collection_path
                    for collection_path in collection_instance_paths
                    if collection_path[:len(state_path)] != state_path
                ))

        return column_instance_paths, summary_instance_paths

    def _determine_id_header(self, schema, overrides):
        return overrides.get(
            "id_title",
            next(find_schema_keyword("title", schema, (PATH_KEY,)), "")
        )

    def _determine_columns(self, schema, overrides):
        # EARLY RETURN
        if "columns" in overrides:
            return overrides["columns"]

        # Don't include things on the summary list
        exclude_list = set(self.summary_includes)

        column_instance_paths, _ = self._find_instance_paths(schema)

        found_columns = [
            ".".join(path[1:])
            for path in column_instance_paths
        ]
        columns = [
            col
            for col in found_columns
            if col not in exclude_list
        ]
        # Sort it based on the column paths for consistency
        return sorted(columns)

    def _determine_summary_includes(self, schema, overrides):
        if "summary_includes" in overrides:
            return overrides["summary_includes"]

        found_column_paths, summary_paths = self._find_instance_paths(schema)

        if "columns" in overrides:
            override_columns = set((
                (PATH_WILDCARD, *dot_path.split("."))
                for dot_path in overrides["columns"]
            ))
            # If we've overridden the columns, we should put everything that
            # isn't in the columns in the summary.
            unhandled_column_paths = found_column_paths - override_columns
            summary_paths.update(unhandled_column_paths)

        return sorted([
            ".".join(path[1:])
            for path in summary_paths
        ])

    def _determine_titles(self, schema, overrides):
        title_overrides = overrides.get("titles", {})

        summary_includes = self.summary_includes
        columns = self.columns
        column_titles = {
            dot_path: title_overrides.get(
                dot_path,
                _get_column_title(schema, dot_path)
            )
            for dot_path in columns
        }
        summary_titles = {
            dot_path: title_overrides.get(
                dot_path,
                _get_summary_title(schema, dot_path)
            )
            for dot_path in summary_includes
        }
        return {
            **summary_titles,
            **column_titles,
        }


def _format_table_item(schema, path, value):
    unit = next(find_schema_keyword("x-cue-unit", schema, path), None)
    # EARLY RETURN
    if unit == "byte":
        return format_bytes(value)

    # EARLY RETURN
    if not isinstance(value, dict):
        return str(value)

    max_properties = set(
        find_schema_keyword("maxProperties", schema, path)
    )
    if max_properties == {1}:
        return next(iter(value.keys()), "")
    return str(value)


def _find_summary_defaults(schema, target_path):
    return tuple(find_schema_keyword("default", schema, target_path))


def create_summary_table(schema, instance):
    from cli_cue.tables import SummaryTable
    collection_view = CollectionView(schema)

    columns = collection_view.columns
    titles = collection_view.titles
    id_title = collection_view.id_title
    headers = [
        id_title, *map(titles.__getitem__, columns)
    ]

    summary_includes = collection_view.summary_includes
    summary_keys = list(map(
        titles.__getitem__,
        summary_includes
    ))

    # Collect the default values, so we can show only the non-defaults
    summary_defaults = {
        path: _find_summary_defaults(
            schema, (PATH_WILDCARD, *path.split("."))
        )
        for path in summary_includes
    }

    rows = []
    summary_rows = []
    for id_, obj in instance.items():
        row = {
            id_title: id_,
            **{
                titles[column]: _format_table_item(
                    schema,
                    (PATH_WILDCARD, *column.split(".")),
                    deep_get(obj, column.split("."), "")
                )
                for column in columns
            }
        }
        rows.append(row)
        summary_row = {}
        for summary_path in summary_includes:
            summary_key = titles[summary_path]
            summary_values = []
            summary_target = deep_get(obj, summary_path.split("."), {})
            target_defaults = summary_defaults[summary_path]

            should_skip = (
                len(target_defaults) == 1
                and summary_target == target_defaults[0]
            )
            if should_skip:
                pass
            elif isinstance(summary_target, dict):
                # HACK: assume dict means a collection
                summary_values.extend(map(str, summary_target.keys()))
            else:
                summary_values.append(
                    _format_table_item(
                        schema,
                        (PATH_WILDCARD, *summary_path.split(".")),
                        summary_target,
                    )
                )
            summary_row[summary_key] = summary_values
        summary_rows.append(summary_row)

    if len(summary_keys) == 0:
        return SummaryTable(headers, rows)
    else:
        return SummaryTable(
            headers, rows, [id_title], summary_keys, summary_rows
        )


###########################
# create_instance_table
###########################

def _chomp_description(description):
    chomped_marker = "..."
    max_length = 70
    if len(description) > max_length:
        # We are trimming to 80, including the length of the chomped_marker.
        content_length = max_length - len(chomped_marker)
        description = description[:content_length]
        # We don't want whitespace before the chomped_marker.
        description = description.rstrip()
        description = description + chomped_marker
    return description


def zip_dict_with_keys(dict_of_lists, fillvalue=None):
    """
    Take a dict of lists and transform it into a list of dicts. For example,

    ```
    {"foo": [1, 2], "bar": [3, 4]}
    ```

    becomes

    ```
    [{"foo": 1, "bar": 3}, {"foo": 2, "bar": 4}]
    ```
    """
    from itertools import zip_longest
    return map(dict, map(
        partial(zip, dict_of_lists.keys()),
        zip_longest(
            *dict_of_lists.values(),
            fillvalue=fillvalue,
        ),
    ))


def create_instance_table(schema, **instances):
    # Make sure this is something we can actually show before formatting it.
    if is_collection(schema):
        # HACK: hardcoded format name
        raise UserError(
            "Cannot use 'end-table' format to display collections."
        )

    from cli_cue.tables import TreeTable
    id_column_header = ""
    headers = [id_column_header, *instances.keys(), "description"]

    paths_by_instance = group_schema_paths_by_instance_path(schema)

    instance_view = {}
    try:
        instance_view = next(
            find_schema_keyword("x-cue-instance-view", schema, ())
        )
    except StopIteration:
        pass

    expand_collections = tuple(
        tuple(instance_loc.split("."))
        for instance_loc in instance_view.get('expand_collections', [])
    )

    collection_locations = set()
    state_machine_locations = set()

    def _should_print(instance_path):
        if len(instance_path) == 0:
            return False
        if instance_path in expand_collections:
            return False
        is_printable = all(str(token) == token for token in instance_path)
        if not is_printable:
            return False

        valid_types = set(find_schema_keyword("type", schema, instance_path))
        if valid_types != {"object"}:
            return True

        if is_collection(schema, instance_path):
            collection_locations.add(instance_path)
            return True

        is_inside_an_fsm = any(
            fsm_loc == instance_path[:len(fsm_loc)]
            for fsm_loc in state_machine_locations
        )
        if is_inside_an_fsm:
            return False
        max_properties = set(find_schema_keyword(
            "maxProperties", schema, instance_path
        ))
        if max_properties == {1}:
            state_machine_locations.add(instance_path)
            return True
        return False

    rows = []
    for instance_path in paths_by_instance.keys():
        if not _should_print(instance_path):
            continue

        wants_object_keys = (
            instance_path in collection_locations
            or instance_path in state_machine_locations
        )
        if wants_object_keys:
            revision_values = {
                rev: list(deep_get(
                    instance, instance_path, {None: {}}
                ).keys())
                for rev, instance in instances.items()
            }
        else:
            revision_values = {
                rev: [deep_get(
                    instance, instance_path, None
                )]
                for rev, instance in instances.items()
            }

        # EARLY CONTINUE
        if all(value == [None] for value in revision_values.values()):
            # Skip it if we don't have data for it
            continue

        description = next(
            find_schema_keyword("description", schema, instance_path),
            "",
        ).splitlines()[0]
        description = _chomp_description(description)

        if instance_path in collection_locations:
            # Inner collections have their parent key in brackets to show
            # that they're different.
            id_value = ".".join([
                *instance_path[:-1], f"[{instance_path[-1]}]"
            ])
        else:
            id_value = ".".join(instance_path)

        for row_contents in zip_dict_with_keys(revision_values):
            row_contents = {
                key: _format_table_item(
                    schema, instance_path, value
                ) if value is not None else ""
                for key, value in row_contents.items()
            }
            rows.append({
                **row_contents,
                id_column_header: id_value,
                "description": description,
            })
            # HACK: only print the description on the first line
            description = ""

    under_tables = {}
    collection_instance, *_ = instances.values()
    for instance_path in expand_collections:
        subschema_path, *_ = paths_by_instance[instance_path]
        subschema = deep_get(schema, subschema_path)
        subinstance = deep_get(collection_instance, instance_path, {})
        # Use the title if we can find it
        try:
            title = next(find_schema_keyword('title', schema, instance_path))
        except StopIteration:
            title = '.'.join(instance_path)
        under_tables[title] = create_summary_table(
            subschema,
            subinstance,
        )

    return (
        TreeTable(
            headers=headers,
            rows=rows,
        ),
        under_tables,
    )


####################
# Output formatting
####################

def format_constable(schema, instance):
    summary_table = create_summary_table(schema, instance)
    return summary_table.render()


def format_end_table(schema, **instances):
    from textwrap import indent

    instance_table, sub_views = create_instance_table(schema, **instances)
    output_sections = [instance_table.render()]

    chars_between_sections = "\n\n\n"
    section_underline_padding = 3
    section_underline_char = "="
    section_indent = "    "

    for name, table in sub_views.items():
        section_parts = [name]
        underline_length = len(name) + section_underline_padding
        section_parts.append(
            section_underline_char * underline_length
        )
        section_parts.append(indent(table.render(), section_indent))

        output_sections.append('\n'.join(section_parts))

    return chars_between_sections.join(output_sections)


def format_output(data, output_format):
    # EARLY RETURN (because json/yaml are way easier)
    if output_format == "json":
        return json.dumps(data, sort_keys=True, indent=2)
    elif output_format == "yaml":
        return yaml_dumps(data)
    elif output_format == "constable":
        return format_constable(**data)
    elif output_format == "end-table":
        return format_end_table(**data)
    raise UserError(f"Unsupported format: {output_format}")


def format_bytes(bytes_: int) -> str:
    """
    Format bytes in a human-readable way.

    Args:
        bytes_: The number of bytes

    Returns:
        A human-readable string including the amount and unit.
    """
    bytes_ = int(bytes_)
    kilobyte = 1024
    megabyte = kilobyte ** 2
    gigabyte = megabyte * 1024
    if bytes_ < kilobyte:
        unit = 'Bytes'
        if bytes_ == 1:
            # Use singular form
            unit = 'Byte'
        return f"{bytes_} {unit}"
    elif kilobyte <= bytes_ < megabyte:
        return '{0:.2f} KB'.format(bytes_ / kilobyte)
    elif megabyte <= bytes_ < gigabyte:
        return '{0:.2f} MB'.format(bytes_ / megabyte)
    elif gigabyte <= bytes_:
        return '{0:.2f} GB'.format(bytes_ / gigabyte)


def needs_color(color, stdin, stdout):
    """
    Decide if the output needs color.

    Args:
        color: The color option parsed from input
        stdin: The stdin stream
        stdout: The stdout stream

    Returns:
        True if color is "always" or if color is "auto" and stdin/stdout are
        both TTYs. Otherwise returns False.
    """
    is_tty = stdin.isatty() and stdout.isatty()
    return (color == "always" or (color == "auto"
                                  and is_tty))


def color_yaml(output_string):
    from pygments import highlight
    from pygments.lexers import YamlLexer
    from pygments.formatters import TerminalFormatter
    return highlight(
        output_string,
        YamlLexer(),
        TerminalFormatter(),
    )


def split_yaml_array_items(yaml_string):
    from ruamel.yaml import YAML
    loaded = YAML(typ="rt").load(yaml_string)
    splits = [
        item.lc.line
        for item in loaded
    ]
    result = []
    remaining_lines = yaml_string.splitlines()
    for idx in reversed(splits):
        cur = "\n".join(remaining_lines[idx:]) + "\n"
        result.append(cur)
        remaining_lines = remaining_lines[:idx]
    return list(reversed(result))


def color_yaml_diff(output_string):
    from pygments import highlight
    from pygments.lexers import YamlLexer
    from pygments.formatters import Terminal256Formatter
    from pygments.styles.default import DefaultStyle
    from pygments.style import Style
    from pygments.token import Token

    class UnsetStyle(Style):
        styles = {
            **DefaultStyle.styles,
            Token.Name.Tag: "#ansidarkred",
        }

    class SetStyle(Style):
        styles = {
            **DefaultStyle.styles,
            Token.Name.Tag: "#ansidarkgreen",
        }

    sections = split_yaml_array_items(output_string)

    color_sections = []
    for section in sections:
        style = DefaultStyle
        # HACK: Dumb but quick way to determine if it's a set or unset.
        if section.startswith("- unset:"):
            style = UnsetStyle
        elif section.startswith("- set:"):
            style = SetStyle
        color_sections.append(
            highlight(
                section,
                YamlLexer(),
                # NOTE: Cannot use TerminalFormatter here, since it does not
                #       allow custom styles.
                Terminal256Formatter(style=style),
            )
        )
    return "".join(color_sections)


def apply_color(output_string, output_format):
    """
    Apply color to an output string based off the output format.

    Args:
        output_string: The output string we're applying color to
        output_format: The --output format we're coloring for

    Returns:
        A colored version of the output_string.
    """
    if not output_string:
        # Nothing to color!
        return output_string

    if output_format == "yaml":
        return color_yaml(output_string)
    elif output_format == "yaml_diff":
        return color_yaml_diff(output_string)
    return output_string


def display_in_pager(output):
    """
    Display output in a pager if stdout is a TTY.

    Respects $PAGER environment variable, if set. Otherwise uses "less".

    Args:
        output: String output to display in the pager.

    Side-effects:
        Runs a pager in a subprocess, or writes directly to stdout (if not it's
        not a TTY).
    """
    # EARLY RETURN
    if not sys.stdout.isatty():
        return sys.stdout.write(output)

    import shlex
    import os
    import subprocess
    # Environment variables taken from git's default PAGER_ENV
    os.environ.setdefault('LESS', 'FRX')
    os.environ.setdefault('LV', '-c')
    pager = os.environ.get('PAGER', 'less')
    subprocess.run(
        # $PAGER could be a command. Split it into args.
        shlex.split(pager),
        input=output,
        text=True,
    )


#####################
# Command decorators
#####################
def prints_result(func=None, *, use_pager=False):
    """
    Print the string return value of the wrapped handler.

    Args:
        use_pager: If True and stdout is a TTY, send output to PAGER.

    Side effects:
        Prints result to `out` stream.
    """
    if func is None:
        return lambda func: prints_result(func, use_pager=use_pager)

    @wraps(func)
    def prints_result_wrapper(cmd, *args, **kwargs):
        result = func(cmd, *args, **kwargs)
        # Ensure that we're always ending with only one newline
        output = result.rstrip("\n")
        if output != "":
            output = output + "\n"
            if use_pager:
                display_in_pager(output)
            else:
                sys.stdout.write(output)
        return result

    return prints_result_wrapper


def fmt_auto_as(fmt):

    def decorator(func):

        @wraps(func)
        def fmt_auto_as_wrapper(cmd, *args, **kwargs):
            cmd.set_auto_output(fmt)
            return func(cmd, *args, **kwargs)

        return fmt_auto_as_wrapper

    return decorator


def formats_result():
    """
    Format the return value of the wrapped handler into a result string.

    Args:
        auto: (keyword-only) String format to use when output is set to "auto"
    """

    def decorator(func):

        @wraps(func)
        def formats_result_wrapper(cmd, *args, **kwargs):
            result = func(cmd, *args, **kwargs)
            # EARLY RETURN
            if result is None:
                # Nothing to print. Give an empty string instead of formatting
                # it.
                return ""
            return format_output(result, cmd.output)

        return formats_result_wrapper

    return decorator


def applies_color(format_override=None, **overrides):
    """
    Apply color (if needed) to wrapped result and return colored result.

    Args:
        format_override: String override for format or None
    """

    def decorator(func):

        @wraps(func)
        def applies_color_wrapper(cmd, *args, **kwargs):
            result = func(cmd, *args, **kwargs)
            format_output = format_override or overrides.get(
                cmd.output, cmd.output
            )
            if needs_color(cmd.color, sys.stdin, sys.stdout):
                result = apply_color(result, format_output)
            return result

        return applies_color_wrapper

    return decorator


def fills_revision():
    """
    If needed, create a new revision and attach to it before handling the
    command.

    Side-effects:
        Creates a new revision and attaches to it (if using the 'tracked'
        revision, and tracked is locked.)
    """

    def decorator(func):
        @wraps(func)
        def fills_revision_wrapper(cmd, *args, **kwargs):
            if (
                # Did the user ask for the tracked revision?
                cmd.original_revision == REVISION_ID_TRACKED
                # Is the specified revision locked?
                and not is_revision_patchable(cmd.revision)
            ):
                # Replace cmd's revision with a newly created pending revision.
                cmd = replace(cmd, revision=make_pending_revision())

            try:
                return func(cmd, *args, **kwargs)
            except CueRequestError as req_err:
                # Is it a branch state conflict on the active pending revision?
                if (
                    req_err.status == 409
                    and cmd.original_revision == REVISION_ID_TRACKED
                ):
                    # Overwrite existing file with new rev and try again
                    cmd = replace(cmd, revision=make_pending_revision())
                    return func(cmd, *args, **kwargs)
                else:
                    # Otherwise, just pass the error through
                    raise req_err

        return fills_revision_wrapper

    return decorator


###################
# Command handlers
###################

@needs_connection
@prints_result(use_pager=True)
@applies_color()
@formats_result()
def handle_show(cmd):
    """
    Show data from CUE's object model.
    """
    path = encode_path(cmd.api, *cmd.positional)
    # EARLY RETURN
    if cmd.output not in ["end-table", "constable", "auto"]:
        return send_request(CueRequest(
            method="GET",
            path=path,
            query_params={"rev": cmd.revision},
        ))

    oper = OaiOperation(cmd.api, cmd.positional, "GET")
    # Resolve "auto" to a specific format
    if cmd.output == "auto":
        if is_collection(oper.schema):
            # If the schema can handle a collection, we'll do that.
            cmd.set_auto_output("constable")
        elif any(param["name"] == "rev" for param in oper.parameters):
            # Showing multiple revisions only makes sense when the rev query
            # parameter is available.
            cmd.set_auto_output("end-table")
        else:
            # Nothing fancy we can do with it. Show it as YAML.
            cmd.set_auto_output("yaml")

    # EARLY RETURN
    if cmd.output == "yaml":
        # YAML is easy. Handle it and bail early.
        return send_request(CueRequest(
            method="GET",
            path=path,
        ))

    if cmd.output == 'constable':
        revisions = [("instance", cmd.revision)]
    elif cmd.original_revision is None:
        # Each item in revisions is a 2-tuple of (header, rev_id)
        revisions = [
            ("operational", "operational"),
            ("applied", "applied"),
        ]
        try:
            revisions.append((
                "pending",
                get_active_pending_revision(),
            ))
        except NoPendingRevisionError:
            # This is fine.
            pass
    elif cmd.original_revision == REVISION_ID_TRACKED:
        revisions = [("applied", "applied")]
        try:
            revisions.append((
                "pending",
                get_active_pending_revision(),
            ))
        except NoPendingRevisionError:
            # This is fine.
            pass
    else:
        revisions = [(cmd.revision, cmd.revision)]

    responses = {}
    for rev_header, rev_id in revisions:
        resp = {}
        try:
            resp = send_request(CueRequest(
                method="GET",
                path=path,
                query_params={"rev": rev_id},
            ))
        except CueRequestError as req_err:
            if req_err.status != 404:
                raise
            resp = req_err
        responses[rev_header] = resp

    # If all of the endpoints 404'd, the command should still fail.
    if all(isinstance(resp, CueRequestError) for resp in responses.values()):
        # HACK: just raise the first error
        raise next(iter(responses.values()))
    # Replace error responses with empty dicts so we can print them.
    responses = {
        key: (
            val
            if not isinstance(val, CueRequestError)
            else {}
        )
        for key, val in responses.items()
    }
    return {
        **responses,
        "schema": oper.schema,
    }


@needs_connection
@fills_revision()
def handle_set(cmd):
    """
    Configure the object model data for a pending revision.
    """
    api = cmd.api
    mappings = cmd.mappings
    positional = cmd.positional
    revision = cmd.revision

    # Get the path_segments and payload for the PATCH.
    if mappings is not None:
        # Create a multi-property PATCH using the mappings.
        path_segments = positional

        dotted_keys, values = zip(*mappings.items())
        # Convert the flat dotted keys into the nested dict for payload
        key_paths = [dot_key[1:].split(".") for dot_key in dotted_keys]
        payload = make_tree(key_paths, values)
    elif len(positional) > 1:
        # Create single-property PATCH using last two positionals.
        *path_segments, payload_key, payload_value = positional
        payload = {payload_key: payload_value}
    else:
        # Not enough positionals to create a single-property patch. Use an
        # empty PATCH instead.
        path_segments = positional
        payload = {}

    # Coerce the types on the payload to reflect the API.
    schema = OaiOperation(api, path_segments, "patch").schema

    # Coerce the values in the payload based off the schema
    payload = map_deep(
        payload,
        partial(coerce_value_from_schema, schema)
    )

    cue_req = CueRequest(
        method="PATCH",
        path=encode_path(cmd.api, *path_segments),
        query_params={"rev": revision},
        payload=payload,
    )
    try:
        return send_request(cue_req)
    except CueRequestError as error:
        # Handle schema validation error cases where the server's default error
        # message may be confusing to CLI users.
        if error.status != 400 or "validation" not in error.body:
            # We don't have any specific handling for this error. Handle it
            # like normal.
            raise

        from urllib.parse import urldefrag
        selected_errors = error.body["validation"]["selected_errors"]
        best_match, *_ = selected_errors
        # The `*Location` values are expressed as URI-References. We only care
        # about the JSON pointer in the fragment.
        _, keyword_pointer = urldefrag(best_match["keywordLocation"])
        keyword_path = convert_json_pointer_to_path(keyword_pointer)

        if not (keyword_path and keyword_path[-1] == "enum"):
            # We don't have any specific handling for this error. Handle it
            # like normal.
            raise

        values = deep_get(schema, keyword_path, coerce_indexes=True)
        # Drop None from expected enum values.
        values = [
            val
            for val in values
            if val is not None
        ]
        _, instance_pointer = urldefrag(best_match["instanceLocation"])
        instance_path = convert_json_pointer_to_path(instance_pointer)
        loc = ".".join(instance_path)
        wrong_value = deep_get(payload, instance_path, '')
        # Construct an error message similar to what the server would have
        # returned.
        # TODO: provide nicer error messages now that validation errors have
        #       enough context for it.
        raise UserError(
            f"Error at {loc}: {repr(wrong_value)} is not one of {repr(values)}"
        )


@needs_connection
@fills_revision()
def handle_unset(cmd):
    """
    Configure the object model data for a pending revision.
    """
    query_params = {
        "rev": cmd.revision
    }
    if len(cmd.positional) > 1:
        *path_tokens, key = cmd.positional
        method = "PATCH"
        path = encode_path(cmd.api, *path_tokens)
        payload = {
            key: None
        }
    else:
        method = "DELETE"
        path = encode_path(cmd.api, *cmd.positional)
        payload = None

    cue_req = CueRequest(
        method=method,
        path=path,
        query_params=query_params,
        payload=payload,
    )
    return send_request(cue_req)


@needs_connection
@fills_revision()
def handle_edit(cmd):
    from textwrap import dedent

    original_config = send_request(CueRequest(
        method="GET",
        path=encode_path("config_v1", "rev", cmd.revision),
        query_params={
            "filled": False,
        },
    ))

    # Start the YAML contents with a header comment to help guide the user.
    instruction_header = dedent(f"""\
    # Edit the CUE configuration tree as a YAML file.
    # An empty file will abort the edit without making any changes.
    #
    # Editing revision {repr(cmd.revision)}
    #
    """)
    starting_yaml = instruction_header + yaml_dumps(original_config)

    # Let the user edit the config file
    edited_yaml = input_editor(
        default=starting_yaml,
        suffix=".yaml"
    )

    # Parse their YAML
    updated_config = yaml_load(edited_yaml)

    if not updated_config:
        raise UserError("Aborting edit due to empty configuration.")

    with RiskyConfigContext(cmd.revision, original_config) as ctx:
        ctx.clear_config()
        send_request(CueRequest(
            method="PATCH",
            path="/cue_v1/",
            query_params={"rev": cmd.revision},
            payload=updated_config,
        ))


@needs_connection
@prints_result(use_pager=True)
def handle_tree(cmd):
    """
    Show CUE's object model.
    """
    from cli_cue.trees import schemas_as_simple_tree, render_simple_tree

    get_schema = OaiOperation(cmd.api, cmd.positional, "GET").schema
    patch_schema = OaiOperation(cmd.api, cmd.positional, "PATCH").schema

    full_schema = None
    # HACK: "proposed" is dropped from the schemas exposed via API. To get the
    #       full root schema, we need to import cue_cue_v1 and get it directly.
    if cmd.include_proposed:
        from cue_cue_v1 import get_openapi
        full_openapi = get_openapi()
        full_root_schema = deep_get(full_openapi, [
            "components", "schemas", "root",
        ])
        grouped = group_schema_paths_by_instance_path(full_root_schema)
        # Find the relevant schema
        paths = next(
            schema_paths
            for instance_path, schema_paths
            in grouped.items()
            if are_paths_matching(tuple(cmd.positional), instance_path)
        )
        # Assume the shortest schema path is the common ancestor
        common_ancestor = min(paths, key=len)
        full_schema = deep_get(full_root_schema, common_ancestor)

    return render_simple_tree(schemas_as_simple_tree(
        read_schema=get_schema,
        write_schema=patch_schema,
        full_schema=full_schema,
    ))


def handle_list_commands(cmd):
    """
    Show CUE's object model.
    """
    from cli_cue.spider_commands import stream_commands
    stream_commands(cmd.positional, sys.stdout)


def _handle_config_confirm_status(cmd):
    rev_data = fetch_revision(cmd.revision)
    # EARLY RAISE
    if rev_data['state'] != STATE_CONFIRM:
        raise UserError(f'{cmd.revision!r} is not awaiting confirmation.')

    from datetime import datetime
    # HACK: grab what we need from config_v1.
    from cue_config_v1.apply_config import pretty_duration

    # Get the end_time from the issue.
    end_time: str = next(
        issue['data']['end_time']
        for issue in rev_data['transition']['issue'].values()
        if issue['code'] == "confirm_duration"
    )
    # Figure out how much time is remaining
    end_datetime = datetime.fromisoformat(end_time)
    now = datetime.now(end_datetime.tzinfo)
    remaining = pretty_duration(end_datetime - now)
    # NOTE: Writing it ourselves to prevent `prints_result` from eating our
    #       extra trailing whitespace.
    sys.stdout.write("\n".join([
        f"{cmd.revision!r} will be rolled back in {remaining}",
        "",
        APPLY_CONFIRM_EXPLANATION,
    ]))
    sys.stdout.flush()


@needs_connection
@prints_result(use_pager=True)
def handle_legacy(cmd):
    legacy_verb, *legacy_tokens = cmd.positional
    return send_request(CueRequest(
        method="GET",
        path=encode_path("netd_v1", "raw", legacy_verb),
        query_params={"cmd": ' '.join(legacy_tokens)},
        header_overrides={'Accept': "text/plain"},
    ))


@needs_connection
def handle_config_apply(cmd):
    """
    Apply a pending revision.
    """
    # EARLY RETURN
    if cmd.confirm_status is True:
        return _handle_config_confirm_status(cmd)

    if (
        # Is it ambiguous?
        cmd.original_revision != cmd.revision
        and (
            # Is the revision already applied?
            cmd.revision in [REVISION_ID_APPLIED]
            or fetch_revision(cmd.revision)["state"] in [STATE_APPLIED]
        )
    ):
        # We don't want to apply an applied revision unless the user explicitly
        # told us to.
        from textwrap import dedent
        suggested_command = f"cl config apply {cmd.revision}"
        raise UserError(
            dedent(
                f"""\
                error: Revision '{cmd.revision}' has already been applied.
                To apply it, use

                    {suggested_command}
                """
            )
        )

    path = encode_path(cmd.api, "revision", cmd.revision)
    apply_state = cmd.apply_state or "apply"
    payload = {"state": apply_state}
    if cmd.apply_confirm:
        payload["state-controls"] = {
            "confirm": cmd.apply_confirm,
        }
    cue_req = CueRequest(
        method="PATCH",
        path=path,
        payload=payload,
    )

    send_request(cue_req)

    exit_code = 0
    try:
        poll_revision_state_machine(
            cmd.revision,
            prompt_assume=cmd.prompt_assume,
        )
    except FailureRevisionStateError as error:
        exit_code = error.exit_code
        if cmd.apply_state == "confirm_no" and error.rollback:
            # This is exactly what the user asked for, so it's good.
            exit_code = 0
    except EarlyExitException as error:
        exit_code = error.exit_code
        if error.state == "confirm":
            # Tell the user how to use this.
            sys.stdout.write("\n")
            sys.stdout.write(APPLY_CONFIRM_EXPLANATION)
            sys.stdout.flush()
    except RevisionPollingError as error:
        exit_code = error.exit_code
    else:
        # The revision is now applied!
        if cmd.original_revision is REVISION_ID_TRACKED:
            # Clean up the pending revision. There's nothing we can do with it
            # anymore.
            detach_pending()

    return sys.exit(exit_code)


@needs_connection
@prints_result(use_pager=True)
@fmt_auto_as("yaml")
@applies_color(yaml="yaml_diff")
@formats_result()
def handle_config_diff(cmd):
    """
    Diff the state of two revisions.
    """
    from cli_cue.patches import (
        create_patch,
        convert_patch_to_cue_yaml,
        simplify_patch,
    )

    base_rev = cmd.diff_revision_base or "applied"
    target_rev = cmd.diff_revision_target or cmd.revision

    # EARLY RETURN
    if base_rev == target_rev:
        # Nothing to do!
        return

    def _fetch_revision(rev):
        return send_request(CueRequest(
            method="GET",
            path=encode_path("config_v1", "rev", rev),
            query_params={
                "filled": "false",
            },
        ))

    target_response = _fetch_revision(target_rev)
    base_response = _fetch_revision(base_rev)

    raw_patch = create_patch(base_response, target_response)
    # TODO: learn collapsibles from schemas
    # TODO: CUE-3423
    simplified_patch = simplify_patch(raw_patch, [("interface",)])
    cue_yaml = convert_patch_to_cue_yaml(simplified_patch)
    return cue_yaml or None


def handle_config_attach(cmd):
    """
    Set a revision as the current pending revision.
    """
    attach_pending(cmd.revision)


def handle_config_detach(cmd):
    """
    Detach from the current pending revision.
    """
    detach_pending()


@needs_connection
def handle_config_save(cmd):
    """
    Write the applied revision to startup.
    """
    api = cmd.api
    revision = "applied"

    path = encode_path(api, "revision", revision)
    cue_req = CueRequest(
        method="PATCH",
        path=path,
        payload={
            "state": STATE_SAVE,
        },
    )

    send_request(cue_req)

    try:
        poll_revision_state_machine(
            revision,
            prompt_assume=PROMPT_ASSUME_DEFAULT,
        )
        ret_code = 0
    except RevisionTimeoutError:
        # Return 0, since it didn't necessarily fail.
        ret_code = 0
    except RevisionPollingError:
        ret_code = 1

    sys.exit(ret_code)


@needs_connection
@fills_revision()
def handle_config_replace(cmd):
    # Load the config YAML
    with RiskyConfigContext(cmd.revision) as ctx:
        ctx.clear_config()
        send_request(CueRequest(
            method="PATCH",
            path="/cue_v1/",
            payload=cmd.cue_file,
            query_params={"rev": cmd.revision}
        ))


@needs_connection
@fills_revision()
def handle_config_patch(cmd):
    send_request(CueRequest(
        method="PATCH",
        path="/cue_v1/",
        payload=cmd.cue_file,
        query_params={"rev": cmd.revision}
    ))


@needs_connection
@prints_result(use_pager=True)
@fmt_auto_as("yaml")
@applies_color()
@formats_result()
def handle_config_revision(cmd):
    """
    Show revision data.
    """
    response = fetch_revisions()

    if cmd.revision_filter is not None:
        rev_filter = cmd.revision_filter
        if rev_filter == "current":
            current_rev = get_active_pending_revision()
            response = {
                current_rev: response[current_rev]
            }
        else:
            response = {
                rev_id: info
                for rev_id, info in response.items()
                if info["state"] == rev_filter
            }

    return response


@needs_connection
@prints_result(use_pager=True)
@fmt_auto_as("yaml")
@applies_color()
@formats_result()
def handle_config_history(cmd):
    """
    Show config history
    """
    return send_request(CueRequest(
        method="GET",
        path=encode_path("versions_v1", cmd.revision, 'history'),
    ))


@needs_connection
@prints_result
def handle_config_tracked(cmd):
    return get_tracked_revision()


def run_handler(cmd):
    if cmd.mode == "show":
        return handle_show(cmd)
    elif cmd.mode == "set":
        return handle_set(cmd)
    elif cmd.mode == "unset":
        return handle_unset(cmd)
    elif cmd.mode == "edit":
        return handle_edit(cmd)
    elif cmd.mode == "tree":
        return handle_tree(cmd)
    elif cmd.mode == "list-commands":
        return handle_list_commands(cmd)
    elif cmd.mode == "legacy":
        return handle_legacy(cmd)
    elif cmd.mode == "config":
        if cmd.config_mode == "apply":
            return handle_config_apply(cmd)
        elif cmd.config_mode == "attach":
            return handle_config_attach(cmd)
        elif cmd.config_mode == "detach":
            return handle_config_detach(cmd)
        elif cmd.config_mode == "diff":
            return handle_config_diff(cmd)
        elif cmd.config_mode == "revision":
            return handle_config_revision(cmd)
        elif cmd.config_mode == "replace":
            return handle_config_replace(cmd)
        elif cmd.config_mode == "patch":
            return handle_config_patch(cmd)
        elif cmd.config_mode == "save":
            return handle_config_save(cmd)
        elif cmd.config_mode == "tracked":
            return handle_config_tracked(cmd)
        elif cmd.config_mode == "history":
            return handle_config_history(cmd)


############################
# Entrypoint for the script
############################
def main(argv):
    """
    The main procedure for the script.

    Raises:
        UserError when we have an error to tell the user about.
    """
    cmd = parse_command(argv)
    return run_handler(cmd)


def cl():  # pragma: no cover
    try:
        main(sys.argv)
    except UserError as err:
        sys.stderr.write(str(err))
        sys.stderr.write("\n")
        sys.exit(1)
    except IOError as err:
        # Prevent cl from throwing an error when piped into another command
        if err.errno == EPIPE:
            # Pipe error means that nobody's listening to us anymore and we can
            # quit early
            sys.exit(0)
        # The other IOErrors are probably worth knowing about though
        raise err


if __name__ == "__main__":  # pragma: no cover
    cl()
