# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

from ._exceptions import NoPendingRevisionError
from ._side_effects import (  # noqa: F401
    get_active_pending_revision,
    fetch_revision,
    fetch_revisions,
    update_revision,
    create_revision,
    is_revision_patchable,
    attach_pending,
    detach_pending,
)


REVISION_ID_ACTIVE_PENDING = "pending"
REVISION_ID_TRACKED = "tracked"
REVISION_ID_APPLIED = "applied"
REVISION_ID_RUNNING = "operational"


def get_tracked_revision():
    """
    Get the tracked revision. If there's an active pending revision, return
    that. Otherwise return "applied"
    """
    try:
        # TODO: should this check the state of the tracked revision?
        tracked = get_active_pending_revision()
    except NoPendingRevisionError:
        tracked = REVISION_ID_APPLIED
    return tracked


def resolve_revision(revision):
    if revision == REVISION_ID_TRACKED:
        return get_tracked_revision()
    elif revision == REVISION_ID_ACTIVE_PENDING:
        return get_active_pending_revision()
    else:
        return revision


def make_pending_revision() -> str:
    """
    Create a new pending revision and store it to CUE_REVISION_ID_FILE.

    Returns the id of the newly created revision

    Side effects:
        - Writes new revision id to CUE_REVISION_ID_FILE
        - Calls the API to create a new revision
    """
    new_revision = create_revision()
    # HACK: assume rev id the only key in response data
    rev_id, *_ = new_revision.keys()
    attach_pending(rev_id)
    return rev_id
