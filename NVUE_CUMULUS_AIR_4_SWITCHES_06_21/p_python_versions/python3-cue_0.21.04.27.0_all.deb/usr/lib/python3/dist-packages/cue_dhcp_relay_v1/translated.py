# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


from cue.exceptions import NotFound


def dhcp_relays_get(ctx):
    return ctx.dhcp_relay_v1.getDhcpRelayConfig()


def dhcp_relay_get(ctx, vrf_id):
    try:
        return ctx.dhcp_relay_v1.getDhcpRelayConfig()[vrf_id]
    except KeyError:
        raise NotFound


def dhcp_relays6_get(ctx):
    return ctx.dhcp_relay_v1.getDhcpRelay6Config()


def dhcp_relay6_get(ctx, vrf_id):
    try:
        return ctx.dhcp_relay_v1.getDhcpRelay6Config()[vrf_id]
    except KeyError:
        raise NotFound
