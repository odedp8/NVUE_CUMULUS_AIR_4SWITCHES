# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from . import templates
import logging


logger = logging.getLogger(__name__)


def prepare_unit(ctx):
    """
    Prepare the unit for lifecycle events.
    """
    # Tell the render engine about our templates
    ctx.render.register_package(templates)

    # Register for events
    ctx.events.verify_config.register("env_v1", handle_verify_config)
    ctx.events.ready_apply.register("env_v1", handle_ready_apply)
    ctx.events.check_health.register("env_v1", handle_check_health)


def handle_verify_config(evt):
    """
    Handle a verify_config event.
    """


def handle_ready_apply(evt):
    """
    Prepare to apply the config.  Generate config files and scripts.  Also,
    look for issues in the config that would prevent us from applying it.
    """
    platform = evt.config_v1.getPlatform()
    hostname_value = platform["hostname"]["value"]
    operational_hostname = evt.platform_v1.getHostname()['hostname']

    if hostname_value != operational_hostname:
        evt.report_warning((
            f"Warning: current hostname `{operational_hostname}`"
            f" will be replaced with `{hostname_value}`"
        ))

    # Generate the scripts and config files
    evt.render(templates, "etc_hostname",
               hostname=hostname_value)
    evt.render(templates, "etc_hosts",
               hostname=hostname_value)
    evt.render(templates, "apply_hostname.sh")

    # Make sure we can update our config files.
    hn_staged = evt.stage_file("etc_hostname", "/etc/hostname")
    hosts_staged = evt.stage_file("etc_hosts", "/etc/hosts")

    if hn_staged or hosts_staged:
        evt.schedule_run_script("apply_hostname.sh")


def handle_check_health(evt):
    """
    Handle an check_health event.

    Use evt.report_error to report any found errors.
    Use evt.report_warning to report any found warnings.

    Warnings *should* clear on their own, given some time, usually indicating
    that a component is still "coming up."  Errors *will not* clear on their
    own.

    Args:
        evt: A CheckHealthEvent instance.
    """
