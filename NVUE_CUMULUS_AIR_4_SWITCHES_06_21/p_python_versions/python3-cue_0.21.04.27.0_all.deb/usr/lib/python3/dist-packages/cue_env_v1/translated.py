# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


def platform_get(ctx):
    return {
        "hostname": hostname_get(ctx),
        "software": software_get(ctx),
    }


def hostname_get(ctx):
    result = {
        "value": ctx.env_v1.getHostnamectl()["static-hostname"],
        "source": "static",
        "dhcp": "off",
    }
    return result


def software_get(ctx):
    return {
        "installed": installed_packages_get(ctx)
    }


def installed_packages_get(ctx):
    native = ctx.env_v1.getDpkgQueryShow()
    result = {}
    for item in native:
        package = item["Package"]
        result[package] = {
            "package": package,
            "version": item["Version"],
            "description": item["Description"]["summary"],
        }
    return result


def installed_package_get(ctx, installed_id):
    return installed_packages_get(ctx).get(installed_id)
