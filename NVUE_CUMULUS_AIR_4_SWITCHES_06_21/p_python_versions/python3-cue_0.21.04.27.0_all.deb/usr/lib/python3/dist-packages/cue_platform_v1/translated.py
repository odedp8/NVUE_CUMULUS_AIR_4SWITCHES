# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.

from cue import exceptions
from pydash import py_


def hardware_get(ctx):
    response = ctx.platform_v1.getPlatformString()
    if not response:
        raise exceptions.NotFound

    vend = response.get('manufacturer')
    mod = response.get('model')
    mod = mod.strip('\n')
    res = {'vendor': vend,
           'model': mod}

    platforms = ctx.platform_v1.getPlatforms()
    soc_vendor = py_.get(platforms, f'{vend},{mod}.0.soc.vendor')
    soc_model = py_.get(platforms, f'{vend},{mod}.0.soc.model')
    if soc_vendor:
        res['asic-vendor'] = soc_vendor
    if soc_model:
        res['asic-model'] = soc_model

    system_mac = ctx.platform_v1.getSystemMac()
    if system_mac:
        res['system-mac'] = system_mac

    return res


###############################
# Breakout modes
###############################

def breakout_modes_get(ctx, component_id, port_id):
    if component_id != "device":
        # Currently, we only support simple, single-switch platforms and not
        # chassis, modules, etc.  Therefore, all ports are on the root
        # component, which we all "device."  If the request is for something
        # other than "device", then raise a NotFound for now.
        raise exceptions.NotFound

    res = {}
    port_modes = ctx.platform_v1.getPortModes()
    if not port_modes:
        raise exceptions.NotFound

    if port_id not in port_modes:
        # Unknown port
        raise exceptions.NotFound

    # Loop through the modes for the requested port
    modes = port_modes[port_id]
    for mode in modes:
        # Parse the mode to get the speed and breakout.
        if ('x' not in mode
                and '/' not in mode
                and mode != 'loopback'
                and mode != 'disabled'):
            breakout = '1x'
        else:
            breakout = mode

        # Add the new mode.
        py_.merge(res, {breakout: {}})

    return res


###############################
# Components
###############################

def components_get(ctx):
    linecards = ctx.platform_v1.getLinecardInfo()
    if not linecards:
        response = ctx.platform_v1.getPlatformString()
        if response:
            vend = response.get('manufacturer')
            mod = response.get('model')
            mod = mod.strip('\n')
            res = {'type': 'switch',
                   'vendor': vend,
                   'model': mod}
            dev = {'device': res}
            return dev
        else:
            raise exceptions.NotFound

    return linecards_get(linecards)


def component_get(ctx, component_id):
    linecard = linecard_get(ctx, component_id)
    if linecard is None:
        components = ctx.platform_v1.getComponents()
        if components:
            return components[component_id]
        else:
            raise exceptions.NotFound

    return linecard


###############################
# Ports
###############################

def ports_get(ctx, component_id):
    res = {}
    ports = ctx.platform_v1.getPortModes()
    for port in ports:
        breakout = breakout_modes_get(ctx, "device", port)
        mode = {}
        mode["breakout-mode"] = breakout
        res[port] = mode
    return res


def port_get(ctx, component_id, port_id):
    port = {}
    port["breakout-mode"] = breakout_modes_get(ctx, "device", port_id)
    return port


###############################
# Fans
###############################

def fans_get(ctx, component_id):
    res = {}
    fans = ctx.platform_v1.getFanInfo()
    for fan in fans:
        name = fan.get('name')
        speed = fan.get('input')
        py_.merge(res, {name: {"speed": speed}})
    return res


def fan_get(ctx, component_id, fan_id):
    fans = fans_get(ctx, component_id)
    try:
        return fans[fan_id]
    except KeyError:
        raise exceptions.NotFound


###############################
# Linecard
###############################
def linecards_get(linecards):
    res = {}
    for slot in linecards:
        res[slot] = {}
        res[slot]['slot'] = linecards[slot]['slot']
        res[slot]['linecard'] = {
            'card-type': linecards[slot]['card_type']
        }
        res[slot]['state'] = linecards[slot]['state']
        res[slot]['serial'] = linecards[slot]['serial']
        res[slot]['type'] = 'linecard'
        res[slot]['vendor'] = "Mellanox"
        res[slot]['model'] = linecards[slot]['card_type']

    return res


def linecard_get(ctx, component_id):
    # It doesn't look like a linecard's name.
    if component_id[0:8] != 'linecard':
        return None

    components = ctx.platform_v1.getLinecardInfo()
    linecards = linecards_get(components)
    if component_id in linecards:
        return linecards[component_id]

    # It's a linecard (by name), but not one we have.
    raise exceptions.NotFound


###############################
# Capabilities
###############################
def ifupdown2_capabilities_get(ctx):
    policies = ctx.platform_v1.getIfupdown2Policy()

    # check if ifupdown2 is in SVD mode
    single_vxlan_device_enabled = {
        "on": True,
        "yes": True,
        "enabled": True
    }.get(
        policies.get("vxlan", {})
        .get("module_globals", {})
        .get("single-vxlan-device"), False)

    return {
        "single-vxlan-device": 'on' if single_vxlan_device_enabled else 'off'
    }


###############################
# Reboot reason
###############################

def reboot_reason_get(ctx):
    trans_res = {}
    nat_res = ctx.platform_v1.getNativeRebootReason()
    key_mapping = {
        'reason': 'cause',
        'gentime': 'gen_time',
        'user': 'user',
    }
    for trans_key, nat_key in key_mapping.items():
        if nat_key in nat_res:
            trans_res[trans_key] = nat_res[nat_key]

    return trans_res


def reboot_history_get(ctx):
    res = {}
    response = ctx.platform_v1.getNativeRebootHistory()
    for item in response.keys():
        reason = response[item].get('cause')
        gentime = response[item].get('gen_time')
        user = response[item].get('user')
        idx = str(item)
        py_.merge(res, {idx: {"reason": reason,
                              "gentime": gentime,
                              "user": user}})

    return res
