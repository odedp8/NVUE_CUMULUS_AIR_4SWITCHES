# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Retrieve and store full configs.  A full config includes defaults,
# immutables, and opinions and matches the "full-config" schema.

from . import startup, repo, empty
import logging


logger = logging.getLogger(__name__)


def full_get(ctx, rev_id):
    """
    Given a revision Id, return the full config, loading it if necessary.  This
    will be a "patch valid" config, not a "schema valid" config.  That means
    individual properties are valid, but the config as a whole may not be
    internally consistent (yet).
    """
    if rev_id == "startup":
        conf = startup.startup_get(ctx)
    elif rev_id == "empty":
        conf = empty.empty_get(ctx)
    else:
        conf = repo.repo_get(ctx, rev_id)

    return conf


def full_put(ctx, rev_id, body):
    """
    Set the configuration tree for the given rev_id and save it.
    """
    # Pass the save to the startup or repo submodules.
    if rev_id == "startup":
        startup.startup_put(ctx, body)
    elif rev_id == "empty":
        empty.empty_put(ctx, body)
    else:
        repo.repo_put(ctx, rev_id, body)

    # Reload the config instead of returning it directly.  This will put it in
    # the cache and normalize it.  More work, but more consistent.
    return full_get(ctx, rev_id)
