# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


from cue.exceptions import NotFound
from pydash import py_


def merge_dicts(dict1, dict2):
    new_dict = py_.merge({}, dict1, dict2)
    return new_dict


def servers_get(ctx):
    """
    Get the collection of DHCP servers.
    """
    dhcpd = ctx.isc_dhcp_v1.getDhcpdConf()
    isc = ctx.isc_dhcp_v1.getIscDhcpServerData()
    new = merge_dicts(dhcpd, isc)
    return new


def server_get(ctx, vrf_id):
    """
    Get the collection of DHCP server.
    """
    servers = ctx.isc_dhcp_v1.getServers()
    try:
        return servers[vrf_id]
    except KeyError:
        raise NotFound


def servers6_get(ctx):
    """
    Get the collection of DHCP servers6.
    """
    dhcpd6 = ctx.isc_dhcp_v1.getDhcpd6Conf()
    isc6 = ctx.isc_dhcp_v1.getIscDhcp6ServerData()
    new = merge_dicts(dhcpd6, isc6)
    return new


def server6_get(ctx, vrf_id):
    """
    Get the collection of DHCP server.
    """
    servers = ctx.isc_dhcp_v1.getServers6()
    try:
        return servers[vrf_id]
    except KeyError:
        raise NotFound
