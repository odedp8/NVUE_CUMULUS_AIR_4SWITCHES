# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.


def ptp_instance_get(ctx, instance_id):
    ptp_inst = {}
    ptp_show = {}
    ptp_conf = ctx.linuxptp_v1.getPtpInstanceConfig(instance_id)
    for key in ptp_conf:
        ptp_inst[key] = ptp_conf[key]
    mon_conf = ctx.linuxptp_v1.getMonitorConfig(instance_id)
    amt_conf = ctx.linuxptp_v1.getAccMasters(instance_id)

    def_ds = ctx.linuxptp_v1.getDefaultDS(instance_id)
    show_clock_quality = def_ds['clock-quality']
    ptp_inst['clock-id'] = def_ds['clock-id']
    ptp_inst['number-ports'] = def_ds['number-ports']

    show_current_ds = ctx.linuxptp_v1.getPtpCurrentDS(instance_id)
    show_parent_ds = ctx.linuxptp_v1.getPtpParentDS(instance_id)
    show_time_prop = ctx.linuxptp_v1.getPtpTimeProperties(instance_id)

    ptp_inst['monitor'] = mon_conf
    ptp_inst['acceptable-master'] = amt_conf

    ptp_inst['ptp-show'] = ptp_show
    ptp_inst['clock-quality'] = show_clock_quality
    ptp_inst['current'] = show_current_ds
    ptp_inst['time'] = show_time_prop
    ptp_inst['parent'] = show_parent_ds

    return ptp_inst


def ptp_default_ds_attribs_get(ctx, instance_id):
    ds_attribs = {}
    ds = ctx.linuxptp_v1.getDefaultDS(instance_id)
    ds_attribs['clock-id'] = ds['clock-id']
    ds_attribs['number-ports'] = ds['number-ports']
    return ds_attribs


def ptp_default_ds_clock_quality_get(ctx, instance_id):
    clock_quality = {}
    ds = ctx.linuxptp_v1.getDefaultDS(instance_id)
    clock_quality = ds['clock-quality']
    return clock_quality


def if_ptp_timers_get(ctx, interface_id):
    timer_ds = {'announce-interval': 0,
                'sync-interval': 0,
                'delay-req-interval': 0,
                'announce-timeout': 0,
                'sync-interval': 0}

    port_ds = ctx.linuxptp_v1.getPTPPortDS(interface_id)

    for key in timer_ds:
        if key in port_ds:
            timer_ds[key] = port_ds[key]

    return timer_ds


def ptp_if_instance_get(ctx, interface_id):
    ptp_if_inst = {}

    ptp_if_conf = ctx.linuxptp_v1.getInterfacePTPConfig(interface_id)
    for key in ptp_if_conf:
        ptp_if_inst[key] = ptp_if_conf[key]
    port_ds = ctx.linuxptp_v1.getPTPPortDS(interface_id)
    ptp_if_inst['port-state'] = port_ds['port-state']
    ptp_if_inst['peer-mean-path-delay'] = port_ds['peer-mean-path-delay']
    ptp_if_inst['protocol-version'] = port_ds['protocol-version']
    ptp_if_timers = if_ptp_timers_get(ctx, interface_id)
    ptp_if_counters = ctx.linuxptp_v1.getPTPPortStats(interface_id)

    ptp_if_inst['counters'] = ptp_if_counters
    ptp_if_inst['timers'] = ptp_if_timers

    return ptp_if_inst
