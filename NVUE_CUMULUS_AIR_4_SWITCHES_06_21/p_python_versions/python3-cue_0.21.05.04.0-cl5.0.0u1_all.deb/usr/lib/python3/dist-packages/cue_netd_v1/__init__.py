# Copyright (C) 2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from cue.utils import loaders


def get_openapi():
    return loaders.load_openapi_json(__package__)


def prepare_unit(ctx):
    # Nothing to do here.
    pass  # pragma: no cover
