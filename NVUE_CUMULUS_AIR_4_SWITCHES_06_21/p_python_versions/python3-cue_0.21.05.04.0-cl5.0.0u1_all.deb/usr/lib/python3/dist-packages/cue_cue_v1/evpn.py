# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue_cue_v1.root import root_patch
from cue.exceptions import NotFound


###############################
# Evpn
###############################
def evpn_get(ctx, rev):
    if rev == 'operational':
        # EVPN config does not have a operational revision
        rev = 'applied'
    return ctx.config_v1.getEvpn(rev)


def evpn_patch(ctx, rev, body=None):
    root = root_patch(ctx, rev, {"evpn": body})
    return root.get("evpn", {})


def evpn_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev)


###############################
# Evpn Route Advertise
###############################
def evpn_ra_get(ctx, rev):
    return evpn_get(ctx, rev)["route-advertise"]


def evpn_ra_patch(ctx, rev, body=None):
    evpn = evpn_patch(ctx, rev, {"route-advertise": body})
    return evpn.get("route-advertise", {})


def evpn_ra_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "route-advertise")


###############################
# Evpn DAD
###############################
def evpn_dad_get(ctx, rev):
    output = evpn_get(ctx, rev)
    try:
        return output["dad"]
    except KeyError:
        raise NotFound


def evpn_dad_patch(ctx, rev, body=None):
    evpn = evpn_patch(ctx, rev, {"dad": body})
    return evpn.get("dad", {})


def evpn_dad_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev, "dad")


###############################
# Evpn DAD Duplicate Action
###############################
def evpn_dad_da_get(ctx, rev):
    output = evpn_dad_get(ctx, rev)
    try:
        return output["duplicate-action"]
    except KeyError:
        raise NotFound


def evpn_dad_da_patch(ctx, rev, body=None):
    dad = evpn_dad_patch(ctx, rev, {"duplicate-action": body})
    return dad.get("duplicate-action", {})


def evpn_dad_da_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "dad", "duplicate-action")


###############################
# Evpn DAD Duplicate Action Freeze
###############################
def evpn_dad_da_freeze_get(ctx, rev):
    output = evpn_dad_da_get(ctx, rev)
    try:
        return output["freeze"]
    except KeyError:
        raise NotFound


def evpn_dad_da_freeze_patch(ctx, rev, body=None):
    dad_da = evpn_dad_da_patch(ctx, rev, {"freeze": body})
    return dad_da.get("freeze", {})


def evpn_dad_da_freeze_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "dad", "duplicate-action", "freeze")


###############################
# Evpn EVIs
###############################
def evpn_evis_get(ctx, rev):
    output = evpn_get(ctx, rev)
    try:
        return output["evi"]
    except KeyError:
        raise NotFound


def evpn_evis_patch(ctx, rev, body=None):
    evpn = evpn_patch(ctx, rev, {"evi": body})
    return evpn.get("evi", {})


def evpn_evis_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev, "evi")


###############################
# Evpn EVI
###############################
def evpn_evi_get(ctx, rev, evi_id):
    evis = evpn_evis_get(ctx, rev)
    try:
        return evis[evi_id]
    except KeyError:
        raise NotFound


def evpn_evi_patch(ctx, rev, evi_id, body=None):
    evis = evpn_evis_patch(ctx, rev, {evi_id: body})
    return evis.get(evi_id, {})


def evpn_evi_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id)


###############################
# Evpn EVI Route advertise
###############################
def evpn_evi_ra_get(ctx, rev, evi_id):
    evi = evpn_evi_get(ctx, rev, evi_id)
    try:
        return evi["route-advertise"]
    except KeyError:
        raise NotFound


def evpn_evi_ra_patch(ctx, rev, evi_id, body=None):
    evi = evpn_evi_patch(ctx, rev, evi_id, {"route-advertise": body})
    return evi.get("route-advertise", {})


def evpn_evi_ra_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-advertise")


###############################
# Evpn EVI Route target
###############################
def evpn_evi_rt_get(ctx, rev, evi_id):
    evi = evpn_evi_get(ctx, rev, evi_id)
    try:
        return evi["route-target"]
    except KeyError:
        raise NotFound


def evpn_evi_rt_patch(ctx, rev, evi_id, body=None):
    evi = evpn_evi_patch(ctx, rev, evi_id, {"route-target": body})
    return evi.get("route-target", {})


def evpn_evi_rt_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target")


###############################
# Evpn EVI Route target Export
###############################
def evpn_evi_rt_exports_get(ctx, rev, evi_id):
    rt = evpn_evi_rt_get(ctx, rev, evi_id)
    try:
        return rt["export"]
    except KeyError:
        raise NotFound


def evpn_evi_rt_exports_patch(ctx, rev, evi_id, body=None):
    evi = evpn_evi_rt_patch(ctx, rev, evi_id, {"export": body})
    return evi.get("export", {})


def evpn_evi_rt_exports_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "export")


###############################
# Evpn EVI Route target Export
###############################
def evpn_evi_rt_export_get(ctx, rev, evi_id, rt_id):
    rt = evpn_evi_rt_exports_get(ctx, rev, evi_id)
    try:
        return rt[rt_id]
    except KeyError:
        raise NotFound


def evpn_evi_rt_export_patch(ctx, rev, evi_id, rt_id, body=None):
    rt = evpn_evi_rt_exports_patch(ctx, rev, evi_id, {rt_id: body})
    return rt.get(rt_id, {})


def evpn_evi_rt_export_delete(ctx, rev, evi_id, rt_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "export", rt_id)


###############################
# Evpn EVI Route target Export
###############################
def evpn_evi_rt_imports_get(ctx, rev, evi_id):
    rt = evpn_evi_rt_get(ctx, rev, evi_id)
    try:
        return rt["import"]
    except KeyError:
        raise NotFound


def evpn_evi_rt_imports_patch(ctx, rev, evi_id, body=None):
    evi = evpn_evi_rt_patch(ctx, rev, evi_id, {"import": body})
    return evi.get("import", {})


def evpn_evi_rt_imports_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "import")


###############################
# Evpn EVI Route target Export
###############################
def evpn_evi_rt_import_get(ctx, rev, evi_id, rt_id):
    rt = evpn_evi_rt_imports_get(ctx, rev, evi_id)
    try:
        return rt[rt_id]
    except KeyError:
        raise NotFound


def evpn_evi_rt_import_patch(ctx, rev, evi_id, rt_id, body=None):
    rt = evpn_evi_rt_imports_patch(ctx, rev, evi_id, {rt_id: body})
    return rt.get(rt_id, {})


def evpn_evi_rt_import_delete(ctx, rev, evi_id, rt_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "import", rt_id)


###############################
# Evpn EVI Route target Both
###############################
def evpn_evi_rt_boths_get(ctx, rev, evi_id):
    rt = evpn_evi_rt_get(ctx, rev, evi_id)
    try:
        return rt["both"]
    except KeyError:
        raise NotFound


def evpn_evi_rt_boths_patch(ctx, rev, evi_id, body=None):
    evi = evpn_evi_rt_patch(ctx, rev, evi_id, {"both": body})
    return evi.get("both", {})


def evpn_evi_rt_boths_delete(ctx, rev, evi_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "both")


###############################
# Evpn EVI Route target both
###############################
def evpn_evi_rt_both_get(ctx, rev, evi_id, rt_id):
    rt = evpn_evi_rt_boths_get(ctx, rev, evi_id)
    try:
        return rt[rt_id]
    except KeyError:
        raise NotFound


def evpn_evi_rt_both_patch(ctx, rev, evi_id, rt_id, body=None):
    rt = evpn_evi_rt_boths_patch(ctx, rev, evi_id, {rt_id: body})
    return rt.get(rt_id, {})


def evpn_evi_rt_both_delete(ctx, rev, evi_id, rt_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "evi", evi_id, "route-target", "both", rt_id)


###############################
# Evpn Multihoming
###############################
def evpn_mh_get(ctx, rev):
    return evpn_get(ctx, rev)["multihoming"]


def evpn_mh_patch(ctx, rev, body=None):
    evpn = evpn_patch(ctx, rev, {"multihoming": body})
    return evpn.get("multihoming", {})


def evpn_mh_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "multihoming")


###############################
# Evpn Multihoming ead-evi-route
###############################
def evpn_mh_ead_get(ctx, rev):
    return evpn_mh_get(ctx, rev)["ead-evi-route"]


def evpn_mh_ead_patch(ctx, rev, body=None):
    evpn_mh = evpn_mh_patch(ctx, rev, {"ead-evi-route": body})
    return evpn_mh.get("ead-evi-route", {})


def evpn_mh_ead_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "multihoming", "ead-evi-route")


###############################
# Evpn Multihoming segment
###############################
def evpn_mh_segment_get(ctx, rev):
    return evpn_mh_get(ctx, rev)["segment"]


def evpn_mh_segment_patch(ctx, rev, body=None):
    evpn_mh = evpn_mh_patch(ctx, rev, {"segment": body})
    return evpn_mh.get("segment", {})


def evpn_mh_segment_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(
        ctx.config_v1.getEvpn, ctx.config_v1.setEvpn, rev,
        "multihoming", "segment")
