# Copyright (C) 2018-2021 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


from cue.exceptions import NotFound
from cue_cue_v1.service import service_patch


###############################
# DHCP Relays
###############################

def dhcp_relays_get(ctx, rev):
    if rev != "operational":
        return ctx.config_v1.getDhcpRelays6(rev)

    return ctx.dhcp_relay_v1.getRelays6()


def dhcp_relays_patch(ctx, rev, body=None):
    service = service_patch(ctx, rev, {"dhcp-relay6": body})
    return service.get("dhcp-relay6", {})


def dhcp_relays_delete(ctx, rev):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelays6,
                             ctx.config_v1.setDhcpRelays6, rev)


def dhcp_relay_get(ctx, rev, vrf_id):
    if rev != "operational":
        return ctx.config_v1.getDhcpRelay6(rev, vrf_id)

    return ctx.dhcp_relay_v1.getRelay6(vrf_id)


def dhcp_relay_patch(ctx, rev, vrf_id, body=None):
    relays = dhcp_relays_patch(ctx, rev, {vrf_id: body})
    return relays.get(vrf_id, {})


def dhcp_relay_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id)


####################################
# DHCP Relay/interface
####################################

def interfaces_get(ctx, rev, vrf_id):
    if rev != "operational":
        relay = ctx.config_v1.getDhcpRelay6(rev, vrf_id)
        return relay["interface"]

    relay = ctx.dhcp_relay_v1.getRelay6(vrf_id)
    return relay["interface"]


def interfaces_patch(ctx, rev, vrf_id, body=None):
    relay = dhcp_relay_patch(ctx, rev, vrf_id, {"interface": body})
    return relay.get("interface", {})


def interfaces_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id,
                             "interface")


####################################
# DHCP Relay/interface/upstream
####################################

def upstream_get(ctx, rev, vrf_id):
    interfaces = interfaces_get(ctx, rev, vrf_id)
    return interfaces["upstream"]


def upstream_patch(ctx, rev, vrf_id, body=None):
    interfaces = interfaces_patch(ctx, rev, vrf_id,
                                  {"upstream": body})
    return interfaces.get("upstream", {})


def upstream_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id,
                             "interface", "upstream")


##################################################
# DHCP Relay/interface/upstream/{interface-id}
##################################################

def upst_interface_get(ctx, rev, vrf_id, interface_id):
    upst = upstream_get(ctx, rev, vrf_id)
    try:
        return upst[interface_id]
    except KeyError:
        raise NotFound


def upst_interface_patch(ctx, rev, vrf_id, interface_id, body=None):
    upst = upstream_patch(ctx, rev, vrf_id, {interface_id: body})
    return upst.get(interface_id, {})


def upst_interface_delete(ctx, rev, vrf_id, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id,
                             "interface", "upstream", interface_id)


####################################
# DHCP Relay/interface/downstream
####################################

def downstream_get(ctx, rev, vrf_id):
    interfaces = interfaces_get(ctx, rev, vrf_id)
    return interfaces["downstream"]


def downstream_patch(ctx, rev, vrf_id, body=None):
    interfaces = interfaces_patch(ctx, rev, vrf_id,
                                  {"downstream": body})
    return interfaces.get("downstream", {})


def downstream_delete(ctx, rev, vrf_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id,
                             "interface", "downstream")


##################################################
# DHCP Relay/interface/downstream/{interface-id}
##################################################

def dnst_interface_get(ctx, rev, vrf_id, interface_id):
    dnst = downstream_get(ctx, rev, vrf_id)
    try:
        return dnst[interface_id]
    except KeyError:
        raise NotFound


def dnst_interface_patch(ctx, rev, vrf_id, interface_id, body=None):
    dnst = downstream_patch(ctx, rev, vrf_id, {interface_id: body})
    return dnst.get(interface_id, {})


def dnst_interface_delete(ctx, rev, vrf_id, interface_id):
    ops = ctx.cue_v1._ops
    ops.pre_delete(rev)
    return ops.delete_config(ctx.config_v1.getDhcpRelay6,
                             ctx.config_v1.setDhcpRelay6, rev, vrf_id,
                             "interface", "downstream", interface_id)
