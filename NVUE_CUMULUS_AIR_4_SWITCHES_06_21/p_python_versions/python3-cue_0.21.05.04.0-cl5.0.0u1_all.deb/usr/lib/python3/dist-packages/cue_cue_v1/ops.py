# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# The cue_v1 endpoints are meant to be "routers" that know where to find the
# requested data.  As a result, their actions are often very formulaic.  This
# module implements the common operations.  This reduces copy and paste, but
# also makes the action plan of each "router" easier to understand.


from cue import exceptions, utils
from pydash import py_
import logging


logger = logging.getLogger(__name__)


READ_ONLY_REVS = ["operational", "startup", "applied"]


def pre_get_oper_only(rev):
    """
    Common operations and checks before a GET on an endpoint that doesn't have
    configuration data.
    """
    if rev != "operational":
        raise exceptions.NotFound(
            description=f"rev must be 'operational', but got '{rev}'")


def pre_patch(rev, body):
    """
    Common operations and checks before allowing a patch operation.
    """
    # Some revisions cannot be patched.
    if rev in READ_ONLY_REVS:
        raise exceptions.Conflict(
            description=f"'{rev}' is a read-only revision")

    # Normalize body into a dictionary.
    return body or {}


_UNSET = utils.sentinel.UNSET


def patch_config(config_get, config_set, rev, *path, patch, prepare=None):
    """
    Get the configuration from config_v1 on the the revision `rev`, merge it
    with `prepare` patch, then `patch` (both relative to path), and set it
    back to config_v1 on the same revision.

    `config_get` is the config_v1 endpoint to get the config and `config_set`
    is the endpoint to set it.

    `path` is passed directly to the config_v1 endpoints, which know how to
    deal with it.
    """
    logger.dump("Patching", rev, path)

    # Get the current set of opinions.  If there aren't any, then start
    # something.
    try:
        opinions = config_get(rev, *path, filled=False)
    except exceptions.NotFound:
        opinions = {}

    # Merge iteratee that looks for unset children and marks them to be
    # filtered out later.  There's no way to tell merge_with() to NOT merge.
    # So, we have to use a sentinel instead.
    def unset_marker(obj_value, src_value):
        # Look for pure unsets to non-existent things.  It's non-existent if
        # obj_value is None.  It's a pure unset if clean_none() says there's
        # nothing in src_value but Nones.  Without this check, an unset of a
        # nested property (e.g. {b: {c: None}}) would leave the property's
        # parents hanging around (e.g. {b: {}}), making it look like the
        # parents were set.
        if ((obj_value is None or obj_value is _UNSET)
                and utils.clean_none(src_value) is None):
            return _UNSET

    # Merge prepare and patch with the existing opinions.  We can count on
    # config_v1 to send us a copy of opinions, so we can merge into it
    # directly.
    # - Start with the optional prepare patch.
    if prepare is not None:
        py_.merge_with(opinions, prepare, iteratee=unset_marker)
    # - Then merge the patch
    py_.merge_with(opinions, patch, iteratee=unset_marker)

    # Now, we can filter Nones and UNSETs from the opinions.  Unfortunately, we
    # have to do this in two steps.  It would be nice to have unset_marker
    # convert all Nones to UNSETs, but merge_with() doesn't recurse into
    # src_value, so we don't see all the Nones.
    opinions = utils.filter_none(opinions)
    opinions = utils.filter_none(opinions, filter_val=_UNSET)

    # Set the new opinions and return it
    return config_set(rev, *path, body=opinions)


def pre_delete(rev):
    """
    Common operations and checks before allowing a delete operation.
    """
    # Some revisions cannot be unset.
    if rev in READ_ONLY_REVS:
        raise exceptions.Conflict(
            description=f"'{rev}' is a read-only revision")
    return {}


def delete_config(config_get, config_set, rev, *path):
    """
    Delete all opinions at the given node.

    If `path` is provided, we'll get it's parent, delete it, and set the
    parent.
    """
    if len(path) > 0:
        logger.dump("Deleting child", rev, path)

        # Pop the last item off the path and use it as the leaf.  We want to
        # actually remove it instead of just setting it to an empty object.  An
        # empty object is a valid value for an instance and in this case, we
        # clearly want to remove the instance.
        leaf = path[-1]
        subpath = path[:-1]

        # Get the current opinions
        opinions = config_get(rev, *subpath, filled=False)

        # Remove the leaf
        if leaf in opinions:
            del opinions[leaf]
    else:
        logger.dump("Deleting parent", rev)

        # Forget all opinions
        opinions = {}
        subpath = path

    # Set the new opinions.
    config_set(rev, *subpath, body=opinions)

    # Always return an empty object
    return {}
