# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from cli_cue.exceptions import UserError


class NoPendingRevisionError(UserError):
    """
    Indicates that the command couldn't be executed, since there's no current
    pending revison.
    """
    def __init__(self, message=None):
        if message is None:
            import os
            # NOTE: `whoami` is more robust than environment variables for
            # determining the current user, but we're not using it. We're using
            # USER here because we use HOME (and other environment vars)to
            # determine where the revision id is stored. If we don't have USER,
            # we probably don't have HOME either, and the "unknown user"
            # message will help indicate that something's wonky with their
            # environment.
            current_user = os.environ.get("USER")
            message = (
                # Show the current user if we know it.
                f'No current pending revision for user "{current_user}".'
                if current_user is not None
                # Otherwise inform user that we don't know.
                else "No current pending revision for unknown user."
            )
        super().__init__(message)
