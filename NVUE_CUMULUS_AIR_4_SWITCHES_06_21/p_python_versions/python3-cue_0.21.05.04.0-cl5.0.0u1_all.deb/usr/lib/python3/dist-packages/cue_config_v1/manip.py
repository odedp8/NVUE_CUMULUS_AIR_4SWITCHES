# Copyright (C) 2018-2021 Cumulus Networks, inc
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Utilities for config manipulations


from pydash import py_

# Import the root morphers.
# TODO CUE-3044.
# This is dirty because it creates a direct dependency between units.
from cue_cue_v1.morphers import root_patch_expand, root_patch_prepare


def merge_trees(tgt_tree, sub_tree):
    """
    Merge the given `sub_tree` into the `tgt_tree`.  `tgt_tree is modified in
    place but returned for convenience.
    """
    py_.merge(tgt_tree, sub_tree)
    return tgt_tree


def merge_deltas(conf, delta_ops):
    """
    Merge a list of delta operations into a configuration.
    """
    for delta_op in delta_ops:
        if "set" in delta_op:
            merge_trees(conf, delta_op["set"])
        elif "unset" in delta_op:
            merge_trees(conf, delta_op["unset"])


def squash_full_config(full_config):
    """
    Squash the full_config into a single tree.  This means merging the config
    trees in full_config (opinions and immutables) into a single tree.
    """
    # Start with empty tree
    full_tree = {}

    # Merge immutables into it.
    merge_trees(full_tree, full_config["immutables"])

    # Some day, we might have multiple trees of opinions.  This is where
    # we'd mix them all together.
    #
    # For example, opinions from a northbound controller might be put into
    # their own tree so that we can remember who "cared" about that
    # configuration, allow overrides, allow the controller to "resync" from a
    # clean-slate, etc.  The user's opinions would always be merged in last.

    # Merge the user's opinions into it, letting them override immutables.
    merge_trees(full_tree, full_config["opinions"])

    return full_tree


def expand_delta(conf):
    """
    Expand a delta and then prepare it, returning an array of deltas that must
    be applied in order.  The array will contain one or two elements.  It will
    always contain the expanded (deglobbed) delta, but may also contain a
    prepare delta that clears config ahead of the expanded delta.
    """
    expanded = py_.clone_deep(conf)
    root_patch_expand(expanded)

    prepare = py_.clone_deep(expanded)
    root_patch_prepare(prepare)

    if prepare == expanded:
        return [expanded]
    else:
        return [prepare, expanded]


def expand_deltas(delta_ops):
    """
    Expand globs in the given list of delta operations.  The deltas are
    modified in place.
    """
    expanded_ops = []
    for delta_op in delta_ops:
        if "set" in delta_op:
            for expanded_delta in expand_delta(delta_op["set"]):
                expanded_ops.append({"set": expanded_delta})
        elif "unset" in delta_op:
            for expanded_delta in expand_delta(delta_op["unset"]):
                expanded_ops.append({"unset": expanded_delta})
    return expanded_ops
