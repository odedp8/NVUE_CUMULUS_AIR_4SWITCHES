# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.

import cue_linuxptp_v1.ptp4lconstants as ptp4lconst
import cue_linuxptp_v1.ptp4lio as ptp4lio


def ptp_current_ds_get(ctx, instance_id):
    """
    Send GET TLV_CURRENT_DATA_SET management command to ptp4l
    """
    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_CURRENT_DATA_SET)
    return ds


def ptp_parent_ds_get(ctx, instance_id):
    """
    Send GET TLV_PARENT_DATA_SET management command to ptp4l
    """
    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_PARENT_DATA_SET)
    return ds


def ptp_time_properties_ds_get(ctx, instance_id):
    """
    Send GET TLV_TIME_PROPERTIES_DATA_SET management command to ptp4l
    """

    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain,
                            ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_TIME_PROPERTIES_DATA_SET)
    return ds


def ptp_acceptable_masters_get(ctx, instance_id):
    """
    Send GET TLV_ACCEPTABLE_MASTER_TABLE management command to ptp4l
    """

    ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                            ptp4lconst.TLV_ACCEPTABLE_MASTER_TABLE)
    return ds


def ptp_default_ds_get(ctx, instance_id):
    """
    Send GET TLV_DEFAULT_DATA_SET management command to ptp4l
    """

    return ptp4lio.ptp_do_get(ptp4lio.ptp_domain, ptp4lconst.PTP_TGT_PORT_ALL,
                              ptp4lconst.TLV_DEFAULT_DATA_SET)


def ptp_port_ds_get(ctx, interface_id):
    """
    Send GET TLV_PORT_DATA_SET management command to ptp4l
    """
    port_ds = {}

    tgt_port = ptp4lio.get_ptp4l_portid(interface_id)
    if tgt_port == 0:
        return port_ds
    port_ds = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, tgt_port,
                                 ptp4lconst.TLV_PORT_DATA_SET)
    return port_ds


def ptp_port_stats_get(ctx, interface_id):
    """
    Send GET TLV_PORT_STATS_NP management command to ptp4l
    """
    port_stats = {}

    tgt_port = ptp4lio.get_ptp4l_portid(interface_id)
    if tgt_port == 0:
        return port_stats
    port_stats = ptp4lio.ptp_do_get(ptp4lio.ptp_domain, tgt_port,
                                    ptp4lconst.TLV_PORT_STATS_NP)
    return port_stats
