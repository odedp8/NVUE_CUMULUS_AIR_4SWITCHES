# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import re


base = r'^mirror\.session\.(?P<session_id>(\d+|all))\.{}\s*=\s*{}'
re_dir = re.compile(base.format('direction',
                                '(?P<direction>(ingress|egress))'))
re_src = re.compile(base.format('src', '(?P<src>.+)'))
re_dest = re.compile(base.format('dest', '(?P<dest>.+)'))
re_type = re.compile(base.format('type', '(?P<type>(span|erspan|none))'))
re_truncate = re.compile(base.format('truncate',
                                     '(?P<truncate>(true|false))'))
re_truncate_size = re.compile(base.format('truncate_size',
                                          r'(?P<truncate_size>\d+)'))


def _parse_direction(line):
    m = re_dir.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'direction' in gd:
            return (gd['session_id'], gd['direction'])
    return (None, None)


def _parse_src(line):
    m = re_src.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'src' in gd:
            return (gd['session_id'], gd['src'])
    return (None, None)


def _parse_dest(line):
    m = re_dest.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'dest' in gd:
            return (gd['session_id'], gd['dest'])
    return (None, None)


def _parse_type(line):
    m = re_type.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'type' in gd:
            return (gd['session_id'], gd['type'])
    return (None, None)


def _parse_truncate(line):
    m = re_truncate.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'truncate' in gd:
            return (gd['session_id'], gd['truncate'])
    return (None, None)


def _parse_truncate_size(line):
    m = re_truncate_size.match(line)
    if m:
        gd = m.groupdict()
        if 'session_id' in gd and 'truncate_size' in gd:
            return (gd['session_id'], gd['truncate_size'])
    return (None, None)


def parse_port_mirror(conf):
    """
            [session_0]
            session-id=0
            mirror.session.0.direction = ingress
            mirror.session.0.src = swp0
            mirror.session.0.dest = swp1
            mirror.session.0.type = span
    """
    res = []
    curr_session = {}
    for line in map(str.strip, conf.splitlines()):
        # Build the session info and then add it to the response
        # once we know the type
        session_id, direction = _parse_direction(line)
        if direction:
            curr_session['direction'] = direction
            continue

        session_id, src = _parse_src(line)
        if src:
            curr_session['src'] = src
            continue

        session_id, dest = _parse_dest(line)
        if dest:
            curr_session['dest'] = dest
            continue

        session_id, truncate = _parse_truncate(line)
        if truncate:
            curr_session['truncate'] = truncate
            continue

        session_id, truncate_size = _parse_truncate_size(line)
        if truncate_size:
            curr_session['truncate_size'] = truncate_size
            continue

        session_id, session_type = _parse_type(line)
        if session_type:
            # We know the type, add the current session to the
            # response
            curr_session['session-id'] = session_id
            curr_session['type'] = session_type
            res.append(curr_session)
            curr_session = {}
    return res


def mirror_config_get(ctx):
    conf = ctx.fileops.load_file("/etc/port_mirror.conf")
    return parse_port_mirror(conf)
