# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Translate the native format into something close to the public format.  This
# is the abstration layer between the public object model and the
# implementation.

import logging


logger = logging.getLogger(__name__)


def mirror_sessions_get(ctx):
    """
    Get the mirror sessions from the system
    """
    res = {}
    configs = ctx.switchd_v1.getPortMirrorConfig()

    for config in configs:
        session_id = config.get('session-id')
        session_type = config.get('type')
        if session_id and session_type:
            if session_id == 'all' and session_type == 'none':
                logger.info('All sessions disabled in /etc/port_mapping.conf')
                return {}

            if session_id in res:
                session = res[session_id]
            else:
                res[session_id] = session = {}

            session[session_type] = _session = {}

            direction = config.get('direction')
            if direction:
                _session['direction'] = direction

            src = config.get('src')
            if src:
                _session['src-port'] = _translate_src(src)

            dest = config.get('dest')
            if dest:
                _session['destination'] = _translate_dest(dest)

            truncate = config.get('truncate')
            if truncate == 'true':
                _session['truncate'] = {'enable': 'on'}
            elif truncate == 'false':
                _session['truncate'] = {'enable': 'off'}

            truncate_size = config.get('truncate_size')
            if truncate_size:
                try:
                    truncate_size = int(truncate_size)
                    if 'truncate' in _session:
                        _session['truncate']['size'] = truncate_size
                    else:
                        _session['truncate'] = {'size': truncate_size}
                except ValueError:
                    pass

    return res


def _translate_src(src):
    """
    Convert strings of the form 'swp1, swp2' into a dict with each
    interface as a key mapping to an empty dict.
    """
    res = {}
    interfaces = src.split(',')
    for intf in map(str.strip, interfaces):
        if intf:
            res[intf] = {}
    return res


def _translate_dest(dest):
    """
    dest takes the form (swpx | <src-ip> <dst-ip>)
    """
    res = {}
    tokens = dest.strip().split(' ')
    if len(tokens) >= 2:  # Shouldn't be > 2, but handling it here anyway
        res['src-ip'] = {tokens[0]: {}}
        res['dst-ip'] = {tokens[1]: {}}
    elif dest:
        res[dest] = {}
    return res
