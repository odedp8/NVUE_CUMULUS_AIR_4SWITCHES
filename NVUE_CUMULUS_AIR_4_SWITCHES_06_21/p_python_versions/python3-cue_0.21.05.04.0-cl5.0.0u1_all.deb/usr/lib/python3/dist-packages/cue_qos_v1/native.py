# Copyright (C) 2018, 2019 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Show the component's data structures in their native format.  The focus is on
# getting the data into Python.


import json
import re

import logging
logger = logging.getLogger(__name__)

# def mlnx_roce_counters_get(ctx, port):
#    output = ctx.sh.sudo(
#        "/usr/lib/cumulus/mlxcmd",
#        "--json", "roce", "status", "--port", port)
#    data = json.loads(str(output))
#    return data


def load_file_qos_conf_get(ctx):
    output = ctx.fileops.load_file("/etc/cumulus/switchd.d/qos.conf")
    return output


def load_file_qos_features_get(ctx):
    file = "/etc/cumulus/datapath/qos/qos_features.conf"
    output = ctx.fileops.load_file(file)
    return output


def load_file_qos_infra_get(ctx):
    output = ctx.fileops.load_file("/etc/mlx/datapath/qos/qos_infra.conf")
    return output


def intf_roce_counters_get(ctx, port):
    output = ctx.sh.sudo("/usr/lib/cumulus/mlxcmd",
                         "--json", "roce", "counters", "--port", port)
    data = json.loads(str(output))
    roce_counters = {}
    for key in data:
        new_key = re.sub("_", "-", key)
        roce_counters[new_key] = data[key]
    return roce_counters


def intf_roce_status_get(ctx, port):
    output = ctx.sh.sudo("/usr/lib/cumulus/mlxcmd",
                         "--json", "roce", "status", "--port", port)
    data = json.loads(str(output))
    return data


def port_buffers_get(ctx, port):
    output = ctx.sh.sudo("/usr/lib/cumulus/mlxcmd",
                         "--json", "buffers", "port_reserved",
                         "counters", "--port", port)
    data = json.loads(str(output))
    return data


def port_sp_pg_map_get(ctx, port):
    output = ctx.sh.sudo("/usr/lib/cumulus/mlxcmd",
                         "--json", "priority", "priority_group",
                         "--port", port)
    data = json.loads(str(output))
    return data


def roce_system_pools_get(ctx):
    output = ctx.sh.sudo("/usr/lib/cumulus/mlxcmd",
                         "--json", "roce", "status", "--system")
    data = json.loads(str(output))
    return data
