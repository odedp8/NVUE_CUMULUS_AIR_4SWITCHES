# Copyright (C) 2020 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

"""
A module for creating finite-state machines and handling transitions.
"""


from dataclasses import dataclass


@dataclass
class TransitionError(Exception):
    old_state: str
    new_state: str
    allowed_next: set

    def __str__(self):
        error_str = "Invalid transition"
        error_str += f" {repr(self.old_state)} -> {repr(self.new_state)}"
        error_str += f" (Allowed next: {repr(self.allowed_next)})"
        return error_str


def validate_transition(entry_states, transitions, old_state, new_state):
    """
    Validate a transition, raising a `TransitionError` for invalid transitions.

    Args:
        entry_states: A collection of states allowed as transitions from
            terminal/unknown states.
        transitions: A dict mapping state keys to collections of states allowed
            as transitions from that state.
        old_state: The state we're transitioning from.
        new_state: The state we're transitioning to.

    Raises:
        TransitionError if `new_state` is not a valid transition from
            `old_state`.
    """
    is_terminal = old_state not in transitions
    if is_terminal:
        # Terminal/unknown states can only go to entry states.
        allowed_next = entry_states
    else:
        allowed_next = transitions[old_state]
    if new_state not in allowed_next:
        raise TransitionError(old_state, new_state, set(allowed_next))
