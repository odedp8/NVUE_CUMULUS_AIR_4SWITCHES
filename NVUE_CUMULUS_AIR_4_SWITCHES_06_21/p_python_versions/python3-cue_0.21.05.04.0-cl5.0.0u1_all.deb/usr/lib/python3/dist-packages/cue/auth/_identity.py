# Copyright (C) 2021 Cumulus Networks, inc.
#
# All rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt
from flask import Request
import pwd
import grp


class AuthenticatedRequest(Request):
    """
    A request that coverts the UDS connection info embedded in `environ` into a
    format that's more immediately useful.

    Attributes:
        username: The string username of the connected user.
        is_root: Whether or not the connected user is using root privileges.
    """
    def __init__(self, environ, populate_request=True, shallow=False):
        super().__init__(environ, populate_request, shallow)
        # Get the current user's entry from the system's user database.
        pw_user = pwd.getpwuid(environ["cue.peer_uid"])
        self.username = pw_user.pw_name
        # UID 0 is always reserved for root user.
        self.is_root = (pw_user.pw_uid == 0)

        self.user_groups = (
            grp.getgrgid(pw_user.pw_gid).gr_name,
            *(
                group.gr_name
                for group in grp.getgrall()
                if pw_user.pw_name in group.gr_mem
            )
        )
