# Copyright (C) 2020 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement
# available at the following locations:
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt


# Collection of flake8 checks specific to CUE.  Remember to plug the checker
# into setup.cfg, [flake8:local-plugins].


###############################
# pydash_import
###############################
CUE001 = (
    "CUE001 pydash should be imported with " # noqa: CUE001
    "`from pydash import py_`"
)


def pydash_import(physical_line, tokens):
    if "import pydash" in physical_line:  # noqa: CUE001
        return (0, CUE001)


pydash_import.name = "pydash_import"
pydash_import.version = "0.1.0"
